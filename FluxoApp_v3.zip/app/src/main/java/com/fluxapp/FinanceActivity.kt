package com.fluxapp

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FinanceActivity : AppCompatActivity() {

    private lateinit var tvSaudacao: TextView
    private lateinit var tvDataAtual: TextView
    private lateinit var tvLucroHoje: TextView
    private lateinit var tvGanhoHoje: TextView
    private lateinit var tvCustoHoje: TextView
    private lateinit var tvAtualizado: TextView
    private lateinit var tvPercentAutonomia: TextView
    private lateinit var tvKmAutonomia: TextView
    private lateinit var tvLitrosRestantes: TextView
    private lateinit var tvAutonomiaEstimada: TextView
    private lateinit var tvDesdeAbastecimento: TextView
    private lateinit var tvConsumo: TextView
    private lateinit var tvOdometro: TextView
    private lateinit var tvKmHoje: TextView
    private lateinit var tvResumoRodado: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_finance)

        // Inicializar views
        initViews()

        // Configurar dados iniciais
        setupData()

        // Configurar botões (mantida funcionalidade original)
        setupButtons()
    }

    private fun initViews() {
        tvSaudacao = findViewById(R.id.tvSaudacao)
        tvDataAtual = findViewById(R.id.tvDataAtual)
        tvLucroHoje = findViewById(R.id.tvLucroHoje)
        tvGanhoHoje = findViewById(R.id.tvGanhoHoje)
        tvCustoHoje = findViewById(R.id.tvCustoHoje)
        tvAtualizado = findViewById(R.id.tvAtualizado)
        tvPercentAutonomia = findViewById(R.id.tvPercentAutonomia)
        tvKmAutonomia = findViewById(R.id.tvKmAutonomia)
        tvLitrosRestantes = findViewById(R.id.tvLitrosRestantes)
        tvAutonomiaEstimada = findViewById(R.id.tvAutonomiaEstimada)
        tvDesdeAbastecimento = findViewById(R.id.tvDesdeAbastecimento)
        tvConsumo = findViewById(R.id.tvConsumo)
        tvOdometro = findViewById(R.id.tvOdometro)
        tvKmHoje = findViewById(R.id.tvKmHoje)
        tvResumoRodado = findViewById(R.id.tvResumoRodado)

        // Botões do layout original
        findViewById<Button>(R.id.btnVoltar).setOnClickListener { finish() }
    }

    private fun setupData() {
        // Configurar data atual
        val dataFormat = SimpleDateFormat("EEEE, dd 'de' MMMM", Locale("pt", "BR"))
        val dataAtual = dataFormat.format(Date()).replaceFirstChar { it.titlecase() }
        tvDataAtual.text = dataAtual

        // Dados de exemplo (substituir por dados reais da sua lógica)
        tvLucroHoje.text = "R$ 0,00"
        tvGanhoHoje.text = "R$ 0,00"
        tvCustoHoje.text = "-R$ 0,00"
        tvAtualizado.text = "🔄 Atualizado agora"

        // Autonomia
        tvPercentAutonomia.text = "93%"
        tvKmAutonomia.text = "82 km"
        tvLitrosRestantes.text = "2,7 L"
        tvAutonomiaEstimada.text = "~82 km"
        tvDesdeAbastecimento.text = "5,4 km"

        // Métricas
        tvConsumo.text = "30,0"
        tvOdometro.text = "326"
        tvKmHoje.text = "0,0"
        tvResumoRodado.text = "0,0 km rodados hoje · Última atualização: agora"
    }

    private fun setupButtons() {
        // Botões de ação (mantida funcionalidade original)
        val btnEditarCalc: Button = findViewById(R.id.btnEditarCalc)
        val btnNovoAbastecimento: Button = findViewById(R.id.btnNovoAbastecimento)
        val btnRegistrarKm: Button = findViewById(R.id.btnRegistrarKm)
        val cardAbastecimento = findViewById<android.widget.LinearLayout>(R.id.cardAbastecimento)
        val btnSalvarAbastecimento: Button = findViewById(R.id.btnSalvarAbastecimento)

        btnNovoAbastecimento.setOnClickListener {
            cardAbastecimento.visibility = if (cardAbastecimento.visibility == android.view.View.VISIBLE) {
                android.view.View.GONE
            } else {
                android.view.View.VISIBLE
            }
        }

        btnSalvarAbastecimento.setOnClickListener {
            // Lógica para salvar abastecimento (mantida do original)
            android.widget.Toast.makeText(this, "Abastecimento salvo!", android.widget.Toast.LENGTH_SHORT).show()
            cardAbastecimento.visibility = android.view.View.GONE
        }

        // Outros botões podem ter suas funcionalidades implementadas aqui
        btnEditarCalc.setOnClickListener {
            android.widget.Toast.makeText(this, "Editar cálculo de combustível", android.widget.Toast.LENGTH_SHORT).show()
        }

        btnRegistrarKm.setOnClickListener {
            android.widget.Toast.makeText(this, "Registrar hodômetro", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    // Método para atualizar dados dinamicamente (pode ser chamado de outros lugares)
    fun atualizarDadosFinanceiros(lucro: String, ganho: String, custo: String) {
        tvLucroHoje.text = lucro
        tvGanhoHoje.text = ganho
        tvCustoHoje.text = "-$custo"
        tvAtualizado.text = "🔄 Atualizado agora"
    }
}