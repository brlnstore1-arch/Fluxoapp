package com.fluxoapp

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class FinanceActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private lateinit var prefs: android.content.SharedPreferences

    override fun attachBaseContext(base: android.content.Context) {
        super.attachBaseContext(FontHelper.wrap(base))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeSelector.aplicar(this)
        setContentView(R.layout.activity_finance)
        db    = DatabaseHelper(this)
        prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        aplicarTema()
        aplicarTemaGlobal()
        configurarBotoes()
        atualizarResumo()
    }

    override fun onResume() {
        super.onResume()
        atualizarResumo()
    }

    // ── RESUMO FINANCEIRO ─────────────────────────────────────
    private fun atualizarResumo() {
        val corridas   = db.buscarHoje()
        val ganhoHoje  = db.resumo(corridas)["total"] ?: 0f
        val totalKm    = db.resumo(db.buscarTodas())["km_total"] ?: 0f

        // Lê parâmetros da calculadora de lucro
        val consumo    = prefs.getFloat("consumo_km_litro", 35f)   // km por litro
        val precoComb  = prefs.getFloat("preco_combustivel", 6.50f) // R$/litro
        // Usa o maior entre km de corridas e km rastreado pelo GPS (cobre deslocamentos sem corrida)
        val kmCorridas = db.resumo(corridas)["km_total"] ?: 0f
        val kmGps      = KmTrackerService.kmHoje(this)
        val kmHoje     = if (kmGps > kmCorridas) kmGps else kmCorridas
        val custoHoje  = if (consumo > 0) (kmHoje / consumo) * precoComb else 0f
        val lucroHoje  = ganhoHoje - custoHoje

        // Odômetro
        val ultimoKm   = db.ultimoKmOdometro()

        try {
            val p     = prefs
            val green = ThemeHelper.cor("accent_green", p)
            val red   = ThemeHelper.cor("accent_red",   p)
            val accent = ThemeHelper.cor("accent_gold", p)

            // Valores principais
            findViewById<TextView>(R.id.tvGanhoHoje)?.text  = "R$ ${"%.2f".format(ganhoHoje).replace(".", ",")}"
            findViewById<TextView>(R.id.tvCustoHoje)?.text  = "- R$ ${"%.2f".format(custoHoje).replace(".", ",")}"
            // Lucro sem prefixo R$ (layout já tem)
            val lucroStr = "%.2f".format(kotlin.math.abs(lucroHoje)).replace(".", ",")
            findViewById<TextView>(R.id.tvLucroHoje)?.apply {
                text = lucroStr
                setTextColor(if (lucroHoje >= 0) green else red)
            }

            // Km + footer
            val kmStr = "%.1f".format(kmHoje).replace(".", ",")
            val agora = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
            val dataStr = java.text.SimpleDateFormat("EEEE, dd 'de' MMMM", java.util.Locale("pt","BR")).format(java.util.Date())
            val dataCapit = dataStr.replaceFirstChar { it.uppercase() }
            findViewById<TextView>(R.id.tvKmHoje)?.text = "$kmStr km rodados hoje · Última atualização: $agora"
            try { findViewById<TextView>(R.id.tvDataHoje)?.text = "📅 $dataCapit" } catch (_: Throwable) {}
            try { findViewById<TextView>(R.id.tvUltimaAtualizacao)?.text = "🕐 Atualizado às $agora" } catch (_: Throwable) {}

            // Odômetro no chip
            val odoStr = if (ultimoKm > 0) "%.0f".format(ultimoKm) else "—"
            val odoTexto = if (ultimoKm > 0) "$odoStr km" else "—"
            try { findViewById<TextView>(R.id.tvOdometro)?.text = odoTexto } catch (_: Throwable) {}

            // Rodado hoje no chip
            try { findViewById<TextView>(R.id.tvRodadoHoje)?.text = "$kmStr" } catch (_: Throwable) {}

            // km/L configurado
            val consumoAtual = prefs.getFloat("consumo_km_litro", 35f)
            try { findViewById<TextView>(R.id.tvKmL)?.text = "%.1f".format(consumoAtual).replace(".", ",") } catch (_: Throwable) {}

            // ── AUTONOMIA ──
            calcularAutonomia()

        } catch (_: Throwable) {}
    }

    private fun calcularAutonomia() {
        try {
            val consumo  = prefs.getFloat("consumo_km_litro", 35f)
            val abastecs = db.buscarAbastecimentos()
            val accent   = ThemeHelper.cor("accent_gold",  prefs)
            val green    = ThemeHelper.cor("accent_green", prefs)
            val red      = ThemeHelper.cor("accent_red",   prefs)
            val txtW     = ThemeHelper.cor("text_white",   prefs)
            val trackClr = android.graphics.Color.argb(40,
                android.graphics.Color.red(green),
                android.graphics.Color.green(green),
                android.graphics.Color.blue(green))

            if (abastecs.isEmpty() || consumo <= 0f) {
                // Sem dados: círculo vazio
                try {
                    (findViewById<com.fluxoapp.CircularProgressView>(R.id.progressAutonomia))
                        ?.setProgress(0, "—", "sem dados", accent, trackClr, txtW)
                } catch (_: Throwable) {}
                return
            }

            val ultimo       = abastecs.first()
            val litros       = ultimo.litros
            val kmAutonom    = litros * consumo

            // km rodado DESDE o abastecimento (GPS + corridas)
            val tsAbast      = ultimo.timestamp
            val corridasDep  = db.buscarTodas().filter { it.timestamp >= tsAbast }
            val kmPercorrido = corridasDep.sumOf { it.kmTotal.toDouble() }.toFloat()
            val kmRestante   = (kmAutonom - kmPercorrido).coerceAtLeast(0f)
            val litrosRest   = (kmRestante / consumo).coerceAtLeast(0f)
            val pct          = if (kmAutonom > 0f) ((kmRestante / kmAutonom) * 100).toInt().coerceIn(0, 100) else 0

            val corProg = when {
                pct > 50 -> green
                pct > 20 -> android.graphics.Color.parseColor("#FFD740")
                else     -> red
            }
            val trackC = android.graphics.Color.argb(40,
                android.graphics.Color.red(corProg),
                android.graphics.Color.green(corProg),
                android.graphics.Color.blue(corProg))

            // Círculo central
            try {
                (findViewById<com.fluxoapp.CircularProgressView>(R.id.progressAutonomia))
                    ?.setProgress(pct, "$pct%", "${"%.0f".format(kmRestante)} km", corProg, trackC, txtW)
            } catch (_: Throwable) {}

            // Campos lado direito
            try { findViewById<android.widget.TextView>(R.id.tvLitrosRestantes)
                ?.text = "${"%.1f".format(litrosRest)} L" } catch (_: Throwable) {}
            try {
                val pbL = findViewById<android.widget.ProgressBar>(R.id.pbLitros)
                pbL?.progress = pct
                pbL?.progressTintList = android.content.res.ColorStateList.valueOf(corProg)
            } catch (_: Throwable) {}
            try { findViewById<android.widget.TextView>(R.id.tvAutonomiaEst)
                ?.text = "~${"%.0f".format(kmRestante)} km" } catch (_: Throwable) {}
            try { findViewById<android.widget.TextView>(R.id.tvDesdeAbastec)
                ?.text = "${"%.1f".format(kmPercorrido)} km" } catch (_: Throwable) {}

        } catch (_: Throwable) {}
    }

    // ── BOTÕES ────────────────────────────────────────────────
    private fun configurarBotoes() {
        try { findViewById<ImageButton>(R.id.btnVoltar)?.setOnClickListener { finish() } } catch (_: Throwable) {}

        // Abastecimento
        try {
            // Novo abastecimento: botão abre/fecha o card colapsável
            val cardAbast = findViewById<android.view.View>(R.id.cardAbastecimento)
            findViewById<android.widget.Button>(R.id.btnNovoAbastecimento)?.setOnClickListener {
                val visible = cardAbast?.visibility == android.view.View.VISIBLE
                if (visible) {
                    cardAbast?.visibility = android.view.View.GONE
                } else {
                    cardAbast?.visibility = android.view.View.VISIBLE
                    // Animar deslize
                    cardAbast?.alpha = 0f
                    cardAbast?.animate()?.alpha(1f)?.setDuration(250)?.start()
                    // Rolar para mostrar o card
                    try {
                        val sv = findViewById<android.widget.ScrollView>(R.id.scrollFinance)
                        sv?.post { sv.smoothScrollTo(0, cardAbast?.top ?: 0) }
                    } catch (_: Throwable) {}
                }
            }
            findViewById<android.widget.Button>(R.id.btnSalvarAbastecimento)?.setOnClickListener {
                salvarAbastecimento()
                cardAbast?.visibility = android.view.View.GONE
            }
        } catch (_: Throwable) {}

        // Calculadora de lucro — editar parâmetros
        try {
            findViewById<Button>(R.id.btnEditarCalc)?.setOnClickListener {
                mostrarDialogoCalculadora()
            }
        } catch (_: Throwable) {}

        // Corrida manual
        try {
            // btnCorridaManual movido para HistoryActivity
        } catch (_: Throwable) {}

        // Registro de quilometragem
        try {
            findViewById<Button>(R.id.btnRegistrarKm)?.setOnClickListener {
                mostrarDialogoRegistrarKm()
            }
        } catch (_: Throwable) {}
    }

    // ── CALCULADORA DE LUCRO REAL ─────────────────────────────
    private fun mostrarDialogoCalculadora() {
        val p      = prefs
        val accent = ThemeHelper.cor("accent_gold", p)
        val bgCard = ThemeHelper.cor("bg_card", p)
        val txtW   = ThemeHelper.cor("text_white", p)
        val dp     = resources.displayMetrics.density

        val consumo   = prefs.getFloat("consumo_km_litro", 35f)
        val precoComb = prefs.getFloat("preco_combustivel", 6.50f)

        val layout = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setBackgroundColor(bgCard)
            setPadding((16*dp).toInt(), (12*dp).toInt(), (16*dp).toInt(), (12*dp).toInt())
        }

        fun label(txt: String) = android.widget.TextView(this).apply {
            text = txt; textSize = 12f
            setTextColor(ThemeHelper.cor("text_gray", p))
            setPadding(0, (8*dp).toInt(), 0, (2*dp).toInt())
        }
        fun campo(valor: String) = android.widget.EditText(this).apply {
            setText(valor)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            textSize = 16f; setTextColor(txtW)
            setBackgroundColor(Color.TRANSPARENT)
        }

        val etConsumo = campo("%.1f".format(consumo))
        val etPreco   = campo("%.2f".format(precoComb))

        layout.addView(label("Consumo da moto (km/litro)"))
        layout.addView(etConsumo)
        layout.addView(label("Preço do combustível (R$/litro)"))
        layout.addView(etPreco)

        android.app.AlertDialog.Builder(this)
            .setTitle("⛽ Calculadora de Lucro Real")
            .setView(layout)
            .setPositiveButton("Salvar") { _, _ ->
                val c = etConsumo.text.toString().replace(",",".").toFloatOrNull() ?: 35f
                val p2 = etPreco.text.toString().replace(",",".").toFloatOrNull() ?: 6.50f
                prefs.edit()
                    .putFloat("consumo_km_litro", c)
                    .putFloat("preco_combustivel", p2)
                    .apply()
                atualizarResumo()
                FluxoToast.info(this, "Calculadora atualizada")
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ── CORRIDA MANUAL ────────────────────────────────────────
    private fun mostrarDialogoCorridaManual() {
        val p      = prefs
        val bgCard = ThemeHelper.cor("bg_card", p)
        val txtW   = ThemeHelper.cor("text_white", p)
        val txtG   = ThemeHelper.cor("text_gray", p)
        val dp     = resources.displayMetrics.density

        val scroll = android.widget.ScrollView(this)
        val layout = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setBackgroundColor(bgCard)
            setPadding((16*dp).toInt(), (12*dp).toInt(), (16*dp).toInt(), (16*dp).toInt())
        }
        scroll.addView(layout)

        fun label(txt: String) = android.widget.TextView(this).apply {
            text = txt; textSize = 12f; setTextColor(txtG)
            setPadding(0, (10*dp).toInt(), 0, (2*dp).toInt())
        }
        fun campo(hint: String, tipo: Int = android.text.InputType.TYPE_CLASS_TEXT) =
            android.widget.EditText(this).apply {
                this.hint = hint; inputType = tipo
                textSize = 14f; setTextColor(txtW)
                setHintTextColor(txtG)
                setBackgroundColor(Color.TRANSPARENT)
            }

        val etValor   = campo("Ex: 4.80", android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val etKm      = campo("Ex: 2.50", android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val etOrigem  = campo("Endereço de origem")
        val etDestino = campo("Endereço de destino")
        val etPag     = campo("Dinheiro / PIX / Cartão")

        // Hora e data com valores padrão
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        val sdfD = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val etHora = campo(sdf.format(Date()))
        val etData = campo(sdfD.format(Date()))
        etHora.setText(sdf.format(Date()))
        etData.setText(sdfD.format(Date()))

        layout.addView(label("Valor (R$) *"))
        layout.addView(etValor)
        layout.addView(label("Distância (km)"))
        layout.addView(etKm)
        layout.addView(label("Forma de pagamento"))
        layout.addView(etPag)
        layout.addView(label("Origem"))
        layout.addView(etOrigem)
        layout.addView(label("Destino"))
        layout.addView(etDestino)
        layout.addView(label("Hora"))
        layout.addView(etHora)
        layout.addView(label("Data (dd/MM/yyyy)"))
        layout.addView(etData)

        android.app.AlertDialog.Builder(this)
            .setTitle("➕ Adicionar Corrida Manual")
            .setView(scroll)
            .setPositiveButton("Salvar") { _, _ ->
                val valor = etValor.text.toString().replace(",",".").toFloatOrNull()
                if (valor == null || valor <= 0f) {
                    FluxoToast.erro(this, "Valor inválido")
                    return@setPositiveButton
                }
                val km    = etKm.text.toString().replace(",",".").toFloatOrNull() ?: 0f
                val gkm   = if (km > 0f) valor / km else 0f
                val min   = prefs.getFloat("minimo_km", 1.20f)
                val dataStr = etData.text.toString().ifBlank { sdfD.format(Date()) }
                val horaStr = etHora.text.toString().ifBlank { sdf.format(Date()) }

                // Converter data+hora em timestamp real
                val ts = try {
                    SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
                        .parse("$dataStr $horaStr")?.time ?: System.currentTimeMillis()
                } catch (_: Throwable) { System.currentTimeMillis() }
                val cal = Calendar.getInstance().apply { timeInMillis = ts }
                val mes = "%02d/%04d".format(cal.get(Calendar.MONTH)+1, cal.get(Calendar.YEAR))
                val ano = "%04d".format(cal.get(Calendar.YEAR))

                db.inserirCorridaManual(Corrida(
                    valor = valor, kmTotal = km, ganhoPorKm = gkm,
                    valeAPena = gkm >= min,
                    timestamp = ts, data = dataStr, hora = horaStr,
                    mes = mes, ano = ano,
                    origem = etOrigem.text.toString(),
                    destino = etDestino.text.toString(),
                    formaPagamento = etPag.text.toString()
                ))
                atualizarResumo()
                // Atualizar widget flutuante
                try { startService(android.content.Intent(this, FloatingEarningsService::class.java)
                    .apply { action = "ATUALIZAR" }) } catch (_: Throwable) {}
                FluxoToast.sucesso(this, "Corrida adicionada: R$${"%.2f".format(valor)}")
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ── REGISTRO DE QUILOMETRAGEM ─────────────────────────────
    private fun mostrarDialogoRegistrarKm() {
        val p      = prefs
        val bgCard = ThemeHelper.cor("bg_card", p)
        val txtW   = ThemeHelper.cor("text_white", p)
        val txtG   = ThemeHelper.cor("text_gray", p)
        val dp     = resources.displayMetrics.density

        val ultimoKm = db.ultimoKmOdometro()

        val layout = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setBackgroundColor(bgCard)
            setPadding((16*dp).toInt(), (12*dp).toInt(), (16*dp).toInt(), (16*dp).toInt())
        }

        if (ultimoKm > 0f) {
            layout.addView(android.widget.TextView(this).apply {
                text = "Último registro: ${"%.0f".format(ultimoKm)} km"
                textSize = 12f; setTextColor(txtG)
                setPadding(0, 0, 0, (8*dp).toInt())
            })
        }

        val etKm = android.widget.EditText(this).apply {
            hint = "Odômetro atual (km)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            textSize = 18f; setTextColor(txtW); setHintTextColor(txtG)
            setBackgroundColor(Color.TRANSPARENT)
        }
        val etObs = android.widget.EditText(this).apply {
            hint = "Observação (opcional)"
            textSize = 13f; setTextColor(txtW); setHintTextColor(txtG)
            setBackgroundColor(Color.TRANSPARENT)
        }

        layout.addView(android.widget.TextView(this).apply {
            text = "Leitura do odômetro (km)"; textSize = 12f; setTextColor(txtG)
            setPadding(0, 0, 0, (4*dp).toInt())
        })
        layout.addView(etKm)
        layout.addView(android.widget.TextView(this).apply {
            text = "Observação"; textSize = 12f; setTextColor(txtG)
            setPadding(0, (12*dp).toInt(), 0, (4*dp).toInt())
        })
        layout.addView(etObs)

        // Mostrar histórico de registros
        val registros = db.buscarKm()
        if (registros.isNotEmpty()) {
            layout.addView(android.widget.TextView(this).apply {
                text = "\nÚltimos registros:"; textSize = 12f; setTextColor(txtG)
            })
            registros.take(5).forEach { (_, km, data) ->
                layout.addView(android.widget.TextView(this).apply {
                    text = "  $data → ${"%.0f".format(km)} km"
                    textSize = 12f; setTextColor(txtW)
                })
            }
        }

        android.app.AlertDialog.Builder(this)
            .setTitle("🏍️ Registrar Quilometragem")
            .setView(layout)
            .setPositiveButton("Registrar") { _, _ ->
                val km = etKm.text.toString().replace(",",".").toFloatOrNull()
                if (km == null || km <= 0f) {
                    FluxoToast.aviso(this, "Informe o km do odômetro")
                    return@setPositiveButton
                }
                db.registrarKm(km, etObs.text.toString())
                atualizarResumo()
                FluxoToast.sucesso(this, "Km registrado: ${"%.0f".format(km)} km")
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ── ABASTECIMENTO ─────────────────────────────────────────
    private fun salvarAbastecimento() {
        try {
            val litros = findViewById<EditText>(R.id.etLitros)?.text.toString()
                .replace(",",".").toFloatOrNull() ?: 0f
            val valor  = findViewById<EditText>(R.id.etValorAbastecimento)?.text.toString()
                .replace(",",".").toFloatOrNull() ?: 0f
            val km     = findViewById<EditText>(R.id.etKmAtual)?.text.toString()
                .replace(",",".").toFloatOrNull() ?: 0f

            if (litros <= 0f || valor <= 0f) {
                FluxoToast.aviso(this, "Informe litros e valor")
                return
            }
            val preco = valor / litros
            db.inserirAbastecimento(Abastecimento(
                litros = litros, valorTotal = valor,
                precoPorLitro = preco, kmAtual = km
            ))
            // Registrar km automaticamente se informado
            if (km > 0f) db.registrarKm(km, "Abastecimento")

            findViewById<EditText>(R.id.etLitros)?.setText("")
            findViewById<EditText>(R.id.etValorAbastecimento)?.setText("")
            findViewById<EditText>(R.id.etKmAtual)?.setText("")
            atualizarResumo()
            FluxoToast.sucesso(this, "⛽ ${litros}L · R$${"%.2f".format(valor)} · R$${"%.2f".format(preco)}/L")
        } catch (e: Throwable) {
            FluxoToast.erro(this, "Erro ao salvar")
        }
    }

    // ── TEMA ─────────────────────────────────────────────────
    private fun aplicarTema() {
        val p      = prefs
        val accent = ThemeHelper.cor("accent_gold",  p)
        val bg     = ThemeHelper.cor("bg_dark",      p)
        val bgCard = ThemeHelper.cor("bg_card",      p)
        val txtW   = ThemeHelper.cor("text_white",   p)
        val txtG   = ThemeHelper.cor("text_gray",    p)
        val green  = ThemeHelper.cor("accent_green", p)
        val red    = ThemeHelper.cor("accent_red",   p)
        val dp     = resources.displayMetrics.density

        try { findViewById<android.view.View>(R.id.scrollFinance)?.setBackgroundColor(bg) } catch (_: Throwable) {}
        try { (this as? android.app.Activity)?.window?.decorView?.setBackgroundColor(bg) } catch (_: Throwable) {}
        try { findViewById<android.widget.ImageButton>(R.id.btnVoltar)?.setColorFilter(accent) } catch (_: Throwable) {}

        // Textos principais
        try { findViewById<TextView>(R.id.tvTituloFinance)?.setTextColor(txtW)  } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvGanhoHoje)?.setTextColor(green)     } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvCustoHoje)?.setTextColor(red)       } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvLucroHoje)?.setTextColor(accent)    } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvKmHoje)?.setTextColor(txtG)         } catch (_: Throwable) {}

        // Chips stats
        for (id in listOf(R.id.tvOdometro, R.id.tvRodadoHoje, R.id.tvKmL)) {
            try { findViewById<TextView>(id)?.setTextColor(accent) } catch (_: Throwable) {}
        }

        // Botões
        try { findViewById<android.widget.Button>(R.id.btnSalvarAbastecimento)?.apply {
            background = GradientDrawable().apply { setColor(accent); cornerRadius = 14f * dp }
            setTextColor(bg)
        }} catch (_: Throwable) {}
        try { findViewById<android.widget.Button>(R.id.btnNovoAbastecimento)?.apply {
            background = GradientDrawable().apply { setColor(accent); cornerRadius = 14f * dp }
            setTextColor(bg)
        }} catch (_: Throwable) {}
        try { findViewById<android.widget.Button>(R.id.btnRegistrarKm)?.apply {
            background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT); cornerRadius = 14f * dp
                setStroke((1.5f * dp).toInt(), accent)
            }
            setTextColor(accent)
        }} catch (_: Throwable) {}
    }
}
