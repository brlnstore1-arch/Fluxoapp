package com.fluxoapp

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View

/**
 * CircularProgressView — FluxoApp
 * Anel de progresso circular estilo banking app.
 * Configurável via setProgress(pct, label, sublabel, accentColor)
 */
class CircularProgressView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var progress    = 0f      // 0..100
    private var labelTop    = ""      // ex: "93%"
    private var labelBottom = ""      // ex: "82 km"
    private var accentColor = Color.parseColor("#00E676")
    private var trackColor  = Color.argb(40, 0, 230, 118)
    private var textColor   = Color.WHITE

    private val paintTrack = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val paintArc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val paintTextTop = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val paintTextBot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
    }

    fun setProgress(pct: Int, top: String, bottom: String, accent: Int, track: Int, txtColor: Int) {
        progress    = pct.coerceIn(0, 100).toFloat()
        labelTop    = top
        labelBottom = bottom
        accentColor = accent
        trackColor  = track
        textColor   = txtColor
        paintArc.color   = accent
        paintTrack.color = track
        paintTextTop.color = txtColor
        paintTextBot.color = Color.argb(160,
            Color.red(txtColor), Color.green(txtColor), Color.blue(txtColor))
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val stroke = w * 0.10f
        val half   = stroke / 2f
        val oval   = RectF(half, half, w - half, h - half)

        paintTrack.strokeWidth = stroke
        paintArc.strokeWidth   = stroke

        // Track (fundo do anel)
        canvas.drawArc(oval, -220f, 260f, false, paintTrack)

        // Arco de progresso
        val sweep = (progress / 100f) * 260f
        canvas.drawArc(oval, -220f, sweep, false, paintArc)

        // Texto central
        val cx = w / 2f
        val cy = h / 2f
        paintTextTop.textSize = w * 0.20f
        paintTextBot.textSize = w * 0.12f

        val fm = paintTextTop.fontMetrics
        val textH = fm.descent - fm.ascent
        canvas.drawText(labelTop, cx, cy - textH * 0.05f, paintTextTop)
        canvas.drawText(labelBottom, cx, cy + textH * 0.75f, paintTextBot)
    }
}
