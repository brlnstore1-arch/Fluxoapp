
package com.fluxoapp.services

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.util.Log

class AccessibilityServiceFluxo : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val text = event.text.toString()

        if (text.contains("R$")) {
            Log.d("FLUXO", "Possível corrida detectada: $text")
        }
    }

    override fun onInterrupt() {}
}
