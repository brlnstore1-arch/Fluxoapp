
package com.fluxoapp.services

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.TextView

class FloatingService : Service() {

    lateinit var windowManager: WindowManager
    lateinit var view: View

    override fun onCreate() {
        super.onCreate()

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        view = LayoutInflater.from(this).inflate(android.R.layout.simple_list_item_1, null)
        val text = view.findViewById<TextView>(android.R.id.text1)
        text.text = "Fluxo R$ 0"

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )

        windowManager.addView(view, params)
    }

    override fun onDestroy() {
        super.onDestroy()
        windowManager.removeView(view)
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
