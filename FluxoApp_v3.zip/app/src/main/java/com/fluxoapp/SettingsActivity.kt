package com.fluxoapp

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import android.graphics.drawable.GradientDrawable
import android.graphics.Color
import android.view.View
import java.util.*

class SettingsActivity : AppCompatActivity() {

    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var db: DatabaseHelper
    private var tamanhoFonteSelecionado = 1 // 0=pequeno, 1=médio, 2=grande

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeSelector.aplicar(this)
        setContentView(R.layout.activity_settings)

        prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        db = DatabaseHelper(this)

        // Carregar tamanho da fonte salvo
        tamanhoFonteSelecionado = prefs.getInt("tamanho_fonte", 1)

        configurarHeader()
        configurarTemaVisual()
        configurarTamanhoFonte()
        configurarDeteccao()
        configurarAutomacoes()
        configurarSonsAlertas()
        configurarMetas()
        configurarBotaoSalvar()

        aplicarTemaGlobal()
    }

    // ══════════════════════════════════════════════════════════════════════
    // HEADER
    // ══════════════════════════════════════════════════════════════════════
    private fun configurarHeader() {
        findViewById<ImageButton>(R.id.btnVoltar)?.setOnClickListener {
            finish()
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    // TEMA VISUAL COM BORDAS GROSSAS
    // ══════════════════════════════════════════════════════════════════════
    private fun configurarTemaVisual() {
        val temaAtual = prefs.getString("tema_estilo", "gold") ?: "gold"
        val modoAtual = prefs.getInt("modo_tema", -1)
        val dp = resources.displayMetrics.density

        // Cards de tema com bordas
        val cardAzul = findViewById<FrameLayout>(R.id.cardTemaAzul)
        val cardGold = findViewById<FrameLayout>(R.id.cardTemaGold)

        atualizarBordaTemaCards(temaAtual, dp)

        cardAzul?.setOnClickListener {
            prefs.edit().putString("tema_estilo", "azul").apply()
            notificarTemaAtualizado()
            atualizarBordaTemaCards("azul", dp)
            recreate()
        }

        cardGold?.setOnClickListener {
            prefs.edit().putString("tema_estilo", "gold").apply()
            notificarTemaAtualizado()
            atualizarBordaTemaCards("gold", dp)
            recreate()
        }

        // Botões de modo com cores do tema
        val btnDia = findViewById<Button>(R.id.btnModoDia)
        val btnNoite = findViewById<Button>(R.id.btnModoNoite)
        val btnAuto = findViewById<Button>(R.id.btnModoAuto)

        atualizarBotoesModoPorModo(modoAtual, btnDia, btnNoite, btnAuto, dp)

        btnDia?.setOnClickListener {
            prefs.edit().putInt("modo_tema", 0).apply()
            notificarTemaAtualizado()
            atualizarBotoesModoPorModo(0, btnDia, btnNoite, btnAuto, dp)
            recreate()
        }

        btnNoite?.setOnClickListener {
            prefs.edit().putInt("modo_tema", 1).apply()
            notificarTemaAtualizado()
            atualizarBotoesModoPorModo(1, btnDia, btnNoite, btnAuto, dp)
            recreate()
        }

        btnAuto?.setOnClickListener {
            prefs.edit().putInt("modo_tema", -1).apply()
            notificarTemaAtualizado()
            atualizarBotoesModoPorModo(-1, btnDia, btnNoite, btnAuto, dp)
            recreate()
        }
    }

    private fun atualizarBordaTemaCards(tema: String, dp: Float) {
        val accentColor = ThemeHelper.cor("accent_gold", prefs)
        val borderAzul = findViewById<View>(R.id.bordaTemaAzul)
        val cardAzul = findViewById<View>(R.id.cardTemaAzul)
        val cardGold = findViewById<View>(R.id.cardTemaGold)

        // Remover bordas de ambos
        cardAzul?.background = GradientDrawable().apply { setColor(Color.TRANSPARENT) }
        cardGold?.background = GradientDrawable().apply { setColor(Color.TRANSPARENT) }

        // Adicionar borda grossa ao tema selecionado
        if (tema == "azul") {
            cardAzul?.background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                cornerRadius = 16f * dp
                setStroke((4f * dp).toInt(), accentColor)
            }
        } else {
            cardGold?.background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                cornerRadius = 16f * dp
                setStroke((4f * dp).toInt(), accentColor)
            }
        }
    }

    private fun atualizarBotoesModoPorModo(
        modo: Int,
        btnDia: Button?,
        btnNoite: Button?,
        btnAuto: Button?,
        dp: Float
    ) {
        val accentColor = ThemeHelper.cor("accent_gold", prefs)
        val bgCard = ThemeHelper.cor("bg_card", prefs)

        fun criarBotaoSelecionado(): GradientDrawable {
            return GradientDrawable().apply {
                setColor(accentColor)
                cornerRadius = 12f * dp
            }
        }

        fun criarBotaoNaoSelecionado(): GradientDrawable {
            return GradientDrawable().apply {
                setColor(bgCard)
                cornerRadius = 12f * dp
            }
        }

        when (modo) {
            0 -> {
                btnDia?.background = criarBotaoSelecionado()
                btnDia?.setTextColor(Color.BLACK)
                btnNoite?.background = criarBotaoNaoSelecionado()
                btnNoite?.setTextColor(ThemeHelper.cor("text_white", prefs).toInt())
                btnAuto?.background = criarBotaoNaoSelecionado()
                btnAuto?.setTextColor(ThemeHelper.cor("text_white", prefs).toInt())
            }
            1 -> {
                btnDia?.background = criarBotaoNaoSelecionado()
                btnDia?.setTextColor(ThemeHelper.cor("text_white", prefs).toInt())
                btnNoite?.background = criarBotaoSelecionado()
                btnNoite?.setTextColor(Color.BLACK)
                btnAuto?.background = criarBotaoNaoSelecionado()
                btnAuto?.setTextColor(ThemeHelper.cor("text_white", prefs).toInt())
            }
            else -> {
                btnDia?.background = criarBotaoNaoSelecionado()
                btnDia?.setTextColor(ThemeHelper.cor("text_white", prefs).toInt())
                btnNoite?.background = criarBotaoNaoSelecionado()
                btnNoite?.setTextColor(ThemeHelper.cor("text_white", prefs).toInt())
                btnAuto?.background = criarBotaoSelecionado()
                btnAuto?.setTextColor(Color.BLACK)
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    // TAMANHO DE FONTE COM ALTERNÂNCIA IMEDIATA
    // ══════════════════════════════════════════════════════════════════════
    private fun configurarTamanhoFonte() {
        val btnPequeno = findViewById<Button>(R.id.btnFontePequeno)
        val btnMedio = findViewById<Button>(R.id.btnFonteMedio)
        val btnGrande = findViewById<Button>(R.id.btnFonteGrande)
        val dp = resources.displayMetrics.density
        val accentColor = ThemeHelper.cor("accent_gold", prefs)
        val bgCard = ThemeHelper.cor("bg_card", prefs)

        fun criarBotaoSelecionado(): GradientDrawable {
            return GradientDrawable().apply {
                setColor(accentColor)
                cornerRadius = 10f * dp
            }
        }

        fun criarBotaoNaoSelecionado(): GradientDrawable {
            return GradientDrawable().apply {
                setColor(bgCard)
                cornerRadius = 10f * dp
            }
        }

        fun atualizarBotoesFont() {
            when (tamanhoFonteSelecionado) {
                0 -> {
                    btnPequeno?.background = criarBotaoSelecionado()
                    btnPequeno?.setTextColor(Color.BLACK)
                    btnMedio?.background = criarBotaoNaoSelecionado()
                    btnMedio?.setTextColor(ThemeHelper.cor("text_white", prefs).toInt())
                    btnGrande?.background = criarBotaoNaoSelecionado()
                    btnGrande?.setTextColor(ThemeHelper.cor("text_white", prefs).toInt())
                }
                1 -> {
                    btnPequeno?.background = criarBotaoNaoSelecionado()
                    btnPequeno?.setTextColor(ThemeHelper.cor("text_white", prefs).toInt())
                    btnMedio?.background = criarBotaoSelecionado()
                    btnMedio?.setTextColor(Color.BLACK)
                    btnGrande?.background = criarBotaoNaoSelecionado()
                    btnGrande?.setTextColor(ThemeHelper.cor("text_white", prefs).toInt())
                }
                2 -> {
                    btnPequeno?.background = criarBotaoNaoSelecionado()
                    btnPequeno?.setTextColor(ThemeHelper.cor("text_white", prefs).toInt())
                    btnMedio?.background = criarBotaoNaoSelecionado()
                    btnMedio?.setTextColor(ThemeHelper.cor("text_white", prefs).toInt())
                    btnGrande?.background = criarBotaoSelecionado()
                    btnGrande?.setTextColor(Color.BLACK)
                }
            }
        }

        // Atualizar initial
        atualizarBotoesFont()

        btnPequeno?.setOnClickListener {
            tamanhoFonteSelecionado = 0
            prefs.edit().putInt("tamanho_fonte", 0).apply()
            atualizarBotoesFont()
            // Aplicar imediatamente sem reiniciar
            notificarTamanhoFonteAlterado()
        }

        btnMedio?.setOnClickListener {
            tamanhoFonteSelecionado = 1
            prefs.edit().putInt("tamanho_fonte", 1).apply()
            atualizarBotoesFont()
            notificarTamanhoFonteAlterado()
        }

        btnGrande?.setOnClickListener {
            tamanhoFonteSelecionado = 2
            prefs.edit().putInt("tamanho_fonte", 2).apply()
            atualizarBotoesFont()
            notificarTamanhoFonteAlterado()
        }
    }

    private fun notificarTamanhoFonteAlterado() {
        // Enviar broadcast para HistoryActivity e outras atividades atualizarem
        try {
            sendBroadcast(Intent(HistoryActivity.ACTION_FONTE_ALTERADA))
        } catch (_: Throwable) {}
    }

    // ══════════════════════════════════════════════════════════════════════
    // DETECÇÃO
    // ══════════════════════════════════════════════════════════════════════
    private fun configurarDeteccao() {
        val etMinimoKm = findViewById<EditText>(R.id.etMinimoKm)
        etMinimoKm?.setText("%.2f".format(prefs.getFloat("minimo_km", 1.20f)))

        val etMinimoValor = findViewById<EditText>(R.id.etMinimoValor)
        etMinimoValor?.setText("%.2f".format(prefs.getFloat("minimo_valor", 0f)))

        val etTempo = findViewById<EditText>(R.id.etTempoAceitar)
        etTempo?.setText((prefs.getInt("tempo_auto_aceitar", 3) - 1).toString())
    }

    // ══════════════════════════════════════════════════════════════════════
    // AUTOMAÇÕES
    // ══════════════════════════════════════════════════════════════════════
    private fun configurarAutomacoes() {
        val switchAutoAceitar = findViewById<Switch>(R.id.switchAutoAceitar)
        switchAutoAceitar?.isChecked = prefs.getBoolean("auto_aceitar", false)

        val switchAutoRecusar = findViewById<Switch>(R.id.switchAutoRecusar)
        switchAutoRecusar?.isChecked = prefs.getBoolean("auto_recusar", false)
    }

    // ══════════════════════════════════════════════════════════════════════
    // SONS E ALERTAS
    // ══════════════════════════════════════════════════════════════════════
    private fun configurarSonsAlertas() {
        val switchSomAceitar = findViewById<Switch>(R.id.switchSomAceitar)
        switchSomAceitar?.isChecked = prefs.getBoolean("som_aceitar", true)

        val switchSomRecusar = findViewById<Switch>(R.id.switchSomRecusar)
        switchSomRecusar?.isChecked = prefs.getBoolean("som_recusar", false)

        val switchSomMeta = findViewById<Switch>(R.id.switchSomMeta)
        switchSomMeta?.isChecked = prefs.getBoolean("som_meta", true)
    }

    // ══════════════════════════════════════════════════════════════════════
    // METAS E PROGRESSO
    // ══════════════════════════════════════════════════════════════════════
    private fun configurarMetas() {
        val etMetaDiaria = findViewById<EditText>(R.id.etMetaDiaria)
        val meta = prefs.getFloat("meta_diaria", 0f)
        etMetaDiaria?.setText(if (meta > 0) "%.2f".format(meta) else "")

        val etMetaSemanal = findViewById<EditText>(R.id.etMetaSemanal)
        val metaSem = prefs.getFloat("meta_semanal", 0f)
        etMetaSemanal?.setText(if (metaSem > 0) "%.2f".format(metaSem) else "")

        val switchNotifMeta = findViewById<Switch>(R.id.switchNotifMeta)
        switchNotifMeta?.isChecked = prefs.getBoolean("notif_meta", true)

        atualizarProgressoMetas()
    }

    private fun atualizarProgressoMetas() {
        try {
            val corridas = db.buscarHoje()
            val resumo = db.resumo(corridas)
            val totalHoje = (resumo["total"] as? Number)?.toFloat() ?: 0f
            val metaDiaria = prefs.getFloat("meta_diaria", 0f)

            val tvProgressoHoje = findViewById<TextView>(R.id.tvProgressoHoje)
            tvProgressoHoje?.text = "Progresso hoje: R$ ${"%,.2f".format(totalHoje)}"

            val progressBar = findViewById<ProgressBar>(R.id.progressMetaDia)
            if (metaDiaria > 0) {
                val percent = (totalHoje / metaDiaria * 100).toInt().coerceIn(0, 100)
                progressBar?.progress = percent
            }

            val tvProgressoSemana = findViewById<TextView>(R.id.tvProgressoSemana)
            tvProgressoSemana?.text = "Progresso esta semana: R$ 0,00"

            val progressSemana = findViewById<ProgressBar>(R.id.progressMetaSemana)
            progressSemana?.progress = 0
        } catch (e: Exception) {
            android.util.Log.e("Settings", "Erro ao atualizar progresso", e)
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    // BOTÃO SALVAR COM COR DO TEMA
    // ══════════════════════════════════════════════════════════════════════
    private fun configurarBotaoSalvar() {
        findViewById<Button>(R.id.btnSalvarConfig)?.setOnClickListener {
            salvarConfigurações()
        }
    }

    private fun salvarConfigurações() {
        try {
            val etMinimoKm = findViewById<EditText>(R.id.etMinimoKm)
            val etMinimoValor = findViewById<EditText>(R.id.etMinimoValor)
            val etTempo = findViewById<EditText>(R.id.etTempoAceitar)
            val etMetaDiaria = findViewById<EditText>(R.id.etMetaDiaria)
            val etMetaSemanal = findViewById<EditText>(R.id.etMetaSemanal)
            val switchAutoAceitar = findViewById<Switch>(R.id.switchAutoAceitar)
            val switchAutoRecusar = findViewById<Switch>(R.id.switchAutoRecusar)
            val switchSomAceitar = findViewById<Switch>(R.id.switchSomAceitar)
            val switchSomRecusar = findViewById<Switch>(R.id.switchSomRecusar)
            val switchSomMeta = findViewById<Switch>(R.id.switchSomMeta)
            val switchNotifMeta = findViewById<Switch>(R.id.switchNotifMeta)

            val minKm = etMinimoKm?.text.toString().replace(",", ".").toFloatOrNull() ?: 1.20f
            val minValor = etMinimoValor?.text.toString().replace(",", ".").toFloatOrNull() ?: 0f
            val tempo = etTempo?.text.toString().toIntOrNull() ?: 2
            val metaDiaria = etMetaDiaria?.text.toString().replace(",", ".").toFloatOrNull() ?: 0f
            val metaSemanal = etMetaSemanal?.text.toString().replace(",", ".").toFloatOrNull() ?: 0f

            prefs.edit().apply {
                putFloat("minimo_km", minKm)
                putFloat("minimo_valor", minValor)
                putInt("tempo_auto_aceitar", tempo + 1)
                putBoolean("auto_aceitar", switchAutoAceitar?.isChecked ?: false)
                putBoolean("auto_recusar", switchAutoRecusar?.isChecked ?: false)
                putBoolean("som_aceitar", switchSomAceitar?.isChecked ?: true)
                putBoolean("som_recusar", switchSomRecusar?.isChecked ?: false)
                putBoolean("som_meta", switchSomMeta?.isChecked ?: true)
                putFloat("meta_diaria", metaDiaria)
                putFloat("meta_semanal", metaSemanal)
                putBoolean("notif_meta", switchNotifMeta?.isChecked ?: true)
            }.apply()

            Toast.makeText(this, "✅ Configurações salvas", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "❌ Erro ao salvar", Toast.LENGTH_SHORT).show()
            android.util.Log.e("Settings", "Erro ao salvar", e)
        }
    }

    private fun notificarTemaAtualizado() {
        try {
            sendBroadcast(Intent(FloatingEarningsService.ACTION_TEMA))
        } catch (_: Throwable) {}
        try {
            iniciarServicoSeguro(Intent(this, FloatingEarningsService::class.java).apply {
                action = FloatingEarningsService.ACTION_TEMA
            })
        } catch (_: Throwable) {}
    }

    private fun iniciarServicoSeguro(intent: Intent) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
        } catch (e: Exception) {
            android.util.Log.e("FluxoApp", "Erro ao iniciar serviço", e)
        }
    }

    private fun aplicarTemaGlobal() {
        val dp = resources.displayMetrics.density
        val bgDark = ThemeHelper.cor("bg_dark", prefs)
        val accentColor = ThemeHelper.cor("accent_gold", prefs)
        val borderColor = ThemeHelper.cor("border", prefs)

        // Adicionar bordas grossas a todos os cards principais
        val cardsParaBorda = listOf(
            R.id.layoutTamanhoFonte,
            R.id.layoutDeteccao,
            R.id.layoutAutomacoes,
            R.id.layoutSonsAlertas,
            R.id.layoutMetas
        )

        for (cardId in cardsParaBorda) {
            try {
                val card = findViewById<View>(cardId)
                if (card != null) {
                    card.background = GradientDrawable().apply {
                        setColor(ThemeHelper.cor("bg_card", prefs).toInt())
                        cornerRadius = 12f * dp
                        setStroke((3f * dp).toInt(), accentColor.toInt())
                    }
                }
            } catch (_: Throwable) {}
        }

        // Botão salvar com cor do tema
        try {
            val btnSalvar = findViewById<Button>(R.id.btnSalvarConfig)
            btnSalvar?.background = GradientDrawable().apply {
                setColor(accentColor.toInt())
                cornerRadius = 14f * dp
            }
            btnSalvar?.setTextColor(Color.BLACK)
        } catch (_: Throwable) {}
    }
}
