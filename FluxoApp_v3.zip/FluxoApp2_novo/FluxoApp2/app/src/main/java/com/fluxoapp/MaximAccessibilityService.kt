package com.fluxoapp

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * MaximAccessibilityService — FluxoApp v3
 *
 * Fluxo:
 *   IDLE
 *     → detecta botões Aceitar+Recusar E valor em reais  → AGUARDANDO_ACEITE
 *       → detecta "a caminho" / desaparecimento dos botões → EM_ANDAMENTO
 *         → detecta "finalizar pedido"                   → FINALIZANDO
 *           → detecta toast/tela de conclusão            → salva → IDLE
 *           OU timeout 45s                               → salva → IDLE
 *         OU timeout EM_ANDAMENTO 12min                  → salva → IDLE
 *     Qualquer estado: "pedido cancelado"                → descarta → IDLE
 */
class MaximAccessibilityService : AccessibilityService() {

    // ── Máquina de estados ─────────────────────────────────────────────────
    private enum class Estado { IDLE, AGUARDANDO_ACEITE, EM_ANDAMENTO, FINALIZANDO }
    private var estado = Estado.IDLE

    // ── Dados da corrida ───────────────────────────────────────────────────
    private var corridaValor      = 0f
    private var corridaKm         = 0f
    private var corridaGanhoPorKm = 0f
    private var corridaValeAPena  = false
    private var corridaOrigem     = ""
    private var corridaDestino    = ""
    private var corridaCliente    = ""
    private var corridaForma      = ""
    private var corridaHoraInicio = ""
    private var finalValor        = 0f
    private var finalKm           = 0f
    private var finalTempo        = ""

    // ── Controle ───────────────────────────────────────────────────────────
    private val handler = Handler(Looper.getMainLooper())
    private var ultimoEventoTelaMs = 0L   // debounce APENAS para processarTela
    private var timeoutRunnable: Runnable? = null

    companion object {
        private const val PKG_TAXSEE        = "com.taxsee.driver"
        private const val DEBOUNCE_TELA_MS  = 350L    // debounce para TYPE_WINDOW_*
        private const val TIMEOUT_FINALIZANDO_MS  = 45_000L   // 45s sem toast → salva
        private const val TIMEOUT_EM_ANDAMENTO_MS = 720_000L  // 12min preso em andamento → salva
    }

    // ══════════════════════════════════════════════════════════════════════
    // PONTO DE ENTRADA
    // ══════════════════════════════════════════════════════════════════════
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        if (event.packageName?.toString() != PKG_TAXSEE) return

        val tipo = event.eventType
        val textoEvento = event.text?.joinToString(" ")?.trim()?.lowercase(Locale.getDefault()) ?: ""

        // ── Toasts e anúncios: sem debounce, processados SEMPRE ──
        if (tipo == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED ||
            tipo == AccessibilityEvent.TYPE_ANNOUNCEMENT) {
            if (textoEvento.isNotBlank()) processarToast(textoEvento)
            return
        }

        // ── Mudanças de janela/conteúdo ──
        if (tipo == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            tipo == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {

            // Toast pode aparecer como window change em Android 11+
            // Checar o texto do evento ANTES do debounce para não perder
            if (textoEvento.isNotBlank()) processarToast(textoEvento)

            // Debounce apenas para varredura da tela (pesada)
            val agora = System.currentTimeMillis()
            if (agora - ultimoEventoTelaMs < DEBOUNCE_TELA_MS) return
            ultimoEventoTelaMs = agora

            val raiz = rootInActiveWindow ?: return
            processarTela(raiz)
        }
    }

    override fun onInterrupt() { resetarEstado() }

    // ══════════════════════════════════════════════════════════════════════
    // PROCESSAMENTO DE TOAST
    // ══════════════════════════════════════════════════════════════════════
    private fun processarToast(texto: String) {
        val t = texto.lowercase(Locale.getDefault()).trim()

        // Finalização detectada via toast
        if (eToastFinalizacao(t)) {
            if (estado == Estado.FINALIZANDO || estado == Estado.EM_ANDAMENTO) {
                cancelarTimeout()
                salvarCorrida()
            }
            return
        }

        // Cancelamento
        if (eToastCancelamento(t)) {
            if (estado != Estado.IDLE) {
                cancelarTimeout()
                esconderOverlay()
                fecharDialogCancelamento()
                resetarEstado()
            }
        }
    }

    /** Variações que o Taxsee usa ao finalizar corrida */
    private fun eToastFinalizacao(t: String): Boolean =
        t.contains("pedido finalizado") ||
        t.contains("viagem finalizada") ||
        t.contains("corrida finalizada") ||
        t.contains("aguarde pelo pr") ||   // "aguarde pelo próximo pedido"
        t.contains("aguarde o pr") ||
        t.contains("entrega conclu") ||
        t.contains("finalizad")            // genérico: finalizada, finalizado

    /** Variações de cancelamento */
    private fun eToastCancelamento(t: String): Boolean =
        t.contains("pedido cancelado") ||
        t.contains("corrida cancelada") ||
        t.contains("viagem cancelada") ||
        t.contains("cancelad")

    // ══════════════════════════════════════════════════════════════════════
    // PROCESSAMENTO DE TELA
    // ══════════════════════════════════════════════════════════════════════
    private fun processarTela(raiz: AccessibilityNodeInfo) {
        val textoTela = coletarTextoTela(raiz)

        when (estado) {
            Estado.IDLE              -> verificarOferta(raiz, textoTela)
            Estado.AGUARDANDO_ACEITE -> verificarAceite(raiz, textoTela)
            Estado.EM_ANDAMENTO      -> verificarAndamento(raiz, textoTela)
            Estado.FINALIZANDO       -> verificarFinalizando(raiz, textoTela)
        }
    }

    // ──────────────────────────────────────────────────────────────────────
    // IDLE → AGUARDANDO_ACEITE
    // ──────────────────────────────────────────────────────────────────────
    private fun verificarOferta(raiz: AccessibilityNodeInfo, textoTela: String) {
        val t = textoTela.lowercase(Locale.getDefault())

        // Condição 1: botões Aceitar E Recusar visíveis
        val temAceitar = temBotaoVisivel(raiz, "Aceitar")
        val temRecusar = temBotaoVisivel(raiz, "Recusar")
        if (!temAceitar || !temRecusar) return

        // Condição 2: há um valor monetário na tela
        val valor = extrairValorOferta(t) ?: return

        val km           = extrairKmOferta(t) ?: 0f
        val ganhoPorKm   = if (km > 0f) valor / km else 0f
        val (orig, dest) = extrairOrigemDestino(raiz)
        val forma        = extrairFormaPagamento(t)

        val prefs       = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val minimoKm    = prefs.getFloat("minimo_km",    1.20f)
        val minimoValor = prefs.getFloat("minimo_valor", 0f)
        val valeAPena   = ganhoPorKm >= minimoKm &&
                          (minimoValor <= 0f || valor >= minimoValor)

        corridaValor      = valor
        corridaKm         = km
        corridaGanhoPorKm = ganhoPorKm
        corridaValeAPena  = valeAPena
        corridaOrigem     = orig
        corridaDestino    = dest
        corridaForma      = forma
        corridaHoraInicio = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        corridaCliente    = ""

        val autoAceitar = prefs.getBoolean("auto_aceitar", false)
        val autoRecusar = prefs.getBoolean("auto_recusar", false)

        mostrarOverlay(valor, km, ganhoPorKm, valeAPena, autoAceitar, autoRecusar)
        tocarSom(valeAPena, prefs)
        estado = Estado.AGUARDANDO_ACEITE

        // Auto-aceitar / auto-recusar
        val tempoAutoMs = prefs.getInt("tempo_auto_aceitar", 3) * 1000L
        when {
            valeAPena && autoAceitar -> handler.postDelayed({
                val r = rootInActiveWindow
                if (r != null) clicarBotao(r, "Aceitar") else realizarTap()
            }, tempoAutoMs)
            !valeAPena && autoRecusar -> handler.postDelayed({
                val r = rootInActiveWindow
                if (r != null) clicarBotao(r, "Recusar")
                estado = Estado.IDLE
            }, tempoAutoMs)
        }
    }

    // ──────────────────────────────────────────────────────────────────────
    // AGUARDANDO_ACEITE → EM_ANDAMENTO ou IDLE (recusado)
    // ──────────────────────────────────────────────────────────────────────
    private fun verificarAceite(raiz: AccessibilityNodeInfo, textoTela: String) {
        val t = textoTela.lowercase(Locale.getDefault())

        // Cancelamento
        if (eToastCancelamento(t) || t.contains("pedido cancelado")) {
            cancelarTimeout(); esconderOverlay(); fecharDialogCancelamento(raiz); resetarEstado()
            return
        }

        // Transição para EM_ANDAMENTO:
        // 1) Tela "A caminho" do Taxsee
        // 2) OU botões Aceitar/Recusar sumiram (driver aceitou manualmente)
        val aCaminho = t.contains("a caminho") ||
                       t.contains("já estou chegando") ||
                       t.contains("cheguei no local") ||
                       t.contains("aguardando passageiro") ||
                       t.contains("aguardando cliente")

        val botoesForam = !temBotaoVisivel(raiz, "Aceitar") && !temBotaoVisivel(raiz, "Recusar")

        if (aCaminho || botoesForam) {
            // Capturar nome do cliente se disponível
            if (corridaCliente.isEmpty())
                corridaCliente = extrairCliente(raiz, t)

            esconderOverlay()
            estado = Estado.EM_ANDAMENTO

            // Backup: se ficar 12 minutos em andamento sem finalizar, salva assim mesmo
            iniciarTimeout(TIMEOUT_EM_ANDAMENTO_MS) {
                if (estado == Estado.EM_ANDAMENTO) salvarCorrida()
            }
        }
    }

    // ──────────────────────────────────────────────────────────────────────
    // EM_ANDAMENTO → FINALIZANDO
    // ──────────────────────────────────────────────────────────────────────
    private fun verificarAndamento(raiz: AccessibilityNodeInfo, textoTela: String) {
        val t = textoTela.lowercase(Locale.getDefault())

        if (eToastCancelamento(t) || t.contains("pedido cancelado")) {
            cancelarTimeout(); esconderOverlay(); fecharDialogCancelamento(raiz); resetarEstado()
            return
        }

        // Detectar tela de finalização
        val telaDeFinalizar = t.contains("finalizar pedido") ||
                              t.contains("finalizar viagem") ||
                              t.contains("finalizar corrida") ||
                              t.contains("preço total")      // tela de preço final

        if (!telaDeFinalizar) {
            // Também verifica se já apareceu indicação de conclusão na tela
            if (eToastFinalizacao(t)) { cancelarTimeout(); salvarCorrida() }
            return
        }

        // Capturar dados finais
        finalValor = extrairValorFinal(raiz, t) ?: corridaValor
        finalKm    = extrairKmFinal(t) ?: corridaKm
        finalTempo = extrairTempo(t)

        cancelarTimeout() // cancela o timeout de 12 min
        estado = Estado.FINALIZANDO

        // Timeout de 45s: se o toast não vier, salva assim mesmo
        iniciarTimeout(TIMEOUT_FINALIZANDO_MS) {
            if (estado == Estado.FINALIZANDO) salvarCorrida()
        }
    }

    // ──────────────────────────────────────────────────────────────────────
    // FINALIZANDO: atualizar valor enquanto motorista confirma
    // ──────────────────────────────────────────────────────────────────────
    private fun verificarFinalizando(raiz: AccessibilityNodeInfo, textoTela: String) {
        val t = textoTela.lowercase(Locale.getDefault())

        // Checar se tela de conclusão já apareceu
        if (eToastFinalizacao(t) ||
            t.contains("como foi sua viagem") ||
            t.contains("avalie") ||
            t.contains("obrigado")) {
            cancelarTimeout(); salvarCorrida(); return
        }

        if (eToastCancelamento(t)) {
            cancelarTimeout(); esconderOverlay(); fecharDialogCancelamento(raiz); resetarEstado()
            return
        }

        // Atualizar valor final enquanto motorista edita
        val novoValor = extrairValorFinal(raiz, t)
        if (novoValor != null && novoValor > 0f) finalValor = novoValor
        val novoKm = extrairKmFinal(t)
        if (novoKm != null && novoKm > 0f) finalKm = novoKm
        if (finalTempo.isEmpty()) finalTempo = extrairTempo(t)
    }

    // ══════════════════════════════════════════════════════════════════════
    // SALVAR CORRIDA
    // ══════════════════════════════════════════════════════════════════════
    private fun salvarCorrida() {
        try {
            val valorFinal = if (finalValor > 0f) finalValor else corridaValor
            val kmFinal    = if (finalKm    > 0f) finalKm    else corridaKm
            val gpkm       = if (kmFinal    > 0f) valorFinal / kmFinal else corridaGanhoPorKm

            val prefs       = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
            val minimoKm    = prefs.getFloat("minimo_km",    1.20f)
            val minimoValor = prefs.getFloat("minimo_valor", 0f)
            val valeAPena   = gpkm >= minimoKm && (minimoValor <= 0f || valorFinal >= minimoValor)
            val horaFim     = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

            DatabaseHelper(this).inserirCorrida(
                Corrida(
                    valor          = valorFinal,
                    kmTotal        = kmFinal,
                    ganhoPorKm     = gpkm,
                    valeAPena      = valeAPena,
                    origem         = corridaOrigem,
                    destino        = corridaDestino,
                    formaPagamento = corridaForma,
                    passageiro     = corridaCliente,
                    horaInicio     = corridaHoraInicio,
                    horaFim        = horaFim,
                    tempoExecucao  = finalTempo
                )
            )

            // Atualizar botão flutuante
            FloatingEarningsService.instanciaAtiva?.atualizarValor()
                ?: startService(Intent(this, FloatingEarningsService::class.java).apply {
                    action = FloatingEarningsService.ACTION_ATUALIZAR
                })

            // Atualizar widget
            try {
                val mgr = android.appwidget.AppWidgetManager.getInstance(this)
                val ids = mgr.getAppWidgetIds(
                    android.content.ComponentName(this, FluxoWidgetProvider::class.java))
                if (ids.isNotEmpty()) sendBroadcast(
                    Intent(this, FluxoWidgetProvider::class.java).apply {
                        action = android.appwidget.AppWidgetManager.ACTION_APPWIDGET_UPDATE
                        putExtra(android.appwidget.AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                    })
            } catch (_: Exception) {}

            // Som de meta
            verificarMeta(valorFinal, prefs)

        } catch (_: Exception) {}

        resetarEstado()
    }

    // ══════════════════════════════════════════════════════════════════════
    // EXTRAÇÃO DE DADOS
    // ══════════════════════════════════════════════════════════════════════

    /**
     * Extrai o valor da oferta (R$).
     * Prioriza "Preço total" quando disponível.
     */
    private fun extrairValorOferta(texto: String): Float? {
        // Tentar próximo de "preço total" ou "r$"
        val regexRs = Regex("""r\$\s*([\d]+[,.][\d]{2})""")
        val valores = regexRs.findAll(texto)
            .mapNotNull { it.groupValues[1].replace(",", ".").toFloatOrNull() }
            .filter { it >= 1f }
            .toList()
        if (valores.isNotEmpty()) return valores.first()

        // Fallback: qualquer valor com 2 casas decimais >= 1.00
        val regexNum = Regex("""(?<!\d)([\d]{1,3}[,.][\d]{2})(?!\d)""")
        return regexNum.findAll(texto)
            .mapNotNull { it.groupValues[1].replace(",", ".").toFloatOrNull() }
            .filter { it >= 1f }
            .firstOrNull()
    }

    /**
     * Extrai km da oferta.
     * O Taxsee mostra 2 valores: "X km até o endereço" + "Y km distância da rota".
     * Soma apenas os 2 primeiros encontrados.
     */
    private fun extrairKmOferta(texto: String): Float? {
        val regex = Regex("""([\d]+[,.]?[\d]*)\s*km""")
        val valores = regex.findAll(texto)
            .mapNotNull { it.groupValues[1].replace(",", ".").toFloatOrNull() }
            .filter { it > 0f }
            .take(2)  // pega no máximo 2
            .toList()
        return when {
            valores.size >= 2 -> valores[0] + valores[1]
            valores.size == 1 -> valores[0]
            else              -> null
        }
    }

    /** Extrai km da tela de finalização (apenas o primeiro valor) */
    private fun extrairKmFinal(texto: String): Float? {
        val regex = Regex("""([\d]+[,.][\d]+)\s*km""")
        return regex.find(texto)?.groupValues?.get(1)?.replace(",", ".")?.toFloatOrNull()
    }

    /** Extrai tempo em minutos da tela */
    private fun extrairTempo(texto: String): String {
        val regex = Regex("""(\d+)\s*min""")
        return regex.find(texto)?.let { "${it.groupValues[1]} min" } ?: ""
    }

    /**
     * Extrai valor final da tela de finalização.
     * Prioriza EditText editável (motorista pode alterar o valor).
     */
    private fun extrairValorFinal(raiz: AccessibilityNodeInfo, textoTela: String): Float? {
        // 1) EditText visível com valor numérico (campo editável de preço)
        val noEdit = encontrarNo(raiz) { no ->
            no.className?.contains("EditText") == true &&
            no.isVisibleToUser &&
            no.text?.toString()?.matches(Regex("""[\d]+[,.][\d]{2}""")) == true
        }
        noEdit?.text?.toString()?.replace(",", ".")?.toFloatOrNull()
            ?.takeIf { it > 0f }?.let { return it }

        // 2) Qualquer valor monetário no texto da tela
        return extrairValorOferta(textoTela)
    }

    private fun extrairFormaPagamento(texto: String): String = when {
        texto.contains("dinheiro")                                -> "Dinheiro"
        texto.contains("cartão") || texto.contains("cartao")     -> "Cartão"
        texto.contains("pix")                                     -> "PIX"
        texto.contains("online")                                  -> "Online"
        else                                                      -> "Dinheiro"
    }

    private fun extrairCliente(raiz: AccessibilityNodeInfo, texto: String): String {
        // Padrão: "cliente NomeProprio"
        val regex = Regex("""cliente\s+([a-záéíóúàâêîôûãõç]+)""", RegexOption.IGNORE_CASE)
        regex.find(texto)?.groupValues?.get(1)
            ?.replaceFirstChar { it.uppercase() }
            ?.let { return it }

        // Fallback: nó de texto com 3-25 chars, sem números, visível
        return encontrarNo(raiz) { no ->
            val txt = no.text?.toString() ?: ""
            txt.length in 3..25 &&
            !txt.any { it.isDigit() } &&
            !txt.contains("km", ignoreCase = true) &&
            !txt.contains("r$", ignoreCase = true) &&
            no.isVisibleToUser
        }?.text?.toString()?.replaceFirstChar { it.uppercase() } ?: ""
    }

    private fun extrairOrigemDestino(raiz: AccessibilityNodeInfo): Pair<String, String> {
        val enderecos = mutableListOf<String>()
        visitarNos(raiz) { no ->
            val txt = no.text?.toString() ?: ""
            if (txt.length > 5 && no.isVisibleToUser &&
                (txt.contains("Rua ", ignoreCase = true) ||
                 txt.contains("Travessa", ignoreCase = true) ||
                 txt.contains("Avenida", ignoreCase = true) ||
                 txt.contains("Alameda", ignoreCase = true) ||
                 txt.contains("Praça", ignoreCase = true) ||
                 txt.contains("(") )
            ) enderecos.add(txt.trim())
        }
        return Pair(
            enderecos.getOrNull(0) ?: "",
            enderecos.getOrNull(1) ?: ""
        )
    }

    private fun coletarTextoTela(raiz: AccessibilityNodeInfo): String {
        val sb = StringBuilder()
        visitarNos(raiz) { no ->
            if (no.isVisibleToUser) {
                no.text?.toString()?.takeIf { it.isNotBlank() }
                    ?.let { sb.append(it).append(" ") }
                no.contentDescription?.toString()?.takeIf { it.isNotBlank() }
                    ?.let { sb.append(it).append(" ") }
            }
        }
        return sb.toString()
    }

    // ══════════════════════════════════════════════════════════════════════
    // INTERAÇÃO COM UI
    // ══════════════════════════════════════════════════════════════════════

    private fun temBotaoVisivel(raiz: AccessibilityNodeInfo, texto: String): Boolean =
        encontrarNo(raiz) { no ->
            no.text?.toString()?.equals(texto, ignoreCase = true) == true && no.isVisibleToUser
        } != null

    private fun clicarBotao(raiz: AccessibilityNodeInfo, texto: String): Boolean {
        val no = encontrarNo(raiz) { no ->
            no.text?.toString()?.equals(texto, ignoreCase = true) == true && no.isVisibleToUser
        } ?: return false
        return no.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun fecharDialogCancelamento(raiz: AccessibilityNodeInfo? = null) {
        val r = raiz ?: rootInActiveWindow ?: return
        encontrarNo(r) { no ->
            no.text?.toString()?.equals("Ok", ignoreCase = true) == true && no.isVisibleToUser
        }?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun realizarTap() {
        try {
            val m = resources.displayMetrics
            val path = Path().apply { moveTo(m.widthPixels / 2f, m.heightPixels * 0.75f) }
            dispatchGesture(
                GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(path, 0L, 100L))
                    .build(), null, null
            )
        } catch (_: Exception) {}
    }

    // ══════════════════════════════════════════════════════════════════════
    // OVERLAY
    // ══════════════════════════════════════════════════════════════════════

    private fun mostrarOverlay(
        valor: Float, km: Float, ganhoPorKm: Float,
        valeAPena: Boolean, autoAceitar: Boolean, autoRecusar: Boolean
    ) {
        startService(Intent(this, OverlayService::class.java).apply {
            action = "MOSTRAR"
            putExtra("valor", valor)
            putExtra("km_total", km)
            putExtra("ganho_por_km", ganhoPorKm)
            putExtra("vale_a_pena", valeAPena)
            putExtra("auto_aceitar", autoAceitar)
            putExtra("auto_recusar", autoRecusar)
        })
    }

    private fun esconderOverlay() {
        try { startService(Intent(this, OverlayService::class.java).apply { action = "ESCONDER" }) }
        catch (_: Exception) {}
    }

    // ══════════════════════════════════════════════════════════════════════
    // SOM E META
    // ══════════════════════════════════════════════════════════════════════

    private fun tocarSom(valeAPena: Boolean, prefs: android.content.SharedPreferences) {
        if (valeAPena && !prefs.getBoolean("som_aceitar", true)) return
        if (!valeAPena && !prefs.getBoolean("som_recusar", false)) return
        try {
            val tipo = if (valeAPena) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_NACK
            val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
            tg.startTone(tipo, 300)
            handler.postDelayed({ try { tg.release() } catch (_: Exception) {} }, 600)
        } catch (_: Exception) {}
    }

    private fun verificarMeta(valorAdicionado: Float, prefs: android.content.SharedPreferences) {
        val meta = prefs.getFloat("meta_diaria", 0f)
        if (meta <= 0f || !prefs.getBoolean("som_meta", true)) return
        try {
            val totalHoje = DatabaseHelper(this).run { resumo(buscarHoje())["total"] ?: 0f }
            if (totalHoje >= meta && (totalHoje - valorAdicionado) < meta) {
                val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100)
                repeat(3) { i ->
                    handler.postDelayed({
                        try { tg.startTone(ToneGenerator.TONE_PROP_BEEP, 200) } catch (_: Exception) {}
                    }, i * 400L)
                }
                handler.postDelayed({ try { tg.release() } catch (_: Exception) {} }, 1800)
            }
        } catch (_: Exception) {}
    }

    // ══════════════════════════════════════════════════════════════════════
    // TIMEOUT E RESET
    // ══════════════════════════════════════════════════════════════════════

    private fun iniciarTimeout(ms: Long, acao: () -> Unit) {
        cancelarTimeout()
        val r = Runnable { acao() }
        timeoutRunnable = r
        handler.postDelayed(r, ms)
    }

    private fun cancelarTimeout() {
        timeoutRunnable?.let { handler.removeCallbacks(it) }
        timeoutRunnable = null
    }

    private fun resetarEstado() {
        estado = Estado.IDLE
        corridaValor = 0f; corridaKm = 0f; corridaGanhoPorKm = 0f
        corridaValeAPena = false
        corridaOrigem = ""; corridaDestino = ""; corridaCliente = ""
        corridaForma = ""; corridaHoraInicio = ""
        finalValor = 0f; finalKm = 0f; finalTempo = ""
        handler.removeCallbacksAndMessages(null)
        cancelarTimeout()
    }

    // ══════════════════════════════════════════════════════════════════════
    // UTILITÁRIOS DE ÁRVORE
    // ══════════════════════════════════════════════════════════════════════

    private fun encontrarNo(
        raiz: AccessibilityNodeInfo,
        predicado: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        if (predicado(raiz)) return raiz
        for (i in 0 until raiz.childCount) {
            val filho = raiz.getChild(i) ?: continue
            val r = encontrarNo(filho, predicado)
            if (r != null) return r
        }
        return null
    }

    private fun visitarNos(
        raiz: AccessibilityNodeInfo,
        visitante: (AccessibilityNodeInfo) -> Unit
    ) {
        visitante(raiz)
        for (i in 0 until raiz.childCount) {
            visitarNos(raiz.getChild(i) ?: continue, visitante)
        }
    }
}
