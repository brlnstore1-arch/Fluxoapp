package com.fluxoapp

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * MaximAccessibilityService — FluxoApp
 *
 * Fluxo de estados:
 *   IDLE
 *     → detecta botões Aceitar+Recusar + valor R$ com forma de pagamento → AGUARDANDO_ACEITE
 *       → botões sumiram (e overlay NÃO está na tela) OU texto "a caminho" → EM_ANDAMENTO
 *         → texto "finalizar pedido" / "preço total"              → FINALIZANDO
 *           → toast "Pedido finalizado!" OU timeout 45s           → salva → IDLE
 *         OU timeout 12min em andamento                           → salva → IDLE
 *     Cancelamento real: "pedido cancelado" / "corrida cancelada" → descarta → IDLE
 *
 * BUGS CORRIGIDOS nesta versão:
 *   1. LOOP DO OVERLAY: "O pedido será cancelado em 18" continha "cancelad"
 *      → resetava o estado toda vez que o contador atualizava.
 *      FIX: eToastCancelamento() agora exige frases COMPLETAS ("pedido cancelado" etc.)
 *
 *   2. VALOR ERRADO: capturava o saldo da conta Maxim (ex: R$ 74,30) em vez do
 *      valor da corrida, porque o saldo aparece antes no texto coletado.
 *      FIX: extrairValorOferta() busca primeiro o padrão "R$ X,XX por [pagamento]"
 *
 *   3. ORIGEM ERRADA: "Confirmação (R$ 8,52)" era capturada como origem porque
 *      contém parêntese "(".
 *      FIX: extrairOrigemDestino() exclui textos com "R$" e usa "(bairro" em vez de "("
 *
 *   4. AUTO-ACEITAR NÃO FUNCIONAVA: handler.removeCallbacksAndMessages(null) cancelava
 *      o Runnable do auto-aceitar durante o loop.
 *      FIX: Runnables nomeados, cancelados apenas quando necessário.
 */
class MaximAccessibilityService : AccessibilityService() {

    // ── Máquina de estados ─────────────────────────────────────────────────
    private enum class Estado { IDLE, AGUARDANDO_ACEITE, EM_ANDAMENTO, FINALIZANDO }
    private var estado = Estado.IDLE

    // ── Dados da corrida ───────────────────────────────────────────────────
    private var corridaValor      = 0f
    private var corridaKm         = 0f
    private var corridaGanhoPorKm = 0f
    private var corridaValeAPena  = false
    private var corridaOrigem     = ""
    private var corridaDestino    = ""
    private var corridaCliente    = ""
    private var corridaForma      = ""
    private var corridaHoraInicio = ""
    private var finalValor        = 0f
    private var finalKm           = 0f
    private var finalTempo        = ""

    // ── Controle de overlay ────────────────────────────────────────────────
    // overlayAtivo: true enquanto o FluxoApp está exibindo o card de análise.
    // Impede que a checagem "botões sumiram" dê falso positivo (os botões
    // do Taxsee podem ser cobertos pelo overlay do FluxoApp).
    private var overlayAtivo      = false
    private var ultimoValorOferta = 0f

    // ── Runnables nomeados (não são cancelados pelo handler global) ────────
    private var runnableAutoAceitar: Runnable? = null
    private var runnableAutoRecusar: Runnable? = null

    // ── Controle de debounce e timeout ────────────────────────────────────
    private val handler            = Handler(Looper.getMainLooper())
    private var ultimoEventoTelaMs = 0L
    private var timeoutRunnable: Runnable? = null

    companion object {
        private const val PKG_TAXSEE              = "com.taxsee.driver"
        private val DEBOUNCE_TELA_MS         = FluxoConfig.DEBOUNCE_TELA_MS
        private val TIMEOUT_FINALIZANDO_MS   = FluxoConfig.TIMEOUT_FINALIZANDO_MS
        private const val TIMEOUT_EM_ANDAMENTO_MS  = 720_000L
    }

    // ══════════════════════════════════════════════════════════════════════
    // PONTO DE ENTRADA
    // ══════════════════════════════════════════════════════════════════════
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        if (event.packageName?.toString() != PKG_TAXSEE) return

        val tipo = event.eventType
        val textoEvento = event.text?.joinToString(" ")?.trim()
            ?.lowercase(Locale.getDefault()) ?: ""

        // Toasts e anúncios — sem debounce, processados imediatamente
        if (tipo == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED ||
            tipo == AccessibilityEvent.TYPE_ANNOUNCEMENT) {
            if (textoEvento.isNotBlank()) processarToast(textoEvento)
            return
        }

        // Mudanças de janela/conteúdo
        if (tipo == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            tipo == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {

            // Verificar toast no texto do evento ANTES do debounce
            if (textoEvento.isNotBlank()) processarToast(textoEvento)

            // Debounce para a varredura completa da tela
            val agora = System.currentTimeMillis()
            if (agora - ultimoEventoTelaMs < DEBOUNCE_TELA_MS) return
            ultimoEventoTelaMs = agora

            val raiz = rootInActiveWindow ?: return
            processarTela(raiz)
        }
    }

    override fun onInterrupt() { resetarEstado() }

    // ══════════════════════════════════════════════════════════════════════
    // PROCESSAMENTO DE TOAST
    // ══════════════════════════════════════════════════════════════════════
    private fun processarToast(texto: String) {
        val t = texto.lowercase(Locale.getDefault()).trim()

        if (eToastFinalizacao(t)) {
            if (estado == Estado.FINALIZANDO || estado == Estado.EM_ANDAMENTO) {
                cancelarTimeout()
                salvarCorrida()
            }
            return
        }

        if (eToastCancelamento(t)) {
            if (estado != Estado.IDLE) {
                cancelarTudo()
                esconderOverlay()
                fecharDialogCancelamento()
                resetarEstado()
            }
        }
    }

    /**
     * Detecta o toast de finalização da corrida.
     * Gatilho principal: "Pedido finalizado!" (palavra "pedido" + "finaliz")
     */
    private fun eToastFinalizacao(t: String): Boolean =
        // Texto EXATO do toast do Taxsee: "Pedido finalizado! Aguarde pelo próximo."
        // ATENÇÃO: não usar "finaliz" genérico — captura o BOTÃO "Finalizar pedido"
        // ATENÇÃO: não usar "avalie" — pode aparecer em telas normais do Taxsee
        t.contains("pedido finalizado")   ||  // toast principal
        t.contains("aguarde pelo próximo")||  // parte do toast
        t.contains("aguarde pelo proximo")||  // sem acento
        t.contains("viagem finalizada")   ||  // variação
        t.contains("corrida finalizada")  ||  // variação
        t.contains("entrega conclu")          // entregas

    /**
     * Detecta o CANCELAMENTO real de uma corrida.
     *
     * ⚠️ IMPORTANTE: NÃO usar "cancelad" genérico.
     * O Taxsee exibe "O pedido será cancelado em 18 segundos" no contador
     * regressivo — esse texto contém "cancelado" mas NÃO é um cancelamento real.
     * Usar apenas frases COMPLETAS e específicas.
     */
    private fun eToastCancelamento(t: String): Boolean =
        t.contains("pedido cancelado")   ||
        t.contains("corrida cancelada")  ||
        t.contains("viagem cancelada")   ||
        t.contains("pedido recusado")    ||
        t.contains("corrida recusada")

    // ══════════════════════════════════════════════════════════════════════
    // PROCESSAMENTO DE TELA
    // ══════════════════════════════════════════════════════════════════════
    private fun processarTela(raiz: AccessibilityNodeInfo) {
        val textoTela = coletarTextoTela(raiz)
        when (estado) {
            Estado.IDLE              -> verificarOferta(raiz, textoTela)
            Estado.AGUARDANDO_ACEITE -> verificarAceite(raiz, textoTela)
            Estado.EM_ANDAMENTO      -> verificarAndamento(raiz, textoTela)
            Estado.FINALIZANDO       -> verificarFinalizando(raiz, textoTela)
        }
    }

    // ──────────────────────────────────────────────────────────────────────
    // IDLE → AGUARDANDO_ACEITE
    // ──────────────────────────────────────────────────────────────────────
    private fun verificarOferta(raiz: AccessibilityNodeInfo, textoTela: String) {
        val t = textoTela.lowercase(Locale.getDefault())

        // Gatilho: ambos os botões Aceitar E Recusar visíveis
        val temAceitar = temBotaoVisivel(raiz, "Aceitar")
        val temRecusar = temBotaoVisivel(raiz, "Recusar")
        if (!temAceitar || !temRecusar) return

        // Extrair valor da oferta (com prioridade para "R$ X,XX por [pagamento]")
        val valor = extrairValorOferta(t) ?: return

        val km           = extrairKmOferta(t) ?: 0f
        val ganhoPorKm   = if (km > 0f) valor / km else 0f
        val (orig, dest) = extrairOrigemDestino(raiz)
        val forma        = extrairFormaPagamento(t)

        val prefs       = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val minimoKm    = prefs.getFloat("minimo_km",    FluxoConfig.GANHO_POR_KM_PADRAO)
        val minimoValor = prefs.getFloat("minimo_valor", 0f)
        val valeAPena   = ganhoPorKm >= minimoKm &&
                          (minimoValor <= 0f || valor >= minimoValor)

        corridaValor      = valor
        corridaKm         = km
        corridaGanhoPorKm = ganhoPorKm
        corridaValeAPena  = valeAPena
        corridaOrigem     = orig
        corridaDestino    = dest
        corridaForma      = forma
        corridaHoraInicio = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        corridaCliente    = ""

        val autoAceitar = prefs.getBoolean("auto_aceitar", false)
        val autoRecusar = prefs.getBoolean("auto_recusar", false)

        // Só exibe overlay e toca som se for oferta NOVA (valor diferente da anterior)
        val ofertaNova = !overlayAtivo ||
                         kotlin.math.abs(valor - ultimoValorOferta) > 0.01f

        if (ofertaNova) {
            ultimoValorOferta = valor
            overlayAtivo      = true
            estado            = Estado.AGUARDANDO_ACEITE

            mostrarOverlay(valor, km, ganhoPorKm, valeAPena, autoAceitar, autoRecusar, orig, dest)

            // Som toca apenas uma vez por oferta nova
            tocarSom(valeAPena, prefs)

            // Agendar auto-aceitar/recusar com Runnable nomeado
            // (não é cancelado pelo resetarEstado geral, apenas por cancelarAutoAR)
            cancelarAutoAR()
            val tempoAutoMs = prefs.getInt("tempo_auto_aceitar", 3) * 1000L
            when {
                valeAPena && autoAceitar -> {
                    runnableAutoAceitar = Runnable {
                        if (estado == Estado.AGUARDANDO_ACEITE) {
                            val r = rootInActiveWindow
                            // Usa versão sem filtro de visibilidade: o overlay do FluxoApp
                            // pode estar cobrindo o botão "Aceitar" do Taxsee visualmente,
                            // mas ele ainda existe e é clicável na árvore de acessibilidade.
                            val clicou = if (r != null) clicarBotaoIgnorandoVisibilidade(r, "Aceitar") else false
                            if (!clicou) realizarTap()
                        }
                    }.also { handler.postDelayed(it, tempoAutoMs) }
                }
                !valeAPena && autoRecusar -> {
                    runnableAutoRecusar = Runnable {
                        if (estado == Estado.AGUARDANDO_ACEITE) {
                            val r = rootInActiveWindow
                            if (r != null) clicarBotaoIgnorandoVisibilidade(r, "Recusar")
                            esconderOverlay()
                            estado = Estado.IDLE
                        }
                    }.also { handler.postDelayed(it, tempoAutoMs) }
                }
            }
        } else {
            // Mesma oferta, só garante o estado correto
            estado = Estado.AGUARDANDO_ACEITE
        }
    }

    // ──────────────────────────────────────────────────────────────────────
    // AGUARDANDO_ACEITE → EM_ANDAMENTO ou IDLE
    // ──────────────────────────────────────────────────────────────────────
    private fun verificarAceite(raiz: AccessibilityNodeInfo, textoTela: String) {
        val t = textoTela.lowercase(Locale.getDefault())

        if (eToastCancelamento(t) || t.contains("pedido cancelado")) {
            cancelarTudo()
            esconderOverlay()
            fecharDialogCancelamento(raiz)
            resetarEstado()
            return
        }

        // Tela "A caminho" → corrida aceita
        val aCaminho = t.contains("a caminho")           ||
                       t.contains("já estou chegando")   ||
                       t.contains("cheguei no local")    ||
                       t.contains("aguardando passageiro") ||
                       t.contains("aguardando cliente")

        // Botões sumiram → corrida aceita manualmente
        // IMPORTANTE: só considera válido se o overlay do FluxoApp NÃO estiver
        // visível, porque o overlay pode cobrir os botões do Taxsee visualmente
        // sem que eles tenham desaparecido de verdade.
        val botoesForam = !overlayAtivo &&
                          !temBotaoVisivel(raiz, "Aceitar") &&
                          !temBotaoVisivel(raiz, "Recusar")

        if (aCaminho || botoesForam) {
            if (corridaCliente.isEmpty())
                corridaCliente = extrairCliente(raiz, t)

            cancelarAutoAR()
            esconderOverlay()
            estado = Estado.EM_ANDAMENTO
            // Sem timeout automático — corrida só salva após toast ou 30s na tela final
        }
    }

    // ──────────────────────────────────────────────────────────────────────
    // EM_ANDAMENTO → FINALIZANDO
    // ──────────────────────────────────────────────────────────────────────
    private fun verificarAndamento(raiz: AccessibilityNodeInfo, textoTela: String) {
        val t = textoTela.lowercase(Locale.getDefault())

        if (eToastCancelamento(t) || t.contains("pedido cancelado")) {
            cancelarTudo()
            esconderOverlay()
            fecharDialogCancelamento(raiz)
            resetarEstado()
            return
        }

        val telaDeFinalizar = t.contains("finalizar pedido") ||
                              t.contains("finalizar viagem") ||
                              t.contains("finalizar corrida") ||
                              t.contains("preço total")

        if (!telaDeFinalizar) {
            // Finalização detectada via toast na tela de conteúdo
            if (eToastFinalizacao(t)) { cancelarTimeout(); salvarCorrida() }
            return
        }

        // Capturar dados finais da tela de finalização
        finalValor = extrairValorFinal(raiz, t) ?: corridaValor
        finalKm    = extrairKmFinal(t)          ?: corridaKm
        finalTempo = extrairTempo(t)

        cancelarTimeout()
        estado = Estado.FINALIZANDO
        FluxoLog.d("MaximService", "Estado FINALIZANDO — valor=$finalValor km=$finalKm tempo=$finalTempo")

        // Se o toast "Pedido finalizado!" não vier em 30s, salva assim mesmo
        iniciarTimeout(TIMEOUT_FINALIZANDO_MS) {
            if (estado == Estado.FINALIZANDO) salvarCorrida()
        }
    }

    // ──────────────────────────────────────────────────────────────────────
    // FINALIZANDO: aguarda confirmação do toast
    // ──────────────────────────────────────────────────────────────────────
    private fun verificarFinalizando(raiz: AccessibilityNodeInfo, textoTela: String) {
        val t = textoTela.lowercase(Locale.getDefault())

        // Só salva pelo toast explícito ou pelo timeout de 30s
        // "avalie" e "obrigado" podem aparecer em outras telas — não usar como gatilho
        if (eToastFinalizacao(t)) {
            cancelarTimeout()
            salvarCorrida()
            return
        }

        if (eToastCancelamento(t)) {
            cancelarTudo()
            esconderOverlay()
            fecharDialogCancelamento(raiz)
            resetarEstado()
            return
        }

        // Atualizar valor final enquanto motorista pode editar o preço
        val novoValor = extrairValorFinal(raiz, t)
        if (novoValor != null && novoValor > 0f) finalValor = novoValor
        val novoKm = extrairKmFinal(t)
        if (novoKm != null && novoKm > 0f) finalKm = novoKm
        if (finalTempo.isEmpty()) finalTempo = extrairTempo(t)
    }

    // ══════════════════════════════════════════════════════════════════════
    // SALVAR CORRIDA
    // ══════════════════════════════════════════════════════════════════════
    private fun salvarCorrida() {
        FluxoLog.d("MaximService", "Salvando corrida — estado=$estado valor=$finalValor km=$finalKm")
        try {
            val valorFinal = if (finalValor > 0f) finalValor else corridaValor
            val kmFinal    = if (finalKm    > 0f) finalKm    else corridaKm
            val gpkm       = if (kmFinal    > 0f) valorFinal / kmFinal else corridaGanhoPorKm

            val prefs       = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
            val minimoKm    = prefs.getFloat("minimo_km",    FluxoConfig.GANHO_POR_KM_PADRAO)
            val minimoValor = prefs.getFloat("minimo_valor", 0f)
            val valeAPena   = gpkm >= minimoKm && (minimoValor <= 0f || valorFinal >= minimoValor)
            val horaFim     = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

            DatabaseHelper.getInstance(this).inserirCorrida(
                Corrida(
                    valor          = valorFinal,
                    kmTotal        = kmFinal,
                    ganhoPorKm     = gpkm,
                    valeAPena      = valeAPena,
                    origem         = corridaOrigem,
                    destino        = corridaDestino,
                    formaPagamento = corridaForma,
                    passageiro     = corridaCliente,
                    horaInicio     = corridaHoraInicio,
                    horaFim        = horaFim,
                    tempoExecucao  = finalTempo
                )
            )

            // Atualizar botão flutuante
            FloatingEarningsService.instanciaAtiva?.atualizarValor()
                ?: startService(Intent(this, FloatingEarningsService::class.java).apply {
                    action = FloatingEarningsService.ACTION_ATUALIZAR
                })

            // Atualizar widget
            try {
                val mgr = android.appwidget.AppWidgetManager.getInstance(this)
                val ids = mgr.getAppWidgetIds(
                    android.content.ComponentName(this, FluxoWidgetProvider::class.java))
                if (ids.isNotEmpty()) sendBroadcast(
                    Intent(this, FluxoWidgetProvider::class.java).apply {
                        action = android.appwidget.AppWidgetManager.ACTION_APPWIDGET_UPDATE
                        putExtra(android.appwidget.AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                    })
            } catch (_: Exception) {}

            verificarMeta(valorFinal, prefs)

        } catch (_: Exception) {}

        resetarEstado()
    }

    // ══════════════════════════════════════════════════════════════════════
    // EXTRAÇÃO DE DADOS
    // ══════════════════════════════════════════════════════════════════════

    /**
     * Extrai o valor da oferta com 3 níveis de prioridade:
     *
     * 1. "R$ X,XX por [pix/dinheiro/cartão/online]" — padrão exato do Taxsee.
     *    Evita capturar o saldo acumulado da conta que aparece antes no texto.
     *
     * 2. Menor valor R$ válido encontrado na tela — o saldo acumulado tende
     *    a ser maior que o valor de uma corrida individual.
     *
     * 3. Fallback genérico para qualquer número com 2 casas decimais.
     */
    private fun extrairValorOferta(texto: String): Float? {
        // Prioridade 1: valor explicitamente ligado à forma de pagamento
        val regexComPagamento = Regex(
            """r\$\s*([\d]+[,.][\d]{2})\s*(?:por\s+)?(pix|dinheiro|cartão|cartao|online|transferência|transferencia)""",
            RegexOption.IGNORE_CASE
        )
        regexComPagamento.find(texto)
            ?.groupValues?.get(1)
            ?.replace(",", ".")?.toFloatOrNull()
            ?.takeIf { it >= 1f }
            ?.let { return it }

        // Prioridade 2: todos os valores R$ válidos — pega o menor
        // (saldo acumulado é sempre > valor de uma corrida)
        val regexRs = Regex("""r\$\s*([\d]+[,.][\d]{2})""")
        val todosValores = regexRs.findAll(texto)
            .mapNotNull { it.groupValues[1].replace(",", ".").toFloatOrNull() }
            .filter { it in 1f..500f }
            .sorted()
            .toList()

        if (todosValores.isNotEmpty()) return todosValores.first()

        // Prioridade 3: fallback — qualquer decimal com 2 casas >= 1
        val regexNum = Regex("""(?<!\d)([\d]{1,3}[,.][\d]{2})(?!\d)""")
        return regexNum.findAll(texto)
            .mapNotNull { it.groupValues[1].replace(",", ".").toFloatOrNull() }
            .filter { it >= 1f }
            .firstOrNull()
    }

    /**
     * Extrai km da oferta.
     * O Taxsee mostra dois valores: "X km até o endereço" + "Y km distância da rota".
     * Soma os dois para estimar o total percorrido.
     */
    private fun extrairKmOferta(texto: String): Float? {
        val regex = Regex("""([\d]+[,.]?[\d]*)\s*km""")
        val valores = regex.findAll(texto)
            .mapNotNull { it.groupValues[1].replace(",", ".").toFloatOrNull() }
            .filter { it > 0f }
            .take(2)
            .toList()
        return when {
            valores.size >= 2 -> valores[0] + valores[1]
            valores.size == 1 -> valores[0]
            else              -> null
        }
    }

    /** Extrai km da tela de finalização (distância real percorrida) */
    private fun extrairKmFinal(texto: String): Float? {
        val regex = Regex("""([\d]+[,.][\d]+)\s*km""")
        return regex.find(texto)?.groupValues?.get(1)?.replace(",", ".")?.toFloatOrNull()
    }

    /** Extrai tempo da corrida em minutos */
    private fun extrairTempo(texto: String): String {
        val regex = Regex("""(\d+)\s*min""")
        return regex.find(texto)?.let { "${it.groupValues[1]} min" } ?: ""
    }

    /** Extrai valor final da tela de finalização (EditText editável tem prioridade) */
    private fun extrairValorFinal(raiz: AccessibilityNodeInfo, textoTela: String): Float? {
        val noEdit = encontrarNo(raiz) { no ->
            no.className?.contains("EditText") == true &&
            no.isVisibleToUser &&
            no.text?.toString()?.matches(Regex("""[\d]+[,.][\d]{2}""")) == true
        }
        noEdit?.text?.toString()?.replace(",", ".")?.toFloatOrNull()
            ?.takeIf { it > 0f }?.let { return it }

        return extrairValorOferta(textoTela)
    }

    /**
     * Detecta a forma de pagamento no texto da tela.
     */
    private fun extrairFormaPagamento(texto: String): String = when {
        texto.contains("pix")                                    -> "PIX"
        texto.contains("dinheiro")                               -> "Dinheiro"
        texto.contains("cartão") || texto.contains("cartao")    -> "Cartão"
        texto.contains("online")                                 -> "Online"
        else                                                     -> "Dinheiro"
    }

    /**
     * Extrai origem e destino da tela de oferta.
     *
     * Condições para um texto ser considerado endereço:
     * - Contém palavra de logradouro (Rua, Travessa, Avenida...) OU "(bairro"
     * - NÃO contém "R$" (exclui textos de preço como "Confirmação (R$ 8,52)")
     * - Tem comprimento mínimo de 5 caracteres
     * - Está visível na tela
     */
    private fun extrairOrigemDestino(raiz: AccessibilityNodeInfo): Pair<String, String> {
        val enderecos = mutableListOf<String>()
        visitarNos(raiz) { no ->
            val txt = no.text?.toString() ?: ""
            if (txt.length > 5 && no.isVisibleToUser) {
                val temLogradouro = txt.contains("Rua ",      ignoreCase = true) ||
                                    txt.contains("Travessa",  ignoreCase = true) ||
                                    txt.contains("Avenida",   ignoreCase = true) ||
                                    txt.contains("Alameda",   ignoreCase = true) ||
                                    txt.contains("Praça",     ignoreCase = true) ||
                                    txt.contains("(bairro",   ignoreCase = true)
                val temPreco = txt.contains("r$", ignoreCase = true)

                if (temLogradouro && !temPreco) {
                    enderecos.add(txt.trim())
                }
            }
        }
        return Pair(
            enderecos.getOrNull(0) ?: "",
            enderecos.getOrNull(1) ?: ""
        )
    }

    private fun extrairCliente(raiz: AccessibilityNodeInfo, texto: String): String {
        val regex = Regex("""cliente\s+([a-záéíóúàâêîôûãõç]+)""", RegexOption.IGNORE_CASE)
        regex.find(texto)?.groupValues?.get(1)
            ?.replaceFirstChar { it.uppercase() }
            ?.let { return it }

        return encontrarNo(raiz) { no ->
            val txt = no.text?.toString() ?: ""
            txt.length in 3..25 &&
            !txt.any { it.isDigit() } &&
            !txt.contains("km", ignoreCase = true) &&
            !txt.contains("r$", ignoreCase = true) &&
            no.isVisibleToUser
        }?.text?.toString()?.replaceFirstChar { it.uppercase() } ?: ""
    }

    private fun coletarTextoTela(raiz: AccessibilityNodeInfo): String {
        val sb = StringBuilder()
        visitarNos(raiz) { no ->
            if (no.isVisibleToUser) {
                no.text?.toString()?.takeIf { it.isNotBlank() }
                    ?.let { sb.append(it).append(" ") }
                no.contentDescription?.toString()?.takeIf { it.isNotBlank() }
                    ?.let { sb.append(it).append(" ") }
            }
        }
        return sb.toString()
    }

    // ══════════════════════════════════════════════════════════════════════
    // INTERAÇÃO COM UI DO TAXSEE
    // ══════════════════════════════════════════════════════════════════════

    private fun temBotaoVisivel(raiz: AccessibilityNodeInfo, texto: String): Boolean =
        encontrarNo(raiz) { no ->
            no.text?.toString()?.equals(texto, ignoreCase = true) == true &&
            no.isVisibleToUser
        } != null

    private fun clicarBotao(raiz: AccessibilityNodeInfo, texto: String): Boolean {
        val no = encontrarNo(raiz) { no ->
            no.text?.toString()?.equals(texto, ignoreCase = true) == true &&
            no.isVisibleToUser
        } ?: return false
        return no.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    /**
     * Clica no botão sem verificar visibilidade.
     * Necessário para auto-aceitar/recusar: o overlay do FluxoApp pode cobrir
     * os botões do Taxsee visualmente, mas eles ainda existem na árvore de
     * acessibilidade e podem ser clicados via ACTION_CLICK.
     */
    private fun clicarBotaoIgnorandoVisibilidade(raiz: AccessibilityNodeInfo, texto: String): Boolean {
        val no = encontrarNo(raiz) { no ->
            no.text?.toString()?.equals(texto, ignoreCase = true) == true &&
            no.isClickable
        } ?: return false
        return no.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun fecharDialogCancelamento(raiz: AccessibilityNodeInfo? = null) {
        val r = raiz ?: rootInActiveWindow ?: return
        encontrarNo(r) { no ->
            no.text?.toString()?.equals("Ok", ignoreCase = true) == true &&
            no.isVisibleToUser
        }?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun realizarTap() {
        try {
            val m = resources.displayMetrics
            val path = Path().apply { moveTo(m.widthPixels / 2f, m.heightPixels * 0.75f) }
            dispatchGesture(
                GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(path, 0L, 100L))
                    .build(), null, null
            )
        } catch (_: Exception) {}
    }

    // ══════════════════════════════════════════════════════════════════════
    // OVERLAY
    // ══════════════════════════════════════════════════════════════════════

    private fun mostrarOverlay(
        valor: Float, km: Float, ganhoPorKm: Float,
        valeAPena: Boolean, autoAceitar: Boolean, autoRecusar: Boolean,
        origem: String = "", destino: String = ""
    ) {
        try {
            androidx.core.content.ContextCompat.startForegroundService(
                this, Intent(this, OverlayService::class.java).apply {
                    action = "MOSTRAR"
                    putExtra("valor",        valor)
                    putExtra("km_total",     km)
                    putExtra("ganho_por_km", ganhoPorKm)
                    putExtra("vale_a_pena",  valeAPena)
                    putExtra("auto_aceitar", autoAceitar)
                    putExtra("auto_recusar", autoRecusar)
                    putExtra("origem",       origem)
                    putExtra("destino",      destino)
                }
            )
        } catch (_: Exception) {}
    }

    private fun esconderOverlay() {
        overlayAtivo = false
        try {
            androidx.core.content.ContextCompat.startForegroundService(
                this, Intent(this, OverlayService::class.java).apply { action = "ESCONDER" }
            )
        } catch (_: Exception) {}
    }

    // ══════════════════════════════════════════════════════════════════════
    // SOM E META
    // ══════════════════════════════════════════════════════════════════════

    private fun tocarSom(valeAPena: Boolean, prefs: android.content.SharedPreferences) {
        if (valeAPena  && !prefs.getBoolean("som_aceitar", true))  return
        if (!valeAPena && !prefs.getBoolean("som_recusar", false)) return
        try {
            val tipo = if (valeAPena) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_NACK
            val tg   = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
            tg.startTone(tipo, 300)
            handler.postDelayed({ try { tg.release() } catch (_: Exception) {} }, 600)
        } catch (_: Exception) {}
    }

    private fun verificarMeta(valorAdicionado: Float, prefs: android.content.SharedPreferences) {
        val meta = prefs.getFloat("meta_diaria", 0f)
        if (meta <= 0f || !prefs.getBoolean("som_meta", true)) return
        try {
            val totalHoje = DatabaseHelper.getInstance(this).run { resumo(buscarHoje())["total"] ?: 0f }
            if (totalHoje >= meta && (totalHoje - valorAdicionado) < meta) {
                val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100)
                repeat(3) { i ->
                    handler.postDelayed({
                        try { tg.startTone(ToneGenerator.TONE_PROP_BEEP, 200) } catch (_: Exception) {}
                    }, i * 400L)
                }
                handler.postDelayed({ try { tg.release() } catch (_: Exception) {} }, 1800)
            }
        } catch (_: Exception) {}
    }

    // ══════════════════════════════════════════════════════════════════════
    // CONTROLE DE TIMEOUT E ESTADO
    // ══════════════════════════════════════════════════════════════════════

    private fun iniciarTimeout(ms: Long, acao: () -> Unit) {
        cancelarTimeout()
        val r = Runnable { acao() }
        timeoutRunnable = r
        handler.postDelayed(r, ms)
    }

    private fun cancelarTimeout() {
        timeoutRunnable?.let { handler.removeCallbacks(it) }
        timeoutRunnable = null
    }

    /** Cancela apenas os Runnables de auto-aceitar/recusar */
    private fun cancelarAutoAR() {
        runnableAutoAceitar?.let { handler.removeCallbacks(it) }
        runnableAutoAceitar = null
        runnableAutoRecusar?.let { handler.removeCallbacks(it) }
        runnableAutoRecusar = null
    }

    /** Cancela timeout + auto-aceitar/recusar */
    private fun cancelarTudo() {
        cancelarTimeout()
        cancelarAutoAR()
    }

    private fun resetarEstado() {
        estado            = Estado.IDLE
        corridaValor      = 0f
        corridaKm         = 0f
        corridaGanhoPorKm = 0f
        corridaValeAPena  = false
        corridaOrigem     = ""
        corridaDestino    = ""
        corridaCliente    = ""
        corridaForma      = ""
        corridaHoraInicio = ""
        finalValor        = 0f
        finalKm           = 0f
        finalTempo        = ""
        overlayAtivo      = false
        ultimoValorOferta = 0f
        cancelarTudo()
    }

    // ══════════════════════════════════════════════════════════════════════
    // UTILITÁRIOS DE ÁRVORE DE ACESSIBILIDADE
    // ══════════════════════════════════════════════════════════════════════

    private fun encontrarNo(
        raiz: AccessibilityNodeInfo,
        predicado: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        if (predicado(raiz)) return raiz
        for (i in 0 until raiz.childCount) {
            val filho = raiz.getChild(i) ?: continue
            val r     = encontrarNo(filho, predicado)
            if (r != null) return r
        }
        return null
    }

    private fun visitarNos(
        raiz: AccessibilityNodeInfo,
        visitante: (AccessibilityNodeInfo) -> Unit
    ) {
        visitante(raiz)
        for (i in 0 until raiz.childCount) {
            visitarNos(raiz.getChild(i) ?: continue, visitante)
        }
    }
}
