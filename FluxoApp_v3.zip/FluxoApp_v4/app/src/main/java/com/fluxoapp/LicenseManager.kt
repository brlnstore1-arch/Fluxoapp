package com.fluxoapp

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import java.util.Date
import java.util.concurrent.TimeUnit

/**
 * LicenseManager — FluxoApp
 *
 * Gerencia o acesso do usuário ao app.
 *
 * Estrutura Firestore: users/{uid}
 *   email:          String
 *   nome:           String
 *   plano:          "trial" | "mensal" | "trimestral" | "anual" | "promo" | "bloqueado"
 *   status:         "ativo" | "expirado" | "bloqueado"
 *   trialStart:     Timestamp  (data do primeiro cadastro)
 *   dataExpiracao:  Timestamp  (null = sem expiração, ex: promo vitalício)
 *   codigoPromo:    String?    (código usado, se houver)
 *   criadoEm:       Timestamp
 *
 * Funções GRATUITAS (sempre acessíveis):
 *   - Ver histórico de corridas
 *   - Ver relatórios
 *   - Configurações
 *   - Perfil
 *
 * Funções PREMIUM (exigem plano ativo ou trial):
 *   - Detecção automática de corridas (serviço de acessibilidade)
 *   - Overlay de análise de oferta
 *   - Auto-aceitar / auto-recusar
 *   - Botão flutuante de ganhos
 *   - Widget
 */
object LicenseManager {

    private val auth get() = FirebaseAuth.getInstance()
    private val db   get() = FirebaseFirestore.getInstance()

    const val TRIAL_DIAS = 7L

    // Planos
    const val PLANO_TRIAL       = "trial"
    const val PLANO_MENSAL      = "mensal"
    const val PLANO_TRIMESTRAL  = "trimestral"
    const val PLANO_ANUAL       = "anual"
    const val PLANO_PROMO       = "promo"
    const val PLANO_BLOQUEADO   = "bloqueado"

    // Status
    const val STATUS_ATIVO      = "ativo"
    const val STATUS_EXPIRADO   = "expirado"
    const val STATUS_BLOQUEADO  = "bloqueado"

    /** Resultado da verificação de licença */
    data class StatusLicenca(
        val temAcesso: Boolean,       // tem acesso às funções premium?
        val plano: String,            // qual plano
        val status: String,           // ativo / expirado / bloqueado
        val diasRestantes: Long,      // dias restantes (trial ou plano pago)
        val mensagem: String          // mensagem para exibir ao usuário
    )

    // Cache em memória para evitar consultas repetidas ao Firestore
    private var cacheStatus: StatusLicenca? = null
    private var cacheTimestamp: Long = 0L
    private const val CACHE_TTL_MS = 5 * 60 * 1000L  // 5 minutos

    /** Verifica se o usuário está logado */
    fun estaLogado(): Boolean = auth.currentUser != null

    /** UID do usuário atual */
    fun uid(): String? = auth.currentUser?.uid

    /** Email do usuário atual */
    fun email(): String? = auth.currentUser?.email

    /**
     * Verifica a licença do usuário atual no Firestore.
     * Usa cache de 5 min para evitar leituras excessivas.
     */
    fun verificarLicenca(callback: (StatusLicenca) -> Unit) {
        val uid = uid() ?: run {
            callback(semAcesso("Faça login para continuar"))
            return
        }

        // Retornar cache se ainda válido
        val agora = System.currentTimeMillis()
        val cached = cacheStatus
        if (cached != null && agora - cacheTimestamp < CACHE_TTL_MS) {
            callback(cached)
            return
        }

        db.collection("users").document(uid).get()
            .addOnSuccessListener { doc ->
                val status = if (doc.exists()) {
                    calcularStatus(doc.data ?: emptyMap())
                } else {
                    // Documento não existe ainda — criar trial
                    criarDocumentoTrial(uid)
                    StatusLicenca(
                        temAcesso    = true,
                        plano        = PLANO_TRIAL,
                        status       = STATUS_ATIVO,
                        diasRestantes = TRIAL_DIAS,
                        mensagem     = "Trial gratuito — ${TRIAL_DIAS} dias"
                    )
                }
                cacheStatus    = status
                cacheTimestamp = agora
                callback(status)
            }
            .addOnFailureListener {
                // Falha de rede — se tinha cache anterior (mesmo expirado), usar
                val fallback = cacheStatus ?: semAcesso("Sem conexão. Faça login novamente.")
                callback(fallback)
            }
    }

    /** Invalida o cache (chamar após compra ou mudança de plano) */
    fun invalidarCache() {
        cacheStatus    = null
        cacheTimestamp = 0L
    }

    /** Cria o documento do usuário no Firestore com trial de 7 dias */
    fun criarDocumentoTrial(uid: String, email: String? = null, nome: String? = null) {
        val agora       = Date()
        val expiracao   = Date(agora.time + TimeUnit.DAYS.toMillis(TRIAL_DIAS))
        val dados = hashMapOf(
            "email"         to (email ?: auth.currentUser?.email ?: ""),
            "nome"          to (nome  ?: auth.currentUser?.displayName ?: ""),
            "plano"         to PLANO_TRIAL,
            "status"        to STATUS_ATIVO,
            "trialStart"    to agora,
            "dataExpiracao" to expiracao,
            "codigoPromo"   to null,
            "criadoEm"      to agora
        )
        db.collection("users").document(uid)
            .set(dados, SetOptions.merge())
    }

    /** Faz logout e invalida cache */
    fun logout() {
        invalidarCache()
        auth.signOut()
    }

    // ── Lógica interna ──────────────────────────────────────────────────

    private fun calcularStatus(data: Map<String, Any>): StatusLicenca {
        val plano  = data["plano"]  as? String ?: PLANO_TRIAL
        val status = data["status"] as? String ?: STATUS_ATIVO

        if (status == STATUS_BLOQUEADO || plano == PLANO_BLOQUEADO) {
            return StatusLicenca(
                temAcesso     = false,
                plano         = plano,
                status        = STATUS_BLOQUEADO,
                diasRestantes = 0,
                mensagem      = "Conta bloqueada. Entre em contato com o suporte."
            )
        }

        val expiracao = when (val v = data["dataExpiracao"]) {
            is com.google.firebase.Timestamp -> v.toDate()
            is Date                          -> v
            else                             -> null
        }

        // Sem data de expiração = acesso vitalício (ex: promo especial)
        if (expiracao == null) {
            return StatusLicenca(
                temAcesso     = true,
                plano         = plano,
                status        = STATUS_ATIVO,
                diasRestantes = 9999,
                mensagem      = nomePlano(plano)
            )
        }

        val agora         = Date()
        val msRestantes   = expiracao.time - agora.time
        val diasRestantes = TimeUnit.MILLISECONDS.toDays(msRestantes)

        return if (msRestantes > 0) {
            StatusLicenca(
                temAcesso     = true,
                plano         = plano,
                status        = STATUS_ATIVO,
                diasRestantes = diasRestantes,
                mensagem      = if (plano == PLANO_TRIAL)
                    "Trial — $diasRestantes dias restantes"
                else
                    "${nomePlano(plano)} — $diasRestantes dias restantes"
            )
        } else {
            StatusLicenca(
                temAcesso     = false,
                plano         = plano,
                status        = STATUS_EXPIRADO,
                diasRestantes = 0,
                mensagem      = if (plano == PLANO_TRIAL)
                    "Seu trial de $TRIAL_DIAS dias encerrou. Assine para continuar."
                else
                    "Seu plano ${nomePlano(plano)} expirou. Renove para continuar."
            )
        }
    }

    private fun semAcesso(mensagem: String) = StatusLicenca(
        temAcesso     = false,
        plano         = PLANO_BLOQUEADO,
        status        = STATUS_EXPIRADO,
        diasRestantes = 0,
        mensagem      = mensagem
    )

    private fun nomePlano(plano: String) = when (plano) {
        PLANO_TRIAL      -> "Trial gratuito"
        PLANO_MENSAL     -> "Plano Mensal"
        PLANO_TRIMESTRAL -> "Plano Trimestral"
        PLANO_ANUAL      -> "Plano Anual"
        PLANO_PROMO      -> "Acesso Promocional"
        else             -> "Sem plano"
    }
}
