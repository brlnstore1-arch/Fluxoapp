package com.fluxoapp

import android.animation.ValueAnimator
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

object ThemeHelper {

    // ── AZUL NOITE ──────────────────────────────────────────────────
    private fun corAzulNoite(chave: String): String = when (chave) {
        "bg_dark"      -> "#0A1628"
        "bg_card"      -> "#0F1E36"
        "bg_section"   -> "#132240"
        "text_white"   -> "#E8F0FE"
        "text_gray"    -> "#3A6090"
        "text_light"   -> "#7A9CC0"
        "accent"       -> "#00C8FF"
        "accent_gold"  -> "#00C8FF"
        "accent_green" -> "#00E676"
        "accent_red"   -> "#FF4560"
        "border"       -> "#1A3055"
        "toolbar"      -> "#0F1E36"
        "status_bar"   -> "#09162A"
        else           -> "#888888"
    }

    // ── AZUL DIA ────────────────────────────────────────────────────
    private fun corAzulDia(chave: String): String = when (chave) {
        "bg_dark"      -> "#E8F2FF"
        "bg_card"      -> "#D0E8FF"
        "bg_section"   -> "#B8D8F8"
        "text_white"   -> "#0A1E3C"
        "text_gray"    -> "#4A7AAA"
        "text_light"   -> "#5A8ABB"
        "accent"       -> "#0055BB"
        "accent_gold"  -> "#0055BB"
        "accent_green" -> "#00875A"
        "accent_red"   -> "#C0392B"
        "border"       -> "#88BBDD"
        "toolbar"      -> "#D0E8FF"
        "status_bar"   -> "#C0D8F0"
        else           -> "#555555"
    }

    // ── GOLD NOITE ──────────────────────────────────────────────────
    private fun corGoldNoite(chave: String): String = when (chave) {
        "bg_dark"      -> "#111111"
        "bg_card"      -> "#1C1C1C"
        "bg_section"   -> "#262626"
        "text_white"   -> "#F0EAD6"
        "text_gray"    -> "#8A7A60"
        "text_light"   -> "#A09070"
        "accent"       -> "#C9A84C"
        "accent_gold"  -> "#C9A84C"
        "accent_green" -> "#4CAF7D"
        "accent_red"   -> "#E05C5C"
        "border"       -> "#3A3020"
        "toolbar"      -> "#1C1C1C"
        "status_bar"   -> "#0A0A0A"
        else           -> "#888888"
    }

    // ── GOLD DIA ────────────────────────────────────────────────────
    private fun corGoldDia(chave: String): String = when (chave) {
        "bg_dark"      -> "#F5F0E8"
        "bg_card"      -> "#EDE8DC"
        "bg_section"   -> "#E0D8C8"
        "text_white"   -> "#1C1408"
        "text_gray"    -> "#7A6040"
        "text_light"   -> "#9A8060"
        "accent"       -> "#8A6010"
        "accent_gold"  -> "#8A6010"
        "accent_green" -> "#3A8A5A"
        "accent_red"   -> "#C0392B"
        "border"       -> "#C8B888"
        "toolbar"      -> "#EDE8DC"
        "status_bar"   -> "#E0D8C8"
        else           -> "#555555"
    }

    fun getTema(prefs: SharedPreferences): String =
        prefs.getString("tema_estilo", "gold") ?: "gold"

    fun isModoNoturno(prefs: SharedPreferences): Boolean {
        return when (prefs.getInt("modo_tema", -1)) {
            0    -> false
            1    -> true
            else -> {
                val hora = java.util.Calendar.getInstance()
                    .get(java.util.Calendar.HOUR_OF_DAY)
                hora >= 18 || hora < 6
            }
        }
    }

    fun cor(chave: String, prefs: SharedPreferences): Int {
        val noturno = isModoNoturno(prefs)
        val tema    = getTema(prefs)
        val hex = when {
            tema == "gold" && noturno  -> corGoldNoite(chave)
            tema == "gold" && !noturno -> corGoldDia(chave)
            noturno                    -> corAzulNoite(chave)
            else                       -> corAzulDia(chave)
        }
        return try { Color.parseColor(hex) } catch (_: Throwable) { Color.DKGRAY }
    }

    fun cor(chave: String, noturno: Boolean): Int {
        val hex = if (noturno) corAzulNoite(chave) else corAzulDia(chave)
        return try { Color.parseColor(hex) } catch (_: Throwable) { Color.DKGRAY }
    }

    fun animarLogoShimmer(tv: TextView, prefs: SharedPreferences) {
        tv.post {
            try {
                // Verificar se a view ainda está na tela
                if (!tv.isAttachedToWindow) return@post
                val w = tv.width.toFloat().takeIf { it > 0 } ?: return@post
                val corBase   = cor("accent", prefs)
                val r = Color.red(corBase); val g = Color.green(corBase); val b = Color.blue(corBase)
                val corShimmer = Color.argb(220, minOf(255, (r * 1.5f).toInt()),
                    minOf(255, (g * 1.5f).toInt()), minOf(255, (b * 1.5f).toInt()))
                val corBright  = Color.argb(180, minOf(255, (r * 1.2f).toInt()),
                    minOf(255, (g * 1.2f).toInt()), minOf(255, (b * 1.2f).toInt()))

                tv.tag?.let { if (it is ValueAnimator) it.cancel() }
                val animator = ValueAnimator.ofFloat(-w, w * 2f).apply {
                    duration     = 2200
                    startDelay   = 600
                    repeatCount  = ValueAnimator.INFINITE
                    repeatMode   = ValueAnimator.RESTART
                    interpolator = android.view.animation.LinearInterpolator()
                    addUpdateListener { anim ->
                        try {
                            if (!tv.isAttachedToWindow) { cancel(); return@addUpdateListener }
                            val x = anim.animatedValue as Float
                            val shader = LinearGradient(
                                x, 0f, x + w, 0f,
                                intArrayOf(corBase, corBase, corBright, corShimmer, corBright, corBase, corBase),
                                floatArrayOf(0f, 0.25f, 0.4f, 0.5f, 0.6f, 0.75f, 1f),
                                Shader.TileMode.CLAMP
                            )
                            tv.paint.shader = shader
                            tv.invalidate()
                        } catch (_: Throwable) {}
                    }
                }
                tv.tag = animator
                animator.start()
            } catch (_: Throwable) {}
        }
    }

    fun aplicarTema(context: Context, view: android.view.View) {
        val prefs = context.getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        view.setBackgroundColor(cor("bg_dark", prefs))
    }
}
