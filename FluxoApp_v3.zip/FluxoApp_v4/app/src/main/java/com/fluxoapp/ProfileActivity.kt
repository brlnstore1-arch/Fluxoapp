package com.fluxoapp

import android.app.Activity
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream

class ProfileActivity : AppCompatActivity() {

    private val PICK_IMAGE = 1001
    private lateinit var prefs: android.content.SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeSelector.aplicar(this)
        setContentView(R.layout.activity_profile)
        prefs = getSharedPreferences("FluxoApp", MODE_PRIVATE)
        aplicarTema()
        aplicarTemaGlobal()
        carregarDados()
        configurarBotoes()
    }

    private fun carregarDados() {
        findViewById<EditText>(R.id.etNome)?.setText(prefs.getString("perfil_nome", ""))
        findViewById<EditText>(R.id.etCidade)?.setText(prefs.getString("perfil_cidade", "Bragança - PA"))
        findViewById<EditText>(R.id.etStatus)?.setText(prefs.getString("perfil_status", "🚀 Trabalhando duro!"))

        val tipoVeiculo = prefs.getString("perfil_veiculo", "moto") ?: "moto"
        when (tipoVeiculo) {
            "moto"  -> findViewById<RadioButton>(R.id.rbMoto)?.isChecked  = true
            "carro" -> findViewById<RadioButton>(R.id.rbCarro)?.isChecked = true
            "bike"  -> findViewById<RadioButton>(R.id.rbBike)?.isChecked  = true
        }
        carregarFoto()
    }

    private fun carregarFoto() {
        val iv = findViewById<ImageView>(R.id.ivFotoGrande) ?: return
        val fotoPath = prefs.getString("perfil_foto", null)
        if (fotoPath != null) {
            try {
                val bmp = BitmapFactory.decodeFile(fotoPath)
                if (bmp != null) iv.setImageBitmap(circularCrop(bmp))
                else iv.setImageResource(android.R.drawable.ic_menu_myplaces)
            } catch (_: Throwable) {
                iv.setImageResource(android.R.drawable.ic_menu_myplaces)
            }
        } else {
            iv.setImageResource(android.R.drawable.ic_menu_myplaces)
        }
    }

    private fun configurarBotoes() {
        val accent = ThemeHelper.cor("accent_gold", prefs)
        val dp     = resources.displayMetrics.density

        findViewById<ImageButton>(R.id.btnVoltar)?.setOnClickListener { finish() }

        // Upload de foto
        findViewById<Button>(R.id.btnEscolherFoto)?.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(intent, PICK_IMAGE)
        }

        // Salvar
        findViewById<Button>(R.id.btnSalvarPerfil)?.setOnClickListener {
            val nome    = findViewById<EditText>(R.id.etNome)?.text?.toString()?.trim() ?: ""
            val cidade  = findViewById<EditText>(R.id.etCidade)?.text?.toString()?.trim() ?: ""
            val status  = findViewById<EditText>(R.id.etStatus)?.text?.toString()?.trim() ?: ""
            val veiculo = when {
                findViewById<RadioButton>(R.id.rbCarro)?.isChecked == true -> "carro"
                findViewById<RadioButton>(R.id.rbBike)?.isChecked  == true -> "bike"
                else -> "moto"
            }
            prefs.edit()
                .putString("perfil_nome", nome)
                .putString("perfil_cidade", cidade)
                .putString("perfil_status", status)
                .putString("perfil_veiculo", veiculo)
                .apply()
            FluxoToast.sucesso(this, "Perfil salvo com sucesso!")
            finish()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE && resultCode == Activity.RESULT_OK) {
            try {
                val uri: Uri = data?.data ?: return
                val bmp = MediaStore.Images.Media.getBitmap(contentResolver, uri)
                val circular = circularCrop(bmp)
                // Salvar localmente
                val file = File(filesDir, "perfil_foto.jpg")
                FileOutputStream(file).use { circular.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                prefs.edit().putString("perfil_foto", file.absolutePath).apply()
                findViewById<ImageView>(R.id.ivFotoGrande)?.setImageBitmap(circular)
                FluxoToast.sucesso(this, "Foto atualizada!")
            } catch (e: Throwable) {
                FluxoToast.erro(this, "Erro ao carregar foto")
            }
        }
    }

    private fun circularCrop(src: Bitmap): Bitmap {
        val size = minOf(src.width, src.height)
        val x    = (src.width  - size) / 2
        val y    = (src.height - size) / 2
        val sq   = Bitmap.createBitmap(src, x, y, size, size)
        val out  = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint  = Paint(Paint.ANTI_ALIAS_FLAG)
        canvas.drawCircle(size / 2f, size / 2f, size / 2f, paint)
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        canvas.drawBitmap(sq, 0f, 0f, paint)
        return out
    }

    private fun aplicarTema() {
        val p      = prefs
        val bg     = ThemeHelper.cor("bg_dark",     p)
        val bgCard = ThemeHelper.cor("bg_card",     p)
        val accent = ThemeHelper.cor("accent_gold", p)
        val txtW   = ThemeHelper.cor("text_white",  p)
        val txtG   = ThemeHelper.cor("text_gray",   p)
        val dp     = resources.displayMetrics.density

        try { findViewById<android.view.View>(R.id.rootLayout)?.setBackgroundColor(bg) } catch (_: Throwable) {}
        try { findViewById<ImageButton>(R.id.btnVoltar)?.setColorFilter(accent) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvTituloPerfil)?.setTextColor(accent) } catch (_: Throwable) {}

        // Campos de texto
        for (id in listOf(R.id.etNome, R.id.etCidade, R.id.etStatus)) {
            try {
                findViewById<EditText>(id)?.apply {
                    setTextColor(txtW); setHintTextColor(txtG)
                    background = GradientDrawable().apply {
                        setColor(bgCard); cornerRadius = 10f * dp
                        setStroke((1f * dp).toInt(), ThemeHelper.cor("border", p))
                    }
                }
            } catch (_: Throwable) {}
        }

        // Botão salvar
        try {
            findViewById<Button>(R.id.btnSalvarPerfil)?.apply {
                background = GradientDrawable().apply {
                    setColor(accent); cornerRadius = 12f * dp
                }
                setTextColor(Color.parseColor("#001A00"))
            }
        } catch (_: Throwable) {}

        // Botão escolher foto
        try {
            findViewById<Button>(R.id.btnEscolherFoto)?.apply {
                background = GradientDrawable().apply {
                    setColor(Color.TRANSPARENT); cornerRadius = 12f * dp
                    setStroke((1f * dp).toInt(), accent)
                }
                setTextColor(accent)
            }
        } catch (_: Throwable) {}

        // Radio buttons
        for (id in listOf(R.id.rbMoto, R.id.rbCarro, R.id.rbBike)) {
            try { findViewById<RadioButton>(id)?.setTextColor(txtW) } catch (_: Throwable) {}
        }

        // Moldura da foto
        try {
            findViewById<FrameLayout>(R.id.layoutFoto)?.background = GradientDrawable().apply {
                shape = 1 // 1 // OVAL
                setColor(Color.TRANSPARENT)
                setStroke((3f * dp).toInt(), accent)
            }
        } catch (_: Throwable) {}
    }
}
