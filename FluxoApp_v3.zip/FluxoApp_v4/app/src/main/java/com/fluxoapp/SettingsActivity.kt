package com.fluxoapp

import androidx.activity.result.contract.ActivityResultContracts
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    private val importLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri ?: return@registerForActivityResult
        importarCSVdaUri(uri)
    }
    private lateinit var prefs: SharedPreferences
    private lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeSelector.aplicar(this)
        setContentView(R.layout.activity_settings)
        prefs = getSharedPreferences("FluxoApp", MODE_PRIVATE)
        db = DatabaseHelper(this)
        aplicarTema()
        aplicarTemaGlobal()
        configurar()
    }

    private fun configurar() {
        findViewById<ImageButton>(R.id.btnVoltar).setOnClickListener { finish() }

        // TEMA VISUAL
        val rgTema = findViewById<android.widget.RadioGroup>(R.id.rgTemaEstilo)
        val rgModo = findViewById<android.widget.RadioGroup>(R.id.rgModoTema)

        if (rgTema != null && rgModo != null) {
            // Tema atual
            val temaAtual = prefs.getString("tema_estilo", "gold")
            if (temaAtual == "gold") rgTema.check(R.id.rbTemaGold)
            else rgTema.check(R.id.rbTemaAzul)

            // Modo atual
            when (prefs.getInt("modo_tema", -1)) {
                0    -> rgModo.check(R.id.rbModoDia)
                1    -> rgModo.check(R.id.rbModoNoite)
                else -> rgModo.check(R.id.rbModoAuto)
            }

            // Listener: salva preferência e reconstrói a activity (sem crash)
            rgTema.setOnCheckedChangeListener { _, id ->
                val tema = if (id == R.id.rbTemaGold) "gold" else "azul"
                prefs.edit().putString("tema_estilo", tema).apply()
                notificarTemaAtualizado()
                recreate()
            }
            rgModo.setOnCheckedChangeListener { _, id ->
                val modo = when (id) {
                    R.id.rbModoDia -> 0
                    R.id.rbModoNoite -> 1
                    else -> -1
                }
                prefs.edit().putInt("modo_tema", modo).apply()
                notificarTemaAtualizado()
                recreate()
            }
        }

        // DETECÇÃO
        val etMinimo = findViewById<EditText>(R.id.etMinimoKm)
        etMinimo.setText("%.2f".format(prefs.getFloat("minimo_km", 1.20f)))

        val etMinimoValor = findViewById<EditText>(R.id.etMinimoValor)
        etMinimoValor.setText("%.2f".format(prefs.getFloat("minimo_valor", 0f)))

        val sbTempo = findViewById<SeekBar>(R.id.sbTempoAceitar)
        val tvTempo = findViewById<TextView>(R.id.tvTempoAceitar)
        sbTempo.max = 9; sbTempo.progress = prefs.getInt("tempo_auto_aceitar", 3) - 1
        tvTempo.text = "${sbTempo.progress + 1}s"
        sbTempo.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) { tvTempo.text = "${p + 1}s" }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        val switchAutoAceitar = findViewById<Switch>(R.id.switchAutoAceitar)
        switchAutoAceitar.isChecked = prefs.getBoolean("auto_aceitar", true)

        val switchAutoRecusar = findViewById<Switch>(R.id.switchAutoRecusar)
        switchAutoRecusar.isChecked = prefs.getBoolean("auto_recusar", false)

        // SONS
        val switchSomAceitar = findViewById<Switch>(R.id.switchSomAceitar)
        switchSomAceitar.isChecked = prefs.getBoolean("som_aceitar", true)

        val switchSomRecusar = findViewById<Switch>(R.id.switchSomRecusar)
        switchSomRecusar.isChecked = prefs.getBoolean("som_recusar", false)

        val switchSomMeta = findViewById<Switch>(R.id.switchSomMeta)
        switchSomMeta.isChecked = prefs.getBoolean("som_meta", true)

        // BOTÃO FLUTUANTE
        val switchFlutuante = findViewById<Switch>(R.id.switchFlutuante)
        switchFlutuante.isChecked = prefs.getBoolean("flutuante_ativo", true)
        switchFlutuante.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) startService(Intent(this, FloatingEarningsService::class.java))
            else stopService(Intent(this, FloatingEarningsService::class.java))
        }

        val rgPosicao = findViewById<RadioGroup>(R.id.rgPosicaoFlutuante)
        if (prefs.getString("flutuante_posicao", "esquerda") == "direita")
            rgPosicao.check(R.id.rbDireita) else rgPosicao.check(R.id.rbEsquerda)

        // METAS
        val etMetaDiaria = findViewById<EditText>(R.id.etMetaDiaria)
        val meta = prefs.getFloat("meta_diaria", 0f)
        etMetaDiaria.setText(if (meta > 0) "%.2f".format(meta) else "")

        val etMetaSemanal = findViewById<EditText>(R.id.etMetaSemanal)
        val metaSem = prefs.getFloat("meta_semanal", 0f)
        etMetaSemanal.setText(if (metaSem > 0) "%.2f".format(metaSem) else "")

        val switchNotifMeta = findViewById<Switch>(R.id.switchNotifMeta)
        switchNotifMeta.isChecked = prefs.getBoolean("notif_meta", true)

        // DADOS
        findViewById<Button>(R.id.btnLimparHoje).setOnClickListener {
            mostrarConfirmacaoDestructiva(
                titulo = "Limpar corridas de hoje?",
                subtitulo = "Todas as corridas registradas hoje serão removidas.",
                textoBotao = "Sim, limpar hoje",
                textoSegundaEtapa = "Confirmar exclusão das corridas de hoje?",
                acao = { db.limparHoje(); FluxoToast.sucesso(this, "Corridas de hoje apagadas") }
            )
        }
        findViewById<Button>(R.id.btnLimparTudo).setOnClickListener {
            mostrarConfirmacaoDestructiva(
                titulo = "Apagar TODO o histórico?",
                subtitulo = "Esta ação é IRREVERSÍVEL. Todas as corridas salvas serão perdidas permanentemente.",
                textoBotao = "Sim, apagar tudo",
                textoSegundaEtapa = "Tem certeza absoluta? Não há como recuperar.",
                acao = { db.limparTudo(); FluxoToast.sucesso(this, "Histórico apagado") }
            )
        }
        findViewById<Button>(R.id.btnExportar).setOnClickListener { exportarCSV() }
        findViewById<Button>(R.id.btnImportar)?.setOnClickListener {
            importLauncher.launch("text/*")
        }

        // SALVAR
        findViewById<Button>(R.id.btnSalvarConfig).setOnClickListener { salvar(
            etMinimo, etMinimoValor, sbTempo, switchAutoAceitar, switchAutoRecusar,
            switchSomAceitar, switchSomRecusar, switchSomMeta,
            switchFlutuante, rgPosicao, etMetaDiaria, etMetaSemanal, switchNotifMeta
        )}
    }

    private fun salvar(
        etMinimo: EditText, etMinimoValor: EditText, sbTempo: SeekBar,
        switchAutoAceitar: Switch, switchAutoRecusar: Switch,
        switchSomAceitar: Switch, switchSomRecusar: Switch, switchSomMeta: Switch,
        switchFlutuante: Switch, rgPosicao: RadioGroup,
        etMetaDiaria: EditText, etMetaSemanal: EditText, switchNotifMeta: Switch
    ) {
        val minKm = etMinimo.text.toString().replace(",", ".").toFloatOrNull() ?: 1.20f
        val minValor = etMinimoValor.text.toString().replace(",", ".").toFloatOrNull() ?: 0f
        val metaDiaria = etMetaDiaria.text.toString().replace(",", ".").toFloatOrNull() ?: 0f
        val metaSemanal = etMetaSemanal.text.toString().replace(",", ".").toFloatOrNull() ?: 0f
        val posicao = if (rgPosicao.checkedRadioButtonId == R.id.rbDireita) "direita" else "esquerda"

        prefs.edit()
            .putFloat("minimo_km", minKm)
            .putFloat("minimo_valor", minValor)
            .putInt("tempo_auto_aceitar", sbTempo.progress + 1)
            .putBoolean("auto_aceitar", switchAutoAceitar.isChecked)
            .putBoolean("auto_recusar", switchAutoRecusar.isChecked)
            .putBoolean("som_aceitar", switchSomAceitar.isChecked)
            .putBoolean("som_recusar", switchSomRecusar.isChecked)
            .putBoolean("som_meta", switchSomMeta.isChecked)
            .putBoolean("flutuante_ativo", switchFlutuante.isChecked)
            .putString("flutuante_posicao", posicao)
            .putFloat("meta_diaria", metaDiaria)
            .putFloat("meta_semanal", metaSemanal)
            .putBoolean("notif_meta", switchNotifMeta.isChecked)
            .apply()

        FluxoToast.sucesso(this, "Configurações salvas!")
        startService(Intent(this, FloatingEarningsService::class.java).apply { action = "ATUALIZAR" })
    }

    private fun exportarCSV() {
        val corridas = db.buscarTodas()
        if (corridas.isEmpty()) { FluxoToast.aviso(this, "Nenhuma corrida para exportar"); return }
        val sb = StringBuilder("Data,Hora,HoraInicio,HoraFim,Valor,KM,GanhoKM,ValeAPena,Origem,Destino,Pagamento,Passageiro,Tempo\n")
        corridas.forEach { c ->
            val orig = c.origem.replace("\"", "'")
            val dest = c.destino.replace("\"", "'")
            sb.append("${c.data},${c.hora},${c.horaInicio},${c.horaFim},${c.valor},${c.kmTotal},${c.ganhoPorKm},${if (c.valeAPena) "Sim" else "Nao"},\"$orig\",\"$dest\",${c.formaPagamento},${c.passageiro},${c.tempoExecucao}\n")
        }
        val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
        val file = java.io.File(downloadsDir, "fluxoapp_historico.csv")
        file.writeText(sb.toString())
        try {
            val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.provider", file)
            val share = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(android.content.Intent.createChooser(share, "Salvar CSV"))
        } catch (_: Throwable) {
            FluxoToast.sucesso(this, "Arquivo exportado com sucesso!")
        }
    }

    private fun importarCSVdaUri(uri: android.net.Uri) {
        try {
            val linhas = contentResolver.openInputStream(uri)?.bufferedReader()?.readLines() ?: return
            if (linhas.size < 2) { FluxoToast.erro(this, "Arquivo vazio ou inválido"); return }
            var importadas = 0; var ignoradas = 0
            val sdfData = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault())
            for (linha in linhas.drop(1)) {
                if (linha.isBlank()) continue
                try {
                    val cols = parseCsvLine(linha)
                    val valor = cols.getOrElse(4) { "0" }.toFloatOrNull() ?: 0f
                    if (valor <= 0f || cols.size < 5) { ignoradas++; continue }

                    // Converter data+hora do CSV em timestamp real
                    val dataStr = cols.getOrElse(0) { "" }
                    val horaStr = cols.getOrElse(1) { "" }.ifBlank { "00:00" }
                    val timestamp = try {
                        sdfData.parse("$dataStr $horaStr")?.time ?: System.currentTimeMillis()
                    } catch (_: Throwable) { System.currentTimeMillis() }

                    // Derivar mes e ano da data real
                    val cal = java.util.Calendar.getInstance().apply { timeInMillis = timestamp }
                    val mes = "%02d/%04d".format(cal.get(java.util.Calendar.MONTH) + 1, cal.get(java.util.Calendar.YEAR))
                    val ano = "%04d".format(cal.get(java.util.Calendar.YEAR))

                    db.inserirCorrida(Corrida(
                        valor          = valor,
                        kmTotal        = cols.getOrElse(5)  { "0" }.toFloatOrNull() ?: 0f,
                        ganhoPorKm     = cols.getOrElse(6)  { "0" }.toFloatOrNull() ?: 0f,
                        valeAPena      = cols.getOrElse(7)  { "Nao" }.equals("Sim", ignoreCase = true),
                        timestamp      = timestamp,
                        data           = dataStr,
                        hora           = cols.getOrElse(1)  { "" },
                        mes            = mes,
                        ano            = ano,
                        horaInicio     = cols.getOrElse(2)  { "" },
                        horaFim        = cols.getOrElse(3)  { "" },
                        origem         = cols.getOrElse(8)  { "" },
                        destino        = cols.getOrElse(9)  { "" },
                        formaPagamento = cols.getOrElse(10) { "" },
                        passageiro     = cols.getOrElse(11) { "" },
                        tempoExecucao  = cols.getOrElse(12) { "" }
                    ))
                    importadas++
                } catch (_: Throwable) { ignoradas++ }
            }
            FluxoToast.sucesso(this, "$importadas corridas importadas! ($ignoradas ignoradas)")
        } catch (e: Throwable) {
            FluxoToast.erro(this, "Erro ao importar: ${e.message}")
        }
    }

    private fun parseCsvLine(line: String): List<String> {
        val result = mutableListOf<String>(); var current = StringBuilder(); var inQuotes = false
        for (ch in line) { when { ch == '"' -> inQuotes = !inQuotes; ch == ',' && !inQuotes -> { result.add(current.toString().trim()); current = StringBuilder() }; else -> current.append(ch) } }
        result.add(current.toString().trim()); return result
    }

    private fun aplicarTema() {
        val p      = getSharedPreferences("FluxoApp", android.content.Context.MODE_PRIVATE)
        val bg     = ThemeHelper.cor("bg_dark",     p)
        val bgCard = ThemeHelper.cor("bg_card",     p)
        val accent = ThemeHelper.cor("accent_gold", p)
        val txtW   = ThemeHelper.cor("text_white",  p)
        val txtG   = ThemeHelper.cor("text_gray",   p)
        val border = ThemeHelper.cor("border",      p)
        val dp     = resources.displayMetrics.density

        fun gdSolid(cor: Int, r: Float) =
            android.graphics.drawable.GradientDrawable().apply {
                setColor(cor); cornerRadius = r * dp
            }
        fun gdOutline(r: Float) =
            android.graphics.drawable.GradientDrawable().apply {
                setColor(android.graphics.Color.TRANSPARENT)
                cornerRadius = r * dp
                setStroke((1.5f * dp).toInt(), accent)
            }

        // Root background
        try { findViewById<android.view.View>(R.id.rootLayout)?.setBackgroundColor(bg) } catch (_: Throwable) {}

        // Botão voltar
        try { findViewById<android.widget.ImageButton>(R.id.btnVoltar)?.setColorFilter(accent) } catch (_: Throwable) {}

        // Botões de outline (Exportar, Importar, LimparHoje, LimparTudo)
        for (id in listOf(R.id.btnExportar, R.id.btnImportar, R.id.btnLimparHoje, R.id.btnLimparTudo)) {
            try {
                findViewById<android.widget.Button>(id)?.apply {
                    background = gdOutline(10f)
                    setTextColor(accent)
                }
            } catch (_: Throwable) {}
        }

        // Botão sólido (Salvar)
        try {
            findViewById<android.widget.Button>(R.id.btnSalvarConfig)?.apply {
                background = gdSolid(accent, 10f)
                setTextColor(android.graphics.Color.BLACK)
            }
        } catch (_: Throwable) {}

        // RadioButtons de tema
        for (id in listOf(R.id.rbTemaAzul, R.id.rbTemaGold, R.id.rbModoDia, R.id.rbModoNoite, R.id.rbModoAuto)) {
            try { findViewById<android.widget.RadioButton>(id)?.setTextColor(txtW) } catch (_: Throwable) {}
        }

        // SeekBar e textos
        try { findViewById<android.widget.SeekBar>(R.id.sbTempoAceitar)?.progressTintList =
            android.content.res.ColorStateList.valueOf(accent) } catch (_: Throwable) {}
        try { findViewById<android.widget.TextView>(R.id.tvTempoAceitar)?.setTextColor(accent) } catch (_: Throwable) {}

        // Recolorir TODOS os Switches com a cor do tema
        val switchIds = listOf(
            R.id.switchAutoAceitar, R.id.switchAutoRecusar,
            R.id.switchSomAceitar, R.id.switchSomRecusar,
            R.id.switchSomMeta, R.id.switchFlutuante, R.id.switchNotifMeta
        )
        val accentStateList = android.content.res.ColorStateList.valueOf(accent)
        for (id in switchIds) {
            try {
                findViewById<android.widget.Switch>(id)?.apply {
                    thumbTintList = accentStateList
                    trackTintList = android.content.res.ColorStateList.valueOf(
                        android.graphics.Color.argb(80,
                            android.graphics.Color.red(accent),
                            android.graphics.Color.green(accent),
                            android.graphics.Color.blue(accent))
                    )
                }
            } catch (_: Throwable) {}
        }

        // Percorrer TODOS os TextViews da tela e aplicar a cor correta
        // Resolve o problema de contraste no Gold Dia onde text_white é quase preto
        // Iteração segura com fila — sem recursão, sem StackOverflow
        try {
            val raizSettings = findViewById<android.view.View>(R.id.rootLayout) ?: return
            val fila = ArrayDeque<android.view.View>()
            fila.add(raizSettings)
            while (fila.isNotEmpty()) {
                val v = fila.removeFirst()
                if (v is android.widget.TextView &&
                    v !is android.widget.Button &&
                    v !is android.widget.RadioButton &&
                    v !is android.widget.Switch) {
                    try {
                        val tag = v.tag?.toString() ?: ""
                        when {
                            tag == "accent" -> v.setTextColor(accent)
                            tag == "gray"   -> v.setTextColor(txtG)
                            else            -> v.setTextColor(txtW)
                        }
                    } catch (_: Throwable) {}
                }
                if (v is android.view.ViewGroup) {
                    for (i in 0 until v.childCount) {
                        try { v.getChildAt(i)?.let { fila.add(it) } } catch (_: Throwable) {}
                    }
                }
            }
        } catch (_: Throwable) {}

        // EditTexts — cor do texto e hint explícitas para todos os temas
        val editIds = listOf(
            R.id.etMinimoKm, R.id.etMinimoValor,
            R.id.etMetaDiaria, R.id.etMetaSemanal
        )
        for (id in editIds) {
            try {
                findViewById<android.widget.EditText>(id)?.apply {
                    setTextColor(txtW)
                    setHintTextColor(android.graphics.Color.argb(100,
                        android.graphics.Color.red(txtW),
                        android.graphics.Color.green(txtW),
                        android.graphics.Color.blue(txtW)))
                    background = android.graphics.drawable.GradientDrawable().apply {
                        setColor(bgCard)
                        cornerRadius = 6f * dp
                        setStroke((1f * dp).toInt(), border)
                    }
                }
            } catch (_: Throwable) {}
        }

        // Cards com fundo correto
        for (id in listOf(R.id.rootLayout)) {
            try { findViewById<android.view.View>(id)?.setBackgroundColor(bg) } catch (_: Throwable) {}
        }
    }

    // Notifica todos os serviços ativos sobre a mudança de tema
    private fun notificarTemaAtualizado() {
        try {
            // Broadcast para FloatingEarningsService
            sendBroadcast(android.content.Intent(FloatingEarningsService.ACTION_TEMA))
        } catch (_: Throwable) {}
        try {
            // Intent direto também (dupla garantia)
            startService(android.content.Intent(this, FloatingEarningsService::class.java).apply {
                action = FloatingEarningsService.ACTION_TEMA
            })
        } catch (_: Throwable) {}
    }

    // ── CONFIRMAÇÃO DESTRUTIVA EM 2 ETAPAS ──────────────────
    private fun mostrarConfirmacaoDestructiva(
        titulo: String,
        subtitulo: String,
        textoBotao: String,
        textoSegundaEtapa: String,
        acao: () -> Unit
    ) {
        val p   = getSharedPreferences("FluxoApp", android.content.Context.MODE_PRIVATE)
        val red = ThemeHelper.cor("accent_red", p)
        val bg  = ThemeHelper.cor("bg_card", p)
        val txtG = ThemeHelper.cor("text_gray", p)
        val accent = ThemeHelper.cor("accent_gold", p)
        val dp  = resources.displayMetrics.density

        // ─── ETAPA 1 ───────────────────────────────────────
        val root1 = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(bg); cornerRadius = 20f * dp
                setStroke((2f * dp).toInt(), red)
            }
            setPadding((24*dp).toInt(), (24*dp).toInt(), (24*dp).toInt(), (20*dp).toInt())
        }
        root1.addView(android.widget.TextView(this).apply {
            text = "⚠️  $titulo"
            textSize = 16f; setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(red); gravity = android.view.Gravity.CENTER
            setPadding(0, 0, 0, (10*dp).toInt())
        })
        root1.addView(android.widget.TextView(this).apply {
            text = subtitulo
            textSize = 12f; setTextColor(txtG)
            gravity = android.view.Gravity.CENTER
            setPadding(0, 0, 0, (20*dp).toInt())
        })
        val btns1 = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
        }
        fun mkBtn(texto: String, fill: Boolean, cor: Int): android.widget.TextView {
            return android.widget.TextView(this).apply {
                text = texto; textSize = 13f
                setTypeface(null, android.graphics.Typeface.BOLD)
                gravity = android.view.Gravity.CENTER
                layoutParams = android.widget.LinearLayout.LayoutParams(
                    0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f
                ).apply { setMargins((4*dp).toInt(), 0, (4*dp).toInt(), 0) }
                setPadding((8*dp).toInt(), (12*dp).toInt(), (8*dp).toInt(), (12*dp).toInt())
                background = android.graphics.drawable.GradientDrawable().apply {
                    if (fill) setColor(cor) else setColor(android.graphics.Color.TRANSPARENT)
                    cornerRadius = 10f * dp
                    if (!fill) setStroke((1.5f * dp).toInt(), cor)
                }
                setTextColor(if (fill) android.graphics.Color.WHITE else cor)
            }
        }
        val btnCancelar1 = mkBtn("Cancelar", false, accent)
        val btnSim1      = mkBtn(textoBotao, true, red)
        btns1.addView(btnCancelar1); btns1.addView(btnSim1)
        root1.addView(btns1)

        val dialog1 = AlertDialog.Builder(this).setView(root1).create()
        dialog1.window?.setBackgroundDrawable(
            android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT))
        btnCancelar1.setOnClickListener { dialog1.dismiss() }
        btnSim1.setOnClickListener {
            dialog1.dismiss()

            // ─── ETAPA 2 (segunda confirmação) ────────────
            val root2 = android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.VERTICAL
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(bg); cornerRadius = 20f * dp
                    setStroke((2f * dp).toInt(), red)
                }
                setPadding((24*dp).toInt(), (24*dp).toInt(), (24*dp).toInt(), (20*dp).toInt())
            }
            root2.addView(android.widget.TextView(this).apply {
                text = "🚨  Última confirmação"
                textSize = 16f; setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(red); gravity = android.view.Gravity.CENTER
                setPadding(0, 0, 0, (10*dp).toInt())
            })
            root2.addView(android.widget.TextView(this).apply {
                text = textoSegundaEtapa
                textSize = 13f; setTextColor(txtG)
                gravity = android.view.Gravity.CENTER
                setPadding(0, 0, 0, (20*dp).toInt())
            })
            val btns2 = android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.HORIZONTAL
            }
            val btnCancelar2 = mkBtn("Não, voltar", false, accent)
            val btnApagar2   = mkBtn("✓ Confirmar", true, red)
            btns2.addView(btnCancelar2); btns2.addView(btnApagar2)
            root2.addView(btns2)

            val dialog2 = AlertDialog.Builder(this).setView(root2).create()
            dialog2.window?.setBackgroundDrawable(
                android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT))
            btnCancelar2.setOnClickListener { dialog2.dismiss() }
            btnApagar2.setOnClickListener {
                dialog2.dismiss()
                acao()
            }
            dialog2.show()
        }
        dialog1.show()
    }
}
