#!/usr/bin/env python3
"""
FluxoBot — Envia ZIP pro GitHub, monitora compilação e devolve o APK + link de download
"""

import os, sys, json, base64, time, threading, zipfile, io
import urllib.request, urllib.error, urllib.parse

# ══════════════════════════════════════════════
TELEGRAM_TOKEN = "8061123558:AAEkm3K2oSy95YIT45Vfro-Nu1uTHdwQaGw"
GITHUB_TOKEN   = "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"
REPO_OWNER     = "brlnstore1-arch"
REPO_NAME      = "Fluxoapp"
ARQUIVO_REPO   = "FluxoApp_v4.zip"
SEU_CHAT_ID    = 6279148786
ARTIFACT_NAME  = "FluxoApp-release"
# ══════════════════════════════════════════════

TELEGRAM_API = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}"
GH_HEADERS   = {
    "Authorization": f"token {GITHUB_TOKEN}",
    "Accept": "application/vnd.github.v3+json",
    "User-Agent": "FluxoBot"
}

# ── TELEGRAM ──────────────────────────────────

def enviar_mensagem(chat_id, texto):
    url     = f"{TELEGRAM_API}/sendMessage"
    payload = json.dumps({"chat_id": chat_id, "text": str(texto)}).encode()
    req     = urllib.request.Request(url, data=payload,
              headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read())
    except Exception as e:
        print(f"Erro enviar_mensagem: {e}")

def enviar_arquivo_bytes(chat_id, conteudo_bytes, nome_arquivo, legenda=""):
    boundary = "FluxoBotBoundary99"
    partes   = []
    partes.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"chat_id\"\r\n\r\n{chat_id}")
    if legenda:
        partes.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"caption\"\r\n\r\n{legenda}")
    header_arq = (
        f"--{boundary}\r\n"
        f"Content-Disposition: form-data; name=\"document\"; filename=\"{nome_arquivo}\"\r\n"
        f"Content-Type: application/octet-stream\r\n\r\n"
    )
    body = ("\r\n".join(partes) + "\r\n").encode()
    body += header_arq.encode() + conteudo_bytes + f"\r\n--{boundary}--\r\n".encode()
    url = f"{TELEGRAM_API}/sendDocument"
    req = urllib.request.Request(url, data=body,
          headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            return json.loads(r.read())
    except Exception as e:
        print(f"Erro enviar_arquivo: {e}")
        enviar_mensagem(chat_id, f"Erro ao enviar arquivo: {e}")

def get_updates(offset):
    url = f"{TELEGRAM_API}/getUpdates?offset={offset}&timeout=30"
    try:
        with urllib.request.urlopen(url, timeout=35) as r:
            return json.loads(r.read())
    except:
        return {}

def baixar_arquivo_tg(file_id):
    url = f"{TELEGRAM_API}/getFile?file_id={file_id}"
    try:
        with urllib.request.urlopen(url, timeout=30) as r:
            data = json.loads(r.read())
        url2 = f"https://api.telegram.org/file/bot{TELEGRAM_TOKEN}/{data['result']['file_path']}"
        with urllib.request.urlopen(url2, timeout=60) as r:
            return r.read()
    except Exception as e:
        print(f"Erro download TG: {e}")
        return None

# ── GITHUB ────────────────────────────────────

def obter_sha():
    url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/contents/{ARQUIVO_REPO}"
    try:
        req = urllib.request.Request(url, headers=GH_HEADERS)
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read()).get("sha")
    except urllib.error.HTTPError as e:
        if e.code == 404: return None
        raise

def enviar_github(conteudo_bytes):
    try:
        sha     = obter_sha()
        url     = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/contents/{ARQUIVO_REPO}"
        payload = {
            "message": "Atualizacao via FluxoBot",
            "content": base64.b64encode(conteudo_bytes).decode()
        }
        if sha:
            payload["sha"] = sha
        req = urllib.request.Request(url,
              data=json.dumps(payload).encode(),
              headers={**GH_HEADERS, "Content-Type": "application/json"},
              method="PUT")
        with urllib.request.urlopen(req, timeout=60) as r:
            result = json.loads(r.read())
            return True, result.get("commit", {}).get("sha", "")[:7]
    except urllib.error.HTTPError as e:
        try:    msg = json.loads(e.read()).get("message", str(e))
        except: msg = str(e)
        return False, msg
    except Exception as e:
        return False, str(e)

def obter_ultimo_run():
    url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/actions/runs?per_page=1"
    try:
        req = urllib.request.Request(url, headers=GH_HEADERS)
        with urllib.request.urlopen(req, timeout=30) as r:
            runs = json.loads(r.read()).get("workflow_runs", [])
        if runs:
            r = runs[0]
            return r["id"], r["status"], r.get("conclusion"), r.get("html_url","")
    except Exception as e:
        print(f"Erro obter_ultimo_run: {e}")
    return None, None, None, None

# ── NOVA FUNÇÃO: CRIAR RELEASE E RETORNAR LINK ──

def criar_release_e_obter_link(run_id, apk_bytes, tag=None):
    """
    Cria uma GitHub Release, faz upload do APK e retorna o link direto de download.
    """
    # Gerar tag com timestamp se não informada
    if not tag:
        tag = f"v{time.strftime('%Y%m%d-%H%M%S')}"

    # 1. Criar a Release
    url_release = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/releases"
    payload = {
        "tag_name": tag,
        "name": f"FluxoApp {tag}",
        "body": f"Build automático via FluxoBot\nRun ID: {run_id}",
        "draft": False,
        "prerelease": False
    }
    try:
        req = urllib.request.Request(
            url_release,
            data=json.dumps(payload).encode(),
            headers={**GH_HEADERS, "Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=30) as r:
            release = json.loads(r.read())

        release_id    = release["id"]
        upload_url    = release["upload_url"].replace("{?name,label}", "")
        html_url      = release["html_url"]

        # 2. Fazer upload do APK na Release
        nome_apk = f"FluxoApp-{tag}.apk"
        upload_req = urllib.request.Request(
            f"{upload_url}?name={nome_apk}",
            data=apk_bytes,
            headers={
                **GH_HEADERS,
                "Content-Type": "application/octet-stream"
            },
            method="POST"
        )
        with urllib.request.urlopen(upload_req, timeout=120) as r:
            asset = json.loads(r.read())

        link_direto = asset.get("browser_download_url", "")
        return True, link_direto, html_url, tag

    except Exception as e:
        return False, str(e), "", tag

def baixar_apk(run_id):
    url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/actions/runs/{run_id}/artifacts"
    try:
        req = urllib.request.Request(url, headers=GH_HEADERS)
        with urllib.request.urlopen(req, timeout=30) as r:
            artifacts = json.loads(r.read()).get("artifacts", [])

        artifact = None
        for a in artifacts:
            if a["name"] == ARTIFACT_NAME:
                artifact = a
                break
        if not artifact and artifacts:
            artifact = artifacts[0]
        if not artifact:
            return None, "Nenhum artifact encontrado"

        artifact_id = artifact["id"]
        print(f"Artifact: {artifact['name']} id={artifact_id}")

        dl_api = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/actions/artifacts/{artifact_id}/zip"

        class NoRedirect(urllib.request.HTTPErrorProcessor):
            def http_response(self, req, resp): return resp
            https_response = http_response

        opener = urllib.request.build_opener(NoRedirect)
        req2   = urllib.request.Request(dl_api, headers=GH_HEADERS)
        with opener.open(req2, timeout=30) as r:
            codigo = r.getcode()
            if codigo in (301, 302, 303, 307, 308):
                azure_url = r.headers.get("Location", "")
                if not azure_url:
                    return None, "Redirect sem Location"
                with urllib.request.urlopen(azure_url, timeout=120) as r2:
                    zip_bytes = r2.read()
            elif codigo == 200:
                zip_bytes = r.read()
            else:
                return None, f"HTTP {codigo} inesperado"

        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
            apk_names = [n for n in zf.namelist() if n.endswith(".apk")]
            if not apk_names:
                return None, "APK não encontrado no artifact"
            apk_bytes = zf.read(apk_names[0])
            print(f"APK extraído: {apk_names[0]} ({len(apk_bytes)/1024/1024:.1f} MB)")
            return apk_bytes, apk_names[0]

    except Exception as e:
        return None, str(e)

def baixar_log_erro(run_id):
    url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/actions/runs/{run_id}/jobs"
    try:
        req = urllib.request.Request(url, headers=GH_HEADERS)
        with urllib.request.urlopen(req, timeout=30) as r:
            jobs = json.loads(r.read()).get("jobs", [])

        linhas = ["=== LOG DE ERRO DA COMPILAÇÃO ===\n\n"]
        for job in jobs:
            if job.get("conclusion") == "failure":
                linhas.append(f"JOB: {job['name']}\n")
                for step in job.get("steps", []):
                    status = step.get("conclusion", step.get("status",""))
                    linhas.append(f"  [{status.upper()}] {step['name']}\n")
                linhas.append("\n")

        log_url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/actions/runs/{run_id}/logs"
        try:
            req2 = urllib.request.Request(log_url, headers=GH_HEADERS)
            try:
                with urllib.request.urlopen(req2, timeout=60) as r:
                    log_zip = r.read()
            except urllib.error.HTTPError as e:
                if e.code in (301, 302):
                    loc = e.headers.get("Location","")
                    with urllib.request.urlopen(loc, timeout=60) as r:
                        log_zip = r.read()
                else:
                    log_zip = b""

            if log_zip:
                with zipfile.ZipFile(io.BytesIO(log_zip)) as zf:
                    for nome in zf.namelist():
                        conteudo = zf.read(nome).decode("utf-8", errors="replace")
                        if "error" in conteudo.lower() or "failed" in conteudo.lower():
                            linhas.append(f"\n=== {nome} ===\n")
                            for linha in conteudo.split("\n"):
                                if any(w in linha.lower() for w in ["error", "failed", "exception", "e: "]):
                                    linhas.append(linha + "\n")
        except Exception as e:
            linhas.append(f"\n(Log detalhado indisponível: {e})\n")

        return "".join(linhas)
    except Exception as e:
        return f"Erro ao buscar log: {e}"

# ── MONITORAMENTO ─────────────────────────────

def monitorar_compilacao(chat_id, run_id_antes):
    time.sleep(10)
    timeout     = 0
    run_id_novo = None

    while timeout < 55:
        time.sleep(10)
        timeout += 1

        run_id, status, conclusion, url = obter_ultimo_run()
        if run_id is None:
            continue
        if run_id == run_id_antes and run_id_antes is not None:
            continue

        run_id_novo = run_id

        if status == "completed":
            if conclusion == "success":
                enviar_mensagem(chat_id, "✅ COMPILAÇÃO OK! Baixando APK...")

                apk_bytes, info = baixar_apk(run_id_novo)
                if apk_bytes:
                    tamanho = len(apk_bytes) / 1024 / 1024

                    # Criar Release e obter link de download
                    enviar_mensagem(chat_id, f"📦 APK pronto! ({tamanho:.1f} MB)\nCriando Release no GitHub...")
                    ok, link_direto, link_release, tag = criar_release_e_obter_link(run_id_novo, apk_bytes)

                    if ok:
                        # Enviar APK pelo Telegram
                        enviar_arquivo_bytes(
                            chat_id,
                            apk_bytes,
                            f"FluxoApp-{tag}.apk",
                            f"✅ FluxoApp {tag} — {tamanho:.1f} MB"
                        )
                        # Enviar links separados
                        enviar_mensagem(chat_id,
                            f"🔗 Link direto de download:\n{link_direto}\n\n"
                            f"📋 Release completa:\n{link_release}\n\n"
                            f"💡 Use esse link para enviar aos usuários!"
                        )
                    else:
                        # Se criar release falhou, envia o APK mesmo assim
                        enviar_arquivo_bytes(
                            chat_id,
                            apk_bytes,
                            "FluxoApp-release.apk",
                            f"✅ FluxoApp atualizado! ({tamanho:.1f} MB)"
                        )
                        enviar_mensagem(chat_id,
                            f"⚠️ Não consegui criar a Release automática: {link_direto}\n"
                            f"APK enviado acima. Crie a release manualmente se precisar do link."
                        )
                else:
                    enviar_mensagem(chat_id,
                        f"✅ Compilação OK, mas não consegui baixar o APK: {info}\n"
                        f"Baixe em: github.com/{REPO_OWNER}/{REPO_NAME}/actions"
                    )

            elif conclusion == "failure":
                enviar_mensagem(chat_id, "❌ COMPILAÇÃO FALHOU! Buscando log...")
                log = baixar_log_erro(run_id_novo)
                enviar_arquivo_bytes(
                    chat_id,
                    log.encode("utf-8"),
                    "erro_compilacao.txt",
                    "❌ Log de erro da compilação"
                )
            else:
                enviar_mensagem(chat_id, f"⚠️ Compilação encerrada: {conclusion}\n{url}")
            return

        elif status in ("in_progress", "queued", "waiting", "requested"):
            continue

    enviar_mensagem(chat_id,
        "⏰ Tempo limite atingido. Verifique:\n"
        f"github.com/{REPO_OWNER}/{REPO_NAME}/actions"
    )

# ── PROCESSAMENTO ─────────────────────────────

def processar(msg):
    chat_id   = msg.get("chat", {}).get("id")
    texto     = msg.get("text", "")
    documento = msg.get("document")

    if chat_id != SEU_CHAT_ID:
        enviar_mensagem(chat_id, "Acesso nao autorizado.")
        return

    if texto == "/start":
        enviar_mensagem(chat_id,
            "FluxoBot pronto!\n\n"
            "Mande o FluxoApp_v4.zip e eu:\n"
            "  1. Envio pro GitHub\n"
            "  2. Monitoro a compilacao\n"
            "  3. Te mando o APK\n"
            "  4. Crio a Release no GitHub\n"
            "  5. Te mando o link direto de download\n\n"
            "Comandos:\n"
            "/status — Ver ultima compilacao\n"
            "/apk    — Baixar APK da ultima build\n"
            "/link   — Pegar link da ultima Release"
        )
        return

    if texto == "/status":
        run_id, status, conclusion, url = obter_ultimo_run()
        if run_id:
            icone = "✅" if conclusion == "success" else "❌" if conclusion == "failure" else "⏳"
            enviar_mensagem(chat_id,
                f"{icone} Ultima compilacao:\n"
                f"Status: {status}\n"
                f"Resultado: {conclusion or 'em andamento'}"
            )
        else:
            enviar_mensagem(chat_id, "Nenhuma compilacao encontrada.")
        return

    if texto == "/apk":
        run_id, status, conclusion, _ = obter_ultimo_run()
        if conclusion == "success" and run_id:
            enviar_mensagem(chat_id, "Baixando APK da ultima build...")
            apk_bytes, info = baixar_apk(run_id)
            if apk_bytes:
                enviar_arquivo_bytes(chat_id, apk_bytes, "FluxoApp-release.apk",
                    "APK da ultima compilacao bem-sucedida")
            else:
                enviar_mensagem(chat_id, f"Nao consegui baixar: {info}")
        else:
            enviar_mensagem(chat_id, f"Ultima build: {conclusion or status}. Nao ha APK disponivel.")
        return

    if texto == "/link":
        # Buscar a última release criada
        url_rel = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/releases/latest"
        try:
            req = urllib.request.Request(url_rel, headers=GH_HEADERS)
            with urllib.request.urlopen(req, timeout=30) as r:
                release = json.loads(r.read())
            tag      = release.get("tag_name", "—")
            html_url = release.get("html_url", "")
            assets   = release.get("assets", [])
            apk_link = ""
            for a in assets:
                if a["name"].endswith(".apk"):
                    apk_link = a["browser_download_url"]
                    break
            msg_link = f"📋 Ultima Release: {tag}\n\n"
            if apk_link:
                msg_link += f"🔗 Link direto APK:\n{apk_link}\n\n"
            msg_link += f"📋 Release completa:\n{html_url}"
            enviar_mensagem(chat_id, msg_link)
        except Exception as e:
            enviar_mensagem(chat_id, f"Nenhuma release encontrada: {e}")
        return

    if documento:
        nome = documento.get("file_name", "")
        kb   = documento.get("file_size", 0) / 1024

        if not nome.lower().endswith(".zip"):
            enviar_mensagem(chat_id, "Mande um arquivo .zip")
            return

        enviar_mensagem(chat_id,
            f"Recebido: {nome} ({kb:.0f} KB)\n"
            "Validando e enviando pro GitHub..."
        )

        conteudo = baixar_arquivo_tg(documento.get("file_id"))
        if not conteudo:
            enviar_mensagem(chat_id, "Erro ao baixar. Tente de novo.")
            return

        # Validar que é um zip válido com a estrutura esperada
        try:
            with zipfile.ZipFile(io.BytesIO(conteudo)) as zf:
                arquivos = zf.namelist()
                tem_gradle = any("build.gradle" in a for a in arquivos)
                tem_manifest = any("AndroidManifest.xml" in a for a in arquivos)
                if not (tem_gradle and tem_manifest):
                    enviar_mensagem(chat_id,
                        "⚠️ ZIP inválido: não parece ser um projeto Android.\n"
                        "Certifique-se de enviar o FluxoApp_v4.zip correto.")
                    return
        except Exception as e:
            enviar_mensagem(chat_id, f"⚠️ ZIP corrompido ou inválido: {e}")
            return

        run_id_antes, _, _, _ = obter_ultimo_run()
        sucesso, resultado = enviar_github(conteudo)

        if sucesso:
            enviar_mensagem(chat_id,
                f"✅ Enviado! Commit: {resultado}\n"
                "Monitorando compilacao... Pode levar 2-5 min."
            )
            threading.Thread(
                target=monitorar_compilacao,
                args=(chat_id, run_id_antes),
                daemon=True
            ).start()
        else:
            enviar_mensagem(chat_id, f"Erro ao enviar pro GitHub:\n{resultado}")
        return

    enviar_mensagem(chat_id, "Mande o FluxoApp_v4.zip")

# ── MAIN ──────────────────────────────────────

def main():
    print("FluxoBot iniciado!")
    print(f"Repositorio: {REPO_OWNER}/{REPO_NAME}")
    print("Aguardando mensagens... (Ctrl+C para parar)\n")

    ultimo = 0
    while True:
        try:
            result = get_updates(ultimo + 1)
            if result.get("ok"):
                for upd in result.get("result", []):
                    ultimo = upd["update_id"]
                    msg = upd.get("message")
                    if msg:
                        tipo = "arquivo" if msg.get("document") else msg.get("text","")[:25]
                        print(f"[{time.strftime('%H:%M:%S')}] {tipo}")
                        processar(msg)
        except KeyboardInterrupt:
            print("\nBot encerrado.")
            break
        except Exception as e:
            print(f"Erro: {e}")
            time.sleep(5)

if __name__ == "__main__":
    main()
