# FluxoApp ProGuard Rules

# Manter classes do app intactas para o AccessibilityService funcionar
-keep class com.fluxoapp.MaximAccessibilityService { *; }
-keep class com.fluxoapp.OverlayService { *; }
-keep class com.fluxoapp.FloatingEarningsService { *; }
-keep class com.fluxoapp.FluxoWidgetProvider { *; }

# Manter data classes (DatabaseHelper, Corrida, Abastecimento)
-keep class com.fluxoapp.DatabaseHelper { *; }
-keepclassmembers class com.fluxoapp.** {
    public <init>(...);
}

# MPAndroidChart
-keep class com.github.mikephil.charting.** { *; }

# Material Components
-keep class com.google.android.material.** { *; }

# AndroidX
-keep class androidx.** { *; }

# Não remover enums
-keepclassmembers enum * { *; }

# Manter Parcelable
-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}
