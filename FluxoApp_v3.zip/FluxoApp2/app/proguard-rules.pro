# ──────────────────────────────────────────────────────────────
# FluxoApp — ProGuard / R8 Rules
# ──────────────────────────────────────────────────────────────

# Data classes usadas pelo SQLite (campos mapeados por nome)
-keep class com.fluxoapp.Corrida { *; }
-keep class com.fluxoapp.Abastecimento { *; }

# Componentes Android (Activities, Services, Receivers)
-keep class com.fluxoapp.MaximAccessibilityService { *; }
-keep class com.fluxoapp.FloatingEarningsService { *; }
-keep class com.fluxoapp.OverlayService { *; }
-keep class com.fluxoapp.FluxoWidgetProvider { *; }
-keep class com.fluxoapp.*Activity { *; }

# Manter nomes de enums (usados em when/switch com reflection)
-keepclassmembers enum * { *; }

# MPAndroidChart
-keep class com.github.mikephil.charting.** { *; }
-dontwarn com.github.mikephil.charting.**

# Kotlin Coroutines / metadata
-keepattributes *Annotation*, InnerClasses, Signature, SourceFile, LineNumberTable
-keep class kotlin.Metadata { *; }

# Suppress warnings desnecessários do AndroidX
-dontwarn androidx.**
