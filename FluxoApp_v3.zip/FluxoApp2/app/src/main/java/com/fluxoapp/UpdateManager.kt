package com.fluxoapp

import android.app.Activity
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.content.FileProvider
import com.google.firebase.firestore.FirebaseFirestore
import java.io.File

/**
 * UpdateManager — FluxoApp
 *
 * Verifica a coleção "updates/latest" no Firestore e,
 * se houver versão nova, exibe um pop-up bonito com:
 *  - Título e descrição da atualização
 *  - Barra de progresso do download
 *  - Botão de instalar após concluir
 *  - Modo obrigatório (sem fechar) ou opcional
 *
 * Estrutura Firestore  updates/latest:
 *   versionCode:  Int
 *   versionName:  String
 *   titulo:       String
 *   descricao:    String
 *   apkUrl:       String   (Firebase Storage download URL)
 *   obrigatoria:  Boolean
 *   tamanhoMb:    Double
 *   criadoEm:     Timestamp
 */
object UpdateManager {

    private val db     get() = FirebaseFirestore.getInstance()
    private val handler = Handler(Looper.getMainLooper())

    // IDs dos downloads ativos (para não baixar duas vezes)
    private var downloadId: Long = -1L
    private var apkFile: File?   = null

    // ── Verificar atualização ─────────────────────────────────────────

    fun verificar(activity: Activity) {
        if (activity.isFinishing || activity.isDestroyed) return
        try {
            val versionCodeAtual = activity.packageManager
                .getPackageInfo(activity.packageName, 0).versionCode

            db.collection("updates").document("latest").get()
                .addOnSuccessListener { doc ->
                    if (!doc.exists()) return@addOnSuccessListener
                    val novaVersao = doc.getLong("versionCode")?.toInt() ?: 0
                    if (novaVersao <= versionCodeAtual) return@addOnSuccessListener

                    val titulo     = doc.getString("titulo")     ?: "Nova versão disponível!"
                    val descricao  = doc.getString("descricao")  ?: "Melhorias e correções de bugs."
                    val apkUrl     = doc.getString("apkUrl")     ?: return@addOnSuccessListener
                    val versionName= doc.getString("versionName")?: ""
                    val obrigat    = doc.getBoolean("obrigatoria")?: false
                    val tamanhoMb  = doc.getDouble("tamanhoMb")  ?: 0.0

                    handler.post {
                        if (!activity.isFinishing && !activity.isDestroyed) {
                            exibirDialogAtualizacao(
                                activity, titulo, descricao, versionName,
                                apkUrl, obrigat, tamanhoMb
                            )
                        }
                    }
                }
                .addOnFailureListener { /* silencioso */ }
        } catch (_: Throwable) {}
    }

    // ── Dialog de atualização ─────────────────────────────────────────

    private fun exibirDialogAtualizacao(
        activity: Activity,
        titulo: String,
        descricao: String,
        versionName: String,
        apkUrl: String,
        obrigatoria: Boolean,
        tamanhoMb: Double
    ) {
        if (activity.isFinishing || activity.isDestroyed) return
        try {
            val prefs  = activity.getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
            val dp     = activity.resources.displayMetrics.density
            val accent = ThemeHelper.cor("accent",       prefs)
            val bgCard = ThemeHelper.cor("bg_card",      prefs)
            val bgDark = ThemeHelper.cor("bg_dark",      prefs)
            val txtW   = ThemeHelper.cor("text_white",   prefs)
            val txtG   = ThemeHelper.cor("text_gray",    prefs)
            val green  = ThemeHelper.cor("accent_green", prefs)
            val border = ThemeHelper.cor("border",       prefs)

            // ── Root overlay ──────────────────────────────────────────
            val decorView = activity.window.decorView as FrameLayout
            val overlay = FrameLayout(activity).apply {
                setBackgroundColor(Color.argb(180, 0, 0, 0))
                layoutParams = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
                elevation = 100 * dp
            }

            // ── Card principal ────────────────────────────────────────
            val card = LinearLayout(activity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding((24*dp).toInt(), (24*dp).toInt(), (24*dp).toInt(), (24*dp).toInt())
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 24 * dp
                    setColor(bgCard)
                    setStroke((1.5f*dp).toInt(), border)
                }
                elevation = 16 * dp
                layoutParams = FrameLayout.LayoutParams(
                    (FrameLayout.LayoutParams.MATCH_PARENT),
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER
                ).also {
                    val m = (20*dp).toInt()
                    it.setMargins(m, 0, m, 0)
                }
            }

            // Ícone + badge nova versão
            val headerRow = LinearLayout(activity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).also { it.bottomMargin = (16*dp).toInt() }
            }
            val icone = TextView(activity).apply {
                text = "🚀"
                textSize = 32f
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).also { it.marginEnd = (12*dp).toInt() }
            }
            val headerTexts = LinearLayout(activity).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val tvTitulo = TextView(activity).apply {
                text = titulo
                textSize = 17f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                setTextColor(txtW)
            }
            val tvBadge = TextView(activity).apply {
                text = if (versionName.isNotBlank()) "v$versionName" else "Nova versão"
                textSize = 11f
                setTextColor(accent)
                setPadding((8*dp).toInt(), (3*dp).toInt(), (8*dp).toInt(), (3*dp).toInt())
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 20 * dp
                    setColor(Color.argb(40,
                        Color.red(accent), Color.green(accent), Color.blue(accent)))
                }
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).also { it.topMargin = (4*dp).toInt() }
            }
            headerTexts.addView(tvTitulo)
            headerTexts.addView(tvBadge)

            // Badge obrigatória
            if (obrigatoria) {
                val tvObrig = TextView(activity).apply {
                    text = "⚠️ Obrigatória"
                    textSize = 10f
                    setTextColor(Color.parseColor("#FF6B6B"))
                    setPadding((8*dp).toInt(), (3*dp).toInt(), (8*dp).toInt(), (3*dp).toInt())
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = 20 * dp
                        setColor(Color.argb(30, 239, 68, 68))
                    }
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).also { it.marginStart = (8*dp).toInt() }
                }
                headerRow.addView(icone)
                headerRow.addView(headerTexts)
                headerRow.addView(tvObrig)
            } else {
                headerRow.addView(icone)
                headerRow.addView(headerTexts)
            }

            // Divisor
            val divisor = View(activity).apply {
                setBackgroundColor(border)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, (1*dp).toInt()
                ).also { it.bottomMargin = (16*dp).toInt() }
            }

            // Descrição
            val tvDesc = TextView(activity).apply {
                text = descricao
                textSize = 13f
                setTextColor(txtG)
                setLineSpacing(0f, 1.4f)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).also { it.bottomMargin = (20*dp).toInt() }
            }

            // Tamanho do arquivo
            val tvTamanho = TextView(activity).apply {
                text = if (tamanhoMb > 0) "📦 Tamanho: ${"%.1f".format(tamanhoMb)} MB" else ""
                textSize = 11f
                setTextColor(txtG)
                visibility = if (tamanhoMb > 0) View.VISIBLE else View.GONE
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).also { it.bottomMargin = (16*dp).toInt() }
            }

            // Progress bar (inicialmente oculta)
            val progressLayout = LinearLayout(activity).apply {
                orientation = LinearLayout.VERTICAL
                visibility = View.GONE
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).also { it.bottomMargin = (16*dp).toInt() }
            }
            val tvProgresso = TextView(activity).apply {
                text = "Baixando..."
                textSize = 12f
                setTextColor(accent)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).also { it.bottomMargin = (8*dp).toInt() }
            }
            val progressBar = ProgressBar(activity, null,
                android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progress = 0
                progressTintList = android.content.res.ColorStateList.valueOf(accent)
                progressBackgroundTintList = android.content.res.ColorStateList.valueOf(border)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, (6*dp).toInt()
                )
            }
            progressLayout.addView(tvProgresso)
            progressLayout.addView(progressBar)

            // Botões
            val btnRow = LinearLayout(activity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.END
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }

            val btnFechar = TextView(activity).apply {
                text = "Depois"
                textSize = 14f
                setTextColor(txtG)
                setPadding((16*dp).toInt(), (12*dp).toInt(), (16*dp).toInt(), (12*dp).toInt())
                visibility = if (obrigatoria) View.GONE else View.VISIBLE
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).also { it.marginEnd = (8*dp).toInt() }
            }

            val btnBaixar = TextView(activity).apply {
                text = "⬇️  Baixar agora"
                textSize = 14f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                setTextColor(bgDark)
                setPadding((20*dp).toInt(), (12*dp).toInt(), (20*dp).toInt(), (12*dp).toInt())
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 12 * dp
                    setColor(accent)
                }
            }

            btnRow.addView(btnFechar)
            btnRow.addView(btnBaixar)

            // Montar card
            card.addView(headerRow)
            card.addView(divisor)
            card.addView(tvDesc)
            card.addView(tvTamanho)
            card.addView(progressLayout)
            card.addView(btnRow)

            overlay.addView(card)
            decorView.addView(overlay)

            // ── Animação de entrada ───────────────────────────────────
            card.alpha = 0f
            card.translationY = 60 * dp
            card.animate().alpha(1f).translationY(0f).setDuration(350)
                .setInterpolator(android.view.animation.DecelerateInterpolator()).start()

            // ── Ações ─────────────────────────────────────────────────
            btnFechar.setOnClickListener {
                card.animate().alpha(0f).translationY(40 * dp).setDuration(250).withEndAction {
                    try { decorView.removeView(overlay) } catch (_: Throwable) {}
                }.start()
            }

            btnBaixar.setOnClickListener {
                btnBaixar.text = "Baixando..."
                btnBaixar.isEnabled = false
                btnFechar.isEnabled = false
                progressLayout.visibility = View.VISIBLE
                tvTamanho.visibility = View.GONE

                iniciarDownload(activity, apkUrl, progressBar, tvProgresso) { arquivo ->
                    // Download concluído
                    apkFile = arquivo
                    progressLayout.visibility = View.GONE

                    btnBaixar.text = "✅  Instalar agora"
                    btnBaixar.isEnabled = true
                    btnBaixar.setTextColor(bgDark)
                    btnBaixar.background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = 12 * dp
                        setColor(green)
                    }

                    btnBaixar.setOnClickListener {
                        instalarApk(activity, arquivo)
                    }
                }
            }

            // Se obrigatória, bloquear botão voltar na activity
            if (obrigatoria) {
                overlay.isFocusableInTouchMode = true
                overlay.requestFocus()
            }

        } catch (_: Throwable) {}
    }

    // ── Download do APK ───────────────────────────────────────────────

    private fun iniciarDownload(
        activity: Activity,
        url: String,
        progressBar: ProgressBar,
        tvProgresso: TextView,
        onConcluido: (File) -> Unit
    ) {
        try {
            val nomeArquivo = "FluxoApp_update.apk"
            val destino = File(
                activity.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),
                nomeArquivo
            )
            // Limpar download anterior
            if (destino.exists()) destino.delete()

            val dm = activity.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val request = DownloadManager.Request(Uri.parse(url)).apply {
                setTitle("FluxoApp — Baixando atualização")
                setDescription("Aguarde...")
                setDestinationUri(Uri.fromFile(destino))
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
                setAllowedOverMetered(true)
                setAllowedOverRoaming(true)
            }

            downloadId = dm.enqueue(request)

            // Receiver para quando concluir
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(ctx: Context?, intent: Intent?) {
                    val id = intent?.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1) ?: -1
                    if (id == downloadId) {
                        try { activity.unregisterReceiver(this) } catch (_: Throwable) {}
                        handler.post {
                            if (!activity.isFinishing) onConcluido(destino)
                        }
                    }
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                activity.registerReceiver(
                    receiver,
                    IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
                    Context.RECEIVER_EXPORTED
                )
            } else {
                activity.registerReceiver(
                    receiver,
                    IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
                )
            }

            // Polling de progresso a cada 500ms
            monitorarProgresso(activity, dm, progressBar, tvProgresso)

        } catch (e: Throwable) {
            FluxoToast.erro(activity, "Erro ao iniciar download: ${e.message}")
        }
    }

    private fun monitorarProgresso(
        activity: Activity,
        dm: DownloadManager,
        progressBar: ProgressBar,
        tvProgresso: TextView
    ) {
        handler.postDelayed({
            if (activity.isFinishing || activity.isDestroyed) return@postDelayed
            try {
                val query = DownloadManager.Query().setFilterById(downloadId)
                val cursor = dm.query(query)
                if (cursor.moveToFirst()) {
                    val baixado = cursor.getLong(
                        cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                    val total = cursor.getLong(
                        cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                    val status = cursor.getInt(
                        cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))

                    if (total > 0) {
                        val pct = ((baixado.toFloat() / total) * 100).toInt()
                        progressBar.progress = pct
                        val baixadoMb = baixado / (1024f * 1024f)
                        val totalMb   = total   / (1024f * 1024f)
                        tvProgresso.text = "Baixando... ${"%.1f".format(baixadoMb)}/${"%.1f".format(totalMb)} MB  ($pct%)"
                    }

                    cursor.close()

                    // Continua monitorando se ainda está baixando
                    if (status == DownloadManager.STATUS_RUNNING ||
                        status == DownloadManager.STATUS_PENDING) {
                        monitorarProgresso(activity, dm, progressBar, tvProgresso)
                    }
                } else {
                    cursor.close()
                }
            } catch (_: Throwable) {}
        }, 500)
    }

    // ── Instalar APK ──────────────────────────────────────────────────

    private fun instalarApk(activity: Activity, arquivo: File) {
        try {
            val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                FileProvider.getUriForFile(
                    activity,
                    "${activity.packageName}.provider",
                    arquivo
                )
            } else {
                Uri.fromFile(arquivo)
            }

            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            // Verificar permissão de instalar apps desconhecidos (API 26+)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (!activity.packageManager.canRequestPackageInstalls()) {
                    android.app.AlertDialog.Builder(activity)
                        .setTitle("Permissão necessária")
                        .setMessage("Para instalar a atualização, permita a instalação de apps desconhecidos nas configurações.")
                        .setPositiveButton("Abrir configurações") { _, _ ->
                            activity.startActivity(Intent(
                                android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                Uri.parse("package:${activity.packageName}")
                            ))
                        }
                        .setNegativeButton("Cancelar", null)
                        .show()
                    return
                }
            }

            activity.startActivity(intent)
        } catch (e: Throwable) {
            FluxoToast.erro(activity, "Erro ao instalar: ${e.message}")
        }
    }
}
