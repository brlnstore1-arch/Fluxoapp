package com.fluxoapp

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.concurrent.Executors

class PixPaymentActivity : AppCompatActivity() {

    private val executor   = Executors.newSingleThreadExecutor()
    private val handler    = Handler(Looper.getMainLooper())
    private var paymentId  = ""
    private var qrCodeTexto = ""
    private var verificando = false
    private var countDown: CountDownTimer? = null
    private var runnableVerificacao: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeSelector.aplicar(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pix_payment)
        aplicarTema()
        gerarPix()
    }

    private fun aplicarTema() {
        val prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val dp    = resources.displayMetrics.density

        val bgDark  = ThemeHelper.cor("bg_dark",     prefs)
        val accent  = ThemeHelper.cor("accent",      prefs)
        val txtW    = ThemeHelper.cor("text_white",  prefs)
        val txtG    = ThemeHelper.cor("text_gray",   prefs)
        val green   = ThemeHelper.cor("accent_green", prefs)
        val border  = ThemeHelper.cor("border",      prefs)

        findViewById<View>(R.id.rootPix).setBackgroundColor(bgDark)
        findViewById<TextView>(R.id.tvTituloPix).setTextColor(accent)
        findViewById<TextView>(R.id.tvValorPix).setTextColor(accent)
        findViewById<TextView>(R.id.tvStatusPagamento).setTextColor(txtG)
        findViewById<View>(R.id.viewDivisorPix).setBackgroundColor(border)

        // Botão copiar
        val btnCopiar = findViewById<Button>(R.id.btnCopiarPix)
        btnCopiar.backgroundTintList = null
        GradientDrawable().apply {
            setColor(accent); cornerRadius = 12 * dp
        }.also { btnCopiar.background = it }
        btnCopiar.setTextColor(bgDark)

        // Botão continuar (aprovado)
        val btnContinuar = findViewById<Button>(R.id.btnContinuar)
        btnContinuar.backgroundTintList = null
        GradientDrawable().apply {
            setColor(green); cornerRadius = 12 * dp
        }.also { btnContinuar.background = it }
        btnContinuar.setTextColor(bgDark)

        // Botão tentar novamente
        val btnTentar = findViewById<Button>(R.id.btnTentarNovamente)
        btnTentar.backgroundTintList = null
        GradientDrawable().apply {
            setColor(accent); cornerRadius = 12 * dp
        }.also { btnTentar.background = it }
        btnTentar.setTextColor(bgDark)
    }

    private fun gerarPix() {
        mostrarLayout("loading")

        val uid   = LicenseManager.uid()    ?: return mostrarErro("Usuário não identificado")
        val email = LicenseManager.email()  ?: "usuario@fluxoapp.com"
        val prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val nome  = prefs.getString("perfil_nome", "Motorista") ?: "Motorista"

        executor.execute {
            val result = PaymentManager.criarPixPagamento(nome, email, uid)
            handler.post {
                if (!result.sucesso) {
                    mostrarErro(result.erro)
                    return@post
                }

                paymentId   = result.paymentId
                qrCodeTexto = result.qrCodeTexto

                // Exibir QR Code
                if (result.qrCodeBase64.isNotEmpty()) {
                    try {
                        val bytes  = Base64.decode(result.qrCodeBase64, Base64.DEFAULT)
                        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        findViewById<ImageView>(R.id.ivQrCode).setImageBitmap(bitmap)
                    } catch (_: Exception) {
                        // Se falhar o decode, só mostra o código texto
                    }
                }

                // Código PIX truncado
                val codigoTruncado = if (qrCodeTexto.length > 60)
                    qrCodeTexto.take(60) + "..." else qrCodeTexto
                findViewById<TextView>(R.id.tvCodigoPix).text = codigoTruncado

                mostrarLayout("qr")
                configurarBotoes()
                iniciarContagem30min()
                iniciarVerificacaoStatus()
            }
        }
    }

    private fun configurarBotoes() {
        // Copiar código PIX
        findViewById<Button>(R.id.btnCopiarPix).setOnClickListener {
            val clip = ClipboardManager::class.java
            val cm   = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("PIX FluxoApp", qrCodeTexto))
            Toast.makeText(this, "Código PIX copiado!", Toast.LENGTH_SHORT).show()
        }

        // Continuar após aprovação
        findViewById<Button>(R.id.btnContinuar).setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            })
            finish()
        }

        // Tentar novamente em caso de erro
        findViewById<Button>(R.id.btnTentarNovamente).setOnClickListener {
            gerarPix()
        }
    }

    private fun iniciarVerificacaoStatus() {
        if (verificando) return
        verificando = true

        val intervaloMs = 5_000L  // verifica a cada 5 segundos

        fun verificar() {
            if (paymentId.isEmpty() || isFinishing) return

            executor.execute {
                val result = PaymentManager.verificarStatusPagamento(paymentId)
                handler.post {
                    when (result.status) {
                        "approved" -> {
                            verificando = false
                            cancelarVerificacao()
                            ativarPlanoPosAprovacao()
                        }
                        "rejected", "cancelled" -> {
                            verificando = false
                            cancelarVerificacao()
                            mostrarErro("Pagamento não aprovado. Tente novamente.")
                        }
                        "pending", "in_process" -> {
                            // Continua aguardando
                            runnableVerificacao = Runnable { verificar() }
                            handler.postDelayed(runnableVerificacao!!, intervaloMs)
                        }
                        else -> {
                            // Erro de rede — tenta de novo
                            runnableVerificacao = Runnable { verificar() }
                            handler.postDelayed(runnableVerificacao!!, intervaloMs * 2)
                        }
                    }
                }
            }
        }

        // Primeira verificação após 5s
        runnableVerificacao = Runnable { verificar() }
        handler.postDelayed(runnableVerificacao!!, intervaloMs)
    }

    private fun ativarPlanoPosAprovacao() {
        val uid = LicenseManager.uid() ?: return
        PaymentManager.ativarPlano(uid, PaymentManager.planoMensal, paymentId) { sucesso ->
            runOnUiThread {
                if (sucesso) {
                    mostrarLayout("aprovado")
                } else {
                    // Plano aprovado no MP mas falhou ao salvar — mostrar mensagem específica
                    mostrarLayout("aprovado")
                    Toast.makeText(this,
                        "Pagamento aprovado! Se o acesso não abrir, reinicie o app.",
                        Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun iniciarContagem30min() {
        val totalMs = 30 * 60 * 1000L
        countDown = object : CountDownTimer(totalMs, 1_000L) {
            override fun onTick(msRestantes: Long) {
                val min = msRestantes / 60_000
                val seg = (msRestantes % 60_000) / 1_000
                val tv  = findViewById<TextView>(R.id.tvExpiracao) ?: return
                tv.text = "PIX válido por %02d:%02d".format(min, seg)
            }
            override fun onFinish() {
                val tv = findViewById<TextView>(R.id.tvExpiracao) ?: return
                tv.text = "PIX expirado — gere um novo"
                cancelarVerificacao()
                verificando = false
            }
        }.start()
    }

    private fun cancelarVerificacao() {
        runnableVerificacao?.let { handler.removeCallbacks(it) }
        runnableVerificacao = null
        countDown?.cancel()
    }

    private fun mostrarLayout(qual: String) {
        findViewById<LinearLayout>(R.id.layoutLoading).visibility =
            if (qual == "loading") View.VISIBLE else View.GONE
        findViewById<LinearLayout>(R.id.layoutQr).visibility =
            if (qual == "qr") View.VISIBLE else View.GONE
        findViewById<LinearLayout>(R.id.layoutAprovado).visibility =
            if (qual == "aprovado") View.VISIBLE else View.GONE
        findViewById<LinearLayout>(R.id.layoutErro).visibility =
            if (qual == "erro") View.VISIBLE else View.GONE
    }

    private fun mostrarErro(msg: String) {
        mostrarLayout("erro")
        findViewById<TextView>(R.id.tvMsgErro).text = msg
    }

    override fun onDestroy() {
        super.onDestroy()
        cancelarVerificacao()
        executor.shutdown()
    }
}
