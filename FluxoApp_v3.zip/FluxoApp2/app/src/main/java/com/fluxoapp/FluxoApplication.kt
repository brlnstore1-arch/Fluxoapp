package com.fluxoapp

import android.app.Application
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory

/**
 * FluxoApplication — ponto de inicialização do app.
 *
 * O App Check é ativado aqui, antes de qualquer chamada ao Firebase.
 * Ele verifica que as requisições ao Firestore/Auth vêm do APK real,
 * assinado com sua keystore, bloqueando apps modificados ou chamadas diretas à API.
 *
 * Configuração necessária no Firebase Console:
 *   1. Acesse firebase.google.com → seu projeto → App Check
 *   2. Registre o app Android → escolha "Play Integrity"
 *   3. Ative enforcement em "Firestore" e "Authentication"
 */
class FluxoApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        FirebaseApp.initializeApp(this)
        configurarAppCheck()
    }

    private fun configurarAppCheck() {
        val appCheck = FirebaseAppCheck.getInstance()

        if (BuildConfig.DEBUG) {
            // Em debug: usa o provider de debug para não bloquear testes locais.
            // O token de debug aparece no Logcat — adicione-o no Firebase Console → App Check → Apps → Debug tokens
            appCheck.installAppCheckProviderFactory(
                com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory.getInstance()
            )
        } else {
            // Em release: Play Integrity verifica que é o APK real assinado com sua keystore
            appCheck.installAppCheckProviderFactory(
                PlayIntegrityAppCheckProviderFactory.getInstance()
            )
        }
    }
}
