package com.fluxoapp

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

/**
 * ApagarDadosActivity — FluxoApp
 *
 * Tela crítica de apagamento de dados com confirmação em 2 etapas.
 * Acessada pelo menu hambúrguer.
 */
class ApagarDadosActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private lateinit var prefs: android.content.SharedPreferences

    override fun attachBaseContext(base: android.content.Context) {
        super.attachBaseContext(FontHelper.wrap(base))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeSelector.aplicar(this)
        super.onCreate(savedInstanceState)
        db    = DatabaseHelper(this)
        prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        construirTela()
    }

    private fun construirTela() {
        val p      = prefs
        val bgDark = ThemeHelper.cor("bg_dark",    p)
        val bgCard = ThemeHelper.cor("bg_card",    p)
        val accent = ThemeHelper.cor("accent",     p)
        val txtW   = ThemeHelper.cor("text_white", p)
        val txtG   = ThemeHelper.cor("text_gray",  p)
        val red    = ThemeHelper.cor("accent_red", p)
        val border = ThemeHelper.cor("border",     p)
        val dp     = resources.displayMetrics.density

        val scroll = ScrollView(this).apply { setBackgroundColor(bgDark) }
        val root   = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, (32 * dp).toInt())
        }

        // Toolbar
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity     = android.view.Gravity.CENTER_VERTICAL
            setBackgroundColor(bgCard)
            setPadding((8 * dp).toInt(), 0, (16 * dp).toInt(), 0)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (56 * dp).toInt()
            )
        }
        val btnVoltar = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_media_previous)
            setColorFilter(accent)
            setBackgroundColor(android.graphics.Color.TRANSPARENT)
            layoutParams = LinearLayout.LayoutParams((44 * dp).toInt(), (44 * dp).toInt())
            setOnClickListener { finish() }
        }
        toolbar.addView(btnVoltar)
        toolbar.addView(TextView(this).apply {
            text = "⚠️  APAGAR DADOS"
            textSize = 17f; setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(red)
            setPadding((6 * dp).toInt(), 0, 0, 0)
        })
        root.addView(toolbar)

        // Aviso geral
        root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.argb(30,
                android.graphics.Color.red(red), android.graphics.Color.green(red), android.graphics.Color.blue(red)))
            setPadding((20 * dp).toInt(), (16 * dp).toInt(), (20 * dp).toInt(), (16 * dp).toInt())
            addView(TextView(this@ApagarDadosActivity).apply {
                text = "⚠️  Atenção — ações irreversíveis"
                textSize = 14f; setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(red); setPadding(0, 0, 0, (6 * dp).toInt())
            })
            addView(TextView(this@ApagarDadosActivity).apply {
                text = "Os dados apagados não podem ser recuperados. Leia com atenção antes de confirmar."
                textSize = 12f; setTextColor(txtG); lineSpacingMultiplier = 1.4f
            })
        })

        fun spacer() = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (16 * dp).toInt()
            )
        }

        // Card: Apagar corridas de hoje
        root.addView(spacer())
        root.addView(buildCard(
            titulo    = "🗑️  Apagar corridas de hoje",
            descricao = "Remove todas as corridas registradas hoje.\n\n" +
                        "• O histórico de dias anteriores fica intacto\n" +
                        "• O total de ganhos do dia vai para zero\n" +
                        "• Não afeta abastecimentos ou quilometragem",
            corBorda  = red,
            bgCard    = bgCard,
            txtW      = txtW,
            txtG      = txtG,
            red       = red,
            accent    = accent,
            dp        = dp,
            labelBtn  = "Apagar corridas de hoje",
            confirmMsg = "Confirma apagar TODAS as corridas de hoje?\n\nEsta ação é irreversível.",
            onConfirm = {
                db.limparHoje()
                FluxoToast.sucesso(this, "Corridas de hoje apagadas")
                finish()
            }
        ))

        // Card: Apagar todo o histórico
        root.addView(spacer())
        root.addView(buildCard(
            titulo    = "💀  Apagar todo o histórico",
            descricao = "Remove TODAS as corridas, de todos os dias.\n\n" +
                        "• Histórico completo será zerado\n" +
                        "• Relatórios e gráficos ficarão vazios\n" +
                        "• Abastecimentos e quilometragem são mantidos",
            corBorda  = red,
            bgCard    = bgCard,
            txtW      = txtW,
            txtG      = txtG,
            red       = red,
            accent    = accent,
            dp        = dp,
            labelBtn  = "Apagar TODO o histórico",
            confirmMsg = "⚠️ ATENÇÃO ⚠️\n\nConfirma apagar TODO o histórico de corridas?\n\nEsta ação é PERMANENTE e irreversível.",
            onConfirm = {
                db.limparTudo()
                FluxoToast.sucesso(this, "Histórico completo apagado")
                finish()
            }
        ))

        scroll.addView(root)
        setContentView(scroll)
    }

    private fun buildCard(
        titulo: String, descricao: String, corBorda: Int,
        bgCard: Int, txtW: Int, txtG: Int, red: Int, accent: Int,
        dp: Float, labelBtn: String, confirmMsg: String,
        onConfirm: () -> Unit
    ): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background  = android.graphics.drawable.GradientDrawable().apply {
                setColor(bgCard)
                cornerRadius = 14f * dp
                setStroke((2f * dp).toInt(), corBorda)
            }
            setPadding((20 * dp).toInt(), (18 * dp).toInt(), (20 * dp).toInt(), (18 * dp).toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { setMargins((16 * dp).toInt(), 0, (16 * dp).toInt(), 0) }
        }

        card.addView(TextView(this).apply {
            text = titulo; textSize = 15f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(red); setPadding(0, 0, 0, (10 * dp).toInt())
        })
        card.addView(TextView(this).apply {
            text = descricao; textSize = 13f
            setTextColor(txtG); lineSpacingMultiplier = 1.5f
            setPadding(0, 0, 0, (18 * dp).toInt())
        })

        // Etapa 1: botão principal
        val btnEtapa1 = Button(this).apply {
            text = "🗑️  $labelBtn"
            textSize = 13f; setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(android.graphics.Color.WHITE)
            backgroundTintList = null
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(red); cornerRadius = 10f * dp
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (46 * dp).toInt()
            )
        }

        // Etapa 2: confirmação (oculta inicialmente)
        val layoutConfirm = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility  = View.GONE
            setPadding(0, (12 * dp).toInt(), 0, 0)
        }
        layoutConfirm.addView(TextView(this).apply {
            text = "⚠️  Tem certeza? Toque em CONFIRMAR para prosseguir."
            textSize = 12f; setTextColor(red)
            setPadding(0, 0, 0, (10 * dp).toInt())
        })
        val rowBtns = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity     = android.view.Gravity.CENTER
        }
        val btnCancelar = Button(this).apply {
            text = "Cancelar"; textSize = 13f
            setTextColor(accent)
            backgroundTintList = null
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(android.graphics.Color.TRANSPARENT)
                cornerRadius = 10f * dp
                setStroke((1.5f * dp).toInt(), accent)
            }
            layoutParams = LinearLayout.LayoutParams(0, (46 * dp).toInt(), 1f).apply {
                setMargins(0, 0, (6 * dp).toInt(), 0)
            }
        }
        val btnConfirmar = Button(this).apply {
            text = "✓  CONFIRMAR"; textSize = 13f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(android.graphics.Color.WHITE)
            backgroundTintList = null
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(red); cornerRadius = 10f * dp
            }
            layoutParams = LinearLayout.LayoutParams(0, (46 * dp).toInt(), 1f).apply {
                setMargins((6 * dp).toInt(), 0, 0, 0)
            }
        }
        rowBtns.addView(btnCancelar)
        rowBtns.addView(btnConfirmar)
        layoutConfirm.addView(rowBtns)

        // Lógica 2 etapas
        btnEtapa1.setOnClickListener {
            btnEtapa1.visibility  = View.GONE
            layoutConfirm.visibility = View.VISIBLE
        }
        btnCancelar.setOnClickListener {
            layoutConfirm.visibility = View.GONE
            btnEtapa1.visibility  = View.VISIBLE
        }
        btnConfirmar.setOnClickListener { onConfirm() }

        card.addView(btnEtapa1)
        card.addView(layoutConfirm)
        return card
    }
}
