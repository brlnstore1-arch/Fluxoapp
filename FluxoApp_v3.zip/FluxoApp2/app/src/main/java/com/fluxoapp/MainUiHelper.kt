package com.fluxoapp

import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.widget.ImageButton
import android.widget.TextView
import android.view.View
import androidx.cardview.widget.CardView

/**
 * MainUiHelper — FluxoApp
 *
 * Responsável por toda a lógica de tema e UI visual da MainActivity:
 *   - Aplicar tema (cores, backgrounds, textos)
 *   - Toggle e ícone do botão de tema
 *   - Shimmer do logo
 *   - Helper gdSolid para criar drawables
 */

internal fun MainActivity.gdSolid(color: Int, radius: Float, strokeColor: Int = 0, sw: Float = 0f): GradientDrawable {
    val dp = resources.displayMetrics.density
    return GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius * dp
        if (sw > 0) setStroke((sw * dp).toInt(), strokeColor)
    }
}

internal fun MainActivity.configurarBotaoTema() {
    atualizarIconeTema()
    findViewById<ImageButton>(R.id.btnTema)?.setOnClickListener {
        val atual = prefs.getInt("modo_tema", -1)
        val novo  = when (atual) { -1 -> 0; 0 -> 1; else -> -1 }
        prefs.edit().putInt("modo_tema", novo).apply()
        aplicarTema()
        aplicarTemaGlobal()
        atualizarIconeTema()
        try { sendBroadcast(Intent(FloatingEarningsService.ACTION_TEMA)) } catch (_: Throwable) {}
        try { startService(Intent(this, FloatingEarningsService::class.java).apply {
            action = FloatingEarningsService.ACTION_TEMA
        }) } catch (_: Throwable) {}
        val msg = when (novo) { 0 -> "☀️ Modo DIA ativado"; 1 -> "🌙 Modo NOITE ativado"; else -> "🔄 Modo AUTO ativado" }
        FluxoToast.info(this, msg)
    }
}

internal fun MainActivity.atualizarIconeTema() {
    val modo    = prefs.getInt("modo_tema", -1)
    val noturno = ThemeHelper.isModoNoturno(prefs)
    val lbl = when { modo == 0 -> "dia"; modo == 1 -> "noite"; noturno -> "noite"; else -> "dia" }
    try { findViewById<TextView>(R.id.tvTemaLabel)?.text = lbl } catch (_: Throwable) {}
    try { findViewById<ImageButton>(R.id.btnTema)?.setColorFilter(ThemeHelper.cor("accent_gold", prefs)) } catch (_: Throwable) {}
}

internal fun MainActivity.aplicarTema() {
    val bgDark  = ThemeHelper.cor("bg_dark",    prefs)
    val bgCard  = ThemeHelper.cor("bg_card",    prefs)
    val bgSect  = ThemeHelper.cor("bg_section", prefs)
    val toolbar = ThemeHelper.cor("toolbar",    prefs)
    val txtG    = ThemeHelper.cor("text_gray",  prefs)
    val txtW    = ThemeHelper.cor("text_white", prefs)
    val accent  = ThemeHelper.cor("accent_gold",  prefs)
    val gold    = ThemeHelper.cor("accent_gold",  prefs)
    val border  = ThemeHelper.cor("border",       prefs)
    val isGold  = ThemeHelper.getTema(prefs) == "gold"

    try { findViewById<android.widget.FrameLayout>(R.id.rootLayout)?.setBackgroundColor(bgDark) } catch (_: Throwable) {}
    try { findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)?.setBackgroundColor(toolbar) } catch (_: Throwable) {}

    try {
        findViewById<com.google.android.material.navigation.NavigationView>(R.id.navView)?.apply {
            setBackgroundColor(bgDark)
            itemTextColor    = android.content.res.ColorStateList.valueOf(txtW)
            itemIconTintList = android.content.res.ColorStateList.valueOf(accent)
        }
    } catch (_: Throwable) {}
    try {
        val nv = findViewById<com.google.android.material.navigation.NavigationView>(R.id.navView)
        if (nv != null) configurarHeaderDrawer(nv)
    } catch (_: Throwable) {}
    try { findViewById<TextView>(R.id.tvLogo)?.setTextColor(accent) } catch (_: Throwable) {}
    for (id in listOf(R.id.menuLine1, R.id.menuLine2, R.id.menuLine3))
        try { findViewById<View>(id)?.setBackgroundColor(accent) } catch (_: Throwable) {}

    try {
        val cv = findViewById<CardView>(R.id.cardGanhos)
        cv?.setCardBackgroundColor(bgCard)
        val inner = cv?.getChildAt(0)
        inner?.setBackgroundResource(if (isGold) R.drawable.earnings_card_gold else R.drawable.earnings_card_bg)
    } catch (_: Throwable) {}
    try { findViewById<TextView>(R.id.tvLabelGanhos)?.setTextColor(txtG) } catch (_: Throwable) {}
    try { findViewById<TextView>(R.id.tvGanhoHoje)?.setTextColor(accent) } catch (_: Throwable) {}

    for (id in listOf(R.id.statCorridas, R.id.statKm, R.id.statMedia))
        try { findViewById<View>(id)?.background = gdSolid(bgSect, 10f, border, 1f) } catch (_: Throwable) {}
    try { findViewById<TextView>(R.id.tvStatCorridas)?.setTextColor(accent) } catch (_: Throwable) {}
    try { findViewById<TextView>(R.id.tvStatKm)?.setTextColor(gold)       } catch (_: Throwable) {}
    try { findViewById<TextView>(R.id.tvStatMedia)?.setTextColor(gold)    } catch (_: Throwable) {}

    try { findViewById<CardView>(R.id.cardLicenca)?.setCardBackgroundColor(bgCard)        } catch (_: Throwable) {}
    try { findViewById<TextView>(R.id.tvLicencaTitulo)?.setTextColor(txtW)                } catch (_: Throwable) {}
    try { findViewById<TextView>(R.id.tvLicencaDiasLabel)?.setTextColor(txtG)             } catch (_: Throwable) {}

    try { findViewById<CardView>(R.id.cardMeta)?.setCardBackgroundColor(bgCard)    } catch (_: Throwable) {}
    try { findViewById<TextView>(R.id.tvMetaInfo)?.setTextColor(txtG)              } catch (_: Throwable) {}
    try { findViewById<TextView>(R.id.tvMetaPercent)?.setTextColor(gold)           } catch (_: Throwable) {}
    try {
        val cl = android.content.res.ColorStateList.valueOf(accent)
        findViewById<android.widget.ProgressBar>(R.id.progressMetaDia)?.progressTintList = cl
    } catch (_: Throwable) {}

    try { findViewById<android.widget.LinearLayout>(R.id.layoutDica)?.background = gdSolid(bgCard, 8f, border, 1f) } catch (_: Throwable) {}
    try { findViewById<View>(R.id.dicaBorder)?.setBackgroundColor(accent) } catch (_: Throwable) {}
    try { findViewById<TextView>(R.id.tvDica)?.setTextColor(txtG)       } catch (_: Throwable) {}

    try { findViewById<android.widget.LinearLayout>(R.id.bottomNav)?.setBackgroundColor(bgCard)  } catch (_: Throwable) {}
    try { findViewById<View>(R.id.indicadorInicio)?.setBackgroundColor(accent)      } catch (_: Throwable) {}
    try { findViewById<TextView>(R.id.tvBotInicio)?.setTextColor(accent)            } catch (_: Throwable) {}
    try { findViewById<TextView>(R.id.tvBotCorridas)?.setTextColor(txtG)          } catch (_: Throwable) {}
    try { findViewById<TextView>(R.id.tvBotMetricas)?.setTextColor(txtG)          } catch (_: Throwable) {}
    try { findViewById<TextView>(R.id.tvBotFinancas)?.setTextColor(txtG)          } catch (_: Throwable) {}

    try { findViewById<com.google.android.material.navigation.NavigationView>(R.id.navView)?.setBackgroundColor(bgCard) } catch (_: Throwable) {}

    atualizarBotaoServico()
}

internal fun MainActivity.iniciarShimmer() {
    try {
        findViewById<View>(R.id.viewShimmer)?.visibility = View.INVISIBLE
        val tvLogo = findViewById<TextView>(R.id.tvLogo) ?: return
        ThemeHelper.animarLogoShimmer(tvLogo, prefs)
    } catch (_: Throwable) {}
}
