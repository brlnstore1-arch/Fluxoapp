package com.fluxoapp

import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

/**
 * MaximExtractor — FluxoApp
 *
 * Funções de extração de dados da tela do Taxsee:
 *   - Valor da oferta (com remoção do saldo do header)
 *   - Km da oferta e da finalização
 *   - Valor final da corrida
 *   - Forma de pagamento
 *   - Origem e destino
 *   - Nome do cliente
 *   - Tempo de execução
 */

internal fun MaximAccessibilityService.extrairValorOferta(texto: String): Float? {
    // Remover o valor do header do Taxsee antes de qualquer análise.
    // Formato: "Sul (R$ 8,07)" → é o SALDO da conta, não o valor da corrida.
    val textoSemHeader = texto.replace(
        Regex("""[a-záéíóúàâêîôûãõç\s]+\(r\$\s*[\d]+[,.][\d]{2}\)""",
            RegexOption.IGNORE_CASE), ""
    )

    // Prioridade 1: valor explicitamente ligado à forma de pagamento
    val regexComPagamento = Regex(
        """r\$\s*([\d]+[,.][\d]{2})\s*(?:por\s+)?(pix|dinheiro|cartão|cartao|online|transferência|transferencia)""",
        RegexOption.IGNORE_CASE
    )
    regexComPagamento.find(textoSemHeader)
        ?.groupValues?.get(1)
        ?.replace(",", ".")?.toFloatOrNull()
        ?.takeIf { it >= 1f }
        ?.let { return it }

    // Prioridade 2: menor valor R$ válido (saldo acumulado tende a ser maior)
    val regexRs = Regex("""r\$\s*([\d]+[,.][\d]{2})""")
    val todosValores = regexRs.findAll(textoSemHeader)
        .mapNotNull { it.groupValues[1].replace(",", ".").toFloatOrNull() }
        .filter { it in 1f..500f }
        .sorted().toList()

    if (todosValores.isNotEmpty()) return todosValores.first()

    // Prioridade 3: fallback — qualquer decimal com 2 casas >= 1
    val regexNum = Regex("""(?<!\d)([\d]{1,3}[,.][\d]{2})(?!\d)""")
    return regexNum.findAll(textoSemHeader)
        .mapNotNull { it.groupValues[1].replace(",", ".").toFloatOrNull() }
        .filter { it >= 1f }
        .firstOrNull()
}

internal fun MaximAccessibilityService.extrairKmOferta(texto: String): Float? {
    val regex = Regex("""([\d]+[,.]?[\d]*)\s*km""")
    val valores = regex.findAll(texto)
        .mapNotNull { it.groupValues[1].replace(",", ".").toFloatOrNull() }
        .filter { it > 0f }.take(2).toList()
    return when {
        valores.size >= 2 -> valores[0] + valores[1]
        valores.size == 1 -> valores[0]
        else              -> null
    }
}

internal fun MaximAccessibilityService.extrairKmFinal(texto: String): Float? {
    val regex = Regex("""([\d]+[,.][\d]+)\s*km""")
    return regex.find(texto)?.groupValues?.get(1)?.replace(",", ".")?.toFloatOrNull()
}

internal fun MaximAccessibilityService.extrairTempo(texto: String): String {
    val regex = Regex("""(\d+)\s*min""")
    return regex.find(texto)?.let { "${it.groupValues[1]} min" } ?: ""
}

internal fun MaximAccessibilityService.extrairValorFinal(raiz: AccessibilityNodeInfo, textoTela: String): Float? {
    // Prioridade 1: EditText editável (usa find(), não matches())
    val noEdit = encontrarNo(raiz) { no ->
        no.className?.contains("EditText") == true && no.isVisibleToUser
    }
    if (noEdit != null) {
        val txt = noEdit.text?.toString() ?: ""
        Regex("""[\d]+[,.][\d]{2}""").find(txt)
            ?.value?.replace(",", ".")?.toFloatOrNull()
            ?.takeIf { it > 0f }?.let { return it }
    }

    // Prioridade 2: menor valor R$ visível
    val regex = Regex("""r\$\s*([\d]+[,.][\d]{2})""")
    return regex.findAll(textoTela.lowercase())
        .mapNotNull { it.groupValues[1].replace(",", ".").toFloatOrNull() }
        .filter { it in 1f..500f }.sorted().firstOrNull()
}

internal fun MaximAccessibilityService.extrairFormaPagamento(texto: String): String = when {
    texto.contains("pix")                                 -> "PIX"
    texto.contains("dinheiro")                            -> "Dinheiro"
    texto.contains("cartão") || texto.contains("cartao") -> "Cartão"
    texto.contains("online")                              -> "Online"
    else                                                  -> "Dinheiro"
}

internal fun MaximAccessibilityService.extrairOrigemDestino(raiz: AccessibilityNodeInfo): Pair<String, String> {
    val enderecos = mutableListOf<String>()
    visitarNos(raiz) { no ->
        val txt = no.text?.toString() ?: ""
        if (txt.length > 5 && no.isVisibleToUser) {
            val temLogradouro = txt.contains("Rua ",     ignoreCase = true) ||
                                txt.contains("Travessa", ignoreCase = true) ||
                                txt.contains("Avenida",  ignoreCase = true) ||
                                txt.contains("Alameda",  ignoreCase = true) ||
                                txt.contains("Praça",    ignoreCase = true) ||
                                txt.contains("(bairro",  ignoreCase = true)
            val temPreco = txt.contains("r$", ignoreCase = true)
            if (temLogradouro && !temPreco) enderecos.add(txt.trim())
        }
    }
    return Pair(enderecos.getOrNull(0) ?: "", enderecos.getOrNull(1) ?: "")
}

internal fun MaximAccessibilityService.extrairCliente(raiz: AccessibilityNodeInfo, texto: String): String {
    val regex = Regex("""cliente\s+([a-záéíóúàâêîôûãõç]+)""", RegexOption.IGNORE_CASE)
    regex.find(texto)?.groupValues?.get(1)
        ?.replaceFirstChar { it.uppercase() }
        ?.let { return it }

    return encontrarNo(raiz) { no ->
        val txt = no.text?.toString() ?: ""
        txt.length in 3..25 &&
        !txt.any { it.isDigit() } &&
        !txt.contains("km", ignoreCase = true) &&
        !txt.contains("r$", ignoreCase = true) &&
        no.isVisibleToUser
    }?.text?.toString()?.replaceFirstChar { it.uppercase() } ?: ""
}
