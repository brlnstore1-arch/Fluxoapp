package com.fluxoapp

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * LocationHelper — FluxoApp
 *
 * Funções de geolocalização sem chave de API:
 *   - Nominatim (OpenStreetMap) → converte lat/lon em endereço legível
 *   - OSRM → calcula distância real da rota entre dois pontos
 *
 * Todas as chamadas são síncronas — executar em thread de background.
 */
object LocationHelper {

    // OSRM público — sem chave, sem limite estrito para uso pessoal
    private const val OSRM_BASE = "https://router.project-osrm.org/route/v1/driving"
    // Nominatim — requer User-Agent identificado
    private const val NOMINATIM_BASE = "https://nominatim.openstreetmap.org/reverse"
    private const val USER_AGENT = "FluxoApp/3.0 (motorista taxsee braganca pa)"

    data class Endereco(
        val logradouro: String,
        val bairro: String,
        val cidade: String,
        val resumo: String  // "Rua X, Bairro Y"
    )

    data class Rota(
        val distanciaKm: Float,
        val duracaoMin: Int,
        val sucesso: Boolean,
        val erro: String = ""
    )

    /**
     * Converte coordenadas em endereço via Nominatim (OpenStreetMap).
     * Retorna null se falhar.
     */
    fun geocodificarInverso(lat: Double, lon: Double): Endereco? {
        return try {
            val url = URL("$NOMINATIM_BASE?lat=$lat&lon=$lon&format=json&accept-language=pt-BR")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                setRequestProperty("User-Agent", USER_AGENT)
                connectTimeout = 8_000
                readTimeout    = 8_000
            }

            if (conn.responseCode !in 200..299) return null

            val json = JSONObject(conn.inputStream.bufferedReader().readText())
            conn.disconnect()

            val addr = json.optJSONObject("address") ?: return null

            val logradouro = addr.optString("road")
                .ifBlank { addr.optString("pedestrian") }
                .ifBlank { addr.optString("path") }
                .ifBlank { "Sem nome" }

            val numero = addr.optString("house_number")
            val bairro = addr.optString("suburb")
                .ifBlank { addr.optString("neighbourhood") }
                .ifBlank { addr.optString("quarter") }
                .ifBlank { "" }
            val cidade = addr.optString("city")
                .ifBlank { addr.optString("town") }
                .ifBlank { addr.optString("municipality") }
                .ifBlank { "" }

            val ruaComNumero = if (numero.isNotBlank()) "$logradouro, $numero" else logradouro
            val resumo = listOf(ruaComNumero, bairro, cidade)
                .filter { it.isNotBlank() }
                .joinToString(", ")

            Endereco(logradouro = ruaComNumero, bairro = bairro, cidade = cidade, resumo = resumo)
        } catch (_: Exception) { null }
    }

    /**
     * Calcula a distância real da rota entre dois pontos via OSRM.
     * Usa o perfil "driving" (carro/moto).
     */
    fun calcularRota(
        latOrigem: Double, lonOrigem: Double,
        latDestino: Double, lonDestino: Double
    ): Rota {
        return try {
            val coords = "$lonOrigem,$latOrigem;$lonDestino,$latDestino"
            val url = URL("$OSRM_BASE/$coords?overview=false")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                setRequestProperty("User-Agent", USER_AGENT)
                connectTimeout = 10_000
                readTimeout    = 10_000
            }

            if (conn.responseCode !in 200..299) {
                return Rota(0f, 0, false, "HTTP ${conn.responseCode}")
            }

            val json = JSONObject(conn.inputStream.bufferedReader().readText())
            conn.disconnect()

            if (json.optString("code") != "Ok") {
                return Rota(0f, 0, false, "OSRM: ${json.optString("message")}")
            }

            val routes = json.optJSONArray("routes") ?: return Rota(0f, 0, false, "Sem rotas")
            val route  = routes.getJSONObject(0)

            val distanciaM = route.optDouble("distance", 0.0)
            val duracaoS   = route.optDouble("duration", 0.0)

            Rota(
                distanciaKm = (distanciaM / 1000.0).toFloat(),
                duracaoMin  = (duracaoS / 60.0).toInt(),
                sucesso     = true
            )
        } catch (e: Exception) {
            Rota(0f, 0, false, e.message ?: "Erro de rede")
        }
    }
}
