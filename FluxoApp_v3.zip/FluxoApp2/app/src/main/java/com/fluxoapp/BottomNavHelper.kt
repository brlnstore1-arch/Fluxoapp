package com.fluxoapp

import android.content.Intent
import android.view.View
import androidx.appcompat.app.AppCompatActivity

/**
 * BottomNavHelper — FluxoApp
 *
 * Item 8 — Menu inferior persistente.
 *
 * Como Dashboard, Histórico, Relatórios e Abastecimento continuam sendo
 * Activities separadas (não Fragments), a barra em si é replicada via
 * <include layout="@layout/bottom_nav_bar"/> em cada tela, e esta classe
 * garante que:
 *   1. A aba correspondente à tela atual sempre aparece destacada.
 *   2. Trocar de aba nunca empilha múltiplas cópias da mesma Activity
 *      (FLAG_ACTIVITY_REORDER_TO_FRONT reaproveita a instância existente).
 *   3. A troca acontece sem animação de transição, para parecer uma
 *      navegação persistente em vez de "abrir uma tela nova".
 *   4. Tocar na aba já ativa não faz nada (evita reabrir a própria tela).
 */
object BottomNavHelper {

    const val ABA_INICIO      = 0
    const val ABA_HISTORICO   = 1
    const val ABA_RELATORIOS  = 2
    const val ABA_FINANCAS    = 3

    /**
     * Configura os cliques e o destaque visual da barra inferior.
     * Chamar no onCreate/onResume de cada Activity que tem a barra incluída.
     *
     * @param activity a Activity atual (usada para achar as views e navegar)
     * @param abaAtiva  qual aba corresponde à tela atual
     */
    fun configurar(activity: AppCompatActivity, abaAtiva: Int) {
        val prefs  = activity.getSharedPreferences("FluxoApp", android.content.Context.MODE_PRIVATE)
        val accent = ThemeHelper.cor("accent",    prefs)
        val txtG   = ThemeHelper.cor("text_gray", prefs)

        destacarAba(activity, abaAtiva, accent, txtG)

        activity.findViewById<View>(R.id.btnBottomInicio)?.setOnClickListener {
            navegarPara(activity, MainActivity::class.java, abaAtiva, ABA_INICIO)
        }
        activity.findViewById<View>(R.id.btnBottomCorridas)?.setOnClickListener {
            navegarPara(activity, HistoryActivity::class.java, abaAtiva, ABA_HISTORICO)
        }
        activity.findViewById<View>(R.id.btnBottomMetricas)?.setOnClickListener {
            navegarPara(activity, ReportsActivity::class.java, abaAtiva, ABA_RELATORIOS)
        }
        activity.findViewById<View>(R.id.btnBottomFinancas)?.setOnClickListener {
            navegarPara(activity, FinanceActivity::class.java, abaAtiva, ABA_FINANCAS)
        }
    }

    private fun navegarPara(
        activity: AppCompatActivity,
        destino: Class<*>,
        abaAtiva: Int,
        abaDestino: Int
    ) {
        // Já está na aba tocada — não faz nada
        if (abaAtiva == abaDestino) return

        val intent = Intent(activity, destino).apply {
            addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        }
        activity.startActivity(intent)
        // Sem animação — dá sensação de barra fixa, não de "abrir tela nova"
        activity.overridePendingTransition(0, 0)

        // Fecha a tela atual (exceto o Dashboard, que é a raiz/base da pilha)
        // para o back stack nunca crescer indefinidamente entre as abas.
        if (activity !is MainActivity) activity.finish()
    }

    private fun destacarAba(activity: AppCompatActivity, aba: Int, corAtiva: Int, corInativa: Int) {
        val indicadores = listOf(
            R.id.indicadorInicio to ABA_INICIO,
            R.id.indicadorCorridas to ABA_HISTORICO,
            R.id.indicadorMetricas to ABA_RELATORIOS,
            R.id.indicadorFinancas to ABA_FINANCAS
        )
        val textos = listOf(
            R.id.tvBotInicio to ABA_INICIO,
            R.id.tvBotCorridas to ABA_HISTORICO,
            R.id.tvBotMetricas to ABA_RELATORIOS,
            R.id.tvBotFinancas to ABA_FINANCAS
        )

        indicadores.forEach { (id, valor) ->
            activity.findViewById<View>(id)?.setBackgroundColor(
                if (valor == aba) corAtiva else android.graphics.Color.TRANSPARENT
            )
        }
        textos.forEach { (id, valor) ->
            activity.findViewById<android.widget.TextView>(id)?.let { tv ->
                tv.setTextColor(if (valor == aba) corAtiva else corInativa)
                tv.setTypeface(tv.typeface, if (valor == aba) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
            }
        }
    }
}
