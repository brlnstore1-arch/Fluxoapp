package com.fluxoapp

import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Build
import android.view.Display
import androidx.annotation.RequiresApi
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors

/**
 * NoveNoveOcrHelper — FluxoApp
 *
 * Fallback de leitura de tela via OCR (reconhecimento de texto em imagem),
 * usado SOMENTE quando a árvore de acessibilidade não expõe texto nenhum
 * na tela de oferta da 99 (proteção anti-bot da plataforma).
 *
 * Como funciona:
 *   1. Tira um screenshot da tela via AccessibilityService.takeScreenshot()
 *      (API nativa do Android 11+, não precisa de MediaProjection nem de
 *      notificação de "gravando tela")
 *   2. Roda o ML Kit Text Recognition OFFLINE (no aparelho, sem internet,
 *      sem custo) sobre a imagem
 *   3. Retorna os blocos de texto encontrados COM a posição (bounding box)
 *      de cada um — essencial pra saber onde tocar no botão "Aceitar",
 *      já que não temos um nó de acessibilidade pra clicar diretamente
 *
 * Resultado de cada bloco: o texto reconhecido + o retângulo na tela onde
 * ele está desenhado (em pixels), usado tanto pra extrair valor/km quanto
 * pra calcular as coordenadas exatas de um toque simulado.
 */
object NoveNoveOcrHelper {

    data class BlocoTexto(val texto: String, val bounds: Rect)
    data class ResultadoOcr(val textoCompleto: String, val blocos: List<BlocoTexto>)

    private val executor = Executors.newSingleThreadExecutor()
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    /**
     * "Aquece" o OCR baixando o modelo do Google Play Services com
     * antecedência, em vez de esperar a primeira corrida real pra
     * descobrir que o modelo ainda não foi baixado (o que causaria um
     * atraso ou falha na primeira detecção). Chamar assim que o usuário
     * ativa "Detectar corridas de 99" nas configurações — não faz nada
     * visível, só garante que o modelo já está pronto quando precisar.
     */
    fun aquecerModelo() {
        try {
            val imagemTeste = InputImage.fromBitmap(
                Bitmap.createBitmap(10, 10, Bitmap.Config.ARGB_8888), 0
            )
            recognizer.process(imagemTeste)
                .addOnSuccessListener { /* só queria forçar o download do modelo */ }
                .addOnFailureListener { /* sem problema — vai tentar de novo na hora real */ }
        } catch (_: Exception) {}
    }

    /**
     * Captura a tela e roda OCR. Chama o callback com o resultado (ou null
     * se falhar em qualquer etapa — API indisponível, screenshot negado,
     * OCR falhou, etc). Sempre roda em background; o callback é chamado
     * na main thread.
     */
    @RequiresApi(Build.VERSION_CODES.R) // API 30 — takeScreenshot()
    fun capturarEler(
        service: NoveNoveAccessibilityService,
        onResult: (ResultadoOcr?) -> Unit
    ) {
        try {
            service.takeScreenshot(
                Display.DEFAULT_DISPLAY,
                executor,
                object : android.accessibilityservice.AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(screenshot: android.accessibilityservice.AccessibilityService.ScreenshotResult) {
                        try {
                            val hb = screenshot.hardwareBuffer
                            val bitmapHw = Bitmap.wrapHardwareBuffer(hb, screenshot.colorSpace)
                            hb.close()
                            if (bitmapHw == null) {
                                service.handler99.post { onResult(null) }
                                return
                            }
                            // ML Kit precisa de um bitmap "software" (ARGB_8888),
                            // não aceita hardware bitmap diretamente
                            val bitmapCompleto = bitmapHw.copy(Bitmap.Config.ARGB_8888, false)
                            bitmapHw.recycle()

                            // Recorta só a parte de BAIXO da tela — é onde o
                            // card da oferta aparece (valor, Aceitar, etc).
                            // Processar uma imagem bem menor deixa o OCR
                            // consideravelmente mais rápido.
                            val alturaTotal = bitmapCompleto.height
                            val recorteTopoY = (alturaTotal * 0.40f).toInt()
                            val alturaRecorte = alturaTotal - recorteTopoY
                            val bitmap = Bitmap.createBitmap(
                                bitmapCompleto, 0, recorteTopoY, bitmapCompleto.width, alturaRecorte
                            )
                            bitmapCompleto.recycle()

                            val image = InputImage.fromBitmap(bitmap, 0)
                            recognizer.process(image)
                                .addOnSuccessListener { visionText ->
                                    val blocos = visionText.textBlocks.mapNotNull { bloco ->
                                        val box = bloco.boundingBox ?: return@mapNotNull null
                                        // Ajusta de volta pras coordenadas REAIS da
                                        // tela (soma o quanto foi recortado do topo),
                                        // essencial pro toque simulado cair no lugar certo
                                        val boxReal = Rect(box.left, box.top + recorteTopoY, box.right, box.bottom + recorteTopoY)
                                        BlocoTexto(bloco.text, boxReal)
                                    }
                                    val textoCompleto = blocos.joinToString(" ") { it.texto }
                                    bitmap.recycle()
                                    service.handler99.post {
                                        onResult(ResultadoOcr(textoCompleto, blocos))
                                    }
                                }
                                .addOnFailureListener {
                                    try { bitmap.recycle() } catch (_: Exception) {}
                                    service.handler99.post { onResult(null) }
                                }
                        } catch (e: Exception) {
                            service.handler99.post { onResult(null) }
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        service.handler99.post { onResult(null) }
                    }
                }
            )
        } catch (e: Exception) {
            onResult(null)
        }
    }

    /** Procura o bloco cujo texto bate (ignorando maiúsculas/acentos simples) com o alvo. */
    fun encontrarBloco(resultado: ResultadoOcr, textoAlvo: String): BlocoTexto? {
        val alvo = textoAlvo.lowercase()
        return resultado.blocos.firstOrNull { it.texto.trim().lowercase() == alvo }
            ?: resultado.blocos.firstOrNull { it.texto.trim().lowercase().contains(alvo) }
    }
}
