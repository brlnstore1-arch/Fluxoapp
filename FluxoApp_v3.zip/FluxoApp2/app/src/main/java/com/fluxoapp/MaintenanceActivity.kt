package com.fluxoapp

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MaintenanceActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeSelector.aplicar(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maintenance)
        val msg = intent.getStringExtra("mensagem") ?: "App em manutenção. Volte em breve!"
        findViewById<TextView>(R.id.tvMaintMessage)?.text = msg
    }
    @Suppress("DEPRECATION")
    override fun onBackPressed() {}
}
