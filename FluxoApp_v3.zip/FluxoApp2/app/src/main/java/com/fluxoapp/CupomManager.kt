package com.fluxoapp

import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import java.util.Date
import java.util.concurrent.TimeUnit

/**
 * CupomManager — valida e aplica cupons no app.
 *
 * Integrado com a coleção "cupons" do Firestore,
 * gerenciada pelo painel admin.
 *
 * Estrutura do cupom no Firestore:
 *   codigo:      String   (ex: "AMIGO30")
 *   tipo:        String   ("dias_gratis" | "desconto" | "vitalicio")
 *   dias:        Int?     (para tipo "dias_gratis")
 *   desconto:    Int?     (para tipo "desconto", valor %)
 *   limite:      Int      (0 = ilimitado)
 *   usosAtual:   Int
 *   ativo:       Boolean
 *   validade:    Timestamp? (null = sem validade)
 *   descricao:   String?
 */
object CupomManager {

    private val db get() = FirebaseFirestore.getInstance()

    data class ResultadoCupom(
        val valido: Boolean,
        val mensagem: String,
        val tipo: String = "",          // "dias_gratis" | "desconto" | "vitalicio"
        val dias: Int = 0,              // dias grátis (se tipo = dias_gratis ou vitalicio)
        val desconto: Int = 0,          // % de desconto (se tipo = desconto)
        val codigo: String = ""
    )

    /**
     * Valida um cupom sem aplicá-lo (só consulta).
     * Útil para mostrar preview antes de confirmar.
     */
    fun validar(codigo: String, callback: (ResultadoCupom) -> Unit) {
        if (codigo.isBlank()) {
            callback(ResultadoCupom(false, "Informe um código de cupom"))
            return
        }

        val codigoUpper = codigo.trim().uppercase()

        db.collection("cupons").document(codigoUpper).get()
            .addOnSuccessListener { doc ->
                if (!doc.exists()) {
                    callback(ResultadoCupom(false, "Cupom \"$codigoUpper\" não encontrado"))
                    return@addOnSuccessListener
                }

                val ativo    = doc.getBoolean("ativo") ?: true
                val limite   = doc.getLong("limite")?.toInt() ?: 0
                val usos     = doc.getLong("usosAtual")?.toInt() ?: 0
                val tipo     = doc.getString("tipo") ?: "dias_gratis"
                val dias     = doc.getLong("dias")?.toInt() ?: 30
                val desconto = doc.getLong("desconto")?.toInt() ?: 0
                val validade = when (val v = doc.get("validade")) {
                    is Timestamp -> v.toDate()
                    is Date      -> v
                    else         -> null
                }

                when {
                    !ativo ->
                        callback(ResultadoCupom(false, "Este cupom está inativo"))

                    validade != null && validade.before(Date()) ->
                        callback(ResultadoCupom(false, "Este cupom expirou em ${
                            java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(validade)
                        }"))

                    limite > 0 && usos >= limite ->
                        callback(ResultadoCupom(false, "Este cupom atingiu o limite de usos"))

                    else -> {
                        val msg = when (tipo) {
                            "dias_gratis" -> "✅ Cupom válido — $dias dias grátis!"
                            "desconto"    -> "✅ Cupom válido — $desconto% de desconto!"
                            "vitalicio"   -> "✅ Cupom válido — Acesso vitalício!"
                            else          -> "✅ Cupom válido!"
                        }
                        callback(ResultadoCupom(
                            valido   = true,
                            mensagem = msg,
                            tipo     = tipo,
                            dias     = if (tipo == "vitalicio") 99999 else dias,
                            desconto = desconto,
                            codigo   = codigoUpper
                        ))
                    }
                }
            }
            .addOnFailureListener {
                callback(ResultadoCupom(false, "Erro ao verificar cupom. Verifique sua conexão."))
            }
    }

    /**
     * Aplica o cupom para o usuário — atualiza Firestore e incrementa o contador.
     * Deve ser chamado após validar() confirmar que é válido.
     */
    fun aplicar(uid: String, resultado: ResultadoCupom, callback: (Boolean, String) -> Unit) {
        if (!resultado.valido || resultado.codigo.isBlank()) {
            callback(false, "Cupom inválido")
            return
        }

        val batch = db.batch()

        // Calcular nova data de expiração
        val agora     = Date()
        val novaExp   = when (resultado.tipo) {
            "vitalicio"   -> null  // null = sem expiração
            "dias_gratis" -> Date(agora.time + TimeUnit.DAYS.toMillis(resultado.dias.toLong()))
            else          -> null  // desconto: será tratado na compra
        }

        // Atualizar documento do usuário
        val userRef = db.collection("users").document(uid)
        val updateUser = mutableMapOf<String, Any>(
            "codigoPromo" to resultado.codigo,
            "atualizadoEm" to Timestamp.now()
        )
        if (resultado.tipo == "dias_gratis" || resultado.tipo == "vitalicio") {
            updateUser["plano"]  = if (resultado.tipo == "vitalicio") LicenseManager.PLANO_PROMO else LicenseManager.PLANO_TRIAL
            updateUser["status"] = LicenseManager.STATUS_ATIVO
            if (novaExp != null) updateUser["dataExpiracao"] = novaExp
            else updateUser["dataExpiracao"] = com.google.firebase.firestore.FieldValue.delete()
        }
        batch.update(userRef, updateUser)

        // Incrementar contador de usos do cupom
        val cupomRef = db.collection("cupons").document(resultado.codigo)
        batch.update(cupomRef, "usosAtual",
            com.google.firebase.firestore.FieldValue.increment(1))

        batch.commit()
            .addOnSuccessListener {
                LicenseManager.invalidarCache()
                val msg = when (resultado.tipo) {
                    "dias_gratis" -> "🎉 ${resultado.dias} dias grátis aplicados!"
                    "vitalicio"   -> "🎉 Acesso vitalício ativado!"
                    "desconto"    -> "🎉 Desconto de ${resultado.desconto}% aplicado!"
                    else          -> "🎉 Cupom aplicado com sucesso!"
                }
                callback(true, msg)
            }
            .addOnFailureListener { e ->
                callback(false, "Erro ao aplicar cupom: ${e.message}")
            }
    }
}
