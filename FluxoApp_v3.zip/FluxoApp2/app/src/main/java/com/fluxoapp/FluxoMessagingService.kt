package com.fluxoapp

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * FluxoMessagingService — recebe notificações push via FCM.
 *
 * Diferente do polling antigo (verificarNotificacoes() no onResume, que só
 * funcionava com o app aberto), este serviço é acordado pelo sistema
 * operacional mesmo com o app fechado ou em background, porque o FCM
 * usa o canal de push nativo do Android (Google Play Services).
 *
 * Fluxo:
 *  1. Painel admin cria documento em `notificacoes`
 *  2. Cloud Function (onNotificacaoCriada) dispara automaticamente
 *  3. Cloud Function envia push via FCM para os tokens dos usuários certos
 *  4. Este serviço recebe e exibe a notificação, mesmo com app fechado
 */
class FluxoMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        salvarTokenNoFirestore(token)
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)

        val titulo = message.notification?.title
            ?: message.data["titulo"]
            ?: "FluxoApp"
        val corpo = message.notification?.body
            ?: message.data["mensagem"]
            ?: return

        mostrarNotificacao(titulo, corpo)
    }

    private fun mostrarNotificacao(titulo: String, msg: String) {
        try {
            val channelId = "fluxoapp_notif"
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val ch = NotificationChannel(
                    channelId, "FluxoApp",
                    NotificationManager.IMPORTANCE_HIGH
                )
                nm.createNotificationChannel(ch)
            }

            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pendingIntent = PendingIntent.getActivity(
                this, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val notif = NotificationCompat.Builder(this, channelId)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(titulo)
                .setContentText(msg)
                .setStyle(NotificationCompat.BigTextStyle().bigText(msg))
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .build()

            nm.notify(System.currentTimeMillis().toInt(), notif)
        } catch (_: Throwable) {}
    }

    private fun salvarTokenNoFirestore(token: String) {
        try {
            val uid = LicenseManager.uid() ?: return
            FirebaseFirestore.getInstance()
                .document("users/$uid")
                .update(
                    "fcmToken", token,
                    "fcmAtualizadoEm", com.google.firebase.Timestamp.now()
                )
        } catch (_: Throwable) {}
    }

    companion object {
        /**
         * Busca o token atual do dispositivo e salva no Firestore.
         * Chamar após login bem-sucedido.
         */
        fun registrarToken(uid: String) {
            try {
                com.google.firebase.messaging.FirebaseMessaging.getInstance().token
                    .addOnSuccessListener { token ->
                        FirebaseFirestore.getInstance()
                            .document("users/$uid")
                            .update(
                                "fcmToken", token,
                                "fcmAtualizadoEm", com.google.firebase.Timestamp.now()
                            )
                            .addOnFailureListener {
                                // Documento pode não ter o campo ainda — usa merge
                                FirebaseFirestore.getInstance()
                                    .document("users/$uid")
                                    .set(
                                        mapOf("fcmToken" to token),
                                        com.google.firebase.firestore.SetOptions.merge()
                                    )
                            }
                    }
            } catch (_: Throwable) {}
        }
    }
}
