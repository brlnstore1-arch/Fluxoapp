package com.fluxoapp

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * NoveNoveAccessibilityService — FluxoApp
 *
 * Módulo EXCLUSIVO da 99. Monitora apenas o pacote com.app99.driver.
 *
 * ⚠️ Este é um serviço de acessibilidade Android COMPLETAMENTE SEPARADO do
 * MaximAccessibilityService. Cada plataforma (Taxsee/Maxim e 99) tem seu
 * próprio serviço, própria máquina de estados, próprios runnables e
 * próprio arquivo de configuração de acessibilidade
 * (accessibility_service_config_99.xml). Nada é compartilhado entre eles
 * além de peças genéricas do app (DatabaseHelper, OverlayService,
 * FloatingEarningsService) que não são específicas de nenhuma plataforma.
 *
 * O usuário precisa ativar ESTE serviço separadamente em
 * Configurações → Acessibilidade → FluxoApp (99), além do serviço do
 * Taxsee/Maxim, se quiser detectar corridas nas duas plataformas.
 *
 * Máquina de estados:
 *   IDLE → AGUARDANDO_ACEITE → EM_ANDAMENTO → FINALIZANDO → IDLE
 *
 * Diferença chave da 99 em relação ao Taxsee:
 *   - Só existe botão "Aceitar" (texto). Recusar é um ícone X, sem texto.
 *   - Tempo+km vêm combinados na tela: "5min (2,7km)"
 *
 * Lógica extraída para helpers próprios:
 *   - NoveNoveExtractor.kt  → extração de valor, km, origem, forma de pagamento
 *   - NoveNoveNodeUtils.kt  → travessia de árvore, cliques, gestos, coleta de texto
 */
class NoveNoveAccessibilityService : AccessibilityService() {

    // ── Máquina de estados (própria, independente da do Maxim) ────────────
    internal enum class Estado99 { IDLE, AGUARDANDO_ACEITE, EM_ANDAMENTO, FINALIZANDO }
    internal var estado99 = Estado99.IDLE

    // ── Dados da corrida ──────────────────────────────────────────────────
    internal var corridaValor99      = 0f
    internal var corridaKm99         = 0f
    internal var corridaGanhoPorKm99 = 0f
    internal var corridaValeAPena99  = false
    internal var corridaOrigem99     = ""
    internal var corridaDestino99    = ""
    internal var corridaForma99      = ""
    internal var corridaHoraInicio99 = ""
    internal var finalValor99        = 0f
    internal var finalKm99           = 0f
    internal var finalTempo99        = ""

    // ── Controle de overlay ───────────────────────────────────────────────
    internal var overlayAtivo99      = false
    internal var ultimoValorOferta99 = 0f

    // ── Runnables nomeados (próprios) ──────────────────────────────────────
    internal var runnableAutoAceitar99:   Runnable? = null
    internal var runnableAutoRecusar99:   Runnable? = null
    internal var runnableLeituraOferta99: Runnable? = null

    // ── OCR (fallback quando a árvore de acessibilidade vem vazia) ─────────
    // Guarda as coordenadas do botão "Aceitar" encontradas via OCR, pra dar
    // um toque simulado nelas (não temos um nó de acessibilidade pra clicar)
    internal var ocrBoundsAceitar99: android.graphics.Rect? = null
    private var ocrEmAndamento99 = false
    private var ultimoOcrMs99 = 0L

    // ── Handler e debounce (próprios) ──────────────────────────────────────
    internal val handler99            = Handler(Looper.getMainLooper())
    internal var ultimoEventoTelaMs99 = 0L
    internal var timeoutRunnable99: Runnable? = null

    companion object {
        // Pacote real do app "99 Motorista e Entregador" (confirmado via
        // Google Play: play.google.com/store/apps/details?id=com.app99.driver)
        internal const val PKG_99                     = "com.app99.driver"
        internal const val DEBOUNCE_TELA_MS_99         = 350L
        internal const val ATRASO_LEITURA_OFERTA_MS_99 = 700L
        internal const val TIMEOUT_FINALIZANDO_MS_99   = 30_000L
        internal const val TIMEOUT_EM_ANDAMENTO_MS_99  = 720_000L
    }

    // ══════════════════════════════════════════════════════════════════════
    // PONTO DE ENTRADA
    // ══════════════════════════════════════════════════════════════════════

    private var ultimoLogGenericoMs99 = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val pacoteRecebido = event.packageName?.toString()
        if (pacoteRecebido != PKG_99) return

        // Throttle: só grava "evento recebido" 1x a cada 5s, senão o buffer
        // do diagnóstico enche de ruído antes da oferta real aparecer.
        val agoraLog = System.currentTimeMillis()
        if (agoraLog - ultimoLogGenericoMs99 > 5000L) {
            ultimoLogGenericoMs99 = agoraLog
            logDiag99("Evento recebido do pacote $PKG_99 (serviço ativo e recebendo normalmente)")
        }

        if (!LicenseManager.estaLogado()) { logDiag99("Bloqueado: usuário não logado no FluxoApp"); return }
        val prefs99config = getSharedPreferences("fluxo_config", Context.MODE_PRIVATE)
        if (!prefs99config.getBoolean("detectar_99", false)) {
            logDiag99("Bloqueado: toggle 'Detectar corridas de 99' está DESLIGADO")
            return
        }

        val prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("servico_ativo", true)) {
            logDiag99("Bloqueado: serviço geral do FluxoApp está pausado")
            return
        }

        val tipo = event.eventType
        val textoEvento = event.text?.joinToString(" ")?.trim()
            ?.lowercase(Locale.getDefault()) ?: ""

        if (tipo == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED ||
            tipo == AccessibilityEvent.TYPE_ANNOUNCEMENT) {
            if (textoEvento.isNotBlank()) processarToast99(textoEvento)
            return
        }

        if (tipo == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            tipo == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            if (textoEvento.isNotBlank()) processarToast99(textoEvento)

            val agora = System.currentTimeMillis()
            if (agora - ultimoEventoTelaMs99 < DEBOUNCE_TELA_MS_99) return
            ultimoEventoTelaMs99 = agora

            // A tela de oferta da 99 é desenhada como OVERLAY por cima da
            // tela principal — nesse momento existem DUAS janelas com o
            // mesmo pacote com.app99.driver simultaneamente. Por isso não
            // usamos mais uma única raiz — verificamos TODAS as janelas.
            val raizes = obterTodasRaizes99()
            if (raizes.isEmpty()) {
                val pacotesVisiveis = try {
                    windows?.mapNotNull { it.root?.packageName?.toString() }
                        ?.distinct()?.joinToString(", ") ?: "nenhuma"
                } catch (_: Exception) { "erro ao listar" }
                logDiag99("Nenhuma janela da 99 encontrada. Janelas visíveis agora: [$pacotesVisiveis]")
                return
            }
            processarTela99(raizes)
        }
    }

    /**
     * Diagnóstico leve — grava as últimas etapas do pipeline de detecção
     * em SharedPreferences para o usuário conseguir ver em
     * Configurações → Diagnóstico 99, sem precisar de logcat/computador.
     * Mantém só as últimas 60 linhas para não pesar o armazenamento.
     */
    internal fun logDiag99(msg: String) {
        try {
            val prefs = getSharedPreferences("fluxo_config", Context.MODE_PRIVATE)
            val hora  = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
            val linhaAtual = "[$hora] $msg"
            val anteriores = prefs.getString("diag_99_log", "") ?: ""
            val linhas = (anteriores.split("\n") + linhaAtual)
                .filter { it.isNotBlank() }
                .takeLast(60)
            prefs.edit().putString("diag_99_log", linhas.joinToString("\n")).apply()
        } catch (_: Exception) {}
    }

    override fun onInterrupt() { resetarEstado99() }

    // ══════════════════════════════════════════════════════════════════════
    // PROCESSAMENTO DE TOAST
    // ══════════════════════════════════════════════════════════════════════

    private fun processarToast99(texto: String) {
        val t = texto.lowercase(Locale.getDefault()).trim()

        if (eToastFinalizacao99(t)) {
            if (estado99 == Estado99.FINALIZANDO || estado99 == Estado99.EM_ANDAMENTO) {
                cancelarTimeout99()
                salvarCorrida99()
            }
            return
        }

        if (eToastCancelamento99(t)) {
            if (estado99 != Estado99.IDLE) {
                cancelarTudo99()
                esconderOverlay99()
                resetarEstado99()
            }
        }
    }

    /** Termos de finalização observados no app da 99 */
    private fun eToastFinalizacao99(t: String): Boolean =
        t.contains("corrida finalizada") ||
        t.contains("viagem finalizada")  ||
        t.contains("entrega conclu")     ||
        t.contains("corrida concluída")  ||
        t.contains("corrida concluida")

    /**
     * ⚠️ NÃO usar "cancelad" genérico — contadores regressivos podem conter
     * a palavra sem ser um cancelamento real.
     */
    private fun eToastCancelamento99(t: String): Boolean =
        t.contains("corrida cancelada") ||
        t.contains("viagem cancelada")  ||
        t.contains("pedido cancelado")  ||
        t.contains("corrida recusada")

    // ══════════════════════════════════════════════════════════════════════
    // PROCESSAMENTO DE TELA
    // ══════════════════════════════════════════════════════════════════════

    private fun processarTela99(raizes: List<AccessibilityNodeInfo>) {
        // Texto combinado de TODAS as janelas (overlay + tela de trás) —
        // usado nos estados que só precisam de texto (toast/finalização).
        val textoTela = raizes.joinToString(" ") { coletarTextoTela99(it) }
        // Raiz "principal" pra ações que precisam de UM nó específico
        // (clique em botão) — a mais alta na pilha (provável overlay).
        val raizPrincipal = raizes.first()

        when (estado99) {
            Estado99.IDLE              -> verificarOferta99(raizes, textoTela)
            Estado99.AGUARDANDO_ACEITE -> verificarAceite99(raizPrincipal, textoTela)
            Estado99.EM_ANDAMENTO      -> verificarAndamento99(raizPrincipal, textoTela)
            Estado99.FINALIZANDO       -> verificarFinalizando99(raizPrincipal, textoTela)
        }
    }

    // ── Detecção OCR-ONLY (a tela de oferta da 99 não expõe texto pra
    //    acessibilidade — confirmado em testes reais) ──────────────────────

    private var ultimoSnapshotMs99 = 0L

    private fun verificarOferta99(raizes: List<AccessibilityNodeInfo>, textoTela: String) {
        if (raizes.isEmpty()) { cancelarLeituraOferta99(); return }

        // Diagnóstico leve (throttled) — só registro, não trava o fluxo
        val agoraSnap = System.currentTimeMillis()
        if (agoraSnap - ultimoSnapshotMs99 > 6000L) {
            ultimoSnapshotMs99 = agoraSnap
            logDiag99("Modo OCR-only — janelas=${raizes.size} texto-acessibilidade=\"${textoTela.take(100)}\"")
        }

        // Vai DIRETO pro OCR — não perde tempo tentando a acessibilidade
        // primeiro, já que na tela de oferta ela nunca retorna nada mesmo.
        // Throttle bem mais curto (900ms) que antes (2.5s) pra não perder
        // a janela de tempo em que a oferta fica visível na tela.
        if (estado99 != Estado99.IDLE) return
        if (ocrEmAndamento99) return
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.R) {
            logDiag99("OCR indisponível — precisa Android 11+")
            return
        }
        if (agoraSnap - ultimoOcrMs99 < 900L) return
        ultimoOcrMs99 = agoraSnap
        dispararOcr99()
    }

    // ── OCR: caminho alternativo quando a acessibilidade vem vazia ─────────

    @androidx.annotation.RequiresApi(android.os.Build.VERSION_CODES.R)
    private fun dispararOcr99() {
        ocrEmAndamento99 = true
        logDiag99("Acessibilidade veio vazia — tentando OCR (leitura por imagem)...")
        NoveNoveOcrHelper.capturarEler(this) { resultado ->
            ocrEmAndamento99 = false
            if (resultado == null) {
                logDiag99("OCR falhou (screenshot ou reconhecimento não funcionou)")
                return@capturarEler
            }
            processarResultadoOcr99(resultado)
        }
    }

    private fun processarResultadoOcr99(resultado: NoveNoveOcrHelper.ResultadoOcr) {
        val t = resultado.textoCompleto.lowercase(Locale.getDefault())
        val blocoAceitar = NoveNoveOcrHelper.encontrarBloco(resultado, "aceitar")

        if (blocoAceitar == null) {
            logDiag99("OCR rodou mas não achou 'Aceitar' na imagem — texto lido: \"${t.take(150)}\"")
            return
        }

        val pareceOferta = ehTela99DeOferta(t)
        logDiag99("OCR encontrou 'Aceitar'! oferta=$pareceOferta texto=\"${t.take(200)}\"")

        if (!pareceOferta) return
        if (estado99 == Estado99.AGUARDANDO_ACEITE) return

        val valor = extrairValor99(t)
        if (valor == null) {
            logDiag99("OCR: FALHA na extração — regex de valor (R$) não encontrou nada no texto lido")
            return
        }
        val km  = extrairKm99(t) ?: 0f
        val ganhoPorKm = if (km > 0f) valor / km else 0f
        // Endereços via OCR: heurística simples (linhas com vírgula, sem R$/km)
        val enderecos = resultado.blocos
            .map { it.texto.trim() }
            .filter { it.length > 8 && it.contains(",") &&
                !it.contains("R$", ignoreCase = true) &&
                !Regex("""\d+\s*(min|km)""", RegexOption.IGNORE_CASE).containsMatchIn(it) }
        val orig = enderecos.getOrNull(0) ?: ""
        val dest = enderecos.getOrNull(1) ?: ""
        val forma = extrairFormaPagamento99(t)

        val prefs       = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val minimoKm    = prefs.getFloat("minimo_km",    1.20f)
        val minimoValor = prefs.getFloat("minimo_valor", 0f)
        val valeAPena   = ganhoPorKm >= minimoKm && (minimoValor <= 0f || valor >= minimoValor)

        corridaValor99      = valor
        corridaKm99         = km
        corridaGanhoPorKm99 = ganhoPorKm
        corridaValeAPena99  = valeAPena
        corridaOrigem99     = orig
        corridaDestino99    = dest
        corridaForma99      = forma
        corridaHoraInicio99 = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        // Guarda a posição do botão "Aceitar" pra poder simular o toque
        ocrBoundsAceitar99 = blocoAceitar.bounds

        val autoAceitar = prefs.getBoolean("auto_aceitar", false)
        val autoRecusar = prefs.getBoolean("auto_recusar", false)
        val ofertaNova  = !overlayAtivo99 || kotlin.math.abs(valor - ultimoValorOferta99) > 0.01f

        if (!ofertaNova) { estado99 = Estado99.AGUARDANDO_ACEITE; return }

        ultimoValorOferta99 = valor
        overlayAtivo99      = true
        estado99            = Estado99.AGUARDANDO_ACEITE
        logDiag99("OCR: oferta processada com sucesso — valor=R$$valor km=$km")

        mostrarOverlay99(valor, km, ganhoPorKm, valeAPena, autoAceitar, autoRecusar, orig, dest)
        tocarSom99(valeAPena, prefs)

        cancelarAutoAR99()
        val tempoAutoMs = prefs.getInt("tempo_auto_aceitar", 3) * 1000L
        if (valeAPena && autoAceitar) {
            runnableAutoAceitar99 = Runnable {
                if (estado99 == Estado99.AGUARDANDO_ACEITE) {
                    val bounds = ocrBoundsAceitar99
                    if (bounds != null) {
                        tocarNasCoordenadas99(bounds.centerX().toFloat(), bounds.centerY().toFloat())
                        logDiag99("OCR: toque simulado em Aceitar nas coordenadas (${bounds.centerX()}, ${bounds.centerY()})")
                    }
                }
            }.also { handler99.postDelayed(it, tempoAutoMs) }
        }
        // Auto-recusar via OCR não é feito por segurança — sem um "X" mapeado
        // com confiança, arriscar tocar no lugar errado é pior que não recusar.
    }

    /** Simula um toque na tela nas coordenadas exatas (usado com resultado de OCR). */
    private fun tocarNasCoordenadas99(x: Float, y: Float) {
        try {
            val path = android.graphics.Path().apply { moveTo(x, y) }
            dispatchGesture(
                android.accessibilityservice.GestureDescription.Builder()
                    .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(path, 0L, 100L))
                    .build(), null, null
            )
        } catch (_: Exception) {}
    }

    // (extração via acessibilidade removida — o app usa exclusivamente OCR
    // pra detectar ofertas da 99, já que a tela de oferta não expõe texto
    // pra acessibilidade. Ver dispararOcr99() / processarResultadoOcr99())

    // ── AGUARDANDO_ACEITE → EM_ANDAMENTO ──────────────────────────────────

    private fun verificarAceite99(raiz: AccessibilityNodeInfo, textoTela: String) {
        val t = textoTela.lowercase(Locale.getDefault())

        if (eToastCancelamento99(t)) {
            cancelarTudo99(); esconderOverlay99(); resetarEstado99(); return
        }

        val aCaminho = t.contains("a caminho")             ||
                       t.contains("já estou chegando")     ||
                       t.contains("cheguei no local")      ||
                       t.contains("aguardando passageiro") ||
                       t.contains("aguardando cliente")

        // Quando o botão "Aceitar" some da tela (sem toque em Recusar
        // porque a 99 não tem esse texto), consideramos que avançou
        val botaoSumiu = !overlayAtivo99 && !temBotaoVisivel99(raiz, "Aceitar")

        if (aCaminho || botaoSumiu) {
            cancelarAutoAR99()
            esconderOverlay99()
            estado99 = Estado99.EM_ANDAMENTO
        }
    }

    // ── EM_ANDAMENTO → FINALIZANDO ────────────────────────────────────────

    private fun verificarAndamento99(raiz: AccessibilityNodeInfo, textoTela: String) {
        val t = textoTela.lowercase(Locale.getDefault())

        if (eToastCancelamento99(t)) {
            cancelarTudo99(); esconderOverlay99(); resetarEstado99(); return
        }

        val telaDeFinalizar = t.contains("finalizar corrida") ||
                              t.contains("finalizar viagem")  ||
                              t.contains("preço total")       ||
                              t.contains("preco total")

        if (!telaDeFinalizar) {
            if (eToastFinalizacao99(t)) { cancelarTimeout99(); salvarCorrida99() }
            return
        }

        finalValor99 = extrairValor99(t) ?: corridaValor99
        finalKm99    = extrairKm99(t)    ?: corridaKm99
        finalTempo99 = extrairTempo99(t)

        cancelarTimeout99()
        estado99 = Estado99.FINALIZANDO
        iniciarTimeout99(TIMEOUT_FINALIZANDO_MS_99) {
            if (estado99 == Estado99.FINALIZANDO) salvarCorrida99()
        }
    }

    // ── FINALIZANDO → aguarda toast ───────────────────────────────────────

    private fun verificarFinalizando99(raiz: AccessibilityNodeInfo, textoTela: String) {
        val t = textoTela.lowercase(Locale.getDefault())

        if (eToastFinalizacao99(t)) { cancelarTimeout99(); salvarCorrida99(); return }

        if (eToastCancelamento99(t)) {
            cancelarTudo99(); esconderOverlay99(); resetarEstado99(); return
        }

        val novoValor = extrairValor99(t)
        if (novoValor != null && novoValor > 0f) finalValor99 = novoValor
        val novoKm = extrairKm99(t)
        if (novoKm != null && novoKm > 0f) finalKm99 = novoKm
        if (finalTempo99.isEmpty()) finalTempo99 = extrairTempo99(t)
    }

    // ══════════════════════════════════════════════════════════════════════
    // SALVAR CORRIDA
    // ══════════════════════════════════════════════════════════════════════

    private fun salvarCorrida99() {
        try {
            val valorFinal = if (finalValor99 > 0f) finalValor99 else corridaValor99
            val kmFinal    = if (finalKm99    > 0f) finalKm99    else corridaKm99
            val gpkm       = if (kmFinal      > 0f) valorFinal / kmFinal else corridaGanhoPorKm99

            val prefs       = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
            val minimoKm    = prefs.getFloat("minimo_km",    1.20f)
            val minimoValor = prefs.getFloat("minimo_valor", 0f)
            val valeAPena   = gpkm >= minimoKm && (minimoValor <= 0f || valorFinal >= minimoValor)
            val horaFim     = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

            DatabaseHelper(this).inserirCorrida(
                Corrida(
                    valor          = valorFinal,
                    kmTotal        = kmFinal,
                    ganhoPorKm     = gpkm,
                    valeAPena      = valeAPena,
                    origem         = corridaOrigem99,
                    destino        = corridaDestino99,
                    formaPagamento = corridaForma99,
                    passageiro     = "",
                    horaInicio     = corridaHoraInicio99,
                    horaFim        = horaFim,
                    tempoExecucao  = finalTempo99
                )
            )

            FloatingEarningsService.instanciaAtiva?.atualizarValor()
                ?: startService(Intent(this, FloatingEarningsService::class.java).apply {
                    action = FloatingEarningsService.ACTION_ATUALIZAR
                })

            try {
                val mgr = android.appwidget.AppWidgetManager.getInstance(this)
                val ids = mgr.getAppWidgetIds(
                    android.content.ComponentName(this, FluxoWidgetProvider::class.java))
                if (ids.isNotEmpty()) sendBroadcast(
                    Intent(this, FluxoWidgetProvider::class.java).apply {
                        action = android.appwidget.AppWidgetManager.ACTION_APPWIDGET_UPDATE
                        putExtra(android.appwidget.AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                    })
            } catch (_: Exception) {}

            verificarMeta99(valorFinal, prefs)
        } catch (_: Exception) {}

        resetarEstado99()
    }

    // ══════════════════════════════════════════════════════════════════════
    // OVERLAY (reusa o mesmo OverlayService genérico do app)
    // ══════════════════════════════════════════════════════════════════════

    private fun mostrarOverlay99(
        valor: Float, km: Float, ganhoPorKm: Float,
        valeAPena: Boolean, autoAceitar: Boolean, autoRecusar: Boolean,
        origem: String = "", destino: String = ""
    ) {
        try {
            androidx.core.content.ContextCompat.startForegroundService(
                this, Intent(this, OverlayService::class.java).apply {
                    action = "MOSTRAR"
                    putExtra("valor",        valor)
                    putExtra("km_total",     km)
                    putExtra("ganho_por_km", ganhoPorKm)
                    putExtra("vale_a_pena",  valeAPena)
                    putExtra("auto_aceitar", autoAceitar)
                    putExtra("auto_recusar", autoRecusar)
                    putExtra("origem",       origem)
                    putExtra("destino",      destino)
                }
            )
            logDiag99("mostrarOverlay99() chamado sem erros")
        } catch (e: Exception) {
            logDiag99("ERRO ao chamar OverlayService: ${e.javaClass.simpleName} — ${e.message}")
        }
    }

    internal fun esconderOverlay99() {
        overlayAtivo99 = false
        try {
            androidx.core.content.ContextCompat.startForegroundService(
                this, Intent(this, OverlayService::class.java).apply { action = "ESCONDER" }
            )
        } catch (_: Exception) {}
    }

    // ══════════════════════════════════════════════════════════════════════
    // SOM E META
    // ══════════════════════════════════════════════════════════════════════

    private fun tocarSom99(valeAPena: Boolean, prefs: android.content.SharedPreferences) {
        if (valeAPena  && !prefs.getBoolean("som_aceitar", true))  return
        if (!valeAPena && !prefs.getBoolean("som_recusar", false)) return
        try {
            val tipo = if (valeAPena) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_NACK
            val tg   = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
            tg.startTone(tipo, 300)
            handler99.postDelayed({ try { tg.release() } catch (_: Exception) {} }, 600)
        } catch (_: Exception) {}
    }

    private fun verificarMeta99(valorAdicionado: Float, prefs: android.content.SharedPreferences) {
        val meta = prefs.getFloat("meta_diaria", 0f)
        if (meta <= 0f || !prefs.getBoolean("som_meta", true)) return
        try {
            val totalHoje = DatabaseHelper(this).run { resumo(buscarHoje())["total"] ?: 0f }
            if (totalHoje >= meta && (totalHoje - valorAdicionado) < meta) {
                val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100)
                repeat(3) { i ->
                    handler99.postDelayed({
                        try { tg.startTone(ToneGenerator.TONE_PROP_BEEP, 200) } catch (_: Exception) {}
                    }, i * 400L)
                }
                handler99.postDelayed({ try { tg.release() } catch (_: Exception) {} }, 1800)
            }
        } catch (_: Exception) {}
    }

    // ══════════════════════════════════════════════════════════════════════
    // CONTROLE DE TIMEOUT E ESTADO
    // ══════════════════════════════════════════════════════════════════════

    private fun iniciarTimeout99(ms: Long, acao: () -> Unit) {
        cancelarTimeout99()
        val r = Runnable { acao() }
        timeoutRunnable99 = r
        handler99.postDelayed(r, ms)
    }

    internal fun cancelarTimeout99() {
        timeoutRunnable99?.let { handler99.removeCallbacks(it) }
        timeoutRunnable99 = null
    }

    internal fun cancelarAutoAR99() {
        runnableAutoAceitar99?.let { handler99.removeCallbacks(it) }; runnableAutoAceitar99 = null
        runnableAutoRecusar99?.let { handler99.removeCallbacks(it) }; runnableAutoRecusar99 = null
    }

    internal fun cancelarLeituraOferta99() {
        runnableLeituraOferta99?.let { handler99.removeCallbacks(it) }
        runnableLeituraOferta99 = null
    }

    internal fun cancelarTudo99() {
        cancelarTimeout99()
        cancelarAutoAR99()
        cancelarLeituraOferta99()
    }

    internal fun resetarEstado99() {
        estado99            = Estado99.IDLE
        corridaValor99      = 0f; corridaKm99 = 0f; corridaGanhoPorKm99 = 0f
        corridaValeAPena99  = false
        corridaOrigem99     = ""; corridaDestino99 = ""
        corridaForma99      = ""; corridaHoraInicio99 = ""
        finalValor99        = 0f; finalKm99 = 0f; finalTempo99 = ""
        overlayAtivo99      = false; ultimoValorOferta99 = 0f
        ocrBoundsAceitar99  = null
        cancelarTudo99()
    }
}
