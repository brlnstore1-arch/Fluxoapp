package com.fluxoapp

import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo

/**
 * MaximNodeUtils — FluxoApp
 *
 * Utilitários de árvore de acessibilidade e interação com a UI do Taxsee:
 *   - Busca e travessia de nós
 *   - Detecção de botões visíveis
 *   - Clique em nós (com e sem verificação de visibilidade)
 *   - Gestos de tap (coordenadas fixas e reais)
 *   - Coleta de texto da tela
 *   - Acesso à janela do Taxsee
 */

// ── Travessia de árvore ───────────────────────────────────────────────────────

internal fun MaximAccessibilityService.encontrarNo(
    raiz: AccessibilityNodeInfo,
    predicado: (AccessibilityNodeInfo) -> Boolean
): AccessibilityNodeInfo? {
    if (predicado(raiz)) return raiz
    for (i in 0 until raiz.childCount) {
        val filho = raiz.getChild(i) ?: continue
        val r     = encontrarNo(filho, predicado)
        if (r != null) return r
    }
    return null
}

internal fun MaximAccessibilityService.visitarNos(
    raiz: AccessibilityNodeInfo,
    visitante: (AccessibilityNodeInfo) -> Unit
) {
    visitante(raiz)
    for (i in 0 until raiz.childCount) {
        visitarNos(raiz.getChild(i) ?: continue, visitante)
    }
}

internal fun MaximAccessibilityService.coletarTextoTela(raiz: AccessibilityNodeInfo): String {
    val sb = StringBuilder()
    visitarNos(raiz) { no ->
        if (no.isVisibleToUser) {
            no.text?.toString()?.takeIf { it.isNotBlank() }
                ?.let { sb.append(it).append(" ") }
            no.contentDescription?.toString()?.takeIf { it.isNotBlank() }
                ?.let { sb.append(it).append(" ") }
        }
    }
    return sb.toString()
}

// ── Botões e cliques ──────────────────────────────────────────────────────────

internal fun MaximAccessibilityService.temBotaoVisivel(raiz: AccessibilityNodeInfo, texto: String): Boolean =
    encontrarNo(raiz) { no ->
        no.text?.toString()?.equals(texto, ignoreCase = true) == true && no.isVisibleToUser
    } != null

internal fun MaximAccessibilityService.clicarBotao(raiz: AccessibilityNodeInfo, texto: String): Boolean {
    val no = encontrarNo(raiz) { no ->
        no.text?.toString()?.equals(texto, ignoreCase = true) == true && no.isVisibleToUser
    } ?: return false
    return no.performAction(AccessibilityNodeInfo.ACTION_CLICK)
}

/**
 * Clica sem verificar visibilidade nem isClickable.
 * Estratégia em 3 tentativas:
 *   1. ACTION_CLICK no nó do texto
 *   2. ACTION_CLICK no pai (Taxsee registra o listener no ViewGroup)
 *   3. Tap nas coordenadas reais via gesto
 */
internal fun MaximAccessibilityService.clicarBotaoIgnorandoVisibilidade(raiz: AccessibilityNodeInfo, texto: String): Boolean {
    val no = encontrarNo(raiz) { n ->
        n.text?.toString()?.equals(texto, ignoreCase = true) == true
    } ?: return false

    if (no.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true

    val pai = no.parent
    if (pai != null && pai.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true

    val bounds = Rect()
    no.getBoundsInScreen(bounds)
    if (!bounds.isEmpty) {
        realizarTapNoBotao(raiz, texto)
        return true
    }

    return false
}

internal fun MaximAccessibilityService.fecharDialogCancelamento(raiz: AccessibilityNodeInfo? = null) {
    val r = raiz ?: rootInActiveWindow ?: return
    encontrarNo(r) { no ->
        no.text?.toString()?.equals("Ok", ignoreCase = true) == true && no.isVisibleToUser
    }?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
}

// ── Gestos e janela ───────────────────────────────────────────────────────────

/**
 * Retorna a raiz da janela do Taxsee buscando diretamente na lista de janelas.
 * Quando o overlay do FluxoApp está ativo, rootInActiveWindow pode retornar
 * a raiz do overlay em vez do Taxsee.
 */
internal fun MaximAccessibilityService.getRaizTaxsee(): AccessibilityNodeInfo? {
    return try {
        windows?.firstOrNull { win ->
            win.root?.packageName?.toString() == "com.taxsee.driver"
        }?.root
    } catch (_: Exception) { rootInActiveWindow }
}

internal fun MaximAccessibilityService.realizarTap() {
    try {
        val m = resources.displayMetrics
        val path = Path().apply { moveTo(m.widthPixels / 2f, m.heightPixels * 0.75f) }
        dispatchGesture(
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0L, 100L))
                .build(), null, null
        )
    } catch (_: Exception) {}
}

/**
 * Tap nas coordenadas reais do botão, mais preciso que realizarTap().
 */
internal fun MaximAccessibilityService.realizarTapNoBotao(raiz: AccessibilityNodeInfo?, texto: String) {
    try {
        if (raiz != null) {
            val no = encontrarNo(raiz) { n ->
                n.text?.toString()?.equals(texto, ignoreCase = true) == true
            }
            if (no != null) {
                val bounds = Rect()
                no.getBoundsInScreen(bounds)
                if (!bounds.isEmpty) {
                    val path = Path().apply {
                        moveTo(bounds.centerX().toFloat(), bounds.centerY().toFloat())
                    }
                    dispatchGesture(
                        GestureDescription.Builder()
                            .addStroke(GestureDescription.StrokeDescription(path, 0L, 100L))
                            .build(), null, null
                    )
                    return
                }
            }
        }
        realizarTap()
    } catch (_: Exception) {}
}
