package com.fluxoapp

/**
 * Constantes centralizadas do FluxoApp.
 * Evita valores hardcoded espalhados pelo código.
 */
object FluxoConfig {

    // SharedPreferences
    const val PREFS_NAME = "FluxoApp"

    // Detecção de corridas
    const val GANHO_POR_KM_PADRAO  = 1.20f
    const val MINIMO_VALOR_PADRAO  = 0f
    const val TEMPO_AUTO_PADRAO    = 3       // segundos

    // Timeouts do AccessibilityService
    const val TIMEOUT_FINALIZANDO_MS    = 30_000L   // 30s aguardando toast
    const val DEBOUNCE_TELA_MS          = 800L       // debounce eventos de tela
    const val DELAY_MOSTRAR_OVERLAY_MS  = 800L       // delay antes de exibir overlay

    // Pacote monitorado
    const val PKG_TAXSEE = "com.taxsee.driver"

    // Período offline tolerado sem revalidar licença
    const val MAX_OFFLINE_DIAS = 3L
}
