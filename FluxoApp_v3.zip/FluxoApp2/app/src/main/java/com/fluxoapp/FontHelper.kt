package com.fluxoapp

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.content.res.Resources

/**
 * FontHelper — FluxoApp
 *
 * Aplica o tamanho de fonte global configurado pelo usuário.
 * Funciona sobrescrevendo o fontScale nos recursos da Activity.
 *
 * Chame attachBaseContext() em cada Activity para aplicar.
 * Valores: 0=Pequeno(0.85x)  1=Médio(1.0x)  2=Grande(1.2x)
 */
object FontHelper {

    private val escalas = mapOf(0 to 0.85f, 1 to 1.0f, 2 to 1.2f)

    fun escalaAtual(context: Context): Float {
        val nivel = context.getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
            .getInt("tamanho_fonte", 1).coerceIn(0, 2)
        return escalas[nivel] ?: 1.0f
    }

    /**
     * Chame no attachBaseContext de cada Activity:
     *   override fun attachBaseContext(base: Context) {
     *       super.attachBaseContext(FontHelper.wrap(base))
     *   }
     */
    fun wrap(context: Context): Context {
        val escala = escalaAtual(context)
        if (escala == 1.0f) return context  // sem alteração, evita overhead

        val config = Configuration(context.resources.configuration)
        config.fontScale = escala
        return context.createConfigurationContext(config)
    }
}
