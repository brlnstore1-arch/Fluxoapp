package com.fluxoapp

import android.app.*
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * KmTrackerService — FluxoApp
 *
 * Serviço foreground leve que rastreia km reais rodados durante o dia.
 * Usa GPS nativo (sem dependências externas). Acumula distância total
 * mesmo entre corridas — alimenta métricas de abastecimento.
 *
 * Ativado quando o motorista liga o serviço de monitoramento.
 * Reinicia a contagem à meia-noite automaticamente.
 */
class KmTrackerService : Service(), LocationListener {

    private var locationManager: LocationManager? = null
    private var ultimaLocalizacao: Location? = null
    private var kmAcumuladoSessao = 0f
    private var dataAtual = dataHoje()

    companion object {
        const val CHANNEL_ID   = "km_tracker_channel"
        const val NOTIF_ID     = 42
        const val ACTION_PARAR = "KM_TRACKER_PARAR"
        const val PREF_KM_HOJE = "km_rastreado_hoje"
        const val PREF_DATA_KM = "km_data_registro"

        // Distância mínima para atualizar (5m) e intervalo mínimo (3s)
        private const val MIN_DISTANCIA_M = 5f
        private const val MIN_INTERVALO_MS = 3_000L

        // Velocidade máxima razoável para moto/carro: 150 km/h = 41.7 m/s
        // Filtra pulos de GPS (teleportação)
        private const val VELOCIDADE_MAX_MS = 42f

        @Volatile var instancia: KmTrackerService? = null

        fun kmHoje(context: Context): Float {
            val prefs = context.getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
            val dataRegistro = prefs.getString(PREF_DATA_KM, "") ?: ""
            return if (dataRegistro == dataHoje()) prefs.getFloat(PREF_KM_HOJE, 0f) else 0f
        }

        private fun dataHoje(): String {
            val sdf = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault())
            return sdf.format(java.util.Date())
        }
    }

    override fun onCreate() {
        super.onCreate()
        instancia = this
        criarCanal()
        startForeground(NOTIF_ID, criarNotificacao(0f))
        iniciarRastreamento()
        // Restaurar km já acumulado hoje (se reiniciou)
        val prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val dataRegistro = prefs.getString(PREF_DATA_KM, "")
        kmAcumuladoSessao = if (dataRegistro == dataHoje()) prefs.getFloat(PREF_KM_HOJE, 0f) else 0f
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_PARAR) {
            pararRastreamento()
            stopSelf()
            return START_NOT_STICKY
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        pararRastreamento()
        if (instancia == this) instancia = null
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ── GPS ──────────────────────────────────────────────────────────────

    private fun iniciarRastreamento() {
        try {
            locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
            val provider = when {
                locationManager!!.isProviderEnabled(LocationManager.GPS_PROVIDER)     -> LocationManager.GPS_PROVIDER
                locationManager!!.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                else -> return
            }
            locationManager!!.requestLocationUpdates(provider, MIN_INTERVALO_MS, MIN_DISTANCIA_M, this)
        } catch (_: SecurityException) {}
        catch (_: Exception) {}
    }

    private fun pararRastreamento() {
        try { locationManager?.removeUpdates(this) } catch (_: Exception) {}
    }

    override fun onLocationChanged(loc: Location) {
        val anterior = ultimaLocalizacao
        val hoje = dataHoje()

        // Reiniciar contagem à meia-noite
        if (hoje != dataAtual) {
            dataAtual = hoje
            kmAcumuladoSessao = 0f
        }

        if (anterior != null) {
            val distanciaM = anterior.distanceTo(loc)
            val tempoS = (loc.time - anterior.time) / 1000f

            // Filtrar: velocidade razoável + distância mínima significativa
            val velocidade = if (tempoS > 0) distanciaM / tempoS else 0f
            if (distanciaM >= MIN_DISTANCIA_M && velocidade <= VELOCIDADE_MAX_MS) {
                val kmPercorrido = distanciaM / 1000f
                kmAcumuladoSessao += kmPercorrido
                salvarKm(kmAcumuladoSessao)
                atualizarNotificacao(kmAcumuladoSessao)
            }
        }

        ultimaLocalizacao = loc
    }

    private fun salvarKm(km: Float) {
        getSharedPreferences("FluxoApp", Context.MODE_PRIVATE).edit()
            .putFloat(PREF_KM_HOJE, km)
            .putString(PREF_DATA_KM, dataHoje())
            .apply()
    }

    private fun atualizarNotificacao(km: Float) {
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIF_ID, criarNotificacao(km))
        } catch (_: Exception) {}
    }

    private fun criarNotificacao(km: Float): Notification {
        val kmStr = "%.1f".format(km)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("FluxoApp — Rastreando km")
            .setContentText("$kmStr km rodados hoje")
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun criarCanal() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID, "Rastreamento de km",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Km rodados no dia" }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    // Callbacks obrigatórios do LocationListener
    @Deprecated("Deprecated in API 29")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}
}
