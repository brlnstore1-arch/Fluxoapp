package com.fluxoapp

import android.app.*
import android.content.Context
import android.content.Intent
import android.location.Location
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority

/**
 * KmTrackerService — rastreamento de km via GPS.
 *
 * Precisão melhorada (versão 2):
 *  1. Usa FusedLocationProviderClient (Google Play Services) em vez do
 *     LocationManager puro — combina GPS + rede + sensores com filtro
 *     Kalman interno do próprio Google, resultado muito mais estável.
 *  2. Descarta fixes com acurácia declarada ruim (> ACURACIA_MAX_M),
 *     que são a maior causa de "km fantasma" quando o GPS está impreciso
 *     (prédios altos, dentro de casa, começo do trajeto etc).
 *  3. Exige que a distância medida supere a margem de erro combinada dos
 *     dois pontos (soma das acurácias × fator) — filtro clássico contra
 *     "jitter" de GPS parado, que faz o app contar km com o veículo parado.
 *  4. Descarta velocidades abaixo de VELOCIDADE_MIN_MS (parado/jitter) e
 *     acima de VELOCIDADE_MAX_MS (salto de GPS impossível).
 *  5. Só atualiza o ponto de referência (ultimaLocalizacao) quando o fix
 *     atual tem acurácia aceitável — evita que um fix ruim vire a base de
 *     comparação para o próximo cálculo, o que arrastaria o erro adiante.
 */
class KmTrackerService : Service() {

    private var fusedClient: FusedLocationProviderClient? = null
    private var locationCallback: LocationCallback? = null
    private var ultimaLocalizacao: Location? = null
    private var kmAcumuladoSessao = 0f
    private var dataAtual = dataHoje()

    companion object {
        const val CHANNEL_ID          = "km_tracker_channel"
        const val NOTIF_ID            = 42
        const val ACTION_PARAR        = "KM_TRACKER_PARAR"
        const val ACTION_KM_ATUALIZADO = "com.fluxoapp.KM_ATUALIZADO"

        const val PREF_KM_HOJE        = "km_rastreado_hoje"
        const val PREF_DATA_KM        = "km_data_registro"
        // Acumulador persistente: km desde o último abastecimento
        // É zerado em salvarAbastecimento() e nunca reseta por data
        const val PREF_KM_DESDE_ABASTEC = "km_desde_abastec"

        private const val MIN_DISTANCIA_M   = 8f
        private const val MIN_INTERVALO_MS  = 3_000L
        private const val VELOCIDADE_MAX_MS = 42f   // ~150 km/h — descarta saltos de GPS
        private const val VELOCIDADE_MIN_MS = 0.6f  // ~2,2 km/h — descarta jitter parado
        private const val ACURACIA_MAX_M    = 25f   // ignora fixes com erro declarado muito alto
        // Fração da margem de erro combinada que a distância precisa superar
        // para ser considerada movimento real (filtro clássico de ruído GPS)
        private const val FATOR_MARGEM_ERRO = 0.7f
        private const val ACURACIA_PADRAO_M = 15f   // usada se o fix não informar acurácia

        @Volatile var instancia: KmTrackerService? = null

        /** km GPS do dia atual */
        fun kmHoje(context: Context): Float {
            val prefs = context.getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
            val dataRegistro = prefs.getString(PREF_DATA_KM, "") ?: ""
            return if (dataRegistro == dataHoje()) prefs.getFloat(PREF_KM_HOJE, 0f) else 0f
        }

        /**
         * km total percorrido desde o último abastecimento.
         * Acumula entre dias — não reseta à meia-noite.
         */
        fun kmDesdeAbastec(context: Context): Float {
            return context.getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
                .getFloat(PREF_KM_DESDE_ABASTEC, 0f)
        }

        /**
         * Zera o acumulador desde o abastecimento.
         * Chamar imediatamente após registrar um novo abastecimento.
         */
        fun zerarKmDesdeAbastec(context: Context) {
            context.getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
                .edit().putFloat(PREF_KM_DESDE_ABASTEC, 0f).apply()
        }

        fun dataHoje(): String {
            val sdf = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault())
            return sdf.format(java.util.Date())
        }
    }

    override fun onCreate() {
        super.onCreate()
        instancia = this
        criarCanal()
        startForeground(NOTIF_ID, criarNotificacao(0f))
        // Restaurar km hoje já acumulado (se o serviço foi reiniciado)
        val prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val dataRegistro = prefs.getString(PREF_DATA_KM, "")
        kmAcumuladoSessao = if (dataRegistro == dataHoje()) prefs.getFloat(PREF_KM_HOJE, 0f) else 0f
        iniciarRastreamento()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_PARAR) {
            pararRastreamento()
            stopSelf()
            return START_NOT_STICKY
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        pararRastreamento()
        if (instancia == this) instancia = null
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ── GPS (FusedLocationProviderClient) ──────────────────────────────────

    private fun iniciarRastreamento() {
        try {
            fusedClient = LocationServices.getFusedLocationProviderClient(this)

            val request = LocationRequest.Builder(
                Priority.PRIORITY_HIGH_ACCURACY, MIN_INTERVALO_MS
            )
                .setMinUpdateDistanceMeters(MIN_DISTANCIA_M)
                .setMinUpdateIntervalMillis(MIN_INTERVALO_MS)
                .setWaitForAccurateLocation(true)
                .build()

            locationCallback = object : LocationCallback() {
                override fun onLocationResult(result: LocationResult) {
                    result.lastLocation?.let { processarLocalizacao(it) }
                }
            }

            fusedClient?.requestLocationUpdates(
                request, locationCallback!!, mainLooper
            )
        } catch (_: SecurityException) {}
        catch (_: Exception) {}
    }

    private fun pararRastreamento() {
        try { locationCallback?.let { fusedClient?.removeLocationUpdates(it) } } catch (_: Exception) {}
    }

    // ── Processamento com filtros de precisão ──────────────────────────────

    private fun processarLocalizacao(loc: Location) {
        val hoje = dataHoje()

        // Reiniciar contagem diária à meia-noite (sem tocar no acumulador de abastecimento)
        if (hoje != dataAtual) {
            dataAtual = hoje
            kmAcumuladoSessao = 0f
        }

        // FILTRO 1 — descarta fixes com acurácia declarada ruim.
        // Isso evita que um GPS "perdido" (prédio, começo do trajeto,
        // dentro de casa) já entre como ponto de referência.
        val acuraciaAtual = if (loc.hasAccuracy()) loc.accuracy else ACURACIA_PADRAO_M
        if (acuraciaAtual > ACURACIA_MAX_M) return

        val anterior = ultimaLocalizacao

        if (anterior == null) {
            ultimaLocalizacao = loc
            return
        }

        val distanciaM = anterior.distanceTo(loc)
        val tempoS     = (loc.time - anterior.time) / 1000f
        val velocidade = if (tempoS > 0) distanciaM / tempoS else 0f

        // FILTRO 2 — margem de erro combinada. A distância medida precisa
        // superar a soma das acurácias dos dois pontos (× fator), senão é
        // muito provável que seja apenas ruído de GPS com o veículo parado.
        val acuraciaAnterior = if (anterior.hasAccuracy()) anterior.accuracy else ACURACIA_PADRAO_M
        val margemErro = (acuraciaAnterior + acuraciaAtual) * FATOR_MARGEM_ERRO

        val distanciaValida  = distanciaM >= MIN_DISTANCIA_M && distanciaM > margemErro
        val velocidadeValida = velocidade in VELOCIDADE_MIN_MS..VELOCIDADE_MAX_MS

        if (distanciaValida && velocidadeValida) {
            val kmPercorrido = distanciaM / 1000f

            // 1) Acumulador diário (reseta à meia-noite)
            kmAcumuladoSessao += kmPercorrido
            salvarKmHoje(kmAcumuladoSessao)

            // 2) Acumulador desde o abastecimento (persiste entre dias)
            val prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
            val kmAbastec = prefs.getFloat(PREF_KM_DESDE_ABASTEC, 0f) + kmPercorrido
            prefs.edit().putFloat(PREF_KM_DESDE_ABASTEC, kmAbastec).apply()

            atualizarNotificacao(kmAcumuladoSessao)

            // 3) Broadcast para FinanceActivity/FloatingEarningsService
            //    atualizarem o gauge em tempo real
            try {
                sendBroadcast(Intent(ACTION_KM_ATUALIZADO).apply {
                    putExtra("km_hoje",          kmAcumuladoSessao)
                    putExtra("km_desde_abastec",  kmAbastec)
                })
            } catch (_: Exception) {}

            // Movimento real confirmado — atualiza o ponto de referência
            ultimaLocalizacao = loc
        } else if (velocidade < VELOCIDADE_MIN_MS) {
            // Veículo parado (sinal, engarrafamento) com fix de boa qualidade —
            // atualiza a referência para não acumular jitter, mas sem contar km
            ultimaLocalizacao = loc
        }
        // Se caiu aqui sem atualizar: fix suspeito (salto ou ruído) — mantém
        // o ponto de referência anterior, evitando que o erro se propague.
    }

    private fun salvarKmHoje(km: Float) {
        getSharedPreferences("FluxoApp", Context.MODE_PRIVATE).edit()
            .putFloat(PREF_KM_HOJE, km)
            .putString(PREF_DATA_KM, dataHoje())
            .apply()
    }

    private fun atualizarNotificacao(km: Float) {
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIF_ID, criarNotificacao(km))
        } catch (_: Exception) {}
    }

    private fun criarNotificacao(km: Float): Notification {
        val kmStr = "%.1f".format(km)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("FluxoApp — Rastreando km")
            .setContentText("$kmStr km rodados hoje")
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun criarCanal() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID, "Rastreamento de km",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Km rodados no dia" }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }
}
