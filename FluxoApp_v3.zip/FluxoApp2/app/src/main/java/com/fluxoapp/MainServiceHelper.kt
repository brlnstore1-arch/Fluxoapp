package com.fluxoapp

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.FrameLayout
import android.widget.TextView
import android.view.View
import android.graphics.Color

/**
 * MainServiceHelper — FluxoApp
 *
 * Responsável por toda a lógica de serviço, licença e permissões da MainActivity:
 *   - Toggle ativar/desativar serviço de acessibilidade
 *   - Verificação de licença e restrições premium
 *   - Dialogs de acessibilidade e desativação segura
 *   - Banner de licença (trial / plano expirando)
 */

// ── SERVIÇO ──────────────────────────────────────────────────────────────────

internal fun MainActivity.configurarBotaoServico() {
    atualizarBotaoServico()
    findViewById<View>(R.id.btnServico)?.setOnClickListener {
        val ativo = prefs.getBoolean("servico_ativo", true)
        if (!ativo) {
            when {
                !isAccessibilityEnabled() -> {
                    mostrarDialogAcessibilidade()
                    return@setOnClickListener
                }
                !Settings.canDrawOverlays(this) -> {
                    FluxoToast.aviso(this, "Permita a sobreposição de tela nas configurações")
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    return@setOnClickListener
                }
                else -> {
                    prefs.edit().putBoolean("servico_ativo", true).apply()
                    try { startService(Intent(this, FloatingEarningsService::class.java)) } catch (_: Throwable) {}
                    FluxoToast.sucesso(this, "Serviço ativado — monitorando corridas!")
                }
            }
        } else {
            prefs.edit().putBoolean("servico_ativo", false).apply()
            try {
                FloatingEarningsService.devePararDefinitivamente = true
                startService(Intent(this, FloatingEarningsService::class.java).apply {
                    action = FloatingEarningsService.ACTION_PARAR
                })
                stopService(Intent(this, FloatingEarningsService::class.java))
            } catch (_: Throwable) {}
            try { stopService(Intent(this, OverlayService::class.java)) } catch (_: Throwable) {}
            mostrarDialogDesativarServico()
            return@setOnClickListener
        }
        atualizarBotaoServico()
    }
}

internal fun MainActivity.atualizarBotaoServico() {
    val btn    = try { findViewById<FrameLayout>(R.id.btnServico) }  catch (_: Throwable) { null } ?: return
    val tvPrin = try { findViewById<TextView>(R.id.tvStatusBar) }    catch (_: Throwable) { null }
    val tvSub  = try { findViewById<TextView>(R.id.tvStatusSub) }    catch (_: Throwable) { null }
    val dot    = try { findViewById<View>(R.id.dotServico) }          catch (_: Throwable) { null }

    val servicoNoSistema = isAccessibilityEnabled()
    val ativoNaPrefs     = prefs.getBoolean("servico_ativo", true)

    if (!servicoNoSistema && ativoNaPrefs) {
        prefs.edit().putBoolean("servico_ativo", false).apply()
    }

    val ativo  = ativoNaPrefs && servicoNoSistema
    val permOk = servicoNoSistema && Settings.canDrawOverlays(this)

    when {
        !ativo -> {
            btn.setBackgroundResource(R.drawable.btn_servico_inativo)
            tvPrin?.text = "SERVIÇO DESATIVADO"
            tvSub?.text  = "Toque para ativar o monitoramento"
            dot?.setBackgroundColor(Color.parseColor("#FF4560"))
        }
        !permOk -> {
            btn.setBackgroundResource(R.drawable.btn_servico_inativo)
            tvPrin?.text = "PERMISSÃO NECESSÁRIA"
            tvSub?.text  = "Toque para configurar"
            dot?.setBackgroundColor(Color.parseColor("#F0B429"))
        }
        else -> {
            btn.setBackgroundResource(R.drawable.btn_servico_ativo)
            tvPrin?.text = "SERVIÇO ATIVO"
            tvSub?.text  = "Monitorando corridas automaticamente"
            try { dot?.setBackgroundResource(R.drawable.dot_status) } catch (_: Throwable) {
                dot?.setBackgroundColor(Color.parseColor("#00E676"))
            }
        }
    }
}

internal fun MainActivity.isAccessibilityEnabled(): Boolean {
    return try {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        s.contains("fluxoapp", ignoreCase = true) || s.contains("MaximAccessibilityService", ignoreCase = true)
    } catch (_: Throwable) { false }
}

// ── DIALOGS DE SERVIÇO ───────────────────────────────────────────────────────

internal fun MainActivity.mostrarDialogAcessibilidade() {
    val passo1Feito = prefs.getBoolean("acessib_passo1_feito", false)

    if (!passo1Feito) {
        val msg = "Vamos ativar em 2 passos simples.\n\n" +
            "PASSO 1 de 2\n" +
            "Voce sera direcionado para Acessibilidade.\n\n" +
            "ATENCAO: vai aparecer um aviso de configuracao restrita - isso e normal!\n\n" +
            "Toque em OK nesse aviso e volte aqui para o Passo 2."
        android.app.AlertDialog.Builder(this)
            .setTitle("Ativar Monitoramento")
            .setMessage(msg)
            .setPositiveButton("Ir para Acessibilidade") { _, _ ->
                prefs.edit().putBoolean("acessib_passo1_feito", true).apply()
                try {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    })
                } catch (_: Throwable) {}
            }
            .setNegativeButton("Cancelar") { d, _ -> d.dismiss() }
            .show()
    } else {
        val msg = "PASSO 2 de 2\n\n" +
            "Libere a restricao:\n\n" +
            "1. Toque em Ir para Aplicativos\n" +
            "2. Toque nos 3 pontos no canto superior direito\n" +
            "3. Toque em Permitir configuracoes restritas\n" +
            "4. Volte aqui e ative o monitoramento\n\n" +
            "Apos liberar, o FluxoApp funcionara normalmente!"
        android.app.AlertDialog.Builder(this)
            .setTitle("Liberar Restricao")
            .setMessage(msg)
            .setPositiveButton("Ir para Aplicativos") { _, _ ->
                prefs.edit().putBoolean("acessib_passo1_feito", false).apply()
                try {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = android.net.Uri.parse("package:$packageName")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    })
                } catch (_: Throwable) {
                    try {
                        startActivity(Intent(Settings.ACTION_APPLICATION_SETTINGS).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        })
                    } catch (_: Throwable) {}
                }
            }
            .setNegativeButton("Cancelar") { d, _ ->
                prefs.edit().putBoolean("acessib_passo1_feito", false).apply()
                d.dismiss()
            }
            .show()
    }
}

internal fun MainActivity.mostrarDialogDesativarServico() {
    val accent = ThemeHelper.cor("accent", prefs)

    val dialog = androidx.appcompat.app.AlertDialog.Builder(this)
        .setTitle("Desativar monitoramento")
        .setMessage(
            "Para parar o monitoramento completamente (necessario para usar bancos como Nubank):" +
            "\n\n1. Toque em ABRIR CONFIGURACOES abaixo" +
            "\n2. Encontre FluxoApp na lista" +
            "\n3. Desative o servico" +
            "\n4. Volte ao app" +
            "\n\nQuando quiser reativar, basta tocar no botao novamente."
        )
        .setPositiveButton("ABRIR CONFIGURAÇÕES") { _, _ ->
            try {
                val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                startActivity(intent)
            } catch (_: Throwable) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }
        .setNegativeButton("Cancelar") { _, _ ->
            prefs.edit().putBoolean("servico_ativo", true).apply()
            atualizarBotaoServico()
        }
        .setCancelable(false)
        .create()

    dialog.show()
    try {
        dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE)?.setTextColor(accent)
    } catch (_: Throwable) {}
}

// ── LICENÇA ──────────────────────────────────────────────────────────────────

internal fun MainActivity.verificarLicencaERestringir() {
    LicenseManager.verificarLicenca { status ->
        runOnUiThread {
            if (!status.temAcesso) {
                if (prefs.getBoolean("servico_ativo", true)) {
                    prefs.edit().putBoolean("servico_ativo", false).apply()
                    try {
                        FloatingEarningsService.devePararDefinitivamente = true
                        startService(Intent(this, FloatingEarningsService::class.java).apply {
                            action = FloatingEarningsService.ACTION_PARAR
                        })
                        stopService(Intent(this, FloatingEarningsService::class.java))
                    } catch (_: Throwable) {}
                }
                prefs.edit()
                    .putBoolean("auto_aceitar", false)
                    .putBoolean("auto_recusar", false)
                    .apply()
                mostrarBannerLicenca(status.mensagem)
            }
        }
    }
}

internal fun MainActivity.mostrarDialogTrial() {
    prefs.edit().putBoolean("mostrar_aviso_trial", false).apply()

    LicenseManager.verificarLicenca { status ->
        runOnUiThread {
            if (status.plano != LicenseManager.PLANO_TRIAL || !status.temAcesso) return@runOnUiThread

            val accent = ThemeHelper.cor("accent", prefs)
            val txtG   = ThemeHelper.cor("text_gray", prefs)

            val msgTrial = "Você está no período de teste gratuito de 7 dias com acesso completo ao FluxoApp." +
                "\n\nDias restantes: " + status.diasRestantes + " dia(s)" +
                "\n\nApós o teste, você precisará assinar o Plano Mensal (R$ 4,99/mês) para continuar " +
                "usando a detecção automática, overlay e auto-aceitar." +
                "\n\nHistórico e relatórios sempre gratuitos. ✓"

            val dialog = androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("🎉 Período de teste ativo")
                .setMessage(msgTrial)
                .setPositiveButton("ASSINAR AGORA") { _, _ ->
                    startActivity(android.content.Intent(this, PlansActivity::class.java))
                }
                .setNegativeButton("Continuar no teste", null)
                .create()

            dialog.show()
            try {
                dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE)?.setTextColor(accent)
                dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEGATIVE)?.setTextColor(txtG)
            } catch (_: Throwable) {}
        }
    }
}

internal fun MainActivity.mostrarBannerLicenca(mensagem: String) {
    try {
        FluxoToast.aviso(this, "⚠️ $mensagem")
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            if (!isFinishing) startActivity(Intent(this, PlansActivity::class.java))
        }, 1_800)
    } catch (_: Throwable) {}
}

internal fun MainActivity.atualizarBannerLicenca() {
    LicenseManager.verificarLicenca { status ->
        runOnUiThread {
            try {
                val card        = findViewById<androidx.cardview.widget.CardView>(R.id.cardLicenca) ?: return@runOnUiThread
                val bg          = findViewById<android.widget.LinearLayout>(R.id.licencaBg)
                val tvIcone     = findViewById<TextView>(R.id.tvLicencaIcone)
                val tvTitulo    = findViewById<TextView>(R.id.tvLicencaTitulo)
                val tvSub       = findViewById<TextView>(R.id.tvLicencaSub)
                val tvDiasLabel = findViewById<TextView>(R.id.tvLicencaDiasLabel)
                val tvDiasRest  = findViewById<TextView>(R.id.tvLicencaDiasRestantes)
                val progress    = findViewById<android.widget.ProgressBar>(R.id.progressLicenca)
                val btnAcao     = findViewById<TextView>(R.id.btnLicencaAcao)
                val dp          = resources.displayMetrics.density

                val accent = ThemeHelper.cor("accent_gold", prefs)
                val green  = ThemeHelper.cor("accent_green", prefs)
                val red    = ThemeHelper.cor("accent_red", prefs)
                val bgCard = ThemeHelper.cor("bg_card", prefs)

                if (status.plano == LicenseManager.PLANO_BLOQUEADO) {
                    card.visibility = View.GONE; return@runOnUiThread
                }

                when {
                    status.plano == LicenseManager.PLANO_TRIAL && status.temAcesso -> {
                        val dias = status.diasRestantes.toInt().coerceAtLeast(0)
                        val totalTrial = LicenseManager.TRIAL_DIAS.toInt()
                        val pct = ((dias.toFloat() / totalTrial) * 100).toInt().coerceIn(0, 100)

                        val (corAcento, _) = when {
                            dias <= 1 -> Pair(red, android.graphics.Color.argb(30, android.graphics.Color.red(red), android.graphics.Color.green(red), android.graphics.Color.blue(red)))
                            dias <= 3 -> Pair(android.graphics.Color.parseColor("#FFD166"), android.graphics.Color.argb(25, 255, 209, 102))
                            else      -> Pair(accent, android.graphics.Color.argb(20, android.graphics.Color.red(accent), android.graphics.Color.green(accent), android.graphics.Color.blue(accent)))
                        }

                        bg?.setBackgroundColor(bgCard)
                        card.setCardBackgroundColor(bgCard)
                        tvIcone?.text = when { dias <= 1 -> "🔴"; dias <= 3 -> "⚠️"; else -> "⏱" }
                        tvTitulo?.text = "Período de teste gratuito"
                        tvTitulo?.setTextColor(ThemeHelper.cor("text_white", prefs))
                        tvSub?.text = if (dias <= 0) "Trial encerrado" else "$dias dia${if (dias != 1) "s" else ""} restante${if (dias != 1) "s" else ""}"
                        tvSub?.setTextColor(corAcento)
                        progress?.progress = pct
                        progress?.progressTintList = android.content.res.ColorStateList.valueOf(corAcento)
                        tvDiasLabel?.text = "Teste iniciado"
                        tvDiasRest?.text  = if (dias <= 0) "Expirado" else "$dias/${totalTrial} dias"
                        tvDiasRest?.setTextColor(corAcento)
                        btnAcao?.visibility = View.VISIBLE
                        btnAcao?.text = "Assinar agora"
                        btnAcao?.background = android.graphics.drawable.GradientDrawable().apply {
                            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                            cornerRadius = 8 * dp; setColor(corAcento)
                        }
                        btnAcao?.setTextColor(android.graphics.Color.parseColor("#000000"))
                        btnAcao?.setOnClickListener { startActivity(android.content.Intent(this, PlansActivity::class.java)) }
                        card.visibility = View.VISIBLE
                    }

                    status.plano != LicenseManager.PLANO_TRIAL && status.temAcesso -> {
                        val dias = status.diasRestantes.toInt()
                        if (dias > 15 || dias == 9999) { card.visibility = View.GONE; return@runOnUiThread }
                        val corAcento = if (dias <= 3) red else android.graphics.Color.parseColor("#FFD166")
                        tvIcone?.text = if (dias <= 3) "🔴" else "📅"
                        tvTitulo?.text = "Plano ${nomePlanoFormatado(status.plano)}"
                        tvTitulo?.setTextColor(ThemeHelper.cor("text_white", prefs))
                        tvSub?.text = "$dias dia${if (dias != 1) "s" else ""} para expirar"
                        tvSub?.setTextColor(corAcento)
                        progress?.progress = ((dias.toFloat() / 30f) * 100).toInt().coerceIn(0, 100)
                        progress?.progressTintList = android.content.res.ColorStateList.valueOf(corAcento)
                        tvDiasLabel?.text = "Vencimento próximo"
                        tvDiasRest?.text  = "$dias dias restantes"
                        tvDiasRest?.setTextColor(corAcento)
                        btnAcao?.visibility = View.VISIBLE
                        btnAcao?.text = "Renovar"
                        btnAcao?.background = android.graphics.drawable.GradientDrawable().apply {
                            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                            cornerRadius = 8 * dp; setColor(corAcento)
                        }
                        btnAcao?.setTextColor(android.graphics.Color.parseColor("#000000"))
                        btnAcao?.setOnClickListener { startActivity(android.content.Intent(this, PlansActivity::class.java)) }
                        card.visibility = View.VISIBLE
                    }

                    else -> { card.visibility = View.GONE }
                }
            } catch (_: Throwable) {}
        }
    }
}

internal fun MainActivity.nomePlanoFormatado(plano: String) = when (plano) {
    LicenseManager.PLANO_MENSAL      -> "Mensal"
    LicenseManager.PLANO_TRIMESTRAL  -> "Trimestral"
    LicenseManager.PLANO_ANUAL       -> "Anual"
    LicenseManager.PLANO_PROMO       -> "Promocional"
    else                             -> plano.replaceFirstChar { it.uppercase() }
}
