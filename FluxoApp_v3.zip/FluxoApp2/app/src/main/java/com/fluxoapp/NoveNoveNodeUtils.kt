package com.fluxoapp

import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo

/**
 * NoveNoveNodeUtils — FluxoApp
 *
 * Utilitários de árvore de acessibilidade e interação com a UI da 99.
 * Módulo 100% independente do MaximNodeUtils.kt — nenhuma função aqui é
 * compartilhada com o Taxsee/Maxim, mesmo que a lógica pareça similar.
 *
 * Diferença chave da 99 em relação ao Taxsee:
 *   - Só existe o botão "Aceitar" (texto). Não há botão "Recusar" — a 99
 *     usa um ícone "X" no canto superior para fechar/recusar a oferta.
 *   - Layout da tela mostra tempo+distância combinados: "5min (2,7km)"
 */

// ── Travessia de árvore ───────────────────────────────────────────────────────

internal fun NoveNoveAccessibilityService.encontrarNo99(
    raiz: AccessibilityNodeInfo,
    predicado: (AccessibilityNodeInfo) -> Boolean
): AccessibilityNodeInfo? {
    if (predicado(raiz)) return raiz
    for (i in 0 until raiz.childCount) {
        val filho = raiz.getChild(i) ?: continue
        val r     = encontrarNo99(filho, predicado)
        if (r != null) return r
    }
    return null
}

internal fun NoveNoveAccessibilityService.visitarNos99(
    raiz: AccessibilityNodeInfo,
    visitante: (AccessibilityNodeInfo) -> Unit
) {
    visitante(raiz)
    for (i in 0 until raiz.childCount) {
        visitarNos99(raiz.getChild(i) ?: continue, visitante)
    }
}

internal fun NoveNoveAccessibilityService.coletarTextoTela99(raiz: AccessibilityNodeInfo): String {
    val sb = StringBuilder()
    visitarNos99(raiz) { no ->
        if (no.isVisibleToUser) {
            no.text?.toString()?.takeIf { it.isNotBlank() }
                ?.let { sb.append(it).append(" ") }
            no.contentDescription?.toString()?.takeIf { it.isNotBlank() }
                ?.let { sb.append(it).append(" ") }
        }
    }
    return sb.toString()
}

// ── Botões e cliques ──────────────────────────────────────────────────────────

internal fun NoveNoveAccessibilityService.temBotaoVisivel99(raiz: AccessibilityNodeInfo, texto: String): Boolean =
    encontrarNo99(raiz) { no ->
        no.text?.toString()?.equals(texto, ignoreCase = true) == true && no.isVisibleToUser
    } != null

/**
 * Detecta o botão "X" de fechar/recusar oferta da 99.
 * A 99 não usa texto "Recusar" — o botão é só um ícone, então buscamos
 * pela contentDescription (acessibilidade costuma expor "Fechar", "Close",
 * "Cancelar", "Recusar oferta" etc dependendo da versão do app/idioma).
 */
internal fun NoveNoveAccessibilityService.temBotaoFecharVisivel99(raiz: AccessibilityNodeInfo): Boolean =
    encontrarNo99(raiz) { no ->
        val desc = no.contentDescription?.toString()?.lowercase() ?: ""
        no.isVisibleToUser && (
            desc.contains("fechar") || desc.contains("close") ||
            desc.contains("cancelar") || desc.contains("recusar") ||
            desc.contains("dismiss")
        )
    } != null

internal fun NoveNoveAccessibilityService.clicarBotao99(raiz: AccessibilityNodeInfo, texto: String): Boolean {
    val no = encontrarNo99(raiz) { no ->
        no.text?.toString()?.equals(texto, ignoreCase = true) == true && no.isVisibleToUser
    } ?: return false
    return no.performAction(AccessibilityNodeInfo.ACTION_CLICK)
}

/**
 * Clica sem verificar visibilidade nem isClickable.
 * Estratégia em 3 tentativas:
 *   1. ACTION_CLICK no nó do texto
 *   2. ACTION_CLICK no pai (apps costumam registrar o listener no ViewGroup)
 *   3. Tap nas coordenadas reais via gesto
 */
internal fun NoveNoveAccessibilityService.clicarBotaoIgnorandoVisibilidade99(raiz: AccessibilityNodeInfo, texto: String): Boolean {
    val no = encontrarNo99(raiz) { n ->
        n.text?.toString()?.equals(texto, ignoreCase = true) == true
    } ?: return false

    if (no.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true

    val pai = no.parent
    if (pai != null && pai.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true

    val bounds = Rect()
    no.getBoundsInScreen(bounds)
    if (!bounds.isEmpty) {
        realizarTapNoBotao99(raiz, texto)
        return true
    }

    return false
}

/**
 * Clica no botão "X" de fechar/recusar (ícone, sem texto).
 * Busca por contentDescription e clica no próprio nó ou no pai.
 */
internal fun NoveNoveAccessibilityService.clicarBotaoFechar99(raiz: AccessibilityNodeInfo): Boolean {
    val no = encontrarNo99(raiz) { n ->
        val desc = n.contentDescription?.toString()?.lowercase() ?: ""
        desc.contains("fechar") || desc.contains("close") ||
        desc.contains("cancelar") || desc.contains("recusar") ||
        desc.contains("dismiss")
    } ?: return false

    if (no.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
    val pai = no.parent
    if (pai != null && pai.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true

    val bounds = Rect()
    no.getBoundsInScreen(bounds)
    if (!bounds.isEmpty) {
        try {
            val path = Path().apply { moveTo(bounds.centerX().toFloat(), bounds.centerY().toFloat()) }
            dispatchGesture(
                GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(path, 0L, 100L))
                    .build(), null, null
            )
            return true
        } catch (_: Exception) {}
    }
    return false
}

// ── Gestos e janela ───────────────────────────────────────────────────────────

/**
 * Retorna a raiz da janela da 99 buscando diretamente na lista de janelas.
 * Quando o overlay do FluxoApp está ativo, rootInActiveWindow pode retornar
 * a raiz do overlay em vez da 99.
 */
internal fun NoveNoveAccessibilityService.getRaiz99(): AccessibilityNodeInfo? {
    return try {
        windows?.firstOrNull { win ->
            win.root?.packageName?.toString() == NoveNoveAccessibilityService.PKG_99
        }?.root
    } catch (_: Exception) { rootInActiveWindow }
}

internal fun NoveNoveAccessibilityService.realizarTap99() {
    try {
        val m = resources.displayMetrics
        val path = Path().apply { moveTo(m.widthPixels / 2f, m.heightPixels * 0.75f) }
        dispatchGesture(
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0L, 100L))
                .build(), null, null
        )
    } catch (_: Exception) {}
}

/**
 * Tap nas coordenadas reais do botão, mais preciso que realizarTap99().
 */
internal fun NoveNoveAccessibilityService.realizarTapNoBotao99(raiz: AccessibilityNodeInfo?, texto: String) {
    try {
        if (raiz != null) {
            val no = encontrarNo99(raiz) { n ->
                n.text?.toString()?.equals(texto, ignoreCase = true) == true
            }
            if (no != null) {
                val bounds = Rect()
                no.getBoundsInScreen(bounds)
                if (!bounds.isEmpty) {
                    val path = Path().apply {
                        moveTo(bounds.centerX().toFloat(), bounds.centerY().toFloat())
                    }
                    dispatchGesture(
                        GestureDescription.Builder()
                            .addStroke(GestureDescription.StrokeDescription(path, 0L, 100L))
                            .build(), null, null
                    )
                    return
                }
            }
        }
        realizarTap99()
    } catch (_: Exception) {}
}
