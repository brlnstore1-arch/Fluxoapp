package com.fluxoapp

import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo

/**
 * NoveNoveNodeUtils — FluxoApp
 *
 * Utilitários de árvore de acessibilidade e interação com a UI da 99.
 * Módulo 100% independente do MaximNodeUtils.kt — nenhuma função aqui é
 * compartilhada com o Taxsee/Maxim, mesmo que a lógica pareça similar.
 *
 * Diferença chave da 99 em relação ao Taxsee:
 *   - Só existe o botão "Aceitar" (texto). Não há botão "Recusar" — a 99
 *     usa um ícone "X" no canto superior para fechar/recusar a oferta.
 *   - Layout da tela mostra tempo+distância combinados: "5min (2,7km)"
 */

// ── Travessia de árvore ───────────────────────────────────────────────────────

internal fun NoveNoveAccessibilityService.encontrarNo99(
    raiz: AccessibilityNodeInfo,
    predicado: (AccessibilityNodeInfo) -> Boolean
): AccessibilityNodeInfo? {
    if (predicado(raiz)) return raiz
    for (i in 0 until raiz.childCount) {
        val filho = raiz.getChild(i) ?: continue
        val r     = encontrarNo99(filho, predicado)
        if (r != null) return r
    }
    return null
}

internal fun NoveNoveAccessibilityService.visitarNos99(
    raiz: AccessibilityNodeInfo,
    visitante: (AccessibilityNodeInfo) -> Unit
) {
    visitante(raiz)
    for (i in 0 until raiz.childCount) {
        visitarNos99(raiz.getChild(i) ?: continue, visitante)
    }
}

/**
 * Diagnóstico — conta quantos nós existem na árvore e amostra os tipos de
 * classe encontrados, mesmo quando não há texto nenhum. Isso distingue:
 *   - árvore com poucos nós (1-3, tipo só um Canvas/WebView) → tela
 *     desenhada sem qualquer estrutura de acessibilidade (comum em
 *     apps que bloqueiam de propósito a leitura por acessibilidade)
 *   - árvore com muitos nós mas nenhum com texto → estrutura existe,
 *     mas os textos foram deliberadamente ocultados/removidos
 */
internal fun NoveNoveAccessibilityService.diagnosticarArvore99(raiz: AccessibilityNodeInfo): String {
    var contagem = 0
    val classes = mutableSetOf<String>()
    visitarNos99(raiz) { no ->
        contagem++
        no.className?.toString()?.let { classes.add(it.substringAfterLast('.')) }
    }
    return "nós=$contagem classes=${classes.take(8).joinToString(",")}"
}

internal fun NoveNoveAccessibilityService.coletarTextoTela99(raiz: AccessibilityNodeInfo): String {
    val sb = StringBuilder()
    visitarNos99(raiz) { no ->
        if (no.isVisibleToUser) {
            no.text?.toString()?.takeIf { it.isNotBlank() }
                ?.let { sb.append(it).append(" ") }
            no.contentDescription?.toString()?.takeIf { it.isNotBlank() }
                ?.let { sb.append(it).append(" ") }
        }
    }
    return sb.toString()
}

// ── Botões e cliques ──────────────────────────────────────────────────────────

internal fun NoveNoveAccessibilityService.temBotaoVisivel99(raiz: AccessibilityNodeInfo, texto: String): Boolean =
    encontrarNo99(raiz) { no ->
        no.text?.toString()?.equals(texto, ignoreCase = true) == true && no.isVisibleToUser
    } != null

/**
 * Detecta o botão "X" de fechar/recusar oferta da 99.
 * A 99 não usa texto "Recusar" — o botão é só um ícone, então buscamos
 * pela contentDescription (acessibilidade costuma expor "Fechar", "Close",
 * "Cancelar", "Recusar oferta" etc dependendo da versão do app/idioma).
 */
internal fun NoveNoveAccessibilityService.temBotaoFecharVisivel99(raiz: AccessibilityNodeInfo): Boolean =
    encontrarNo99(raiz) { no ->
        val desc = no.contentDescription?.toString()?.lowercase() ?: ""
        no.isVisibleToUser && (
            desc.contains("fechar") || desc.contains("close") ||
            desc.contains("cancelar") || desc.contains("recusar") ||
            desc.contains("dismiss")
        )
    } != null

internal fun NoveNoveAccessibilityService.clicarBotao99(raiz: AccessibilityNodeInfo, texto: String): Boolean {
    val no = encontrarNo99(raiz) { no ->
        no.text?.toString()?.equals(texto, ignoreCase = true) == true && no.isVisibleToUser
    } ?: return false
    return no.performAction(AccessibilityNodeInfo.ACTION_CLICK)
}

/**
 * Clica sem verificar visibilidade nem isClickable.
 * Estratégia em 3 tentativas:
 *   1. ACTION_CLICK no nó do texto
 *   2. ACTION_CLICK no pai (apps costumam registrar o listener no ViewGroup)
 *   3. Tap nas coordenadas reais via gesto
 */
internal fun NoveNoveAccessibilityService.clicarBotaoIgnorandoVisibilidade99(raiz: AccessibilityNodeInfo, texto: String): Boolean {
    val no = encontrarNo99(raiz) { n ->
        n.text?.toString()?.equals(texto, ignoreCase = true) == true
    } ?: return false

    if (no.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true

    val pai = no.parent
    if (pai != null && pai.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true

    val bounds = Rect()
    no.getBoundsInScreen(bounds)
    if (!bounds.isEmpty) {
        realizarTapNoBotao99(raiz, texto)
        return true
    }

    return false
}

/**
 * Clica no botão "X" de fechar/recusar (ícone, sem texto).
 * Busca por contentDescription e clica no próprio nó ou no pai.
 */
internal fun NoveNoveAccessibilityService.clicarBotaoFechar99(raiz: AccessibilityNodeInfo): Boolean {
    val no = encontrarNo99(raiz) { n ->
        val desc = n.contentDescription?.toString()?.lowercase() ?: ""
        desc.contains("fechar") || desc.contains("close") ||
        desc.contains("cancelar") || desc.contains("recusar") ||
        desc.contains("dismiss")
    } ?: return false

    if (no.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
    val pai = no.parent
    if (pai != null && pai.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true

    val bounds = Rect()
    no.getBoundsInScreen(bounds)
    if (!bounds.isEmpty) {
        try {
            val path = Path().apply { moveTo(bounds.centerX().toFloat(), bounds.centerY().toFloat()) }
            dispatchGesture(
                GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(path, 0L, 100L))
                    .build(), null, null
            )
            return true
        } catch (_: Exception) {}
    }
    return false
}

// ── Gestos e janela ───────────────────────────────────────────────────────────

/**
 * Retorna a raiz da janela da 99 buscando diretamente na lista de janelas.
 * Mantido por compatibilidade — prefere a MAIS ALTA na pilha (maior layer),
 * já que a oferta é desenhada como overlay POR CIMA da tela principal.
 */
internal fun NoveNoveAccessibilityService.getRaiz99(): AccessibilityNodeInfo? {
    return try {
        windows
            ?.filter { it.root?.packageName?.toString() == NoveNoveAccessibilityService.PKG_99 }
            ?.maxByOrNull { it.layer }
            ?.root
    } catch (_: Exception) { rootInActiveWindow }
}

/**
 * Retorna TODAS as raízes de janela pertencentes à 99 (não só a primeira).
 * Essencial porque a tela de oferta é desenhada como um OVERLAY separado
 * por cima da tela principal — nesse momento existem DUAS janelas com o
 * mesmo pacote com.app99.driver ao mesmo tempo: a de trás (mapa/app) e a
 * de cima (a oferta). Se checarmos só uma, podemos pegar a errada.
 * Ordenado da mais alta (layer maior = mais no topo) pra mais baixa.
 */
internal fun NoveNoveAccessibilityService.obterTodasRaizes99(): List<AccessibilityNodeInfo> {
    return try {
        windows
            ?.filter { it.root?.packageName?.toString() == NoveNoveAccessibilityService.PKG_99 }
            ?.sortedByDescending { it.layer }
            ?.mapNotNull { it.root }
            ?: emptyList()
    } catch (_: Exception) {
        rootInActiveWindow?.let { listOf(it) } ?: emptyList()
    }
}

/** Verifica o botão em QUALQUER uma das janelas da 99 (overlay incluído). */
internal fun NoveNoveAccessibilityService.temBotaoVisivelEmQualquerJanela99(texto: String): Boolean {
    return obterTodasRaizes99().any { raiz -> temBotaoVisivel99(raiz, texto) }
}

/** Junta o texto de TODAS as janelas da 99 (overlay + tela de trás). */
internal fun NoveNoveAccessibilityService.coletarTextoTodasJanelas99(): String {
    return obterTodasRaizes99().joinToString(" ") { raiz -> coletarTextoTela99(raiz) }
}

/** Retorna a primeira janela (na ordem de prioridade) que tem o botão visível. */
internal fun NoveNoveAccessibilityService.raizComBotaoVisivel99(texto: String): AccessibilityNodeInfo? {
    return obterTodasRaizes99().firstOrNull { raiz -> temBotaoVisivel99(raiz, texto) }
}

internal fun NoveNoveAccessibilityService.realizarTap99() {
    try {
        val m = resources.displayMetrics
        val path = Path().apply { moveTo(m.widthPixels / 2f, m.heightPixels * 0.75f) }
        dispatchGesture(
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0L, 100L))
                .build(), null, null
        )
    } catch (_: Exception) {}
}

/**
 * Tap nas coordenadas reais do botão, mais preciso que realizarTap99().
 */
internal fun NoveNoveAccessibilityService.realizarTapNoBotao99(raiz: AccessibilityNodeInfo?, texto: String) {
    try {
        if (raiz != null) {
            val no = encontrarNo99(raiz) { n ->
                n.text?.toString()?.equals(texto, ignoreCase = true) == true
            }
            if (no != null) {
                val bounds = Rect()
                no.getBoundsInScreen(bounds)
                if (!bounds.isEmpty) {
                    val path = Path().apply {
                        moveTo(bounds.centerX().toFloat(), bounds.centerY().toFloat())
                    }
                    dispatchGesture(
                        GestureDescription.Builder()
                            .addStroke(GestureDescription.StrokeDescription(path, 0L, 100L))
                            .build(), null, null
                    )
                    return
                }
            }
        }
        realizarTap99()
    } catch (_: Exception) {}
}
