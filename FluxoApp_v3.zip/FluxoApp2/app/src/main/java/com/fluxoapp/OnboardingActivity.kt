package com.fluxoapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

class OnboardingActivity : AppCompatActivity() {

    private lateinit var prefs: android.content.SharedPreferences

    // Etapas do onboarding
    private val STEP_TEMA        = 0
    private val STEP_OVERLAY     = 1
    private val STEP_ACESSIB     = 2
    private val STEP_CONCLUIDO   = 3

    private var stepAtual = STEP_TEMA
    private var temaSelecionado = "azul"   // azul | gold
    private var modoSelecionado = "auto"   // dia | noite | auto

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("FluxoApp", MODE_PRIVATE)

        // Se já passou pelo onboarding, vai direto para MainActivity
        if (prefs.getBoolean("onboarding_ok", false)) {
            irParaMain()
            return
        }

        setContentView(R.layout.activity_onboarding)
        mostrarStep(STEP_TEMA)
    }

    override fun onResume() {
        super.onResume()
        // Ao voltar de uma tela de permissão, verificar se foi concedida
        if (stepAtual == STEP_OVERLAY && Settings.canDrawOverlays(this)) {
            mostrarStep(STEP_ACESSIB)
        } else if (stepAtual == STEP_ACESSIB && isAccessibilityEnabled()) {
            mostrarStep(STEP_CONCLUIDO)
        }
    }

    private fun mostrarStep(step: Int) {
        stepAtual = step

        val layoutTema     = findViewById<View>(R.id.layoutStepTema)
        val layoutOverlay  = findViewById<View>(R.id.layoutStepOverlay)
        val layoutAcessib  = findViewById<View>(R.id.layoutStepAcessib)
        val layoutConcluido = findViewById<View>(R.id.layoutStepConcluido)

        layoutTema?.visibility     = if (step == STEP_TEMA)      View.VISIBLE else View.GONE
        layoutOverlay?.visibility  = if (step == STEP_OVERLAY)   View.VISIBLE else View.GONE
        layoutAcessib?.visibility  = if (step == STEP_ACESSIB)   View.VISIBLE else View.GONE
        layoutConcluido?.visibility = if (step == STEP_CONCLUIDO) View.VISIBLE else View.GONE

        atualizarIndicadores(step)

        when (step) {
            STEP_TEMA     -> configurarStepTema()
            STEP_OVERLAY  -> configurarStepOverlay()
            STEP_ACESSIB  -> configurarStepAcessib()
            STEP_CONCLUIDO -> configurarStepConcluido()
        }
    }

    // ── STEP 0: Escolha de tema ──────────────────────────────────────
    private fun configurarStepTema() {
        val cardAzul  = findViewById<CardView>(R.id.cardTemaAzul)
        val cardGold  = findViewById<CardView>(R.id.cardTemaGold)
        val btnDia    = findViewById<Button>(R.id.btnModoDia)
        val btnNoite  = findViewById<Button>(R.id.btnModoNoite)
        val btnAuto   = findViewById<Button>(R.id.btnModoAuto)
        val btnProx   = findViewById<Button>(R.id.btnProxTema)

        fun atualizarSelecao() {
            val corAzul  = if (temaSelecionado == "azul") getColor(R.color.accent_cyan) else getColor(R.color.bg_card)
            val corGold  = if (temaSelecionado == "gold") android.graphics.Color.parseColor("#C9A84C") else getColor(R.color.bg_card)
            cardAzul?.setCardBackgroundColor(android.graphics.Color.TRANSPARENT)
            cardGold?.setCardBackgroundColor(android.graphics.Color.TRANSPARENT)

            val strokeAzul = if (temaSelecionado == "azul") 4 else 1
            val strokeGold = if (temaSelecionado == "gold") 4 else 1
            // Destaque visual via elevation
            cardAzul?.cardElevation = if (temaSelecionado == "azul") 12f else 2f
            cardGold?.cardElevation = if (temaSelecionado == "gold") 12f else 2f
        }

        cardAzul?.setOnClickListener {
            temaSelecionado = "azul"
            atualizarSelecao()
        }

        cardGold?.setOnClickListener {
            temaSelecionado = "gold"
            atualizarSelecao()
        }

        btnDia?.setOnClickListener { modoSelecionado = "dia"; atualizarBotoesMode(btnDia, btnNoite, btnAuto) }
        btnNoite?.setOnClickListener { modoSelecionado = "noite"; atualizarBotoesMode(btnDia, btnNoite, btnAuto) }
        btnAuto?.setOnClickListener { modoSelecionado = "auto"; atualizarBotoesMode(btnDia, btnNoite, btnAuto) }

        // Padrão inicial
        atualizarSelecao()
        atualizarBotoesMode(btnDia, btnNoite, btnAuto)

        btnProx?.setOnClickListener {
            // Salvar escolha
            prefs.edit()
                .putString("tema_estilo", temaSelecionado)   // azul | gold
                .putString("modo_tema_str", modoSelecionado) // dia | noite | auto
                .putInt("modo_tema", when (modoSelecionado) {
                    "dia"   -> 0
                    "noite" -> 1
                    else    -> -1
                })
                .apply()

            // Próximo passo
            if (Settings.canDrawOverlays(this)) {
                if (isAccessibilityEnabled()) mostrarStep(STEP_CONCLUIDO)
                else mostrarStep(STEP_ACESSIB)
            } else {
                mostrarStep(STEP_OVERLAY)
            }
        }
    }

    private fun atualizarBotoesMode(btnDia: Button?, btnNoite: Button?, btnAuto: Button?) {
        val cor = try { getColor(R.color.accent_cyan) } catch (_: Exception) { android.graphics.Color.CYAN }
        val cinza = android.graphics.Color.parseColor("#333333")
        btnDia?.setBackgroundColor(if (modoSelecionado == "dia") cor else cinza)
        btnNoite?.setBackgroundColor(if (modoSelecionado == "noite") cor else cinza)
        btnAuto?.setBackgroundColor(if (modoSelecionado == "auto") cor else cinza)
    }

    // ── STEP 1: Permissão de sobreposição ───────────────────────────
    private fun configurarStepOverlay() {
        val btnConceder = findViewById<Button>(R.id.btnConcederOverlay)
        val btnPular    = findViewById<Button>(R.id.btnPularOverlay)

        btnConceder?.setOnClickListener {
            try {
                startActivity(Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                ))
            } catch (_: Exception) {
                Toast.makeText(this, "Abra Configurações > Apps > FluxoApp > Aparecer sobre outros apps", Toast.LENGTH_LONG).show()
            }
        }

        btnPular?.setOnClickListener {
            if (isAccessibilityEnabled()) mostrarStep(STEP_CONCLUIDO)
            else mostrarStep(STEP_ACESSIB)
        }
    }

    // ── STEP 2: Permissão de acessibilidade ─────────────────────────
    private fun configurarStepAcessib() {
        val btnConceder = findViewById<Button>(R.id.btnConcederAcessib)
        val btnPular    = findViewById<Button>(R.id.btnPularAcessib)

        btnConceder?.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } catch (_: Exception) {
                Toast.makeText(this, "Abra Configurações > Acessibilidade > FluxoApp", Toast.LENGTH_LONG).show()
            }
        }

        btnPular?.setOnClickListener {
            mostrarStep(STEP_CONCLUIDO)
        }
    }

    // ── STEP 3: Concluído ───────────────────────────────────────────
    private fun configurarStepConcluido() {
        val btnComecar = findViewById<Button>(R.id.btnComecar)
        btnComecar?.setOnClickListener {
            prefs.edit().putBoolean("onboarding_ok", true).apply()
            irParaMain()
        }
    }

    private fun atualizarIndicadores(step: Int) {
        val ids = listOf(
            R.id.dot0, R.id.dot1, R.id.dot2, R.id.dot3
        )
        val cor    = try { getColor(R.color.accent_cyan) } catch (_: Exception) { android.graphics.Color.CYAN }
        val cinza  = android.graphics.Color.parseColor("#2A2A2A")
        ids.forEachIndexed { i, id ->
            val v = findViewById<View>(id)
            v?.setBackgroundColor(if (i == step) cor else cinza)
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val manager = getSystemService(ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.contains("MaximAccessibilityService", ignoreCase = true)
    }

    private fun irParaMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
