package com.fluxoapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

class OnboardingActivity : AppCompatActivity() {

    private lateinit var prefs: android.content.SharedPreferences

    // Etapas do onboarding
    private val STEP_TEMA        = 0
    private val STEP_OVERLAY     = 1
    private val STEP_ACESSIB     = 2
    private val STEP_CONCLUIDO   = 3

    private var stepAtual = STEP_TEMA
    private var temaSelecionado = "gold"   // azul | gold
    private var modoSelecionado = "auto"   // dia | noite | auto

    override fun attachBaseContext(base: android.content.Context) {
        super.attachBaseContext(FontHelper.wrap(base))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeSelector.aplicar(this)
        prefs = getSharedPreferences("FluxoApp", MODE_PRIVATE)

        // Se já passou pelo onboarding, vai direto para MainActivity
        if (prefs.getBoolean("onboarding_ok", false)) {
            irParaMain()
            return
        }

        setContentView(R.layout.activity_onboarding)

        // Pedir permissão de notificação imediatamente (Android 13+)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) !=
                android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 100)
            }
        }

        mostrarStep(STEP_TEMA)
    }

    override fun onResume() {
        super.onResume()
        // Ao voltar de uma tela de permissão, verificar se foi concedida
        if (stepAtual == STEP_OVERLAY && Settings.canDrawOverlays(this)) {
            mostrarStep(STEP_ACESSIB)
        } else if (stepAtual == STEP_ACESSIB && isAccessibilityEnabled()) {
            mostrarStep(STEP_CONCLUIDO)
        }
    }

    private fun mostrarStep(step: Int) {
        stepAtual = step

        val layoutTema     = findViewById<View>(R.id.layoutStepTema)
        val layoutOverlay  = findViewById<View>(R.id.layoutStepOverlay)
        val layoutAcessib  = findViewById<View>(R.id.layoutStepAcessib)
        val layoutConcluido = findViewById<View>(R.id.layoutStepConcluido)

        layoutTema?.visibility     = if (step == STEP_TEMA)      View.VISIBLE else View.GONE
        layoutOverlay?.visibility  = if (step == STEP_OVERLAY)   View.VISIBLE else View.GONE
        layoutAcessib?.visibility  = if (step == STEP_ACESSIB)   View.VISIBLE else View.GONE
        layoutConcluido?.visibility = if (step == STEP_CONCLUIDO) View.VISIBLE else View.GONE

        atualizarIndicadores(step)

        when (step) {
            STEP_TEMA     -> configurarStepTema()
            STEP_OVERLAY  -> configurarStepOverlay()
            STEP_ACESSIB  -> configurarStepAcessib()
            STEP_CONCLUIDO -> configurarStepConcluido()
        }
    }

    // ── STEP 0: Escolha de tema ──────────────────────────────────────
    private fun configurarStepTema() {
        val cardAzul  = findViewById<CardView>(R.id.cardTemaAzul)
        val cardGold  = findViewById<CardView>(R.id.cardTemaGold)
        val btnDia    = findViewById<Button>(R.id.btnModoDia)
        val btnNoite  = findViewById<Button>(R.id.btnModoNoite)
        val btnAuto   = findViewById<Button>(R.id.btnModoAuto)
        val btnProx   = findViewById<Button>(R.id.btnProxTema)

        fun atualizarSelecao() {
            val dp       = resources.displayMetrics.density
            val corAzul  = android.graphics.Color.parseColor("#00C8FF")  // cyan do azul
            val corGold  = android.graphics.Color.parseColor("#C9A84C")  // dourado
            val corNao   = android.graphics.Color.parseColor("#2A2A2A")  // borda inativa

            // Borda azul selecionado
            val bgAzulSel = android.graphics.drawable.GradientDrawable().apply {
                setColor(android.graphics.Color.parseColor("#0A1628"))
                cornerRadius = 16f * dp
                setStroke((3f * dp).toInt(), corAzul)
            }
            val bgAzulNao = android.graphics.drawable.GradientDrawable().apply {
                setColor(android.graphics.Color.parseColor("#141414"))
                cornerRadius = 16f * dp
                setStroke((1f * dp).toInt(), corNao)
            }
            // Borda dourada selecionado
            val bgGoldSel = android.graphics.drawable.GradientDrawable().apply {
                setColor(android.graphics.Color.parseColor("#1A1610"))
                cornerRadius = 16f * dp
                setStroke((3f * dp).toInt(), corGold)
            }
            val bgGoldNao = android.graphics.drawable.GradientDrawable().apply {
                setColor(android.graphics.Color.parseColor("#141414"))
                cornerRadius = 16f * dp
                setStroke((1f * dp).toInt(), corNao)
            }

            // Aplicar fundo + elevation
            cardAzul?.background = if (temaSelecionado == "azul") bgAzulSel else bgAzulNao
            cardGold?.background = if (temaSelecionado == "gold") bgGoldSel else bgGoldNao
            cardAzul?.cardElevation = if (temaSelecionado == "azul") 16f else 2f
            cardGold?.cardElevation = if (temaSelecionado == "gold") 16f else 2f

            // Rótulo de selecionado
            try {
                val tvAzulSel = cardAzul?.findViewById<android.widget.TextView>(
                    resources.getIdentifier("tvAzulSelecionado", "id", packageName))
                val tvGoldSel = cardGold?.findViewById<android.widget.TextView>(
                    resources.getIdentifier("tvGoldSelecionado", "id", packageName))
                tvAzulSel?.visibility = if (temaSelecionado == "azul") android.view.View.VISIBLE else android.view.View.GONE
                tvGoldSel?.visibility = if (temaSelecionado == "gold") android.view.View.VISIBLE else android.view.View.GONE
            } catch (_: Throwable) {}
        }

        cardAzul?.setOnClickListener {
            temaSelecionado = "azul"
            atualizarSelecao()
        }

        cardGold?.setOnClickListener {
            temaSelecionado = "gold"
            atualizarSelecao()
        }

        btnDia?.setOnClickListener { modoSelecionado = "dia"; atualizarBotoesMode(btnDia, btnNoite, btnAuto) }
        btnNoite?.setOnClickListener { modoSelecionado = "noite"; atualizarBotoesMode(btnDia, btnNoite, btnAuto) }
        btnAuto?.setOnClickListener { modoSelecionado = "auto"; atualizarBotoesMode(btnDia, btnNoite, btnAuto) }

        // Padrão inicial
        atualizarSelecao()
        atualizarBotoesMode(btnDia, btnNoite, btnAuto)

        btnProx?.setOnClickListener {
            // Salvar escolha
            prefs.edit()
                .putString("tema_estilo", temaSelecionado)   // azul | gold
                .putString("modo_tema_str", modoSelecionado) // dia | noite | auto
                .putInt("modo_tema", when (modoSelecionado) {
                    "dia"   -> 0
                    "noite" -> 1
                    else    -> -1
                })
                .apply()

            // Próximo passo
            if (Settings.canDrawOverlays(this)) {
                if (isAccessibilityEnabled()) mostrarStep(STEP_CONCLUIDO)
                else mostrarStep(STEP_ACESSIB)
            } else {
                mostrarStep(STEP_OVERLAY)
            }
        }
    }

    private fun atualizarBotoesMode(btnDia: Button?, btnNoite: Button?, btnAuto: Button?) {
        val corSelecionado   = try { getColor(R.color.accent_gold) } catch (_: Throwable) { android.graphics.Color.CYAN }
        val corNaoSelecionado = resources.getColor(R.color.onboarding_dot_inactive, null)
        // Item 2/9 — texto sempre precisa trocar junto com o fundo:
        // selecionado (fundo claro/dourado) → texto escuro
        // não selecionado (fundo cinza escuro) → texto claro
        val txtSelecionado    = android.graphics.Color.BLACK
        val txtNaoSelecionado = android.graphics.Color.WHITE

        val botoes = listOf(
            Pair(btnDia,   modoSelecionado == "dia"),
            Pair(btnNoite, modoSelecionado == "noite"),
            Pair(btnAuto,  modoSelecionado == "auto")
        )
        botoes.forEach { (btn, ativo) ->
            btn?.setBackgroundColor(if (ativo) corSelecionado else corNaoSelecionado)
            btn?.setTextColor(if (ativo) txtSelecionado else txtNaoSelecionado)
        }
    }

    // ── STEP 1: Permissão de sobreposição ───────────────────────────
    private fun configurarStepOverlay() {
        val btnConceder = findViewById<Button>(R.id.btnConcederOverlay)
        val btnPular    = findViewById<Button>(R.id.btnPularOverlay)

        btnConceder?.setOnClickListener {
            try {
                startActivity(Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                ))
            } catch (_: Throwable) {
                FluxoToast.aviso(this, "Abra Configurações > Apps > FluxoApp > Aparecer sobre outros apps")
            }
        }

        btnPular?.setOnClickListener {
            if (isAccessibilityEnabled()) mostrarStep(STEP_CONCLUIDO)
            else mostrarStep(STEP_ACESSIB)
        }
    }

    // ── STEP 2: Permissão de acessibilidade ─────────────────────────
    private fun configurarStepAcessib() {
        val btnConceder = findViewById<Button>(R.id.btnConcederAcessib)
        val btnPular    = findViewById<Button>(R.id.btnPularAcessib)

        btnConceder?.setOnClickListener {
            // Item 11 — Android 13+ bloqueia a ativação de serviços de
            // acessibilidade em apps instalados fora da Play Store até o
            // usuário liberar manualmente as "Configurações restritas".
            // Sem esse passo, o toggle de Acessibilidade aparece cinza/
            // travado e o usuário não entende por quê.
            if (android.os.Build.VERSION.SDK_INT >= 33 && !isAccessibilityEnabled()) {
                mostrarDialogConfigRestritas()
            } else {
                abrirAcessibilidade()
            }
        }

        btnPular?.setOnClickListener {
            mostrarStep(STEP_CONCLUIDO)
        }
    }

    private fun mostrarDialogConfigRestritas() {
        android.app.AlertDialog.Builder(this)
            .setTitle("Antes de continuar")
            .setMessage(
                "No Android 13 ou mais recente, é preciso liberar as " +
                "\"Configurações restritas\" antes de ativar a Acessibilidade:\n\n" +
                "1. Toque em \"Abrir info do app\"\n" +
                "2. Toque no menu (⋮) no canto superior direito\n" +
                "3. Toque em \"Permitir acesso restrito\"\n" +
                "4. Volte aqui e toque em \"Ativar Acessibilidade\" novamente"
            )
            .setPositiveButton("Abrir info do app") { _, _ ->
                try {
                    startActivity(Intent(
                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:$packageName")
                    ))
                } catch (_: Throwable) {
                    FluxoToast.aviso(this, "Abra Configurações > Apps > FluxoApp")
                }
            }
            .setNegativeButton("Já liberei — continuar") { _, _ -> abrirAcessibilidade() }
            .setNeutralButton("Pular") { _, _ -> mostrarStep(STEP_CONCLUIDO) }
            .show()
    }

    private fun abrirAcessibilidade() {
        try {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } catch (_: Throwable) {
            FluxoToast.aviso(this, "Abra Configurações > Acessibilidade > FluxoApp")
        }
    }

    // ── STEP 3: Concluído ───────────────────────────────────────────
    private fun configurarStepConcluido() {
        val btnComecar = findViewById<Button>(R.id.btnComecar)
        btnComecar?.setOnClickListener {
            prefs.edit().putBoolean("onboarding_ok", true).apply()
            irParaMain()
        }
    }

    private fun atualizarIndicadores(step: Int) {
        val ids = listOf(
            R.id.dot0, R.id.dot1, R.id.dot2, R.id.dot3
        )
        val cor    = try { getColor(R.color.accent_gold) } catch (_: Throwable) { android.graphics.Color.CYAN }
        val cinza  = resources.getColor(R.color.onboarding_dot_inactive, null)
        ids.forEachIndexed { i, id ->
            val v = findViewById<View>(id)
            v?.setBackgroundColor(if (i == step) cor else cinza)
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.contains("MaximAccessibilityService", ignoreCase = true)
    }

    private fun irParaMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
