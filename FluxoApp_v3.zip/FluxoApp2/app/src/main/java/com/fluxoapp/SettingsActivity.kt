package com.fluxoapp

import android.content.Context
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

class SettingsActivity : AppCompatActivity() {

    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var db: DatabaseHelper
    // Item 3 — controla se há alterações pendentes para dar destaque real
    // ao botão Salvar (só fica com aparência "clicável" quando há mudanças)
    private var temAlteracoesPendentes = false

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(FontHelper.wrap(base))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeSelector.aplicar(this)
        setContentView(R.layout.activity_settings)

        prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        db    = DatabaseHelper(this)

        configurarHeader()
        configurarTemaVisual()
        configurarTamanhoFonte()
        configurarDeteccao()
        configurarAutomacoes()
        configurarSonsAlertas()
        configurarMetas()
        configurarBotaoSalvar()

        // Item 3 — rastreia qualquer alteração feita pelo usuário para dar
        // destaque real ao botão Salvar (aplicado por último, depois de
        // todos os switches/inputs já existirem na árvore)
        configurarRastreioAlteracoes()

        aplicarTemaGlobal()
    }

    // ─────────────────────────────────────────────────────────────
    // HEADER
    // ─────────────────────────────────────────────────────────────
    private fun configurarHeader() {
        findViewById<ImageButton>(R.id.btnVoltar)?.setOnClickListener { finish() }
    }

    // ─────────────────────────────────────────────────────────────
    // TEMA VISUAL
    // ─────────────────────────────────────────────────────────────
    private fun configurarTemaVisual() {
        val temaAtual = ThemeHelper.getTema(prefs)

        // Marcar card selecionado + borda grossa estilo banco
        destacarCardSelecionado(temaAtual)

        // Clicks nos cards
        findViewById<CardView>(R.id.cardTemaAzul)?.setOnClickListener {
            prefs.edit().putString("tema_estilo", "azul").apply()
            notificarTema()
            recreate()
        }
        findViewById<CardView>(R.id.cardTemaGold)?.setOnClickListener {
            prefs.edit().putString("tema_estilo", "gold").apply()
            notificarTema()
            recreate()
        }

        // Botões Dia / Noite / Auto
        val modoAtual = prefs.getInt("modo_tema", -1)
        val btnDia   = findViewById<Button>(R.id.btnModoDia)
        val btnNoite = findViewById<Button>(R.id.btnModoNoite)
        val btnAuto  = findViewById<Button>(R.id.btnModoAuto)

        pintarBotoes(modoAtual, listOf(Pair(btnDia, 0), Pair(btnNoite, 1), Pair(btnAuto, -1)))

        btnDia?.setOnClickListener   { salvarModo(0);  recreate() }
        btnNoite?.setOnClickListener { salvarModo(1);  recreate() }
        btnAuto?.setOnClickListener  { salvarModo(-1); recreate() }
    }

    private fun destacarCardSelecionado(temaAtual: String) {
        val dp = resources.displayMetrics.density
        val cardAzul = findViewById<CardView>(R.id.cardTemaAzul)
        val cardGold = findViewById<CardView>(R.id.cardTemaGold)
        val tvAzulSel = findViewById<TextView>(R.id.tvAzulSelecionado)
        val tvGoldSel = findViewById<TextView>(R.id.tvGoldSelecionado)

        // Accent de cada tema (fixo, independente do modo)
        val accentAzul = android.graphics.Color.parseColor("#00C8FF")
        val accentGold = android.graphics.Color.parseColor("#C9A84C")

        if (temaAtual == "azul") {
            // Card azul: borda grossa ciano + elevation alta
            cardAzul?.cardElevation = 20f * dp
            cardAzul?.setCardBackgroundColor(android.graphics.Color.parseColor("#0F1E36"))
            // Borda grossa via foreground
            val borderAzul = GradientDrawable().apply {
                setColor(android.graphics.Color.TRANSPARENT)
                cornerRadius = 14f * dp
                setStroke((4f * dp).toInt(), accentAzul)
            }
            cardAzul?.foreground = borderAzul
            tvAzulSel?.visibility = android.view.View.VISIBLE

            // Card gold: sem destaque
            cardGold?.cardElevation = 2f * dp
            cardGold?.foreground = null
            tvGoldSel?.visibility = android.view.View.GONE
        } else {
            // Card gold: borda grossa dourada + elevation alta
            cardGold?.cardElevation = 20f * dp
            val borderGold = GradientDrawable().apply {
                setColor(android.graphics.Color.TRANSPARENT)
                cornerRadius = 14f * dp
                setStroke((4f * dp).toInt(), accentGold)
            }
            cardGold?.foreground = borderGold
            tvGoldSel?.visibility = android.view.View.VISIBLE

            // Card azul: sem destaque
            cardAzul?.cardElevation = 2f * dp
            cardAzul?.foreground = null
            tvAzulSel?.visibility = android.view.View.GONE
        }
    }

    // ─────────────────────────────────────────────────────────────
    // TAMANHO DE FONTE
    // ─────────────────────────────────────────────────────────────
    private fun configurarTamanhoFonte() {
        val btnP = findViewById<Button>(R.id.btnFontePequeno)
        val btnM = findViewById<Button>(R.id.btnFonteMedio)
        val btnG = findViewById<Button>(R.id.btnFonteGrande)
        val atual = prefs.getInt("tamanho_fonte", 1)

        pintarBotoes(atual, listOf(Pair(btnP, 0), Pair(btnM, 1), Pair(btnG, 2)))

        btnP?.setOnClickListener { prefs.edit().putInt("tamanho_fonte", 0).apply(); recreate() }
        btnM?.setOnClickListener { prefs.edit().putInt("tamanho_fonte", 1).apply(); recreate() }
        btnG?.setOnClickListener { prefs.edit().putInt("tamanho_fonte", 2).apply(); recreate() }
    }

    // ─────────────────────────────────────────────────────────────
    // DETECÇÃO
    // ─────────────────────────────────────────────────────────────
    private fun configurarDeteccao() {
        findViewById<EditText>(R.id.etMinimoKm)?.setText(
            "%.2f".format(prefs.getFloat("minimo_km", 1.20f)))
        findViewById<EditText>(R.id.etMinimoValor)?.setText(
            "%.2f".format(prefs.getFloat("minimo_valor", 0f)))
        findViewById<EditText>(R.id.etTempoAceitar)?.setText(
            (prefs.getInt("tempo_auto_aceitar", 3) - 1).toString())
    }

    // ─────────────────────────────────────────────────────────────
    // AUTOMAÇÕES
    // ─────────────────────────────────────────────────────────────
    private fun configurarAutomacoes() {
        findViewById<Switch>(R.id.switchAutoAceitar)?.isChecked = prefs.getBoolean("auto_aceitar", false)
        findViewById<Switch>(R.id.switchAutoRecusar)?.isChecked = prefs.getBoolean("auto_recusar", false)
    }

    // ─────────────────────────────────────────────────────────────
    // SONS E ALERTAS
    // ─────────────────────────────────────────────────────────────
    private fun configurarSonsAlertas() {
        findViewById<Switch>(R.id.switchSomAceitar)?.isChecked = prefs.getBoolean("som_aceitar", true)
        findViewById<Switch>(R.id.switchSomRecusar)?.isChecked = prefs.getBoolean("som_recusar", false)
        findViewById<Switch>(R.id.switchSomMeta)?.isChecked    = prefs.getBoolean("som_meta", true)
    }

    // ─────────────────────────────────────────────────────────────
    // METAS
    // ─────────────────────────────────────────────────────────────
    private fun configurarMetas() {
        val metaDia = prefs.getFloat("meta_diaria",  0f)
        val metaSem = prefs.getFloat("meta_semanal", 0f)

        findViewById<EditText>(R.id.etMetaDiaria)?.setText(if (metaDia > 0) "%.2f".format(metaDia) else "")
        findViewById<EditText>(R.id.etMetaSemanal)?.setText(if (metaSem > 0) "%.2f".format(metaSem) else "")
        findViewById<Switch>(R.id.switchNotifMeta)?.isChecked = prefs.getBoolean("notif_meta", true)
        
        // 99 — Detectar corridas de 99 também
        // Como é um serviço de acessibilidade SEPARADO do Taxsee/Maxim, o
        // usuário precisa habilitá-lo independentemente nas configurações
        // do Android. Este toggle só liga/desliga a lógica de detecção;
        // ele não ativa a permissão do sistema sozinho.
        val prefs99 = getSharedPreferences("fluxo_config", Context.MODE_PRIVATE)
        val switch99 = findViewById<Switch>(R.id.switchDetectar99)
        switch99?.isChecked = prefs99.getBoolean("detectar_99", false)
        // Sincroniza o valor atual uma vez ao abrir a tela — cobre usuários
        // que já tinham essa preferência configurada antes dessa atualização
        sincronizarPlataforma99(switch99?.isChecked ?: false)
        switch99?.setOnCheckedChangeListener { _, isChecked ->
            prefs99.edit().putBoolean("detectar_99", isChecked).apply()
            sincronizarPlataforma99(isChecked)
            if (isChecked) {
                // Já dispara o download do modelo de OCR em segundo plano,
                // pra não esperar a primeira corrida real descobrir que
                // ainda não tinha baixado (Android 11+, senão não faz nada)
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                    try { NoveNoveOcrHelper.aquecerModelo() } catch (_: Throwable) {}
                }
            }
            if (isChecked && !servicoAcessibilidade99Ativo()) {
                android.app.AlertDialog.Builder(this)
                    .setTitle("Ativar detecção da 99")
                    .setMessage("Para detectar corridas da 99, você também precisa " +
                        "ativar o serviço \"FluxoApp (99)\" em Acessibilidade — é uma " +
                        "permissão separada da do Taxsee/Maxim.\n\nAbrir configurações agora?")
                    .setPositiveButton("Abrir") { _, _ ->
                        try {
                            startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        } catch (_: Exception) {}
                    }
                    .setNegativeButton("Depois", null)
                    .show()
            } else {
                val msg = if (isChecked) "🔍 Detectando 99 ativado" else "🔍 Apenas Taxsee/Maxim"
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
            }
        }
        // Diagnóstico — toque e segure no texto/switch da 99 para ver o log
        // de detecção (últimas 25 etapas), útil pra descobrir onde travou
        // sem precisar de computador/logcat.
        switch99?.setOnLongClickListener { mostrarDiagnostico99(); true }

        try {
            val corridas  = db.buscarHoje()
            val resumo    = db.resumo(corridas)
            val totalHoje = (resumo["total"] as? Number)?.toFloat() ?: 0f

            findViewById<TextView>(R.id.tvProgressoHoje)?.text =
                "Progresso hoje: R$ ${"%.2f".format(totalHoje)}"

            if (metaDia > 0) {
                val pct = (totalHoje / metaDia * 100).toInt().coerceIn(0, 100)
                findViewById<ProgressBar>(R.id.progressMetaDia)?.progress = pct
            }
        } catch (_: Exception) {}

        try {
            findViewById<TextView>(R.id.tvProgressoSemana)?.text = "Progresso esta semana: R$ 0,00"
            findViewById<ProgressBar>(R.id.progressMetaSemana)?.progress = 0
        } catch (_: Exception) {}
    }

    // ─────────────────────────────────────────────────────────────
    // BOTÃO SALVAR
    // ─────────────────────────────────────────────────────────────
    private fun configurarBotaoSalvar() {
        val btn = findViewById<Button>(R.id.btnSalvarConfig)
        // Protege este botão de ser repintado pelo aplicarTemaGlobal genérico
        // (item 4 — evita que a lógica heurística de cores do app sobrescreva
        // o estado visual "com mudanças pendentes / sem mudanças" deste botão)
        btn?.tag = "no_theme_override"
        btn?.setOnClickListener { salvarTudo() }
        // Estado inicial: sem alterações pendentes → aparência desabilitada
        atualizarEstadoBotaoSalvar()
    }

    /**
     * Item 3 — Botão Salvar com estado visual real:
     *   • Há mudanças pendentes → cor sólida do accent, alto contraste, 100% opaco, clicável
     *   • Sem mudanças          → cinza neutro, opacidade reduzida, aparência desabilitada
     */
    private fun atualizarEstadoBotaoSalvar() {
        val dp      = resources.displayMetrics.density
        val accent  = ThemeHelper.cor("accent",     prefs)
        val bgDark  = ThemeHelper.cor("bg_dark",    prefs)
        val bgSect  = ThemeHelper.cor("bg_section", prefs)
        val txtGray = ThemeHelper.cor("text_gray",  prefs)
        val btn = findViewById<Button>(R.id.btnSalvarConfig) ?: return

        if (temAlteracoesPendentes) {
            btn.background = GradientDrawable().apply {
                setColor(accent)
                cornerRadius = 10f * dp
            }
            btn.setTextColor(bgDark)
            btn.alpha     = 1f
            btn.isEnabled = true
        } else {
            btn.background = GradientDrawable().apply {
                setColor(bgSect)
                cornerRadius = 10f * dp
            }
            btn.setTextColor(txtGray)
            btn.alpha     = 0.55f
            btn.isEnabled = false
        }
    }

    /**
     * Item 3 — Percorre toda a árvore de views da tela e conecta um listener
     * de mudança em cada Switch e EditText, para detectar qualquer alteração
     * feita pelo usuário e atualizar o estado visual do botão Salvar.
     */
    private fun configurarRastreioAlteracoes() {
        val raiz = findViewById<View>(android.R.id.content) ?: return
        conectarListenersRecursivo(raiz)
    }

    private fun conectarListenersRecursivo(view: View) {
        when (view) {
            is Switch -> view.setOnCheckedChangeListener { _, _ -> marcarAlterado() }
            is EditText -> view.addTextChangedListener(object : android.text.TextWatcher {
                override fun afterTextChanged(s: android.text.Editable?) { marcarAlterado() }
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            })
        }
        if (view is android.view.ViewGroup) {
            for (i in 0 until view.childCount) conectarListenersRecursivo(view.getChildAt(i))
        }
    }

    private fun marcarAlterado() {
        if (!temAlteracoesPendentes) {
            temAlteracoesPendentes = true
            atualizarEstadoBotaoSalvar()
        }
    }

    // ─────────────────────────────────────────────────────────────
    // PINTAR BOTÕES (selecionado = accent do tema; outros = neutro)
    // ─────────────────────────────────────────────────────────────
    private fun pintarBotoes(valorAtual: Int, botoes: List<Pair<Button?, Int>>) {
        val dp     = resources.displayMetrics.density
        val accent = ThemeHelper.cor("accent",    prefs)
        val bgSect = ThemeHelper.cor("bg_section", prefs)
        val txtW   = ThemeHelper.cor("text_white", prefs)
        val bgDark = ThemeHelper.cor("bg_dark",    prefs)

        botoes.forEach { (btn, valor) ->
            val ativo = valor == valorAtual
            btn?.background = GradientDrawable().apply {
                setColor(if (ativo) accent else bgSect)
                cornerRadius = 8f * dp
            }
            btn?.setTextColor(if (ativo) bgDark else txtW)
        }
    }

    // ─────────────────────────────────────────────────────────────
    // SALVAR
    // ─────────────────────────────────────────────────────────────
    private fun salvarTudo() {
        try {
            val minKm   = findViewById<EditText>(R.id.etMinimoKm)?.text.toString().replace(",",".").toFloatOrNull() ?: 1.20f
            val minVal  = findViewById<EditText>(R.id.etMinimoValor)?.text.toString().replace(",",".").toFloatOrNull() ?: 0f
            val tempo   = findViewById<EditText>(R.id.etTempoAceitar)?.text.toString().toIntOrNull() ?: 2
            val metaDia = findViewById<EditText>(R.id.etMetaDiaria)?.text.toString().replace(",",".").toFloatOrNull() ?: 0f
            val metaSem = findViewById<EditText>(R.id.etMetaSemanal)?.text.toString().replace(",",".").toFloatOrNull() ?: 0f

            prefs.edit().apply {
                putFloat("minimo_km",        minKm)
                putFloat("minimo_valor",     minVal)
                putInt("tempo_auto_aceitar", tempo + 1)
                putBoolean("auto_aceitar",   findViewById<Switch>(R.id.switchAutoAceitar)?.isChecked ?: false)
                putBoolean("auto_recusar",   findViewById<Switch>(R.id.switchAutoRecusar)?.isChecked ?: false)
                putBoolean("som_aceitar",    findViewById<Switch>(R.id.switchSomAceitar)?.isChecked  ?: true)
                putBoolean("som_recusar",    findViewById<Switch>(R.id.switchSomRecusar)?.isChecked  ?: false)
                putBoolean("som_meta",       findViewById<Switch>(R.id.switchSomMeta)?.isChecked     ?: true)
                putFloat("meta_diaria",      metaDia)
                putFloat("meta_semanal",     metaSem)
                putBoolean("notif_meta",     findViewById<Switch>(R.id.switchNotifMeta)?.isChecked   ?: true)
            }.apply()
            
            // Salvar toggle de 99 em prefs separado
            val prefs99 = getSharedPreferences("fluxo_config", android.content.Context.MODE_PRIVATE)
            prefs99.edit().putBoolean("detectar_99", findViewById<Switch>(R.id.switchDetectar99)?.isChecked ?: false).apply()

            // Item 3 — salvo com sucesso: volta o botão ao estado "sem mudanças"
            temAlteracoesPendentes = false
            atualizarEstadoBotaoSalvar()

            Toast.makeText(this, "✅ Configurações salvas", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "❌ Erro ao salvar", Toast.LENGTH_SHORT).show()
            android.util.Log.e("Settings", "salvarTudo", e)
        }
    }

    private fun salvarModo(modo: Int) {
        prefs.edit().putInt("modo_tema", modo).apply()
        notificarTema()
    }

    /**
     * Mostra o log de diagnóstico da detecção da 99 — últimas 25 etapas
     * gravadas pelo NoveNoveAccessibilityService. Acessível segurando o
     * dedo no switch "Detectar corridas de 99".
     */
    private fun mostrarDiagnostico99() {
        val prefs99 = getSharedPreferences("fluxo_config", Context.MODE_PRIVATE)
        val log = prefs99.getString("diag_99_log", "")
        val texto = if (log.isNullOrBlank()) {
            "Nenhum evento registrado ainda.\n\n" +
            "Isso normalmente significa que o Android NÃO está entregando " +
            "eventos do app 99 para o FluxoApp. Verifique:\n\n" +
            "1. Configurações → Acessibilidade → \"FluxoApp (99)\" está ATIVADO?\n" +
            "2. O toggle \"Detectar corridas de 99\" aqui nas configurações está ligado?\n" +
            "3. Tente abrir uma oferta de corrida na 99 agora e volte aqui."
        } else log

        android.app.AlertDialog.Builder(this)
            .setTitle("Diagnóstico — Detecção 99")
            .setMessage(texto)
            .setPositiveButton("Fechar", null)
            .setNegativeButton("Limpar log") { _, _ ->
                prefs99.edit().remove("diag_99_log").apply()
            }
            .show()
    }

    /**
     * Sincroniza a plataforma escolhida (Taxsee/Maxim vs 99) pro Firestore,
     * pra o painel admin conseguir filtrar/ver quem usa qual plataforma.
     * Antes disso, essa info só existia no SharedPreferences local do
     * celular — o painel não tinha nenhuma visibilidade sobre isso.
     */
    private fun sincronizarPlataforma99(detectar99: Boolean) {
        val uid = LicenseManager.uid() ?: return
        try {
            com.google.firebase.firestore.FirebaseFirestore.getInstance()
                .document("users/$uid")
                .update(
                    "plataforma99Ativa", detectar99,
                    "atualizadoEm", com.google.firebase.Timestamp.now()
                )
                .addOnFailureListener {
                    // Documento pode não ter esses campos ainda — cria via merge
                    com.google.firebase.firestore.FirebaseFirestore.getInstance()
                        .document("users/$uid")
                        .set(
                            mapOf("plataforma99Ativa" to detectar99),
                            com.google.firebase.firestore.SetOptions.merge()
                        )
                }
        } catch (_: Exception) {}
    }

    private fun notificarTema() {
        try { sendBroadcast(Intent(FloatingEarningsService.ACTION_TEMA)) } catch (_: Throwable) {}
    }

    /**
     * Verifica se o serviço de acessibilidade NoveNoveAccessibilityService
     * (exclusivo da 99) está habilitado pelo usuário nas configurações do
     * Android. É uma permissão separada da do Taxsee/Maxim.
     */
    private fun servicoAcessibilidade99Ativo(): Boolean {
        return try {
            val ativos = android.provider.Settings.Secure.getString(
                contentResolver,
                android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: ""
            ativos.contains("${packageName}/${packageName}.NoveNoveAccessibilityService")
        } catch (_: Exception) { false }
    }
}
