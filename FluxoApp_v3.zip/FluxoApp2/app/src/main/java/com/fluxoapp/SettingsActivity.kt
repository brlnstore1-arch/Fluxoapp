package com.fluxoapp

import androidx.activity.result.contract.ActivityResultContracts
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    private val importLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri ?: return@registerForActivityResult
        importarCSVdaUri(uri)
    }
    private lateinit var prefs: SharedPreferences
    private lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        prefs = getSharedPreferences("FluxoApp", MODE_PRIVATE)
        db = DatabaseHelper(this)
        aplicarTema()
        configurar()
    }

    private fun configurar() {
        findViewById<ImageButton>(R.id.btnVoltar).setOnClickListener { finish() }

        // TEMA VISUAL
        val rgTema = findViewById<android.widget.RadioGroup>(R.id.rgTemaEstilo)
        val rgModo = findViewById<android.widget.RadioGroup>(R.id.rgModoTema)

        if (rgTema != null && rgModo != null) {
            // Tema atual
            val temaAtual = prefs.getString("tema_estilo", "azul")
            if (temaAtual == "gold") rgTema.check(R.id.rbTemaGold)
            else rgTema.check(R.id.rbTemaAzul)

            // Modo atual
            when (prefs.getInt("modo_tema", -1)) {
                0    -> rgModo.check(R.id.rbModoDia)
                1    -> rgModo.check(R.id.rbModoNoite)
                else -> rgModo.check(R.id.rbModoAuto)
            }

            // Listener: aplica imediatamente ao mudar e notifica serviços
            rgTema.setOnCheckedChangeListener { _, id ->
                val tema = if (id == R.id.rbTemaGold) "gold" else "azul"
                prefs.edit().putString("tema_estilo", tema).apply()
                notificarTemaAtualizado()
                recreate()
            }
            rgModo.setOnCheckedChangeListener { _, id ->
                val modo = when (id) {
                    R.id.rbModoDia -> 0
                    R.id.rbModoNoite -> 1
                    else -> -1
                }
                prefs.edit().putInt("modo_tema", modo).apply()
                notificarTemaAtualizado()
                recreate()
            }
        }

        // DETECÇÃO
        val etMinimo = findViewById<EditText>(R.id.etMinimoKm)
        etMinimo.setText("%.2f".format(prefs.getFloat("minimo_km", 1.20f)))

        val etMinimoValor = findViewById<EditText>(R.id.etMinimoValor)
        etMinimoValor.setText("%.2f".format(prefs.getFloat("minimo_valor", 0f)))

        val sbTempo = findViewById<SeekBar>(R.id.sbTempoAceitar)
        val tvTempo = findViewById<TextView>(R.id.tvTempoAceitar)
        sbTempo.max = 9; sbTempo.progress = prefs.getInt("tempo_auto_aceitar", 3) - 1
        tvTempo.text = "${sbTempo.progress + 1}s"
        sbTempo.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) { tvTempo.text = "${p + 1}s" }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        val switchAutoAceitar = findViewById<Switch>(R.id.switchAutoAceitar)
        switchAutoAceitar.isChecked = prefs.getBoolean("auto_aceitar", false)

        val switchAutoRecusar = findViewById<Switch>(R.id.switchAutoRecusar)
        switchAutoRecusar.isChecked = prefs.getBoolean("auto_recusar", false)

        // SONS
        val switchSomAceitar = findViewById<Switch>(R.id.switchSomAceitar)
        switchSomAceitar.isChecked = prefs.getBoolean("som_aceitar", true)

        val switchSomRecusar = findViewById<Switch>(R.id.switchSomRecusar)
        switchSomRecusar.isChecked = prefs.getBoolean("som_recusar", false)

        val switchSomMeta = findViewById<Switch>(R.id.switchSomMeta)
        switchSomMeta.isChecked = prefs.getBoolean("som_meta", true)

        // BOTÃO FLUTUANTE
        val switchFlutuante = findViewById<Switch>(R.id.switchFlutuante)
        switchFlutuante.isChecked = prefs.getBoolean("flutuante_ativo", true)
        switchFlutuante.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) startService(Intent(this, FloatingEarningsService::class.java))
            else stopService(Intent(this, FloatingEarningsService::class.java))
        }

        val rgPosicao = findViewById<RadioGroup>(R.id.rgPosicaoFlutuante)
        if (prefs.getString("flutuante_posicao", "esquerda") == "direita")
            rgPosicao.check(R.id.rbDireita) else rgPosicao.check(R.id.rbEsquerda)

        // METAS
        val etMetaDiaria = findViewById<EditText>(R.id.etMetaDiaria)
        val meta = prefs.getFloat("meta_diaria", 0f)
        etMetaDiaria.setText(if (meta > 0) "%.2f".format(meta) else "")

        val etMetaSemanal = findViewById<EditText>(R.id.etMetaSemanal)
        val metaSem = prefs.getFloat("meta_semanal", 0f)
        etMetaSemanal.setText(if (metaSem > 0) "%.2f".format(metaSem) else "")

        val switchNotifMeta = findViewById<Switch>(R.id.switchNotifMeta)
        switchNotifMeta.isChecked = prefs.getBoolean("notif_meta", true)

        // DADOS
        findViewById<Button>(R.id.btnLimparHoje).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Limpar hoje")
                .setMessage("Apagar todas as corridas de hoje?")
                .setPositiveButton("Sim") { _, _ -> db.limparHoje(); Toast.makeText(this, "✅ Corridas de hoje apagadas", Toast.LENGTH_SHORT).show() }
                .setNegativeButton("Não", null).show()
        }
        findViewById<Button>(R.id.btnLimparTudo).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Limpar tudo")
                .setMessage("Apagar TODO o histórico? Esta ação é irreversível!")
                .setPositiveButton("Sim, apagar tudo") { _, _ -> db.limparTudo(); Toast.makeText(this, "✅ Histórico apagado", Toast.LENGTH_SHORT).show() }
                .setNegativeButton("Cancelar", null).show()
        }
        findViewById<Button>(R.id.btnExportar).setOnClickListener { exportarCSV() }
        findViewById<Button>(R.id.btnImportar)?.setOnClickListener {
            importLauncher.launch("text/*")
        }

        // SALVAR
        findViewById<Button>(R.id.btnSalvarConfig).setOnClickListener { salvar(
            etMinimo, etMinimoValor, sbTempo, switchAutoAceitar, switchAutoRecusar,
            switchSomAceitar, switchSomRecusar, switchSomMeta,
            switchFlutuante, rgPosicao, etMetaDiaria, etMetaSemanal, switchNotifMeta
        )}
    }

    private fun salvar(
        etMinimo: EditText, etMinimoValor: EditText, sbTempo: SeekBar,
        switchAutoAceitar: Switch, switchAutoRecusar: Switch,
        switchSomAceitar: Switch, switchSomRecusar: Switch, switchSomMeta: Switch,
        switchFlutuante: Switch, rgPosicao: RadioGroup,
        etMetaDiaria: EditText, etMetaSemanal: EditText, switchNotifMeta: Switch
    ) {
        val minKm = etMinimo.text.toString().replace(",", ".").toFloatOrNull() ?: 1.20f
        val minValor = etMinimoValor.text.toString().replace(",", ".").toFloatOrNull() ?: 0f
        val metaDiaria = etMetaDiaria.text.toString().replace(",", ".").toFloatOrNull() ?: 0f
        val metaSemanal = etMetaSemanal.text.toString().replace(",", ".").toFloatOrNull() ?: 0f
        val posicao = if (rgPosicao.checkedRadioButtonId == R.id.rbDireita) "direita" else "esquerda"

        prefs.edit()
            .putFloat("minimo_km", minKm)
            .putFloat("minimo_valor", minValor)
            .putInt("tempo_auto_aceitar", sbTempo.progress + 1)
            .putBoolean("auto_aceitar", switchAutoAceitar.isChecked)
            .putBoolean("auto_recusar", switchAutoRecusar.isChecked)
            .putBoolean("som_aceitar", switchSomAceitar.isChecked)
            .putBoolean("som_recusar", switchSomRecusar.isChecked)
            .putBoolean("som_meta", switchSomMeta.isChecked)
            .putBoolean("flutuante_ativo", switchFlutuante.isChecked)
            .putString("flutuante_posicao", posicao)
            .putFloat("meta_diaria", metaDiaria)
            .putFloat("meta_semanal", metaSemanal)
            .putBoolean("notif_meta", switchNotifMeta.isChecked)
            .apply()

        Toast.makeText(this, "✅ Configurações salvas!", Toast.LENGTH_SHORT).show()
        startService(Intent(this, FloatingEarningsService::class.java).apply { action = "ATUALIZAR" })
    }

    private fun exportarCSV() {
        val corridas = db.buscarTodas()
        if (corridas.isEmpty()) { Toast.makeText(this, "Nenhuma corrida para exportar", Toast.LENGTH_SHORT).show(); return }
        val sb = StringBuilder("Data,Hora,HoraInicio,HoraFim,Valor,KM,GanhoKM,ValeAPena,Origem,Destino,Pagamento,Passageiro,Tempo\n")
        corridas.forEach { c ->
            val orig = c.origem.replace("\"", "'")
            val dest = c.destino.replace("\"", "'")
            sb.append("${c.data},${c.hora},${c.horaInicio},${c.horaFim},${c.valor},${c.kmTotal},${c.ganhoPorKm},${if (c.valeAPena) "Sim" else "Nao"},\"$orig\",\"$dest\",${c.formaPagamento},${c.passageiro},${c.tempoExecucao}\n")
        }
        val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
        val file = java.io.File(downloadsDir, "fluxoapp_historico.csv")
        file.writeText(sb.toString())
        try {
            val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.provider", file)
            val share = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(android.content.Intent.createChooser(share, "Salvar CSV"))
        } catch (_: Exception) {
            Toast.makeText(this, "Exportado: ${file.absolutePath}", Toast.LENGTH_LONG).show()
        }
    }

    private fun importarCSVdaUri(uri: android.net.Uri) {
        try {
            val linhas = contentResolver.openInputStream(uri)?.bufferedReader()?.readLines() ?: return
            if (linhas.size < 2) { Toast.makeText(this, "Arquivo vazio ou invalido", Toast.LENGTH_SHORT).show(); return }
            var importadas = 0; var ignoradas = 0
            for (linha in linhas.drop(1)) {
                if (linha.isBlank()) continue
                try {
                    val cols = parseCsvLine(linha)
                    val valor = cols.getOrElse(4) { "0" }.toFloatOrNull() ?: 0f
                    if (valor <= 0f || cols.size < 5) { ignoradas++; continue }
                    db.inserirCorrida(Corrida(
                        valor = valor,
                        kmTotal        = cols.getOrElse(5)  { "0" }.toFloatOrNull() ?: 0f,
                        ganhoPorKm     = cols.getOrElse(6)  { "0" }.toFloatOrNull() ?: 0f,
                        valeAPena      = cols.getOrElse(7)  { "Nao" }.equals("Sim", ignoreCase = true),
                        data           = cols.getOrElse(0)  { "" },
                        hora           = cols.getOrElse(1)  { "" },
                        horaInicio     = cols.getOrElse(2)  { "" },
                        horaFim        = cols.getOrElse(3)  { "" },
                        origem         = cols.getOrElse(8)  { "" },
                        destino        = cols.getOrElse(9)  { "" },
                        formaPagamento = cols.getOrElse(10) { "" },
                        passageiro     = cols.getOrElse(11) { "" },
                        tempoExecucao  = cols.getOrElse(12) { "" }
                    ))
                    importadas++
                } catch (_: Exception) { ignoradas++ }
            }
            Toast.makeText(this, "$importadas corridas importadas! ($ignoradas ignoradas)", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Erro: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun parseCsvLine(line: String): List<String> {
        val result = mutableListOf<String>(); var current = StringBuilder(); var inQuotes = false
        for (ch in line) { when { ch == '"' -> inQuotes = !inQuotes; ch == ',' && !inQuotes -> { result.add(current.toString().trim()); current = StringBuilder() }; else -> current.append(ch) } }
        result.add(current.toString().trim()); return result
    }

    private fun aplicarTema() {
        val p  = getSharedPreferences("FluxoApp", android.content.Context.MODE_PRIVATE)
        val bg     = ThemeHelper.cor("bg_dark",     p)
        val bgCard = ThemeHelper.cor("bg_card",     p)
        val cyan   = ThemeHelper.cor("accent_cyan", p)
        val txtW   = ThemeHelper.cor("text_white",  p)
        val border = ThemeHelper.cor("border",      p)
        try {
            // Tenta encontrar rootLayout genérico
            for (idNome in listOf("rootLayout", "rootLayoutSettings", "scrollRoot")) {
                val id = resources.getIdentifier(idNome, "id", packageName)
                if (id != 0) { findViewById<android.view.View>(id)?.setBackgroundColor(bg); break }
            }
        } catch (_: Exception) {}
        try { findViewById<android.widget.ImageButton>(R.id.btnVoltar)?.setColorFilter(cyan) } catch (_: Exception) {}
    }

    // Notifica todos os serviços ativos sobre a mudança de tema
    private fun notificarTemaAtualizado() {
        try {
            // Broadcast para FloatingEarningsService
            sendBroadcast(android.content.Intent(FloatingEarningsService.ACTION_TEMA))
        } catch (_: Exception) {}
        try {
            // Intent direto também (dupla garantia)
            startService(android.content.Intent(this, FloatingEarningsService::class.java).apply {
                action = FloatingEarningsService.ACTION_TEMA
            })
        } catch (_: Exception) {}
    }
}
