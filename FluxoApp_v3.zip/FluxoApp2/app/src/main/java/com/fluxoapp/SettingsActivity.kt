package com.fluxoapp

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import android.graphics.drawable.GradientDrawable
import android.graphics.Color
import android.view.ViewGroup
import android.view.View
import java.util.*

class SettingsActivity : AppCompatActivity() {

    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var db: DatabaseHelper
    private var temaAtual = "gold"
    private var modoAtual = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeSelector.aplicar(this)
        setContentView(R.layout.activity_settings)

        prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        db = DatabaseHelper(this)

        // Carregar tema e modo atuais
        temaAtual = prefs.getString("tema_estilo", "gold") ?: "gold"
        modoAtual = prefs.getInt("modo_tema", -1)

        try {
            configurarHeader()
            configurarTemaVisual()
            configurarTamanhoFonte()
            configurarDeteccao()
            configurarAutomacoes()
            configurarSonsAlertas()
            configurarMetas()
            configurarBotaoSalvar()
        } catch (e: Exception) {
            android.util.Log.e("Settings", "Erro ao configurar UI", e)
        }
    }

    private fun configurarHeader() {
        try {
            findViewById<ImageButton>(R.id.btnVoltar)?.setOnClickListener {
                finish()
            }
        } catch (_: Exception) {}
    }

    private fun configurarTemaVisual() {
        try {
            val cardAzul = findViewById<FrameLayout>(R.id.cardTemaAzul)
            val cardGold = findViewById<FrameLayout>(R.id.cardTemaGold)

            atualizarBordasTema()

            cardAzul?.setOnClickListener {
                temaAtual = "azul"
                prefs.edit().putString("tema_estilo", "azul").apply()
                notificarTemaAtualizado()
                recreate()
            }

            cardGold?.setOnClickListener {
                temaAtual = "gold"
                prefs.edit().putString("tema_estilo", "gold").apply()
                notificarTemaAtualizado()
                recreate()
            }

            val btnDia = findViewById<Button>(R.id.btnModoDia)
            val btnNoite = findViewById<Button>(R.id.btnModoNoite)
            val btnAuto = findViewById<Button>(R.id.btnModoAuto)

            atualizarBotoesModoPorModo(modoAtual, btnDia, btnNoite, btnAuto)

            btnDia?.setOnClickListener {
                modoAtual = 0
                prefs.edit().putInt("modo_tema", 0).apply()
                notificarTemaAtualizado()
                recreate()
            }

            btnNoite?.setOnClickListener {
                modoAtual = 1
                prefs.edit().putInt("modo_tema", 1).apply()
                notificarTemaAtualizado()
                recreate()
            }

            btnAuto?.setOnClickListener {
                modoAtual = -1
                prefs.edit().putInt("modo_tema", -1).apply()
                notificarTemaAtualizado()
                recreate()
            }
        } catch (e: Exception) {
            android.util.Log.e("Settings", "Erro em configurarTemaVisual", e)
        }
    }

    private fun atualizarBordasTema() {
        try {
            val cardAzul = findViewById<FrameLayout>(R.id.cardTemaAzul)
            val cardGold = findViewById<FrameLayout>(R.id.cardTemaGold)
            val dp = resources.displayMetrics.density

            if (temaAtual == "azul") {
                cardAzul?.background = GradientDrawable().apply {
                    setColor(Color.parseColor("#1a2a3a"))
                    cornerRadius = 12f * dp
                    setStroke((3f * dp).toInt(), 0xFF5A8ABB.toInt())
                }
                cardGold?.background = GradientDrawable().apply {
                    setColor(Color.parseColor("#1a2a3a"))
                    cornerRadius = 12f * dp
                    setStroke((2f * dp).toInt(), Color.TRANSPARENT)
                }
            } else {
                cardGold?.background = GradientDrawable().apply {
                    setColor(Color.parseColor("#1a2a3a"))
                    cornerRadius = 12f * dp
                    setStroke((3f * dp).toInt(), 0xFFDAA520.toInt())
                }
                cardAzul?.background = GradientDrawable().apply {
                    setColor(Color.parseColor("#1a2a3a"))
                    cornerRadius = 12f * dp
                    setStroke((2f * dp).toInt(), Color.TRANSPARENT)
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("Settings", "Erro em atualizarBordasTema", e)
        }
    }

    private fun atualizarBotoesModoPorModo(modo: Int, btnDia: Button?, btnNoite: Button?, btnAuto: Button?) {
        try {
            val corTema = if (temaAtual == "azul") "#5A8ABB" else "#DAA520"
            val corInt = Color.parseColor(corTema)
            val dp = resources.displayMetrics.density

            when (modo) {
                0 -> {
                    btnDia?.setBackgroundDrawable(GradientDrawable().apply {
                        setColor(corInt)
                        cornerRadius = 8f * dp
                    })
                    btnDia?.setTextColor(Color.WHITE)
                    btnNoite?.setBackgroundColor(Color.parseColor("#2a3a4a"))
                    btnNoite?.setTextColor(Color.parseColor("#cccccc"))
                    btnAuto?.setBackgroundColor(Color.parseColor("#2a3a4a"))
                    btnAuto?.setTextColor(Color.parseColor("#cccccc"))
                }
                1 -> {
                    btnDia?.setBackgroundColor(Color.parseColor("#2a3a4a"))
                    btnDia?.setTextColor(Color.parseColor("#cccccc"))
                    btnNoite?.setBackgroundDrawable(GradientDrawable().apply {
                        setColor(corInt)
                        cornerRadius = 8f * dp
                    })
                    btnNoite?.setTextColor(Color.WHITE)
                    btnAuto?.setBackgroundColor(Color.parseColor("#2a3a4a"))
                    btnAuto?.setTextColor(Color.parseColor("#cccccc"))
                }
                else -> {
                    btnDia?.setBackgroundColor(Color.parseColor("#2a3a4a"))
                    btnDia?.setTextColor(Color.parseColor("#cccccc"))
                    btnNoite?.setBackgroundColor(Color.parseColor("#2a3a4a"))
                    btnNoite?.setTextColor(Color.parseColor("#cccccc"))
                    btnAuto?.setBackgroundDrawable(GradientDrawable().apply {
                        setColor(corInt)
                        cornerRadius = 8f * dp
                    })
                    btnAuto?.setTextColor(Color.WHITE)
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("Settings", "Erro em atualizarBotoesModoPorModo", e)
        }
    }

    private fun configurarTamanhoFonte() {
        try {
            val btnPequeno = findViewById<Button>(R.id.btnFontePequeno)
            val btnMedio = findViewById<Button>(R.id.btnFonteMedio)
            val btnGrande = findViewById<Button>(R.id.btnFonteGrande)

            val tamanhoAtual = prefs.getString("tamanho_fonte", "medio") ?: "medio"
            atualizarBotoesFonte(tamanhoAtual)

            btnPequeno?.setOnClickListener {
                prefs.edit().putString("tamanho_fonte", "pequeno").apply()
                atualizarBotoesFonte("pequeno")
                Toast.makeText(this, "Fonte alterada para Pequeno", Toast.LENGTH_SHORT).show()
            }

            btnMedio?.setOnClickListener {
                prefs.edit().putString("tamanho_fonte", "medio").apply()
                atualizarBotoesFonte("medio")
                Toast.makeText(this, "Fonte alterada para Médio", Toast.LENGTH_SHORT).show()
            }

            btnGrande?.setOnClickListener {
                prefs.edit().putString("tamanho_fonte", "grande").apply()
                atualizarBotoesFonte("grande")
                Toast.makeText(this, "Fonte alterada para Grande", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            android.util.Log.e("Settings", "Erro em configurarTamanhoFonte", e)
        }
    }

    private fun atualizarBotoesFonte(tamanho: String) {
        try {
            val btnPequeno = findViewById<Button>(R.id.btnFontePequeno)
            val btnMedio = findViewById<Button>(R.id.btnFonteMedio)
            val btnGrande = findViewById<Button>(R.id.btnFonteGrande)
            val corTema = if (temaAtual == "azul") "#5A8ABB" else "#DAA520"
            val corInt = Color.parseColor(corTema)
            val dp = resources.displayMetrics.density

            btnPequeno?.setBackgroundColor(Color.parseColor("#2a3a4a"))
            btnPequeno?.setTextColor(Color.parseColor("#cccccc"))
            btnMedio?.setBackgroundColor(Color.parseColor("#2a3a4a"))
            btnMedio?.setTextColor(Color.parseColor("#cccccc"))
            btnGrande?.setBackgroundColor(Color.parseColor("#2a3a4a"))
            btnGrande?.setTextColor(Color.parseColor("#cccccc"))

            when (tamanho) {
                "pequeno" -> {
                    btnPequeno?.setBackgroundDrawable(GradientDrawable().apply {
                        setColor(corInt)
                        cornerRadius = 8f * dp
                    })
                    btnPequeno?.setTextColor(Color.WHITE)
                }
                "medio" -> {
                    btnMedio?.setBackgroundDrawable(GradientDrawable().apply {
                        setColor(corInt)
                        cornerRadius = 8f * dp
                    })
                    btnMedio?.setTextColor(Color.WHITE)
                }
                "grande" -> {
                    btnGrande?.setBackgroundDrawable(GradientDrawable().apply {
                        setColor(corInt)
                        cornerRadius = 8f * dp
                    })
                    btnGrande?.setTextColor(Color.WHITE)
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("Settings", "Erro em atualizarBotoesFonte", e)
        }
    }

    private fun configurarDeteccao() {
        try {
            val etMinimoKm = findViewById<EditText>(R.id.etMinimoKm)
            etMinimoKm?.setText("%.2f".format(prefs.getFloat("minimo_km", 1.20f)))

            val etMinimoValor = findViewById<EditText>(R.id.etMinimoValor)
            etMinimoValor?.setText("%.2f".format(prefs.getFloat("minimo_valor", 0f)))

            val etTempo = findViewById<EditText>(R.id.etTempoAceitar)
            etTempo?.setText((prefs.getInt("tempo_auto_aceitar", 3) - 1).toString())
        } catch (e: Exception) {
            android.util.Log.e("Settings", "Erro em configurarDeteccao", e)
        }
    }

    private fun configurarAutomacoes() {
        try {
            val switchAutoAceitar = findViewById<Switch>(R.id.switchAutoAceitar)
            switchAutoAceitar?.isChecked = prefs.getBoolean("auto_aceitar", false)

            val switchAutoRecusar = findViewById<Switch>(R.id.switchAutoRecusar)
            switchAutoRecusar?.isChecked = prefs.getBoolean("auto_recusar", false)
        } catch (e: Exception) {
            android.util.Log.e("Settings", "Erro em configurarAutomacoes", e)
        }
    }

    private fun configurarSonsAlertas() {
        try {
            val switchSomAceitar = findViewById<Switch>(R.id.switchSomAceitar)
            switchSomAceitar?.isChecked = prefs.getBoolean("som_aceitar", true)

            val switchSomRecusar = findViewById<Switch>(R.id.switchSomRecusar)
            switchSomRecusar?.isChecked = prefs.getBoolean("som_recusar", false)

            val switchSomMeta = findViewById<Switch>(R.id.switchSomMeta)
            switchSomMeta?.isChecked = prefs.getBoolean("som_meta", true)
        } catch (e: Exception) {
            android.util.Log.e("Settings", "Erro em configurarSonsAlertas", e)
        }
    }

    private fun configurarMetas() {
        try {
            val etMetaDiaria = findViewById<EditText>(R.id.etMetaDiaria)
            val meta = prefs.getFloat("meta_diaria", 0f)
            etMetaDiaria?.setText(if (meta > 0) "%.2f".format(meta) else "")

            val etMetaSemanal = findViewById<EditText>(R.id.etMetaSemanal)
            val metaSem = prefs.getFloat("meta_semanal", 0f)
            etMetaSemanal?.setText(if (metaSem > 0) "%.2f".format(metaSem) else "")

            val switchNotifMeta = findViewById<Switch>(R.id.switchNotifMeta)
            switchNotifMeta?.isChecked = prefs.getBoolean("notif_meta", true)

            atualizarProgressoMetas()
        } catch (e: Exception) {
            android.util.Log.e("Settings", "Erro em configurarMetas", e)
        }
    }

    private fun atualizarProgressoMetas() {
        try {
            val corridas = db.buscarHoje()
            val resumo = db.resumo(corridas)
            val totalHoje = (resumo["total"] as? Number)?.toFloat() ?: 0f
            val metaDiaria = prefs.getFloat("meta_diaria", 0f)

            val tvProgressoHoje = findViewById<TextView>(R.id.tvProgressoHoje)
            tvProgressoHoje?.text = "Progresso hoje: R$ ${"%.2f".format(totalHoje)}"

            val progressBar = findViewById<ProgressBar>(R.id.progressMetaDia)
            if (metaDiaria > 0) {
                val percent = (totalHoje / metaDiaria * 100).toInt().coerceIn(0, 100)
                progressBar?.progress = percent
            }

            val tvProgressoSemana = findViewById<TextView>(R.id.tvProgressoSemana)
            tvProgressoSemana?.text = "Progresso esta semana: R$ 0,00"

            val progressSemana = findViewById<ProgressBar>(R.id.progressMetaSemana)
            progressSemana?.progress = 0
        } catch (e: Exception) {
            android.util.Log.e("Settings", "Erro ao atualizar progresso", e)
        }
    }

    private fun configurarBotaoSalvar() {
        try {
            atualizarCorBotaoSalvar()
            findViewById<Button>(R.id.btnSalvarConfig)?.setOnClickListener {
                salvarConfigurações()
            }
        } catch (e: Exception) {
            android.util.Log.e("Settings", "Erro em configurarBotaoSalvar", e)
        }
    }

    private fun atualizarCorBotaoSalvar() {
        try {
            val btnSalvar = findViewById<Button>(R.id.btnSalvarConfig)
            val corTema = if (temaAtual == "azul") "#5A8ABB" else "#DAA520"
            val corInt = Color.parseColor(corTema)
            val dp = resources.displayMetrics.density

            btnSalvar?.setBackgroundDrawable(GradientDrawable().apply {
                setColor(corInt)
                cornerRadius = 8f * dp
            })
            btnSalvar?.setTextColor(Color.WHITE)
        } catch (e: Exception) {
            android.util.Log.e("Settings", "Erro em atualizarCorBotaoSalvar", e)
        }
    }

    private fun salvarConfigurações() {
        try {
            val etMinimoKm = findViewById<EditText>(R.id.etMinimoKm)
            val etMinimoValor = findViewById<EditText>(R.id.etMinimoValor)
            val etTempo = findViewById<EditText>(R.id.etTempoAceitar)
            val etMetaDiaria = findViewById<EditText>(R.id.etMetaDiaria)
            val etMetaSemanal = findViewById<EditText>(R.id.etMetaSemanal)
            val switchAutoAceitar = findViewById<Switch>(R.id.switchAutoAceitar)
            val switchAutoRecusar = findViewById<Switch>(R.id.switchAutoRecusar)
            val switchSomAceitar = findViewById<Switch>(R.id.switchSomAceitar)
            val switchSomRecusar = findViewById<Switch>(R.id.switchSomRecusar)
            val switchSomMeta = findViewById<Switch>(R.id.switchSomMeta)
            val switchNotifMeta = findViewById<Switch>(R.id.switchNotifMeta)

            val minKm = etMinimoKm?.text.toString().replace(",", ".").toFloatOrNull() ?: 1.20f
            val minValor = etMinimoValor?.text.toString().replace(",", ".").toFloatOrNull() ?: 0f
            val tempo = etTempo?.text.toString().toIntOrNull() ?: 2
            val metaDiaria = etMetaDiaria?.text.toString().replace(",", ".").toFloatOrNull() ?: 0f
            val metaSemanal = etMetaSemanal?.text.toString().replace(",", ".").toFloatOrNull() ?: 0f

            prefs.edit().apply {
                putFloat("minimo_km", minKm)
                putFloat("minimo_valor", minValor)
                putInt("tempo_auto_aceitar", tempo + 1)
                putBoolean("auto_aceitar", switchAutoAceitar?.isChecked ?: false)
                putBoolean("auto_recusar", switchAutoRecusar?.isChecked ?: false)
                putBoolean("som_aceitar", switchSomAceitar?.isChecked ?: true)
                putBoolean("som_recusar", switchSomRecusar?.isChecked ?: false)
                putBoolean("som_meta", switchSomMeta?.isChecked ?: true)
                putFloat("meta_diaria", metaDiaria)
                putFloat("meta_semanal", metaSemanal)
                putBoolean("notif_meta", switchNotifMeta?.isChecked ?: true)
            }.apply()

            Toast.makeText(this, "✅ Configurações salvas", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "❌ Erro ao salvar", Toast.LENGTH_SHORT).show()
            android.util.Log.e("Settings", "Erro ao salvar", e)
        }
    }

    private fun notificarTemaAtualizado() {
        try {
            sendBroadcast(Intent(FloatingEarningsService.ACTION_TEMA))
        } catch (_: Throwable) {}
    }
}
