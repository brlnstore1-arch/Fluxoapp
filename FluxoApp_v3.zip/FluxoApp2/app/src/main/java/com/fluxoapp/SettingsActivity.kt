package com.fluxoapp

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import android.graphics.drawable.GradientDrawable
import android.graphics.Color
import android.view.ViewGroup
import android.view.View
import java.util.*

class SettingsActivity : AppCompatActivity() {

    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var db: DatabaseHelper
    private var temaAtual = "gold"
    private var modoAtual = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeSelector.aplicar(this)
        setContentView(R.layout.activity_settings)

        prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        db = DatabaseHelper(this)

        // Carregar tema e modo atuais
        temaAtual = prefs.getString("tema_estilo", "gold") ?: "gold"
        modoAtual = prefs.getInt("modo_tema", -1)

        configurarHeader()
        configurarTemaVisual()
        configurarTamanhoFonte()
        configurarDeteccao()
        configurarAutomacoes()
        configurarSonsAlertas()
        configurarMetas()
        configurarBotaoSalvar()

        aplicarTemaGlobal()
    }

    // ══════════════════════════════════════════════════════════════════════
    // HEADER
    // ══════════════════════════════════════════════════════════════════════
    private fun configurarHeader() {
        findViewById<ImageButton>(R.id.btnVoltar)?.setOnClickListener {
            finish()
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    // TEMA VISUAL
    // ══════════════════════════════════════════════════════════════════════
    private fun configurarTemaVisual() {
        // Cards de tema
        val cardAzul = findViewById<FrameLayout>(R.id.cardTemaAzul)
        val cardGold = findViewById<FrameLayout>(R.id.cardTemaGold)

        atualizarBordasTema()

        cardAzul?.setOnClickListener {
            temaAtual = "azul"
            prefs.edit().putString("tema_estilo", "azul").apply()
            notificarTemaAtualizado()
            atualizarBordasTema()
            atualizarCoresBotoesPorTema()
            recreate()
        }

        cardGold?.setOnClickListener {
            temaAtual = "gold"
            prefs.edit().putString("tema_estilo", "gold").apply()
            notificarTemaAtualizado()
            atualizarBordasTema()
            atualizarCoresBotoesPorTema()
            recreate()
        }

        // Botões de modo
        val btnDia = findViewById<Button>(R.id.btnModoDia)
        val btnNoite = findViewById<Button>(R.id.btnModoNoite)
        val btnAuto = findViewById<Button>(R.id.btnModoAuto)

        atualizarBotoesModoPorModo(modoAtual, btnDia, btnNoite, btnAuto)

        btnDia?.setOnClickListener {
            modoAtual = 0
            prefs.edit().putInt("modo_tema", 0).apply()
            notificarTemaAtualizado()
            atualizarBotoesModoPorModo(0, btnDia, btnNoite, btnAuto)
            atualizarCoresBotoesPorTema()
            recreate()
        }

        btnNoite?.setOnClickListener {
            modoAtual = 1
            prefs.edit().putInt("modo_tema", 1).apply()
            notificarTemaAtualizado()
            atualizarBotoesModoPorModo(1, btnDia, btnNoite, btnAuto)
            atualizarCoresBotoesPorTema()
            recreate()
        }

        btnAuto?.setOnClickListener {
            modoAtual = -1
            prefs.edit().putInt("modo_tema", -1).apply()
            notificarTemaAtualizado()
            atualizarBotoesModoPorModo(-1, btnDia, btnNoite, btnAuto)
            atualizarCoresBotoesPorTema()
            recreate()
        }
    }

    private fun atualizarBordasTema() {
        val cardAzul = findViewById<FrameLayout>(R.id.cardTemaAzul)
        val cardGold = findViewById<FrameLayout>(R.id.cardTemaGold)
        val dp = resources.displayMetrics.density

        if (temaAtual == "azul") {
            cardAzul?.background = GradientDrawable().apply {
                setColor(ThemeHelper.cor("bg_card", prefs))
                cornerRadius = 12f * dp
                setStroke((3f * dp).toInt(), 0xFF5A8ABB.toInt())
            }
            cardGold?.background = GradientDrawable().apply {
                setColor(ThemeHelper.cor("bg_card", prefs))
                cornerRadius = 12f * dp
                setStroke((2f * dp).toInt(), Color.TRANSPARENT)
            }
        } else {
            cardGold?.background = GradientDrawable().apply {
                setColor(ThemeHelper.cor("bg_card", prefs))
                cornerRadius = 12f * dp
                setStroke((3f * dp).toInt(), 0xFFDAA520.toInt())
            }
            cardAzul?.background = GradientDrawable().apply {
                setColor(ThemeHelper.cor("bg_card", prefs))
                cornerRadius = 12f * dp
                setStroke((2f * dp).toInt(), Color.TRANSPARENT)
            }
        }
    }

    private fun atualizarBotoesModoPorModo(modo: Int, btnDia: Button?, btnNoite: Button?, btnAuto: Button?) {
        val corTema = if (temaAtual == "azul") "#5A8ABB" else "#DAA520"
        val corInt = Color.parseColor(corTema)
        val dp = resources.displayMetrics.density

        when (modo) {
            0 -> {
                btnDia?.setBackgroundDrawable(GradientDrawable().apply {
                    setColor(corInt)
                    cornerRadius = 8f * dp
                })
                btnDia?.setTextColor(Color.WHITE)
                btnNoite?.setBackgroundColor(ThemeHelper.cor("bg_section", prefs))
                btnNoite?.setTextColor(ThemeHelper.cor("text_white", prefs))
                btnAuto?.setBackgroundColor(ThemeHelper.cor("bg_section", prefs))
                btnAuto?.setTextColor(ThemeHelper.cor("text_white", prefs))
            }
            1 -> {
                btnDia?.setBackgroundColor(ThemeHelper.cor("bg_section", prefs))
                btnDia?.setTextColor(ThemeHelper.cor("text_white", prefs))
                btnNoite?.setBackgroundDrawable(GradientDrawable().apply {
                    setColor(corInt)
                    cornerRadius = 8f * dp
                })
                btnNoite?.setTextColor(Color.WHITE)
                btnAuto?.setBackgroundColor(ThemeHelper.cor("bg_section", prefs))
                btnAuto?.setTextColor(ThemeHelper.cor("text_white", prefs))
            }
            else -> {
                btnDia?.setBackgroundColor(ThemeHelper.cor("bg_section", prefs))
                btnDia?.setTextColor(ThemeHelper.cor("text_white", prefs))
                btnNoite?.setBackgroundColor(ThemeHelper.cor("bg_section", prefs))
                btnNoite?.setTextColor(ThemeHelper.cor("text_white", prefs))
                btnAuto?.setBackgroundDrawable(GradientDrawable().apply {
                    setColor(corInt)
                    cornerRadius = 8f * dp
                })
                btnAuto?.setTextColor(Color.WHITE)
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    // TAMANHO DE FONTE
    // ══════════════════════════════════════════════════════════════════════
    private fun configurarTamanhoFonte() {
        val btnPequeno = findViewById<Button>(R.id.btnFontePequeno)
        val btnMedio = findViewById<Button>(R.id.btnFonteMedio)
        val btnGrande = findViewById<Button>(R.id.btnFonteGrande)

        val tamanhoAtual = prefs.getString("tamanho_fonte", "medio") ?: "medio"
        atualizarBotoesFonte(tamanhoAtual)

        btnPequeno?.setOnClickListener {
            prefs.edit().putString("tamanho_fonte", "pequeno").apply()
            atualizarBotoesFonte("pequeno")
            atualizarTamanhoFonteGlobal("pequeno")
            Toast.makeText(this, "Fonte alterada para Pequeno", Toast.LENGTH_SHORT).show()
        }

        btnMedio?.setOnClickListener {
            prefs.edit().putString("tamanho_fonte", "medio").apply()
            atualizarBotoesFonte("medio")
            atualizarTamanhoFonteGlobal("medio")
            Toast.makeText(this, "Fonte alterada para Médio", Toast.LENGTH_SHORT).show()
        }

        btnGrande?.setOnClickListener {
            prefs.edit().putString("tamanho_fonte", "grande").apply()
            atualizarBotoesFonte("grande")
            atualizarTamanhoFonteGlobal("grande")
            Toast.makeText(this, "Fonte alterada para Grande", Toast.LENGTH_SHORT).show()
        }
    }

    private fun atualizarBotoesFonte(tamanho: String) {
        val btnPequeno = findViewById<Button>(R.id.btnFontePequeno)
        val btnMedio = findViewById<Button>(R.id.btnFonteMedio)
        val btnGrande = findViewById<Button>(R.id.btnFonteGrande)
        val corTema = if (temaAtual == "azul") "#5A8ABB" else "#DAA520"
        val corInt = Color.parseColor(corTema)
        val dp = resources.displayMetrics.density

        // Reset todos
        btnPequeno?.setBackgroundColor(ThemeHelper.cor("bg_section", prefs))
        btnPequeno?.setTextColor(ThemeHelper.cor("text_white", prefs))
        btnMedio?.setBackgroundColor(ThemeHelper.cor("bg_section", prefs))
        btnMedio?.setTextColor(ThemeHelper.cor("text_white", prefs))
        btnGrande?.setBackgroundColor(ThemeHelper.cor("bg_section", prefs))
        btnGrande?.setTextColor(ThemeHelper.cor("text_white", prefs))

        // Marcar selecionado
        when (tamanho) {
            "pequeno" -> {
                btnPequeno?.setBackgroundDrawable(GradientDrawable().apply {
                    setColor(corInt)
                    cornerRadius = 8f * dp
                })
                btnPequeno?.setTextColor(Color.WHITE)
            }
            "medio" -> {
                btnMedio?.setBackgroundDrawable(GradientDrawable().apply {
                    setColor(corInt)
                    cornerRadius = 8f * dp
                })
                btnMedio?.setTextColor(Color.WHITE)
            }
            "grande" -> {
                btnGrande?.setBackgroundDrawable(GradientDrawable().apply {
                    setColor(corInt)
                    cornerRadius = 8f * dp
                })
                btnGrande?.setTextColor(Color.WHITE)
            }
        }
    }

    private fun atualizarTamanhoFonteGlobal(tamanho: String) {
        try {
            val tamanhoSp = when (tamanho) {
                "pequeno" -> 11f
                "grande" -> 15f
                else -> 13f
            }

            // Aplicar em views da settings
            val rootLayout = findViewById<LinearLayout>(R.id.rootLayout)
            aplicarTamanhoFonteRecursivo(rootLayout, tamanhoSp)
        } catch (e: Exception) {
            android.util.Log.e("Settings", "Erro ao aplicar tamanho de fonte", e)
        }
    }

    private fun aplicarTamanhoFonteRecursivo(view: View, tamanhoSp: Float) {
        if (view is TextView) {
            // Não alterar tamanho de labels/títulos fixos
            val currentSize = view.textSize / resources.displayMetrics.density
            if (currentSize < 16) { // Apenas TextViews pequenas (histórico)
                view.textSize = tamanhoSp
            }
        }
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                aplicarTamanhoFonteRecursivo(view.getChildAt(i), tamanhoSp)
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    // DETECÇÃO
    // ══════════════════════════════════════════════════════════════════════
    private fun configurarDeteccao() {
        val etMinimoKm = findViewById<EditText>(R.id.etMinimoKm)
        etMinimoKm?.setText("%.2f".format(prefs.getFloat("minimo_km", 1.20f)))

        val etMinimoValor = findViewById<EditText>(R.id.etMinimoValor)
        etMinimoValor?.setText("%.2f".format(prefs.getFloat("minimo_valor", 0f)))

        val etTempo = findViewById<EditText>(R.id.etTempoAceitar)
        etTempo?.setText((prefs.getInt("tempo_auto_aceitar", 3) - 1).toString())
    }

    // ══════════════════════════════════════════════════════════════════════
    // AUTOMAÇÕES
    // ══════════════════════════════════════════════════════════════════════
    private fun configurarAutomacoes() {
        val switchAutoAceitar = findViewById<Switch>(R.id.switchAutoAceitar)
        switchAutoAceitar?.isChecked = prefs.getBoolean("auto_aceitar", false)

        val switchAutoRecusar = findViewById<Switch>(R.id.switchAutoRecusar)
        switchAutoRecusar?.isChecked = prefs.getBoolean("auto_recusar", false)
    }

    // ══════════════════════════════════════════════════════════════════════
    // SONS E ALERTAS
    // ══════════════════════════════════════════════════════════════════════
    private fun configurarSonsAlertas() {
        val switchSomAceitar = findViewById<Switch>(R.id.switchSomAceitar)
        switchSomAceitar?.isChecked = prefs.getBoolean("som_aceitar", true)

        val switchSomRecusar = findViewById<Switch>(R.id.switchSomRecusar)
        switchSomRecusar?.isChecked = prefs.getBoolean("som_recusar", false)

        val switchSomMeta = findViewById<Switch>(R.id.switchSomMeta)
        switchSomMeta?.isChecked = prefs.getBoolean("som_meta", true)
    }

    // ══════════════════════════════════════════════════════════════════════
    // METAS E PROGRESSO
    // ══════════════════════════════════════════════════════════════════════
    private fun configurarMetas() {
        val etMetaDiaria = findViewById<EditText>(R.id.etMetaDiaria)
        val meta = prefs.getFloat("meta_diaria", 0f)
        etMetaDiaria?.setText(if (meta > 0) "%.2f".format(meta) else "")

        val etMetaSemanal = findViewById<EditText>(R.id.etMetaSemanal)
        val metaSem = prefs.getFloat("meta_semanal", 0f)
        etMetaSemanal?.setText(if (metaSem > 0) "%.2f".format(metaSem) else "")

        val switchNotifMeta = findViewById<Switch>(R.id.switchNotifMeta)
        switchNotifMeta?.isChecked = prefs.getBoolean("notif_meta", true)

        atualizarProgressoMetas()
    }

    private fun atualizarProgressoMetas() {
        try {
            val corridas = db.buscarHoje()
            val resumo = db.resumo(corridas)
            val totalHoje = (resumo["total"] as? Number)?.toFloat() ?: 0f
            val metaDiaria = prefs.getFloat("meta_diaria", 0f)

            val tvProgressoHoje = findViewById<TextView>(R.id.tvProgressoHoje)
            tvProgressoHoje?.text = "Progresso hoje: R$ ${"%.2f".format(totalHoje)}"

            val progressBar = findViewById<ProgressBar>(R.id.progressMetaDia)
            if (metaDiaria > 0) {
                val percent = (totalHoje / metaDiaria * 100).toInt().coerceIn(0, 100)
                progressBar?.progress = percent
            }

            val tvProgressoSemana = findViewById<TextView>(R.id.tvProgressoSemana)
            tvProgressoSemana?.text = "Progresso esta semana: R$ 0,00"

            val progressSemana = findViewById<ProgressBar>(R.id.progressMetaSemana)
            progressSemana?.progress = 0
        } catch (e: Exception) {
            android.util.Log.e("Settings", "Erro ao atualizar progresso", e)
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    // BOTÃO SALVAR
    // ══════════════════════════════════════════════════════════════════════
    private fun configurarBotaoSalvar() {
        atualizarCorBotaoSalvar()
        findViewById<Button>(R.id.btnSalvarConfig)?.setOnClickListener {
            salvarConfigurações()
        }
    }

    private fun atualizarCorBotaoSalvar() {
        val btnSalvar = findViewById<Button>(R.id.btnSalvarConfig)
        val corTema = if (temaAtual == "azul") "#5A8ABB" else "#DAA520"
        val corInt = Color.parseColor(corTema)
        val dp = resources.displayMetrics.density

        btnSalvar?.setBackgroundDrawable(GradientDrawable().apply {
            setColor(corInt)
            cornerRadius = 8f * dp
        })
        btnSalvar?.setTextColor(Color.WHITE)
    }

    private fun atualizarCoresBotoesPorTema() {
        // Atualizar cores de todos os botões com o novo tema
        val btnDia = findViewById<Button>(R.id.btnModoDia)
        val btnNoite = findViewById<Button>(R.id.btnModoNoite)
        val btnAuto = findViewById<Button>(R.id.btnModoAuto)
        atualizarBotoesModoPorModo(modoAtual, btnDia, btnNoite, btnAuto)

        atualizarBotoesFonte(prefs.getString("tamanho_fonte", "medio") ?: "medio")
        atualizarCorBotaoSalvar()
    }

    private fun salvarConfigurações() {
        try {
            val etMinimoKm = findViewById<EditText>(R.id.etMinimoKm)
            val etMinimoValor = findViewById<EditText>(R.id.etMinimoValor)
            val etTempo = findViewById<EditText>(R.id.etTempoAceitar)
            val etMetaDiaria = findViewById<EditText>(R.id.etMetaDiaria)
            val etMetaSemanal = findViewById<EditText>(R.id.etMetaSemanal)
            val switchAutoAceitar = findViewById<Switch>(R.id.switchAutoAceitar)
            val switchAutoRecusar = findViewById<Switch>(R.id.switchAutoRecusar)
            val switchSomAceitar = findViewById<Switch>(R.id.switchSomAceitar)
            val switchSomRecusar = findViewById<Switch>(R.id.switchSomRecusar)
            val switchSomMeta = findViewById<Switch>(R.id.switchSomMeta)
            val switchNotifMeta = findViewById<Switch>(R.id.switchNotifMeta)

            val minKm = etMinimoKm?.text.toString().replace(",", ".").toFloatOrNull() ?: 1.20f
            val minValor = etMinimoValor?.text.toString().replace(",", ".").toFloatOrNull() ?: 0f
            val tempo = etTempo?.text.toString().toIntOrNull() ?: 2
            val metaDiaria = etMetaDiaria?.text.toString().replace(",", ".").toFloatOrNull() ?: 0f
            val metaSemanal = etMetaSemanal?.text.toString().replace(",", ".").toFloatOrNull() ?: 0f

            prefs.edit().apply {
                putFloat("minimo_km", minKm)
                putFloat("minimo_valor", minValor)
                putInt("tempo_auto_aceitar", tempo + 1)
                putBoolean("auto_aceitar", switchAutoAceitar?.isChecked ?: false)
                putBoolean("auto_recusar", switchAutoRecusar?.isChecked ?: false)
                putBoolean("som_aceitar", switchSomAceitar?.isChecked ?: true)
                putBoolean("som_recusar", switchSomRecusar?.isChecked ?: false)
                putBoolean("som_meta", switchSomMeta?.isChecked ?: true)
                putFloat("meta_diaria", metaDiaria)
                putFloat("meta_semanal", metaSemanal)
                putBoolean("notif_meta", switchNotifMeta?.isChecked ?: true)
            }.apply()

            Toast.makeText(this, "✅ Configurações salvas", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "❌ Erro ao salvar", Toast.LENGTH_SHORT).show()
            android.util.Log.e("Settings", "Erro ao salvar", e)
        }
    }

    private fun notificarTemaAtualizado() {
        try {
            sendBroadcast(Intent(FloatingEarningsService.ACTION_TEMA))
        } catch (_: Throwable) {}
        try {
            iniciarServicoSeguro(Intent(this, FloatingEarningsService::class.java).apply {
                action = FloatingEarningsService.ACTION_TEMA
            })
        } catch (_: Throwable) {}
    }

    private fun iniciarServicoSeguro(intent: Intent) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
        } catch (e: Exception) {
            android.util.Log.e("FluxoApp", "Erro ao iniciar serviço", e)
        }
    }
}
