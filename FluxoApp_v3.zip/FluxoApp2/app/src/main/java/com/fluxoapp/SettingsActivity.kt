package com.fluxoapp

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        prefs = getSharedPreferences("FluxoApp", MODE_PRIVATE)
        db = DatabaseHelper(this)
        configurar()
    }

    private fun configurar() {
        findViewById<ImageButton>(R.id.btnVoltar).setOnClickListener { finish() }

        // DETECÇÃO
        val etMinimo = findViewById<EditText>(R.id.etMinimoKm)
        etMinimo.setText("%.2f".format(prefs.getFloat("minimo_km", 1.20f)))

        val etMinimoValor = findViewById<EditText>(R.id.etMinimoValor)
        etMinimoValor.setText("%.2f".format(prefs.getFloat("minimo_valor", 0f)))

        val sbTempo = findViewById<SeekBar>(R.id.sbTempoAceitar)
        val tvTempo = findViewById<TextView>(R.id.tvTempoAceitar)
        sbTempo.max = 9; sbTempo.progress = prefs.getInt("tempo_auto_aceitar", 3) - 1
        tvTempo.text = "${sbTempo.progress + 1}s"
        sbTempo.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) { tvTempo.text = "${p + 1}s" }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        val switchAutoAceitar = findViewById<Switch>(R.id.switchAutoAceitar)
        switchAutoAceitar.isChecked = prefs.getBoolean("auto_aceitar", false)

        val switchAutoRecusar = findViewById<Switch>(R.id.switchAutoRecusar)
        switchAutoRecusar.isChecked = prefs.getBoolean("auto_recusar", false)

        // SONS
        val switchSomAceitar = findViewById<Switch>(R.id.switchSomAceitar)
        switchSomAceitar.isChecked = prefs.getBoolean("som_aceitar", true)

        val switchSomRecusar = findViewById<Switch>(R.id.switchSomRecusar)
        switchSomRecusar.isChecked = prefs.getBoolean("som_recusar", false)

        val switchSomMeta = findViewById<Switch>(R.id.switchSomMeta)
        switchSomMeta.isChecked = prefs.getBoolean("som_meta", true)

        // BOTÃO FLUTUANTE
        val switchFlutuante = findViewById<Switch>(R.id.switchFlutuante)
        switchFlutuante.isChecked = prefs.getBoolean("flutuante_ativo", true)
        switchFlutuante.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) startService(Intent(this, FloatingEarningsService::class.java))
            else stopService(Intent(this, FloatingEarningsService::class.java))
        }

        val rgPosicao = findViewById<RadioGroup>(R.id.rgPosicaoFlutuante)
        if (prefs.getString("flutuante_posicao", "esquerda") == "direita")
            rgPosicao.check(R.id.rbDireita) else rgPosicao.check(R.id.rbEsquerda)

        // METAS
        val etMetaDiaria = findViewById<EditText>(R.id.etMetaDiaria)
        val meta = prefs.getFloat("meta_diaria", 0f)
        etMetaDiaria.setText(if (meta > 0) "%.2f".format(meta) else "")

        val etMetaSemanal = findViewById<EditText>(R.id.etMetaSemanal)
        val metaSem = prefs.getFloat("meta_semanal", 0f)
        etMetaSemanal.setText(if (metaSem > 0) "%.2f".format(metaSem) else "")

        val switchNotifMeta = findViewById<Switch>(R.id.switchNotifMeta)
        switchNotifMeta.isChecked = prefs.getBoolean("notif_meta", true)

        // DADOS
        findViewById<Button>(R.id.btnLimparHoje).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Limpar hoje")
                .setMessage("Apagar todas as corridas de hoje?")
                .setPositiveButton("Sim") { _, _ -> db.limparHoje(); Toast.makeText(this, "✅ Corridas de hoje apagadas", Toast.LENGTH_SHORT).show() }
                .setNegativeButton("Não", null).show()
        }
        findViewById<Button>(R.id.btnLimparTudo).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Limpar tudo")
                .setMessage("Apagar TODO o histórico? Esta ação é irreversível!")
                .setPositiveButton("Sim, apagar tudo") { _, _ -> db.limparTudo(); Toast.makeText(this, "✅ Histórico apagado", Toast.LENGTH_SHORT).show() }
                .setNegativeButton("Cancelar", null).show()
        }
        findViewById<Button>(R.id.btnExportar).setOnClickListener { exportarCSV() }

        // SALVAR
        findViewById<Button>(R.id.btnSalvarConfig).setOnClickListener { salvar(
            etMinimo, etMinimoValor, sbTempo, switchAutoAceitar, switchAutoRecusar,
            switchSomAceitar, switchSomRecusar, switchSomMeta,
            switchFlutuante, rgPosicao, etMetaDiaria, etMetaSemanal, switchNotifMeta
        )}
    }

    private fun salvar(
        etMinimo: EditText, etMinimoValor: EditText, sbTempo: SeekBar,
        switchAutoAceitar: Switch, switchAutoRecusar: Switch,
        switchSomAceitar: Switch, switchSomRecusar: Switch, switchSomMeta: Switch,
        switchFlutuante: Switch, rgPosicao: RadioGroup,
        etMetaDiaria: EditText, etMetaSemanal: EditText, switchNotifMeta: Switch
    ) {
        val minKm = etMinimo.text.toString().replace(",", ".").toFloatOrNull() ?: 1.20f
        val minValor = etMinimoValor.text.toString().replace(",", ".").toFloatOrNull() ?: 0f
        val metaDiaria = etMetaDiaria.text.toString().replace(",", ".").toFloatOrNull() ?: 0f
        val metaSemanal = etMetaSemanal.text.toString().replace(",", ".").toFloatOrNull() ?: 0f
        val posicao = if (rgPosicao.checkedRadioButtonId == R.id.rbDireita) "direita" else "esquerda"

        prefs.edit()
            .putFloat("minimo_km", minKm)
            .putFloat("minimo_valor", minValor)
            .putInt("tempo_auto_aceitar", sbTempo.progress + 1)
            .putBoolean("auto_aceitar", switchAutoAceitar.isChecked)
            .putBoolean("auto_recusar", switchAutoRecusar.isChecked)
            .putBoolean("som_aceitar", switchSomAceitar.isChecked)
            .putBoolean("som_recusar", switchSomRecusar.isChecked)
            .putBoolean("som_meta", switchSomMeta.isChecked)
            .putBoolean("flutuante_ativo", switchFlutuante.isChecked)
            .putString("flutuante_posicao", posicao)
            .putFloat("meta_diaria", metaDiaria)
            .putFloat("meta_semanal", metaSemanal)
            .putBoolean("notif_meta", switchNotifMeta.isChecked)
            .apply()

        Toast.makeText(this, "✅ Configurações salvas!", Toast.LENGTH_SHORT).show()
        startService(Intent(this, FloatingEarningsService::class.java).apply { action = "ATUALIZAR" })
    }

    private fun exportarCSV() {
        val corridas = db.buscarTodas()
        if (corridas.isEmpty()) { Toast.makeText(this, "Nenhuma corrida para exportar", Toast.LENGTH_SHORT).show(); return }
        val sb = StringBuilder("Data,Hora,Valor,KM Total,Ganho/KM,Vale a Pena,Destino,Pagamento\n")
        corridas.forEach { c ->
            sb.append("${c.data},${c.hora},${c.valor},${c.kmTotal},${c.ganhoPorKm},${if (c.valeAPena) "Sim" else "Nao"},${c.destino},${c.formaPagamento}\n")
        }
        val file = java.io.File(getExternalFilesDir(null), "fluxoapp_historico.csv")
        file.writeText(sb.toString())
        Toast.makeText(this, "✅ Exportado: ${file.absolutePath}", Toast.LENGTH_LONG).show()
    }
}
