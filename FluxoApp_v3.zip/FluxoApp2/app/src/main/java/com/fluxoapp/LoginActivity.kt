package com.fluxoapp

import android.content.Context
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {

    private val auth by lazy { FirebaseAuth.getInstance() }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeSelector.aplicar(this)
        super.onCreate(savedInstanceState)

        // Se já está logado, ir direto para MainActivity
        if (auth.currentUser != null) {
            irParaMain()
            return
        }

        setContentView(R.layout.activity_login)
        aplicarTema()
        configurarBotoes()
    }

    private fun aplicarTema() {
        val prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val dp    = resources.displayMetrics.density

        val bgDark   = ThemeHelper.cor("bg_dark",   prefs)
        val bgCard   = ThemeHelper.cor("bg_card",   prefs)
        val accent   = ThemeHelper.cor("accent",    prefs)
        val txtW     = ThemeHelper.cor("text_white", prefs)
        val txtG     = ThemeHelper.cor("text_gray",  prefs)
        val border   = ThemeHelper.cor("border",     prefs)

        findViewById<View>(R.id.rootLogin).setBackgroundColor(bgDark)

        // Logo com cor accent
        findViewById<TextView>(R.id.tvLogoLogin).setTextColor(accent)

        // Labels
        listOf(R.id.tvLabelEmailLogin, R.id.tvLabelSenhaLogin).forEach {
            findViewById<TextView>(it).setTextColor(txtG)
        }

        // Campos de texto
        listOf(R.id.etEmailLogin, R.id.etSenhaLogin).forEach {
            val et = findViewById<EditText>(it)
            et.setTextColor(txtW)
            et.setHintTextColor(txtG)
        }

        // Esqueci senha
        findViewById<TextView>(R.id.tvEsqueciSenha).setTextColor(accent)

        // Botão entrar
        val btnEntrar = findViewById<Button>(R.id.btnEntrar)
        btnEntrar.backgroundTintList = null  // remove tint do Material que sobrescreve o background
        GradientDrawable().apply {
            setColor(accent)
            cornerRadius = 12 * dp
        }.also { btnEntrar.background = it }
        btnEntrar.setTextColor(bgDark)

        // Divisor
        findViewById<View>(R.id.viewDivisorLogin).setBackgroundColor(border)

        // Link cadastro
        findViewById<TextView>(R.id.tvIrParaCadastro).setTextColor(accent)
    }

    private fun configurarBotoes() {
        val etEmail = findViewById<EditText>(R.id.etEmailLogin)
        val etSenha = findViewById<EditText>(R.id.etSenhaLogin)
        val tvErro  = findViewById<TextView>(R.id.tvErroLogin)
        val btnEntrar = findViewById<Button>(R.id.btnEntrar)

        btnEntrar.setOnClickListener {
            val email = etEmail.text.toString().trim()
            val senha = etSenha.text.toString()

            tvErro.visibility = View.GONE

            if (email.isEmpty()) { mostrarErro(tvErro, "Informe o e-mail"); return@setOnClickListener }
            if (senha.isEmpty()) { mostrarErro(tvErro, "Informe a senha");  return@setOnClickListener }

            btnEntrar.isEnabled = false
            btnEntrar.text      = "Entrando..."
            esconderTeclado()

            auth.signInWithEmailAndPassword(email, senha)
                .addOnSuccessListener { result ->
                    val uid = result.user?.uid
                    if (uid != null) {
                        AppStartupManager.salvarDeviceInfo(uid)
                        val vc = try { packageManager.getPackageInfo(packageName, 0).versionCode } catch (_: Exception) { 0 }
                        AppStartupManager.verificarConfigApp(this, vc) { irParaMain() }
                    } else {
                        irParaMain()
                    }
                }
                .addOnFailureListener { e ->
                    btnEntrar.isEnabled = true
                    btnEntrar.text      = "ENTRAR"
                    mostrarErro(tvErro, traduzirErroFirebase(e.message))
                }
        }

        findViewById<TextView>(R.id.tvEsqueciSenha).setOnClickListener {
            val email = etEmail.text.toString().trim()
            if (email.isEmpty()) {
                mostrarErro(tvErro, "Informe o e-mail para recuperar a senha")
                return@setOnClickListener
            }
            auth.sendPasswordResetEmail(email)
                .addOnSuccessListener {
                    mostrarErro(tvErro, "E-mail de recuperação enviado!", erro = false)
                }
                .addOnFailureListener {
                    mostrarErro(tvErro, "Não foi possível enviar o e-mail de recuperação")
                }
        }

        findViewById<TextView>(R.id.tvIrParaCadastro).setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
    }

    private fun mostrarErro(tv: TextView, msg: String, erro: Boolean = true) {
        tv.text       = msg
        tv.setTextColor(if (erro) 0xFFFF4560.toInt() else 0xFF00E676.toInt())
        tv.visibility = View.VISIBLE
    }

    private fun irParaMain() {
        startActivity(Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        })
        finish()
    }

    private fun esconderTeclado() {
        currentFocus?.let {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .hideSoftInputFromWindow(it.windowToken, 0)
        }
    }

    private fun traduzirErroFirebase(msg: String?): String = when {
        msg == null                          -> "Erro desconhecido. Tente novamente."
        msg.contains("no user record")       -> "E-mail não cadastrado."
        msg.contains("password is invalid")  -> "Senha incorreta."
        msg.contains("badly formatted")      -> "E-mail inválido."
        msg.contains("blocked")              -> "Muitas tentativas. Tente mais tarde."
        msg.contains("network")              -> "Sem conexão com a internet."
        else                                 -> "E-mail ou senha incorretos."
    }
}
