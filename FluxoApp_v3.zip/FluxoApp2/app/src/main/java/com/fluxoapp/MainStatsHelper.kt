package com.fluxoapp

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.ProgressBar
import android.widget.TextView

/**
 * MainStatsHelper — FluxoApp
 *
 * Responsável por estatísticas, notificações, dicas, celebração e widget:
 *   - Atualizar stats da tela principal (ganhos, corridas, km, média)
 *   - Dica motivacional do dia
 *   - Verificação e celebração de meta diária
 *   - Atualização do widget
 *   - Notificações locais do Firebase
 */

internal fun MainActivity.atualizarStats() {
    val corridas = try { db.buscarHoje() } catch (_: Throwable) { emptyList() }
    val resumo   = try { db.resumo(corridas) } catch (_: Throwable) { mapOf() }
    val total    = resumo["total"]         ?: 0f
    // km das corridas + km rastreado pelo GPS hoje
    val kmCorridas  = resumo["km_total"] ?: 0f
    val kmGps       = KmTrackerService.kmHoje(this)
    val km          = if (kmGps > kmCorridas) kmGps else kmCorridas
    val media    = resumo["media_corrida"] ?: 0f
    val qtd      = (resumo["corridas"]     ?: 0f).toInt()
    val meta     = prefs.getFloat("meta_diaria", 0f)
    val accent   = ThemeHelper.cor("accent_gold", prefs)
    val gold     = ThemeHelper.cor("accent_gold", prefs)

    try { findViewById<TextView>(R.id.tvGanhoHoje)?.text   = "%.2f".format(total).replace(".", ",") } catch (_: Throwable) {}
    try { findViewById<TextView>(R.id.tvStatCorridas)?.text = "$qtd"                                 } catch (_: Throwable) {}
    try { findViewById<TextView>(R.id.tvStatKm)?.text       = "%.1f km".format(km).replace(".", ",") } catch (_: Throwable) {}
    try { findViewById<TextView>(R.id.tvStatMedia)?.text    = "R$ %.2f".format(media).replace(".", ",") } catch (_: Throwable) {}

    val cardMeta = try { findViewById<androidx.cardview.widget.CardView>(R.id.cardMeta) } catch (_: Throwable) { null }
    if (meta > 0f) {
        val pct = ((total / meta) * 100).toInt().coerceIn(0, 100)
        cardMeta?.visibility = View.VISIBLE
        try { findViewById<TextView>(R.id.tvMetaInfo)?.text    = "META DIÁRIA · R$ %.0f".format(meta) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvMetaPercent)?.text = "$pct%"                               } catch (_: Throwable) {}
        try {
            val pb = findViewById<ProgressBar>(R.id.progressMetaDia)
            pb?.progress = pct
            val corMeta = when {
                pct >= 100 -> Color.parseColor("#FFD740")
                pct >= 75  -> ThemeHelper.cor("accent_green", prefs)
                else       -> accent
            }
            pb?.progressTintList = android.content.res.ColorStateList.valueOf(corMeta)
        } catch (_: Throwable) {}
        if (total >= meta) verificarCelebracao(total, meta)
    } else {
        cardMeta?.visibility = View.GONE
    }

    exibirDica()
    atualizarWidget()
    atualizarBotaoServico()
    atualizarBannerLicenca()
}

internal fun MainActivity.exibirDica() {
    try {
        val corridas = db.buscarHoje()
        val qtd  = corridas.size
        val day  = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR)
        val dica = when {
            qtd == 0 -> DICAS[day % DICAS.size]
            qtd < 3  -> "Você já fez $qtd corrida${if (qtd > 1) "s" else ""} hoje. Continue assim!"
            qtd < 10 -> "Você já fez $qtd corridas hoje. Ótimo ritmo!"
            else     -> "Dia incrível! $qtd corridas completas!"
        }
        findViewById<TextView>(R.id.tvDica)?.text = dica
    } catch (_: Throwable) {}
}

internal fun MainActivity.verificarCelebracao(total: Float, meta: Float) {
    if (meta <= 0 || total < meta) return
    val hoje = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(java.util.Date())
    if (prefs.getString("ultima_celebracao", "") == hoje) return
    prefs.edit().putString("ultima_celebracao", hoje).apply()
    celebrarMeta()
}

internal fun MainActivity.celebrarMeta() {
    try {
        val gold = ThemeHelper.cor("accent_gold", prefs)
        val root = window.decorView.rootView
        repeat(8) { i ->
            handler.postDelayed({
                try { root.setBackgroundColor(if (i % 2 == 0) gold else Color.TRANSPARENT) } catch (_: Throwable) {}
            }, i * 180L)
        }
        handler.postDelayed({ try { root.setBackgroundColor(Color.TRANSPARENT) } catch (_: Throwable) {} }, 1500L)
        val tv = try { findViewById<TextView>(R.id.tvGanhoHoje) } catch (_: Throwable) { null }
        tv?.let {
            AnimatorSet().apply {
                playTogether(
                    ObjectAnimator.ofFloat(it, "scaleX", 1f, 1.4f, 1.1f),
                    ObjectAnimator.ofFloat(it, "scaleY", 1f, 1.4f, 1.1f)
                )
                duration = 600; interpolator = AccelerateDecelerateInterpolator(); start()
            }
        }
        try { (getSystemService(android.content.Context.VIBRATOR_SERVICE) as android.os.Vibrator).vibrate(longArrayOf(0, 150, 80, 150, 80, 500), -1) } catch (_: Throwable) {}
        handler.postDelayed({ FluxoToast.celebrar(this, "🏆 META BATIDA! PARABÉNS!") }, 600L)
        atualizarWidget()
    } catch (_: Throwable) {}
}

internal fun MainActivity.atualizarWidget() {
    try {
        val mgr = AppWidgetManager.getInstance(this)
        mgr.getAppWidgetIds(ComponentName(this, FluxoWidgetProvider::class.java))
            .forEach { FluxoWidgetProvider.updateWidget(this, mgr, it) }
    } catch (_: Throwable) {}
}

internal fun MainActivity.verificarNotificacoes() {
    val uid = try { LicenseManager.uid() } catch (_: Throwable) { return } ?: return
    val plano = prefs.getString("plano_atual", "trial") ?: "trial"
    val ultimaId = prefs.getString("ultima_notif_id", "")
    com.google.firebase.firestore.FirebaseFirestore.getInstance()
        .collection("notificacoes")
        .orderBy("criadoEm", com.google.firebase.firestore.Query.Direction.DESCENDING)
        .limit(5).get()
        .addOnSuccessListener { docs ->
            for (doc in docs) {
                val id = doc.id
                if (id == ultimaId) break
                val dest = doc.getString("destinatarios") ?: continue
                val devo = when (dest) {
                    "todos"  -> true
                    "trial"  -> plano == "trial"
                    "ativos" -> plano != "trial" && plano != "bloqueado"
                    else     -> false
                }
                if (devo) {
                    val titulo = doc.getString("titulo") ?: continue
                    val msg    = doc.getString("mensagem") ?: continue
                    mostrarNotificacaoLocal(titulo, msg)
                    prefs.edit().putString("ultima_notif_id", id).apply()
                    break
                }
            }
        }
}

internal fun MainActivity.mostrarNotificacaoLocal(titulo: String, msg: String) {
    try {
        val channelId = "fluxoapp_notif"
        val nm = getSystemService(android.content.Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            val ch = android.app.NotificationChannel(channelId, "FluxoApp", android.app.NotificationManager.IMPORTANCE_DEFAULT)
            nm.createNotificationChannel(ch)
        }
        val notif = androidx.core.app.NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(titulo).setContentText(msg).setAutoCancel(true).build()
        nm.notify(System.currentTimeMillis().toInt(), notif)
    } catch (_: Throwable) {}
}
