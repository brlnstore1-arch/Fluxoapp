package com.fluxoapp

import android.app.Application
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FluxoApp : Application() {

    override fun onCreate() {
        super.onCreate()
        instalarCrashHandler(this)
    }
}

fun instalarCrashHandler(context: Context) {
    val handlerPadrao = Thread.getDefaultUncaughtExceptionHandler()

    Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
        try {
            // Montar mensagem de erro resumida
            val causa = throwable.cause ?: throwable
            val mensagem = buildString {
                append("CRASH: ${causa.javaClass.simpleName}\n")
                append(causa.message?.take(120) ?: "sem mensagem")
                append("\n---\n")
                // Primeiras 3 linhas do stack relevantes ao fluxoapp
                causa.stackTrace
                    .filter { it.className.contains("fluxoapp", ignoreCase = true) }
                    .take(3)
                    .forEach { append("${it.className.substringAfterLast('.')}.${it.methodName}:${it.lineNumber}\n") }
                // Se não tiver linha do fluxoapp, pegar as 3 primeiras gerais
                if (causa.stackTrace.none { it.className.contains("fluxoapp", ignoreCase = true) }) {
                    causa.stackTrace.take(3).forEach {
                        append("${it.className.substringAfterLast('.')}.${it.methodName}:${it.lineNumber}\n")
                    }
                }
            }

            // Salvar log completo em arquivo
            salvarLogCompleto(context, throwable)

            // Mostrar Toast na thread principal
            Handler(Looper.getMainLooper()).post {
                try {
                    Toast.makeText(context, mensagem, Toast.LENGTH_LONG).show()
                } catch (_: Exception) {}
            }

            // Aguardar o Toast aparecer antes de encerrar
            Thread.sleep(4000)

        } catch (_: Exception) {}

        // Chamar handler original (mata o app normalmente)
        handlerPadrao?.uncaughtException(thread, throwable)
    }
}

fun salvarLogCompleto(context: Context, throwable: Throwable) {
    try {
        val sdf = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.getDefault())
        val timestamp = sdf.format(Date())
        val arquivo = File(context.getExternalFilesDir(null), "crash_$timestamp.txt")

        FileWriter(arquivo).use { writer ->
            writer.write("=== FluxoApp Crash Log ===\n")
            writer.write("Horario: $timestamp\n")
            writer.write("Android: ${android.os.Build.VERSION.SDK_INT} (${android.os.Build.VERSION.RELEASE})\n")
            writer.write("Dispositivo: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}\n\n")
            writer.write("=== EXCEPTION ===\n")
            writer.write(throwable.toString() + "\n\n")
            writer.write("=== STACK TRACE ===\n")
            throwable.stackTrace.forEach { writer.write("  at $it\n") }
            throwable.cause?.let { causa ->
                writer.write("\n=== CAUSED BY ===\n")
                writer.write(causa.toString() + "\n")
                causa.stackTrace.forEach { writer.write("  at $it\n") }
            }
        }

        // Mostrar caminho do arquivo em Toast separado
        Handler(Looper.getMainLooper()).postDelayed({
            try {
                Toast.makeText(context, "Log salvo em:\n${arquivo.absolutePath}", Toast.LENGTH_LONG).show()
            } catch (_: Exception) {}
        }, 4500)

    } catch (_: Exception) {}
}
