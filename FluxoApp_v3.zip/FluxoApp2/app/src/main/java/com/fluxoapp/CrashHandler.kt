package com.fluxoapp

import android.app.Application
import android.content.Context
import android.os.Handler
import android.os.Looper

class FluxoApp : Application() {
    override fun onCreate() {
        super.onCreate()

        val handlerPadrao = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val causa = throwable.cause ?: throwable
                val msg = buildString {
                    append("${causa.javaClass.simpleName}: ${causa.message?.take(100)}\n")
                    causa.stackTrace
                        .filter { it.className.contains("fluxoapp", ignoreCase = true) }
                        .take(3)
                        .forEach { append("${it.className.substringAfterLast('.')}.${it.methodName}:${it.lineNumber}\n") }
                }
                // Salvar com commit() síncrono — funciona mesmo com MIUI matando o processo
                getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
                    .edit()
                    .putString("ultimo_crash", msg)
                    .commit()
            } catch (_: Throwable) {}
            handlerPadrao?.uncaughtException(thread, throwable)
        }
    }
}
