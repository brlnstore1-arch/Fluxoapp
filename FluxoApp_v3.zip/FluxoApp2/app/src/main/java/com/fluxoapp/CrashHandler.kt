package com.fluxoapp

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast

class FluxoApp : Application() {
    override fun onCreate() {
        super.onCreate()
        instalarCrashHandler(this)
    }
}

fun instalarCrashHandler(context: Context) {
    val handlerPadrao = Thread.getDefaultUncaughtExceptionHandler()

    Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
        try {
            // Montar mensagem curta do crash
            val causa = throwable.cause ?: throwable
            val stackFluxo = causa.stackTrace
                .filter { it.className.contains("fluxoapp", ignoreCase = true) }
                .take(2)
                .joinToString("\n") { "${it.className.substringAfterLast('.')}.${it.methodName}:${it.lineNumber}" }

            val stackGeral = causa.stackTrace.take(2)
                .joinToString("\n") { "${it.className.substringAfterLast('.')}.${it.methodName}:${it.lineNumber}" }

            val msg = buildString {
                append("ERRO: ${causa.javaClass.simpleName}\n")
                append((causa.message ?: throwable.message ?: "sem mensagem").take(100))
                append("\n")
                append(if (stackFluxo.isNotBlank()) stackFluxo else stackGeral)
            }

            // SALVAR em SharedPreferences com commit() SÍNCRONO
            // (funciona mesmo que o MIUI mate o processo logo depois)
            try {
                context.getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
                    .edit()
                    .putString("ultimo_crash", msg)
                    .putString("ultimo_crash_completo", buildString {
                        append("Android ${Build.VERSION.SDK_INT} | ${Build.MANUFACTURER} ${Build.MODEL}\n\n")
                        append(throwable.toString()).append("\n")
                        throwable.stackTrace.take(20).forEach { append("  at $it\n") }
                        throwable.cause?.let { c ->
                            append("\nCaused by: $c\n")
                            c.stackTrace.take(10).forEach { append("  at $it\n") }
                        }
                    })
                    .commit() // COMMIT síncrono — garante que salva antes do processo morrer
            } catch (_: Exception) {}

            // Tentar mostrar Toast (pode não funcionar no MIUI mas tenta)
            try {
                Handler(Looper.getMainLooper()).post {
                    try { Toast.makeText(context, "CRASH SALVO!\n$msg", Toast.LENGTH_LONG).show() }
                    catch (_: Exception) {}
                }
                Thread.sleep(3000)
            } catch (_: Exception) {}

        } catch (_: Throwable) {}

        handlerPadrao?.uncaughtException(thread, throwable)
    }
}

/** Chame no onCreate() de qualquer Activity para exibir crash da sessão anterior */
fun verificarCrashAnterior(context: Context) {
    try {
        val prefs = context.getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val crash = prefs.getString("ultimo_crash", null) ?: return

        // Limpar imediatamente para não mostrar de novo
        prefs.edit().remove("ultimo_crash").commit()

        // Mostrar após 1s (dar tempo do app inicializar)
        Handler(Looper.getMainLooper()).postDelayed({
            try {
                android.app.AlertDialog.Builder(context as android.app.Activity)
                    .setTitle("⚠️ Crash detectado na sessão anterior")
                    .setMessage(crash)
                    .setPositiveButton("OK", null)
                    .setNeutralButton("Ver log completo") { _, _ ->
                        val completo = prefs.getString("ultimo_crash_completo", crash) ?: crash
                        android.app.AlertDialog.Builder(context)
                            .setTitle("Log completo")
                            .setMessage(completo)
                            .setPositiveButton("OK", null)
                            .show()
                    }
                    .show()
            } catch (_: Exception) {}
        }, 1500)

    } catch (_: Exception) {}
}

/** Detecta MIUI e guia o usuário a liberar o Autostart */
fun verificarPermissoesMIUI(context: Context) {
    try {
        val isMIUI = Build.MANUFACTURER.equals("Xiaomi", ignoreCase = true) ||
                     !context.packageManager.getInstalledPackages(0)
                         .none { it.packageName == "com.miui.securitycenter" }

        if (!isMIUI) return

        val prefs = context.getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        // Mostrar apenas uma vez por sessão
        if (prefs.getBoolean("miui_aviso_mostrado", false)) return
        prefs.edit().putBoolean("miui_aviso_mostrado", true).apply()

        Handler(Looper.getMainLooper()).postDelayed({
            try {
                android.app.AlertDialog.Builder(context as android.app.Activity)
                    .setTitle("📱 Dispositivo Xiaomi detectado")
                    .setMessage(
                        "O MIUI bloqueia serviços em background por padrão.\n\n" +
                        "Para o FluxoApp funcionar corretamente:\n\n" +
                        "1. Vá em Configurações > Apps > FluxoApp\n" +
                        "2. Toque em Bateria\n" +
                        "3. Selecione 'Sem restrições'\n\n" +
                        "4. Vá em Configurações > Permissões\n" +
                        "5. Ative 'Inicialização automática'\n\n" +
                        "Sem isso o app pode fechar sozinho."
                    )
                    .setPositiveButton("Abrir Configurações") { _, _ ->
                        try {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = Uri.parse("package:${context.packageName}")
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        } catch (_: Exception) {}
                    }
                    .setNegativeButton("Agora não", null)
                    .show()
            } catch (_: Exception) {}
        }, 2000)

    } catch (_: Exception) {}
}
