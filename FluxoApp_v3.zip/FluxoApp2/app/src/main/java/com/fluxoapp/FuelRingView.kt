package com.fluxoapp

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

/**
 * FuelRingView — desenha um anel de progresso ao redor do botão flutuante
 * representando o combustível restante (0–100%).
 *
 * O anel começa completo (100%, todo verde) e vai "encolhendo" no sentido
 * horário conforme o combustível é consumido, mudando de cor:
 *   > 50%  → verde
 *   20–50% → amarelo
 *   < 20%  → vermelho
 */
class FuelRingView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var percentual = 100f  // 0..100
    private val strokeWidthPx = 6f * resources.displayMetrics.density

    private val paintFundo = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = strokeWidthPx
        color = Color.parseColor("#33FFFFFF")
        strokeCap = Paint.Cap.ROUND
    }

    private val paintProgresso = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = strokeWidthPx
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#4CAF50")
    }

    private val rect = RectF()

    /** Atualiza o percentual exibido (0–100) e redesenha. */
    fun setPercentual(pct: Float) {
        percentual = pct.coerceIn(0f, 100f)
        paintProgresso.color = when {
            percentual > 50f -> Color.parseColor("#4CAF50") // verde
            percentual > 20f -> Color.parseColor("#FFD740") // amarelo
            else             -> Color.parseColor("#FF5252") // vermelho
        }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val pad = strokeWidthPx / 2f + 2f
        rect.set(pad, pad, width - pad, height - pad)

        // Anel de fundo (trilho completo, sempre visível)
        canvas.drawOval(rect, paintFundo)

        // Arco de progresso — começa no topo (-90°) e vai encolhendo
        // no sentido horário conforme o combustível diminui.
        val sweep = 360f * (percentual / 100f)
        canvas.drawArc(rect, -90f, sweep, false, paintProgresso)
    }
}
