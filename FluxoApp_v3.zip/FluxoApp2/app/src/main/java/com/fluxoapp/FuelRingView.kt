package com.fluxoapp

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.util.AttributeSet
import android.view.View

/**
 * FuelRingView — FluxoApp
 *
 * Indicador de combustível embutido na PRÓPRIA BORDA do botão flutuante.
 * Não é mais um círculo/anel externo — o caminho desenhado é um retângulo
 * arredondado com o MESMO tamanho e MESMO raio de canto do fundo do botão
 * (floating_earnings_bg / floating_earnings_gold, corner radius 18dp), de
 * modo que o traço fique exatamente sobre a borda real do botão.
 *
 * Este view deve ter EXATAMENTE o mesmo layout_width/layout_height do
 * container do botão (floatingRoot) no XML, sobreposto no mesmo lugar.
 *
 * O anel começa completo (100%, verde) e vai "encolhendo" no sentido
 * horário conforme o combustível é consumido, mudando de cor:
 *   > 50%  → verde
 *   20–50% → amarelo
 *   < 20%  → vermelho
 */
class FuelRingView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var percentual = 100f  // 0..100
    private val density = resources.displayMetrics.density

    // Traço fino, para parecer parte da borda do botão — não um anel grosso
    private val strokeWidthPx = 3f * density
    // Mesmo raio de canto usado em floating_earnings_bg.xml / floating_earnings_gold.xml
    private val cornerRadiusPx = 18f * density

    private val paintFundo = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = strokeWidthPx
        color = Color.parseColor("#40FFFFFF")
    }

    private val paintProgresso = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = strokeWidthPx
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#4CAF50")
    }

    private val pathContorno  = Path()
    private val pathProgresso = Path()
    private val pathMeasure   = PathMeasure()

    /** Atualiza o percentual exibido (0–100) e redesenha. */
    fun setPercentual(pct: Float) {
        percentual = pct.coerceIn(0f, 100f)
        paintProgresso.color = when {
            percentual > 50f -> Color.parseColor("#4CAF50") // verde
            percentual > 20f -> Color.parseColor("#FFD740") // amarelo
            else             -> Color.parseColor("#FF5252") // vermelho
        }
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val pad = strokeWidthPx / 2f
        pathContorno.reset()
        // Mesmo retângulo arredondado do fundo do botão — o traço fica
        // exatamente sobre a borda real, não um círculo separado por fora.
        pathContorno.addRoundRect(
            pad, pad, w - pad, h - pad,
            cornerRadiusPx, cornerRadiusPx,
            Path.Direction.CW
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width == 0 || height == 0) return

        // Trilho de fundo (contorno completo, sempre visível, bem sutil)
        canvas.drawPath(pathContorno, paintFundo)

        // Arco de progresso ao longo do MESMO contorno do botão
        pathMeasure.setPath(pathContorno, false)
        val total = pathMeasure.length
        if (total <= 0f) return
        val segmento = total * (percentual / 100f)

        pathProgresso.reset()
        pathMeasure.getSegment(0f, segmento, pathProgresso, true)
        canvas.drawPath(pathProgresso, paintProgresso)
    }
}
