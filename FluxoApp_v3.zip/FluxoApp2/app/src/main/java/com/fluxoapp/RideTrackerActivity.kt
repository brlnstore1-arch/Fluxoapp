package com.fluxoapp

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

/**
 * RideTrackerActivity — FluxoApp
 *
 * Adicionar nova corrida com dois modos:
 *
 * MANUAL — preenche valor, km, origem, destino, pagamento manualmente
 *
 * AUTO (GPS) — toca Iniciar:
 *   1. Captura endereço atual via GPS + Nominatim
 *   2. Rastreia distância em tempo real enquanto roda
 *   3. Toca Finalizar:
 *      - OSRM calcula distância real da rota
 *      - Nominatim captura endereço de destino
 *      - Mostra resumo + campo de valor para preencher
 *      - Salva corrida completa
 */
class RideTrackerActivity : AppCompatActivity(), LocationListener {

    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var db: DatabaseHelper

    private val executor = Executors.newSingleThreadExecutor()
    private val handler  = Handler(Looper.getMainLooper())

    // Estado do rastreamento
    private var rastreando = false
    private var locOrigem: Location? = null
    private var locDestino: Location? = null
    private var locAtual: Location? = null
    private var horaInicio = ""
    private var horaFim    = ""
    private var enderecoOrigem  = ""
    private var enderecoDestino = ""
    private var distanciaRastreada = 0f
    private var locAnterior: Location? = null

    private var locationManager: LocationManager? = null

    companion object {
        private const val REQ_LOCATION = 101
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeSelector.aplicar(this)
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        db    = DatabaseHelper(this)
        construirTela()
    }

    // ═══════════════════════════════════════════════════════
    // TELA PRINCIPAL — escolha de modo
    // ═══════════════════════════════════════════════════════

    private fun construirTela() {
        val p      = prefs
        val bgDark = ThemeHelper.cor("bg_dark",     p)
        val bgCard = ThemeHelper.cor("bg_card",     p)
        val accent = ThemeHelper.cor("accent",      p)
        val txtW   = ThemeHelper.cor("text_white",  p)
        val txtG   = ThemeHelper.cor("text_gray",   p)
        val red    = ThemeHelper.cor("accent_red",  p)
        val green  = ThemeHelper.cor("accent_green",p)
        val dp     = resources.displayMetrics.density

        val scroll = ScrollView(this).apply { setBackgroundColor(bgDark) }
        val root   = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((16*dp).toInt(), 0, (16*dp).toInt(), (32*dp).toInt())
        }

        // Toolbar
        root.addView(buildToolbar(bgCard, accent, txtW, dp))

        // Modo AUTO
        root.addView(buildSectionLabel("🚀  MODO AUTOMÁTICO", accent, dp))
        root.addView(buildAutoCard(bgCard, accent, txtW, txtG, green, red, dp))

        spacer(dp, 16f).let { root.addView(it) }

        // Divisor
        root.addView(buildDividerLabel("── ou adicionar manualmente ──", txtG, dp))

        spacer(dp, 8f).let { root.addView(it) }

        // Modo MANUAL
        root.addView(buildSectionLabel("✏️  MANUAL", accent, dp))
        root.addView(buildManualCard(bgCard, accent, txtW, txtG, red, dp))

        scroll.addView(root)
        setContentView(scroll)
    }

    // ── TOOLBAR ──────────────────────────────────────────────

    private fun buildToolbar(bgCard: Int, accent: Int, txtW: Int, dp: Float): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity     = android.view.Gravity.CENTER_VERTICAL
            setBackgroundColor(bgCard)
            setPadding((8*dp).toInt(), 0, (16*dp).toInt(), 0)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (56*dp).toInt()
            )
            addView(ImageButton(this@RideTrackerActivity).apply {
                setImageResource(android.R.drawable.ic_media_previous)
                setColorFilter(accent)
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                layoutParams = LinearLayout.LayoutParams((44*dp).toInt(), (44*dp).toInt())
                setOnClickListener { finish() }
            })
            addView(TextView(this@RideTrackerActivity).apply {
                text = "Nova corrida"
                textSize = 17f; setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(accent)
                setPadding((6*dp).toInt(), 0, 0, 0)
            })
        }
    }

    // ── AUTO CARD ─────────────────────────────────────────────

    private fun buildAutoCard(
        bgCard: Int, accent: Int, txtW: Int, txtG: Int,
        green: Int, red: Int, dp: Float
    ): LinearLayout {
        val card = card(bgCard, accent, dp)

        // Status
        val tvStatus = TextView(this).apply {
            text = "Toque em INICIAR para capturar sua localização atual e começar a rastrear a corrida automaticamente."
            textSize = 13f; setTextColor(txtG); setLineSpacing(0f, 1.5f)
            setPadding(0, 0, 0, (16*dp).toInt())
        }
        card.addView(tvStatus)

        // Info origem (oculto antes de iniciar)
        val tvOrigem = TextView(this).apply {
            visibility = View.GONE; textSize = 12f; setTextColor(txtG)
        }
        card.addView(tvOrigem)

        // Distância em tempo real
        val tvDist = TextView(this).apply {
            visibility = View.GONE
            text = "📍 0.0 km"
            textSize = 22f; setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(accent)
            gravity = android.view.Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (12*dp).toInt() }
        }
        card.addView(tvDist)

        // Tempo decorrido
        val tvTempo = TextView(this).apply {
            visibility = View.GONE; text = "⏱ 00:00"
            textSize = 14f; setTextColor(txtG)
            gravity = android.view.Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (16*dp).toInt() }
        }
        card.addView(tvTempo)

        // Botão iniciar/finalizar
        val btnIniciar = buildBtn("▶  INICIAR CORRIDA", green, dp)
        card.addView(btnIniciar)

        // Timer de UI
        var timerRunnable: Runnable? = null
        var tsInicio = 0L

        btnIniciar.setOnClickListener {
            if (!rastreando) {
                // Iniciar
                if (!temPermissaoLocalizacao()) {
                    pedirPermissaoLocalizacao(); return@setOnClickListener
                }
                rastreando = true
                tsInicio = System.currentTimeMillis()
                distanciaRastreada = 0f
                locAnterior = null
                horaInicio = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

                tvStatus.text = "Capturando localização de origem..."
                tvDist.visibility  = View.VISIBLE
                tvTempo.visibility = View.VISIBLE
                btnIniciar.text    = "⬛  FINALIZAR CORRIDA"
                (btnIniciar.background as? android.graphics.drawable.GradientDrawable)?.setColor(red)

                iniciarGPS()

                // Capturar endereço de origem em background
                executor.execute {
                    val loc = locAtual
                    if (loc != null) {
                        val end = LocationHelper.geocodificarInverso(loc.latitude, loc.longitude)
                        locOrigem = loc
                        enderecoOrigem = end?.resumo ?: "%.4f, %.4f".format(loc.latitude, loc.longitude)
                        handler.post {
                            tvOrigem.text = "📌 Origem: $enderecoOrigem"
                            tvOrigem.visibility = View.VISIBLE
                            tvStatus.text = "Rastreando... mova-se para acumular km."
                        }
                    } else {
                        handler.post { tvStatus.text = "Aguardando sinal de GPS..." }
                    }
                }

                // Timer de UI
                timerRunnable = object : Runnable {
                    override fun run() {
                        if (!rastreando) return
                        val seg = (System.currentTimeMillis() - tsInicio) / 1000
                        val min = seg / 60; val s = seg % 60
                        tvTempo.text = "⏱ %02d:%02d".format(min, s)
                        tvDist.text  = "📍 ${"%.2f".format(distanciaRastreada)} km"
                        handler.postDelayed(this, 1_000)
                    }
                }.also { handler.post(it) }

            } else {
                // Finalizar
                rastreando = false
                timerRunnable?.let { handler.removeCallbacks(it) }
                pararGPS()
                horaFim = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                val duracaoS = (System.currentTimeMillis() - tsInicio) / 1000

                btnIniciar.isEnabled = false
                btnIniciar.text = "Calculando rota..."
                tvStatus.text = "Buscando endereço de destino e calculando distância..."

                val locFim = locAtual
                executor.execute {
                    val endDest = if (locFim != null) {
                        LocationHelper.geocodificarInverso(locFim.latitude, locFim.longitude)
                    } else null

                    locDestino = locFim
                    enderecoDestino = endDest?.resumo
                        ?: locFim?.let { "%.4f, %.4f".format(it.latitude, it.longitude) }
                        ?: ""

                    // Tentar distância via OSRM se tiver origem e destino
                    val distFinal: Float
                    val duracaoMin: Int
                    val lo = locOrigem; val ld = locFim
                    if (lo != null && ld != null) {
                        val rota = LocationHelper.calcularRota(lo.latitude, lo.longitude, ld.latitude, ld.longitude)
                        distFinal   = if (rota.sucesso && rota.distanciaKm > 0.1f) rota.distanciaKm else distanciaRastreada
                        duracaoMin  = if (rota.sucesso && rota.duracaoMin > 0) rota.duracaoMin else (duracaoS / 60).toInt()
                    } else {
                        distFinal  = distanciaRastreada
                        duracaoMin = (duracaoS / 60).toInt()
                    }

                    handler.post {
                        mostrarResumoAuto(
                            distanciaKm   = distFinal,
                            duracaoMin    = duracaoMin,
                            horaInicio    = horaInicio,
                            horaFim       = horaFim
                        )
                    }
                }
            }
        }

        return card
    }

    // ── RESUMO AUTO — preencher valor e salvar ────────────────

    private fun mostrarResumoAuto(
        distanciaKm: Float, duracaoMin: Int,
        horaInicio: String, horaFim: String
    ) {
        val p      = prefs
        val bgDark = ThemeHelper.cor("bg_dark",     p)
        val bgCard = ThemeHelper.cor("bg_card",     p)
        val accent = ThemeHelper.cor("accent",      p)
        val txtW   = ThemeHelper.cor("text_white",  p)
        val txtG   = ThemeHelper.cor("text_gray",   p)
        val green  = ThemeHelper.cor("accent_green",p)
        val red    = ThemeHelper.cor("accent_red",  p)
        val dp     = resources.displayMetrics.density

        val scroll = ScrollView(this).apply { setBackgroundColor(bgDark) }
        val root   = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((16*dp).toInt(), 0, (16*dp).toInt(), (48*dp).toInt())
        }

        // Toolbar
        root.addView(buildToolbar(bgCard, accent, txtW, dp))

        // Resumo da corrida
        root.addView(buildSectionLabel("✅  Corrida finalizada", green, dp))

        val cardResumo = card(bgCard, green, dp)

        fun addInfo(icone: String, label: String, valor: String) {
            cardResumo.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(0, (6*dp).toInt(), 0, (6*dp).toInt())
                addView(TextView(this@RideTrackerActivity).apply {
                    text = icone; textSize = 16f
                    setPadding(0, 0, (10*dp).toInt(), 0)
                })
                addView(TextView(this@RideTrackerActivity).apply {
                    text = label; textSize = 12f; setTextColor(txtG)
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                })
                addView(TextView(this@RideTrackerActivity).apply {
                    text = valor; textSize = 13f; setTextColor(txtW)
                    setTypeface(null, android.graphics.Typeface.BOLD)
                })
            })
        }

        addInfo("📍", "Distância percorrida", "${"%.2f".format(distanciaKm)} km")
        addInfo("⏱", "Duração estimada", if (duracaoMin > 0) "$duracaoMin min" else "$horaInicio → $horaFim")
        addInfo("📌", "Origem", enderecoOrigem.take(45))
        addInfo("🏁", "Destino", enderecoDestino.take(45))
        addInfo("🕐", "Horário", "$horaInicio → $horaFim")

        root.addView(cardResumo)
        spacer(dp, 12f).let { root.addView(it) }

        // Campos para completar
        root.addView(buildSectionLabel("💰  Complete os dados", accent, dp))
        val cardForm = card(bgCard, accent, dp)

        // Valor recebido
        val etValor = buildInput("Valor recebido (R$)", android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL, dp)
        cardForm.addView(labelSmall("Valor recebido *", txtG, dp))
        cardForm.addView(etValor)

        // Forma de pagamento
        val spinnerPag = Spinner(this)
        val formas = listOf("Dinheiro", "PIX", "Cartão", "Online")
        spinnerPag.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, formas)
        spinnerPag.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, (48*dp).toInt()
        ).apply { bottomMargin = (12*dp).toInt() }
        cardForm.addView(labelSmall("Forma de pagamento", txtG, dp))
        cardForm.addView(spinnerPag)

        // Passageiro (opcional)
        val etPassageiro = buildInput("Nome do passageiro (opcional)", android.text.InputType.TYPE_CLASS_TEXT, dp)
        cardForm.addView(labelSmall("Passageiro", txtG, dp))
        cardForm.addView(etPassageiro)

        root.addView(cardForm)
        spacer(dp, 16f).let { root.addView(it) }

        // Botão salvar
        val btnSalvar = buildBtn("✓  SALVAR CORRIDA", green, dp)
        root.addView(btnSalvar)

        spacer(dp, 8f).let { root.addView(it) }

        val btnDescartar = buildBtn("✕  Descartar", red, dp)
        root.addView(btnDescartar)

        btnSalvar.setOnClickListener {
            val valorStr = etValor.text.toString().replace(",", ".")
            val valor    = valorStr.toFloatOrNull() ?: 0f
            if (valor <= 0f) { FluxoToast.aviso(this, "Informe o valor da corrida"); return@setOnClickListener }

            val ganhoPorKm  = if (distanciaKm > 0f) valor / distanciaKm else 0f
            val minimoKm    = prefs.getFloat("minimo_km", 1.20f)
            val minimoValor = prefs.getFloat("minimo_valor", 0f)
            val valeAPena   = ganhoPorKm >= minimoKm && (minimoValor <= 0f || valor >= minimoValor)
            val forma       = spinnerPag.selectedItem?.toString() ?: "Dinheiro"
            val passageiro  = etPassageiro.text.toString().trim()
            val tempo       = if (duracaoMin > 0) "$duracaoMin min" else ""

            val corrida = Corrida(
                valor          = valor,
                kmTotal        = distanciaKm,
                ganhoPorKm     = ganhoPorKm,
                valeAPena      = valeAPena,
                origem         = enderecoOrigem,
                destino        = enderecoDestino,
                formaPagamento = forma,
                passageiro     = passageiro,
                horaInicio     = horaInicio,
                horaFim        = horaFim,
                tempoExecucao  = tempo
            )
            db.inserirCorrida(corrida)

            // Atualizar botão flutuante e widget
            try { FloatingEarningsService.instanciaAtiva?.atualizarValor()
                ?: startService(Intent(this, FloatingEarningsService::class.java).apply {
                    action = FloatingEarningsService.ACTION_ATUALIZAR
                }) } catch (_: Throwable) {}

            FluxoToast.sucesso(this, "Corrida salva! R$ ${"%.2f".format(valor)} — ${"%.2f".format(distanciaKm)} km")
            finish()
        }

        btnDescartar.setOnClickListener { construirTela() }

        scroll.addView(root)
        setContentView(scroll)
    }

    // ── MANUAL CARD ───────────────────────────────────────────

    private fun buildManualCard(
        bgCard: Int, accent: Int, txtW: Int, txtG: Int, red: Int, dp: Float
    ): LinearLayout {
        val card = card(bgCard, accent, dp)

        val etValor      = buildInput("Valor recebido (R$)", android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL, dp)
        val etKm         = buildInput("Distância (km)", android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL, dp)
        val etOrigem     = buildInput("Endereço de origem (opcional)", android.text.InputType.TYPE_CLASS_TEXT, dp)
        val etDestino    = buildInput("Endereço de destino (opcional)", android.text.InputType.TYPE_CLASS_TEXT, dp)
        val etPassageiro = buildInput("Passageiro (opcional)", android.text.InputType.TYPE_CLASS_TEXT, dp)

        val formas   = listOf("Dinheiro", "PIX", "Cartão", "Online")
        val spinner  = Spinner(this).apply {
            adapter = ArrayAdapter(this@RideTrackerActivity, android.R.layout.simple_spinner_dropdown_item, formas)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (48*dp).toInt()
            ).apply { bottomMargin = (12*dp).toInt() }
        }

        card.addView(labelSmall("Valor *", txtG, dp))
        card.addView(etValor)
        card.addView(labelSmall("Distância (km)", txtG, dp))
        card.addView(etKm)
        card.addView(labelSmall("Forma de pagamento", txtG, dp))
        card.addView(spinner)
        card.addView(labelSmall("Origem", txtG, dp))
        card.addView(etOrigem)
        card.addView(labelSmall("Destino", txtG, dp))
        card.addView(etDestino)
        card.addView(labelSmall("Passageiro", txtG, dp))
        card.addView(etPassageiro)

        val btnSalvar = buildBtn("✓  SALVAR CORRIDA", accent, dp)
        card.addView(btnSalvar)

        btnSalvar.setOnClickListener {
            val valor = etValor.text.toString().replace(",", ".").toFloatOrNull() ?: 0f
            if (valor <= 0f) { FluxoToast.aviso(this, "Informe o valor da corrida"); return@setOnClickListener }

            val km         = etKm.text.toString().replace(",", ".").toFloatOrNull() ?: 0f
            val ganhoPorKm = if (km > 0f) valor / km else 0f
            val minimoKm   = prefs.getFloat("minimo_km", 1.20f)
            val minimoValor = prefs.getFloat("minimo_valor", 0f)
            val valeAPena  = ganhoPorKm >= minimoKm && (minimoValor <= 0f || valor >= minimoValor)
            val hora       = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

            db.inserirCorrida(Corrida(
                valor          = valor,
                kmTotal        = km,
                ganhoPorKm     = ganhoPorKm,
                valeAPena      = valeAPena,
                origem         = etOrigem.text.toString().trim(),
                destino        = etDestino.text.toString().trim(),
                formaPagamento = spinner.selectedItem?.toString() ?: "Dinheiro",
                passageiro     = etPassageiro.text.toString().trim(),
                horaInicio     = hora,
                horaFim        = hora
            ))

            try { FloatingEarningsService.instanciaAtiva?.atualizarValor()
                ?: startService(Intent(this, FloatingEarningsService::class.java).apply {
                    action = FloatingEarningsService.ACTION_ATUALIZAR
                }) } catch (_: Throwable) {}

            FluxoToast.sucesso(this, "Corrida salva!")
            finish()
        }

        return card
    }

    // ── GPS ──────────────────────────────────────────────────

    private fun iniciarGPS() {
        try {
            locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
            val provider = when {
                locationManager!!.isProviderEnabled(LocationManager.GPS_PROVIDER)     -> LocationManager.GPS_PROVIDER
                locationManager!!.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                else -> { FluxoToast.aviso(this, "GPS indisponível"); return }
            }
            locationManager!!.requestLocationUpdates(provider, 2_000L, 5f, this)
        } catch (_: SecurityException) {
            FluxoToast.aviso(this, "Permissão de localização necessária")
        }
    }

    private fun pararGPS() {
        try { locationManager?.removeUpdates(this) } catch (_: Exception) {}
    }

    override fun onLocationChanged(loc: Location) {
        if (!rastreando) return
        if (locOrigem == null) locOrigem = loc

        val ant = locAnterior
        if (ant != null) {
            val dist = ant.distanceTo(loc)
            // Filtrar: entre 5m e ~500m por update (evita saltos de GPS)
            if (dist in 5f..500f) {
                distanciaRastreada += dist / 1000f
            }
        }
        locAnterior = loc
        locAtual    = loc
    }

    @Deprecated("Deprecated in API 29")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}

    // ── Permissão ─────────────────────────────────────────────

    private fun temPermissaoLocalizacao() =
        ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun pedirPermissaoLocalizacao() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
            REQ_LOCATION
        )
    }

    override fun onRequestPermissionsResult(req: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(req, perms, results)
        if (req == REQ_LOCATION && results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) {
            FluxoToast.sucesso(this, "Permissão concedida! Toque em Iniciar novamente.")
        } else {
            FluxoToast.aviso(this, "Permissão de localização negada. Use o modo Manual.")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        pararGPS()
        executor.shutdownNow()
        handler.removeCallbacksAndMessages(null)
    }

    // ── Helpers de UI ─────────────────────────────────────────

    private fun card(bgCard: Int, accentCor: Int, dp: Float) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background  = android.graphics.drawable.GradientDrawable().apply {
            setColor(bgCard); cornerRadius = 14f * dp
            setStroke((1.5f * dp).toInt(), accentCor)
        }
        setPadding((16*dp).toInt(), (16*dp).toInt(), (16*dp).toInt(), (16*dp).toInt())
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = (8*dp).toInt() }
    }

    private fun buildSectionLabel(texto: String, cor: Int, dp: Float) = TextView(this).apply {
        text = texto; textSize = 13f; setTextColor(cor)
        setTypeface(null, android.graphics.Typeface.BOLD)
        setPadding(0, (16*dp).toInt(), 0, (8*dp).toInt())
    }

    private fun buildDividerLabel(texto: String, cor: Int, dp: Float) = TextView(this).apply {
        text = texto; textSize = 11f; setTextColor(cor)
        gravity = android.view.Gravity.CENTER
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
    }

    private fun buildBtn(texto: String, cor: Int, dp: Float) = Button(this).apply {
        text = texto; textSize = 14f
        setTypeface(null, android.graphics.Typeface.BOLD)
        setTextColor(android.graphics.Color.WHITE)
        backgroundTintList = null
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(cor); cornerRadius = 12f * dp
        }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, (52*dp).toInt()
        ).apply { topMargin = (8*dp).toInt() }
    }

    private fun buildInput(hint: String, inputType: Int, dp: Float) = EditText(this).apply {
        this.hint = hint
        this.inputType = inputType
        textSize = 14f
        val txtW = ThemeHelper.cor("text_white", prefs)
        val txtG = ThemeHelper.cor("text_gray",  prefs)
        val border = ThemeHelper.cor("border",   prefs)
        setTextColor(txtW); setHintTextColor(txtG)
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(android.graphics.Color.TRANSPARENT)
            cornerRadius = 10f * dp
            setStroke((1f * dp).toInt(), border)
        }
        setPadding((12*dp).toInt(), (12*dp).toInt(), (12*dp).toInt(), (12*dp).toInt())
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = (12*dp).toInt() }
    }

    private fun labelSmall(texto: String, cor: Int, dp: Float) = TextView(this).apply {
        text = texto; textSize = 11f; setTextColor(cor)
        setPadding(0, 0, 0, (4*dp).toInt())
    }

    private fun spacer(dp: Float, h: Float) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, (h * dp).toInt()
        )
    }
}
