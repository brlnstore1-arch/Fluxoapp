package com.fluxoapp

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import java.text.SimpleDateFormat
import java.util.*

/**
 * RideTrackerActivity — FluxoApp
 *
 * Tela de nova corrida com dois modos:
 *
 * AUTO — delega rastreamento ao RideTrackingService (continua mesmo se sair da tela)
 * MANUAL — preenche dados na mão
 */
class RideTrackerActivity : AppCompatActivity() {

    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var db: DatabaseHelper
    private val handler = Handler(Looper.getMainLooper())

    // Views do modo auto (mantidas para update de UI)
    private var tvStatusAuto:  TextView? = null
    private var tvOrigenAuto:  TextView? = null
    private var tvDistAuto:    TextView? = null
    private var tvTempoAuto:   TextView? = null
    private var btnIniciarRef: Button?   = null

    companion object { private const val REQ_LOCATION = 101 }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeSelector.aplicar(this)
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        db    = DatabaseHelper(this)

        // Se já há rastreamento em andamento (usuário voltou para a tela), restaurar UI
        if (RideTrackingService.rastreando) {
            construirTelaAutoAtiva()
        } else {
            construirTela()
        }
    }

    override fun onResume() {
        super.onResume()
        // Reconectar callbacks ao serviço se rastreando
        if (RideTrackingService.rastreando) {
            reconectarCallbacks()
        }
    }

    override fun onPause() {
        super.onPause()
        // Desconectar callbacks — serviço continua rodando em background
        RideTrackingService.onUpdate         = null
        RideTrackingService.onOrigemCapturada = null
        RideTrackingService.onFinalizado      = null
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }

    // ═══════════════════════════════════════════════════════
    // TELA PRINCIPAL — escolha de modo
    // ═══════════════════════════════════════════════════════

    private fun construirTela() {
        val p      = prefs
        val bgDark = ThemeHelper.cor("bg_dark",     p)
        val bgCard = ThemeHelper.cor("bg_card",     p)
        val accent = ThemeHelper.cor("accent",      p)
        val txtW   = ThemeHelper.cor("text_white",  p)
        val txtG   = ThemeHelper.cor("text_gray",   p)
        val red    = ThemeHelper.cor("accent_red",  p)
        val green  = ThemeHelper.cor("accent_green",p)
        val dp     = resources.displayMetrics.density

        val scroll = ScrollView(this).apply { setBackgroundColor(bgDark) }
        val root   = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((16*dp).toInt(), 0, (16*dp).toInt(), (32*dp).toInt())
        }

        root.addView(buildToolbar(bgCard, accent, txtW, dp))
        root.addView(buildSectionLabel("🚀  AUTOMÁTICO (GPS)", accent, dp))

        // Card auto
        val cardAuto = card(bgCard, accent, dp)

        val tvStatus = buildInfo(
            "Toque em INICIAR para capturar sua localização e rastrear a corrida.\nVocê pode sair da tela — o rastreamento continua em segundo plano.",
            txtG, dp
        )
        tvStatus.setPadding(0, 0, 0, (14*dp).toInt())
        cardAuto.addView(tvStatus)
        tvStatusAuto = tvStatus

        val tvOrigem = buildInfo("", txtG, dp).also { it.visibility = View.GONE }
        cardAuto.addView(tvOrigem)
        tvOrigenAuto = tvOrigem

        val tvDist = TextView(this).apply {
            text = "📍 0,00 km"; textSize = 22f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(accent); gravity = android.view.Gravity.CENTER
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (8*dp).toInt() }
        }
        cardAuto.addView(tvDist)
        tvDistAuto = tvDist

        val tvTempo = TextView(this).apply {
            text = "⏱ 00:00"; textSize = 14f; setTextColor(txtG)
            gravity = android.view.Gravity.CENTER; visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (14*dp).toInt() }
        }
        cardAuto.addView(tvTempo)
        tvTempoAuto = tvTempo

        val btnIniciar = buildBtn("▶  INICIAR CORRIDA", green, dp)
        cardAuto.addView(btnIniciar)
        btnIniciarRef = btnIniciar

        btnIniciar.setOnClickListener { onBtnIniciarClick(btnIniciar, green, red, tvStatus, tvOrigem, tvDist, tvTempo, accent) }

        root.addView(cardAuto)
        root.addView(spacer(dp, 16f))
        root.addView(buildDividerLabel("── ou adicionar manualmente ──", txtG, dp))
        root.addView(spacer(dp, 8f))
        root.addView(buildSectionLabel("✏️  MANUAL", accent, dp))
        root.addView(buildManualCard(bgCard, accent, txtG, red, dp))

        scroll.addView(root)
        setContentView(scroll)
    }

    // Tela quando usuário volta e rastreamento já está ativo
    private fun construirTelaAutoAtiva() {
        construirTela()
        // Restaurar estado visual
        val green = ThemeHelper.cor("accent_green", prefs)
        val red   = ThemeHelper.cor("accent_red",   prefs)
        val accent = ThemeHelper.cor("accent", prefs)
        btnIniciarRef?.apply {
            text = "⬛  FINALIZAR CORRIDA"
            (background as? android.graphics.drawable.GradientDrawable)?.setColor(red)
        }
        tvDistAuto?.visibility  = View.VISIBLE
        tvTempoAuto?.visibility = View.VISIBLE
        tvStatusAuto?.text = "Rastreamento ativo — toque em FINALIZAR quando terminar."
        if (RideTrackingService.enderecoOrigem.isNotBlank()) {
            tvOrigenAuto?.text = "📌 Origem: ${RideTrackingService.enderecoOrigem}"
            tvOrigenAuto?.visibility = View.VISIBLE
        }
        reconectarCallbacks()
    }

    private fun reconectarCallbacks() {
        val accent = ThemeHelper.cor("accent", prefs)
        RideTrackingService.onUpdate = { dist, seg ->
            runOnUiThread {
                tvDistAuto?.text  = "📍 ${"%.2f".format(dist)} km"
                val min = seg / 60; val s = seg % 60
                tvTempoAuto?.text = "⏱ %02d:%02d".format(min, s)
            }
        }
        RideTrackingService.onOrigemCapturada = { end ->
            runOnUiThread {
                tvOrigenAuto?.text = "📌 Origem: $end"
                tvOrigenAuto?.visibility = View.VISIBLE
                tvStatusAuto?.text = "Rastreando... Você pode sair da tela."
            }
        }
        RideTrackingService.onFinalizado = { runOnUiThread { mostrarResumoAuto() } }
    }

    private fun onBtnIniciarClick(
        btn: Button, green: Int, red: Int,
        tvStatus: TextView, tvOrigem: TextView,
        tvDist: TextView, tvTempo: TextView, accent: Int
    ) {
        if (!RideTrackingService.rastreando) {
            // Iniciar
            if (!temPermissaoLocalizacao()) { pedirPermissaoLocalizacao(); return }

            // Iniciar serviço
            startService(Intent(this, RideTrackingService::class.java).apply {
                action = RideTrackingService.ACTION_INICIAR
            })

            btn.text = "⬛  FINALIZAR CORRIDA"
            (btn.background as? android.graphics.drawable.GradientDrawable)?.setColor(red)
            tvStatus.text = "Aguardando sinal de GPS para capturar origem..."
            tvDist.visibility  = View.VISIBLE
            tvTempo.visibility = View.VISIBLE

            // Conectar callbacks
            RideTrackingService.onUpdate = { dist, seg ->
                runOnUiThread {
                    tvDist.text  = "📍 ${"%.2f".format(dist)} km"
                    val min = seg / 60; val s = seg % 60
                    tvTempo.text = "⏱ %02d:%02d".format(min, s)
                }
            }
            RideTrackingService.onOrigemCapturada = { end ->
                runOnUiThread {
                    tvOrigem.text = "📌 Origem: $end"
                    tvOrigem.visibility = View.VISIBLE
                    tvStatus.text = "Rastreando... Você pode sair da tela com segurança."
                }
            }
            RideTrackingService.onFinalizado = { runOnUiThread { mostrarResumoAuto() } }

        } else {
            // Finalizar
            btn.isEnabled = false
            btn.text = "Calculando rota..."
            tvStatus.text = "Buscando endereço de destino e calculando distância real..."

            RideTrackingService.onFinalizado = { runOnUiThread { mostrarResumoAuto() } }
            startService(Intent(this, RideTrackingService::class.java).apply {
                action = RideTrackingService.ACTION_FINALIZAR
            })
        }
    }

    // ── RESUMO AUTO ───────────────────────────────────────────

    private fun mostrarResumoAuto() {
        val p      = prefs
        val bgDark = ThemeHelper.cor("bg_dark",     p)
        val bgCard = ThemeHelper.cor("bg_card",     p)
        val accent = ThemeHelper.cor("accent",      p)
        val txtW   = ThemeHelper.cor("text_white",  p)
        val txtG   = ThemeHelper.cor("text_gray",   p)
        val green  = ThemeHelper.cor("accent_green",p)
        val red    = ThemeHelper.cor("accent_red",  p)
        val dp     = resources.displayMetrics.density

        val distKm         = RideTrackingService.distanciaKm
        val horaIni        = RideTrackingService.horaInicio
        val horaFim        = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        val duracaoSeg     = (System.currentTimeMillis() - RideTrackingService.tsInicio) / 1000
        val duracaoMin     = (duracaoSeg / 60).toInt()
        val origemCapt     = RideTrackingService.enderecoOrigem
        val destinoCapt    = RideTrackingService.enderecoDestino

        val scroll = ScrollView(this).apply { setBackgroundColor(bgDark) }
        val root   = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((16*dp).toInt(), 0, (16*dp).toInt(), (48*dp).toInt())
        }

        root.addView(buildToolbar(bgCard, accent, txtW, dp))
        root.addView(buildSectionLabel("✅  Corrida finalizada", green, dp))

        val cardResumo = card(bgCard, green, dp)
        fun addInfo(ic: String, lbl: String, `val`: String) {
            cardResumo.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(0, (6*dp).toInt(), 0, (6*dp).toInt())
                addView(TextView(this@RideTrackerActivity).apply {
                    text = ic; textSize = 16f; setPadding(0, 0, (10*dp).toInt(), 0) })
                addView(TextView(this@RideTrackerActivity).apply {
                    text = lbl; textSize = 12f; setTextColor(txtG)
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) })
                addView(TextView(this@RideTrackerActivity).apply {
                    text = `val`; textSize = 13f; setTextColor(txtW)
                    setTypeface(null, android.graphics.Typeface.BOLD) })
            })
        }
        addInfo("📍", "Distância", "${"%.2f".format(distKm)} km")
        addInfo("⏱", "Duração", if (duracaoMin > 0) "$duracaoMin min" else "$horaIni → $horaFim")
        addInfo("🕐", "Horário", "$horaIni → $horaFim")
        addInfo("📌", "Origem",  origemCapt.ifBlank { "—" }.take(50))
        addInfo("🏁", "Destino", destinoCapt.ifBlank { "—" }.take(50))
        root.addView(cardResumo)
        root.addView(spacer(dp, 12f))

        // Formulário de complemento
        root.addView(buildSectionLabel("💰  Complete os dados", accent, dp))
        val cardForm = card(bgCard, accent, dp)

        val etValor = buildInput("Valor recebido (R$)",
            android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL, dp)
        val formas  = listOf("Dinheiro", "PIX", "Cartão", "Online")
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@RideTrackerActivity,
                android.R.layout.simple_spinner_dropdown_item, formas)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (48*dp).toInt()
            ).apply { bottomMargin = (12*dp).toInt() }
        }
        val etPassageiro = buildInput("Nome do passageiro (opcional)",
            android.text.InputType.TYPE_CLASS_TEXT, dp)

        cardForm.addView(labelSmall("Valor recebido *", txtG, dp)); cardForm.addView(etValor)
        cardForm.addView(labelSmall("Forma de pagamento", txtG, dp)); cardForm.addView(spinner)
        cardForm.addView(labelSmall("Passageiro", txtG, dp)); cardForm.addView(etPassageiro)
        root.addView(cardForm)
        root.addView(spacer(dp, 12f))

        val btnSalvar    = buildBtn("✓  SALVAR CORRIDA", green, dp)
        val btnDescartar = buildBtn("✕  Descartar corrida", red, dp)
        root.addView(btnSalvar); root.addView(btnDescartar)

        btnSalvar.setOnClickListener {
            val valor = etValor.text.toString().replace(",", ".").toFloatOrNull() ?: 0f
            if (valor <= 0f) { FluxoToast.aviso(this, "Informe o valor da corrida"); return@setOnClickListener }

            val gpk         = if (distKm > 0f) valor / distKm else 0f
            val minimoKm    = prefs.getFloat("minimo_km",    1.20f)
            val minimoValor = prefs.getFloat("minimo_valor", 0f)
            val valeAPena   = gpk >= minimoKm && (minimoValor <= 0f || valor >= minimoValor)

            db.inserirCorrida(Corrida(
                valor          = valor,
                kmTotal        = distKm,
                ganhoPorKm     = gpk,
                valeAPena      = valeAPena,
                origem         = origemCapt,
                destino        = destinoCapt,
                formaPagamento = spinner.selectedItem?.toString() ?: "Dinheiro",
                passageiro     = etPassageiro.text.toString().trim(),
                horaInicio     = horaIni,
                horaFim        = horaFim,
                tempoExecucao  = if (duracaoMin > 0) "$duracaoMin min" else ""
            ))
            try { FloatingEarningsService.instanciaAtiva?.atualizarValor()
                ?: startService(Intent(this, FloatingEarningsService::class.java).apply {
                    action = FloatingEarningsService.ACTION_ATUALIZAR }) } catch (_: Throwable) {}

            FluxoToast.sucesso(this, "Corrida salva! R$ ${"%.2f".format(valor)} · ${"%.2f".format(distKm)} km")
            finish()
        }
        btnDescartar.setOnClickListener {
            RideTrackingService.rastreando = false
            construirTela()
        }

        scroll.addView(root)
        setContentView(scroll)
    }

    // ── MANUAL ────────────────────────────────────────────────

    private fun buildManualCard(bgCard: Int, accent: Int, txtG: Int, red: Int, dp: Float): LinearLayout {
        val card = card(bgCard, accent, dp)

        val etValor      = buildInput("Valor recebido (R$)", android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL, dp)
        val etKm         = buildInput("Distância (km)", android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL, dp)
        val etOrigem     = buildInput("Origem (opcional)", android.text.InputType.TYPE_CLASS_TEXT, dp)
        val etDestino    = buildInput("Destino (opcional)", android.text.InputType.TYPE_CLASS_TEXT, dp)
        val etPassageiro = buildInput("Passageiro (opcional)", android.text.InputType.TYPE_CLASS_TEXT, dp)
        val formas       = listOf("Dinheiro", "PIX", "Cartão", "Online")
        val spinner      = Spinner(this).apply {
            adapter = ArrayAdapter(this@RideTrackerActivity,
                android.R.layout.simple_spinner_dropdown_item, formas)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (48*dp).toInt()
            ).apply { bottomMargin = (12*dp).toInt() }
        }

        card.addView(labelSmall("Valor *", txtG, dp));          card.addView(etValor)
        card.addView(labelSmall("Distância (km)", txtG, dp));   card.addView(etKm)
        card.addView(labelSmall("Pagamento", txtG, dp));        card.addView(spinner)
        card.addView(labelSmall("Origem", txtG, dp));           card.addView(etOrigem)
        card.addView(labelSmall("Destino", txtG, dp));          card.addView(etDestino)
        card.addView(labelSmall("Passageiro", txtG, dp));       card.addView(etPassageiro)

        val btnSalvar = buildBtn("✓  SALVAR CORRIDA", accent, dp)
        card.addView(btnSalvar)

        btnSalvar.setOnClickListener {
            val valor = etValor.text.toString().replace(",", ".").toFloatOrNull() ?: 0f
            if (valor <= 0f) { FluxoToast.aviso(this, "Informe o valor"); return@setOnClickListener }
            val km    = etKm.text.toString().replace(",", ".").toFloatOrNull() ?: 0f
            val gpk   = if (km > 0f) valor / km else 0f
            val minimoKm    = prefs.getFloat("minimo_km",    1.20f)
            val minimoValor = prefs.getFloat("minimo_valor", 0f)
            val valeAPena   = gpk >= minimoKm && (minimoValor <= 0f || valor >= minimoValor)
            val hora  = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

            db.inserirCorrida(Corrida(
                valor          = valor, kmTotal = km, ganhoPorKm = gpk, valeAPena = valeAPena,
                origem         = etOrigem.text.toString().trim(),
                destino        = etDestino.text.toString().trim(),
                formaPagamento = spinner.selectedItem?.toString() ?: "Dinheiro",
                passageiro     = etPassageiro.text.toString().trim(),
                horaInicio = hora, horaFim = hora
            ))
            try { FloatingEarningsService.instanciaAtiva?.atualizarValor()
                ?: startService(Intent(this, FloatingEarningsService::class.java).apply {
                    action = FloatingEarningsService.ACTION_ATUALIZAR }) } catch (_: Throwable) {}
            FluxoToast.sucesso(this, "Corrida salva!")
            finish()
        }
        return card
    }

    // ── Permissão ─────────────────────────────────────────────

    private fun temPermissaoLocalizacao() =
        ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)   == PackageManager.PERMISSION_GRANTED ||
        ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun pedirPermissaoLocalizacao() {
        ActivityCompat.requestPermissions(this,
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
            REQ_LOCATION)
    }

    override fun onRequestPermissionsResult(req: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(req, perms, results)
        if (req == REQ_LOCATION && results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED)
            FluxoToast.sucesso(this, "Permissão concedida! Toque em Iniciar.")
        else
            FluxoToast.aviso(this, "Permissão negada — use o modo Manual.")
    }

    // ── UI helpers ────────────────────────────────────────────

    private fun buildToolbar(bgCard: Int, accent: Int, txtW: Int, dp: Float) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL
        setBackgroundColor(bgCard)
        setPadding((8*dp).toInt(), 0, (16*dp).toInt(), 0)
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (56*dp).toInt())
        addView(ImageButton(this@RideTrackerActivity).apply {
            setImageResource(android.R.drawable.ic_media_previous); setColorFilter(accent)
            setBackgroundColor(android.graphics.Color.TRANSPARENT)
            layoutParams = LinearLayout.LayoutParams((44*dp).toInt(), (44*dp).toInt())
            setOnClickListener { finish() }
        })
        addView(TextView(this@RideTrackerActivity).apply {
            text = "Nova corrida"; textSize = 17f; setTextColor(accent)
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding((6*dp).toInt(), 0, 0, 0)
        })
    }

    private fun buildSectionLabel(t: String, cor: Int, dp: Float) = TextView(this).apply {
        text = t; textSize = 13f; setTextColor(cor)
        setTypeface(null, android.graphics.Typeface.BOLD)
        setPadding(0, (16*dp).toInt(), 0, (8*dp).toInt())
    }

    private fun buildDividerLabel(t: String, cor: Int, dp: Float) = TextView(this).apply {
        text = t; textSize = 11f; setTextColor(cor)
        gravity = android.view.Gravity.CENTER
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun buildInfo(t: String, cor: Int, dp: Float) = TextView(this).apply {
        text = t; textSize = 13f; setTextColor(cor); setLineSpacing(0f, 1.4f)
    }

    private fun buildBtn(t: String, cor: Int, dp: Float) = Button(this).apply {
        text = t; textSize = 14f; setTypeface(null, android.graphics.Typeface.BOLD)
        setTextColor(android.graphics.Color.WHITE); backgroundTintList = null
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(cor); cornerRadius = 12f * dp }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, (52*dp).toInt()
        ).apply { topMargin = (8*dp).toInt() }
    }

    private fun buildInput(hint: String, inputType: Int, dp: Float) = EditText(this).apply {
        this.hint = hint; this.inputType = inputType; textSize = 14f
        setTextColor(ThemeHelper.cor("text_white", prefs))
        setHintTextColor(ThemeHelper.cor("text_gray",  prefs))
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(android.graphics.Color.TRANSPARENT); cornerRadius = 10f * dp
            setStroke((1f * dp).toInt(), ThemeHelper.cor("border", prefs)) }
        setPadding((12*dp).toInt(), (12*dp).toInt(), (12*dp).toInt(), (12*dp).toInt())
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = (12*dp).toInt() }
    }

    private fun labelSmall(t: String, cor: Int, dp: Float) = TextView(this).apply {
        text = t; textSize = 11f; setTextColor(cor)
        setPadding(0, 0, 0, (4*dp).toInt())
    }

    private fun card(bgCard: Int, accentCor: Int, dp: Float) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(bgCard); cornerRadius = 14f * dp
            setStroke((1.5f * dp).toInt(), accentCor) }
        setPadding((16*dp).toInt(), (16*dp).toInt(), (16*dp).toInt(), (16*dp).toInt())
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = (8*dp).toInt() }
    }

    private fun spacer(dp: Float, h: Float) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (h*dp).toInt())
    }
}
