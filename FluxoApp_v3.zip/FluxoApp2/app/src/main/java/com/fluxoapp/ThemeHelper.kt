package com.fluxoapp

import android.animation.ValueAnimator
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.util.Log
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

object ThemeHelper {

    private const val TAG = "FluxoApp.Theme"

    // ── AZUL NOITE ──────────────────────────────────────────────────
    private fun corAzulNoite(chave: String): String = when (chave) {
        "bg_dark"      -> "#0A1628"
        "bg_card"      -> "#0F1E36"
        "bg_section"   -> "#132240"
        "text_white"   -> "#F0F0F5"
        "text_gray"    -> "#3A6090"
        "text_light"   -> "#7A9CC0"
        "accent_gold"  -> "#00C8FF"
        "accent_green" -> "#00E676"
        "accent_red"   -> "#FF4560"
        "border"       -> "#1A3055"
        "toolbar"      -> "#0F1E36"
        "status_bg"    -> "#09162A"  // padronizado: status_bg
        else           -> "#000000"
    }

    // ── AZUL DIA ────────────────────────────────────────────────────
    private fun corAzulDia(chave: String): String = when (chave) {
        "bg_dark"      -> "#F0F6FF"
        "bg_card"      -> "#DAEEFF"
        "bg_section"   -> "#C8E4F8"
        "text_white"   -> "#0A2A5E"
        "text_gray"    -> "#4A7AAA"
        "text_light"   -> "#5A8ABB"
        "accent_gold"  -> "#0066CC"
        "accent_green" -> "#00875A"
        "accent_red"   -> "#C0392B"
        "border"       -> "#A0C8EC"
        "toolbar"      -> "#E4EFF9"
        "status_bg"    -> "#DAEAF8"  // padronizado: status_bg
        else           -> "#000000"
    }

    // ── GOLD NOITE ──────────────────────────────────────────────────
    private fun corGoldNoite(chave: String): String = when (chave) {
        "bg_dark"      -> "#0E0E0E"
        "bg_card"      -> "#141414"
        "bg_section"   -> "#1C1C1C"
        "text_white"   -> "#F5F0E8"
        "text_gray"    -> "#5A4A38"
        "text_light"   -> "#7A6A50"
        "accent_gold"  -> "#C9A84C"
        "accent_green" -> "#4CAF7D"
        "accent_red"   -> "#E05C5C"
        "border"       -> "#2A2418"
        "toolbar"      -> "#141414"
        "status_bg"    -> "#0B0B0B"  // padronizado: status_bg
        else           -> "#000000"
    }

    // ── GOLD DIA ────────────────────────────────────────────────────
    private fun corGoldDia(chave: String): String = when (chave) {
        "bg_dark"      -> "#FAF6EF"
        "bg_card"      -> "#FFF8EC"
        "bg_section"   -> "#F5EFE3"
        "text_white"   -> "#1A1208"
        "text_gray"    -> "#7A6040"
        "text_light"   -> "#9A8060"
        "accent_gold"  -> "#C9A84C"
        "accent_green" -> "#4CAF7D"
        "accent_red"   -> "#C0392B"
        "border"       -> "#E0CCAA"
        "toolbar"      -> "#F5EFE3"
        "status_bg"    -> "#F0E8D6"  // padronizado: status_bg
        else           -> "#000000"
    }

    // ── ITEM 2: VALIDADOR DE TEMA ────────────────────────────────────
    // Só aceita "azul" ou "gold". Qualquer outro valor retorna "azul".
    fun validarTema(valor: String?): String {
        return when (valor) {
            "gold" -> "gold"
            "azul" -> "azul"
            else   -> {
                Log.w(TAG, "Tema inválido detectado: '$valor' → forçando 'azul'")
                "azul"
            }
        }
    }

    // ── ITEM 1: TEMA PADRÃO ALTERADO PARA "azul" ────────────────────
    fun getTema(prefs: SharedPreferences): String {
        val raw = prefs.getString("tema_estilo", "azul") ?: "azul"
        return validarTema(raw)
    }

    // ── ITEM 8: RESET DE EMERGÊNCIA ──────────────────────────────────
    fun resetarParaAzul(prefs: SharedPreferences) {
        Log.w(TAG, "Reset de emergência: forçando tema 'azul'")
        prefs.edit()
            .putString("tema_estilo", "azul")
            .putInt("modo_tema", -1)
            .commit() // commit síncrono — garante gravação imediata
    }

    fun isModoNoturno(prefs: SharedPreferences): Boolean {
        return when (prefs.getInt("modo_tema", -1)) {
            0    -> false
            1    -> true
            else -> {
                val hora = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
                hora >= 18 || hora < 6
            }
        }
    }

    // ── ITEM 7: LOG DE ERROS ─────────────────────────────────────────
    fun cor(chave: String, prefs: SharedPreferences): Int {
        return try {
            val noturno = isModoNoturno(prefs)
            val tema    = getTema(prefs)
            val hex = when {
                tema == "gold" && noturno  -> corGoldNoite(chave)
                tema == "gold" && !noturno -> corGoldDia(chave)
                noturno                    -> corAzulNoite(chave)
                else                       -> corAzulDia(chave)
            }
            Color.parseColor(hex)
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao resolver cor '$chave': ${e.message}")
            Color.BLACK
        }
    }

    // Compatibilidade: aceita tanto "status_bar" quanto "status_bg"
    fun corCompat(chave: String, prefs: SharedPreferences): Int {
        val chaveReal = if (chave == "status_bar") "status_bg" else chave
        return cor(chaveReal, prefs)
    }

    fun cor(chave: String, noturno: Boolean): Int {
        val hex = if (noturno) corAzulNoite(chave) else corAzulDia(chave)
        return try { Color.parseColor(hex) } catch (_: Exception) { Color.BLACK }
    }

    // ── ITEM 3: APLICAR TEMA COM FALLBACK AUTOMÁTICO ─────────────────
    fun aplicarTemaComFallback(
        prefs: SharedPreferences,
        aplicador: () -> Unit
    ) {
        try {
            aplicador()
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao aplicar tema '${getTema(prefs)}': ${e.message}", e)
            Log.w(TAG, "Ativando fallback: resetando para tema 'azul'")
            resetarParaAzul(prefs)
            try {
                aplicador()
            } catch (e2: Exception) {
                Log.e(TAG, "Erro mesmo após fallback para azul: ${e2.message}", e2)
            }
        }
    }

    // ── ITEM 6: HELPER PARA CARREGAR DRAWABLE COM FALLBACK ───────────
    fun setDrawableSeguro(view: android.view.View?, drawableRes: Int, corFallback: Int) {
        try {
            view?.setBackgroundResource(drawableRes)
        } catch (e: Exception) {
            Log.e(TAG, "Drawable $drawableRes falhou, usando cor sólida: ${e.message}")
            try { view?.setBackgroundColor(corFallback) } catch (_: Exception) {}
        }
    }

    data class TemaAtual(
        val bgDark: Int, val bgCard: Int, val bgSection: Int, val toolbar: Int,
        val textWhite: Int, val textGray: Int, val textLight: Int,
        val accent: Int, val green: Int, val red: Int, val border: Int,
        val statusBg: Int, val isGold: Boolean, val isNoturno: Boolean
    )

    fun resolverTema(prefs: SharedPreferences): TemaAtual {
        val noturno = isModoNoturno(prefs)
        val tema    = getTema(prefs)
        return TemaAtual(
            bgDark    = cor("bg_dark",     prefs),
            bgCard    = cor("bg_card",     prefs),
            bgSection = cor("bg_section",  prefs),
            toolbar   = cor("toolbar",     prefs),
            textWhite = cor("text_white",  prefs),
            textGray  = cor("text_gray",   prefs),
            textLight = cor("text_light",  prefs),
            accent    = cor("accent_gold", prefs),
            green     = cor("accent_green",prefs),
            red       = cor("accent_red",  prefs),
            border    = cor("border",      prefs),
            statusBg  = cor("status_bg",   prefs),  // padronizado
            isGold    = tema == "gold",
            isNoturno = noturno
        )
    }

    fun animarLogoShimmer(tv: TextView, prefs: SharedPreferences) {
        tv.post {
            try {
                val w = tv.width.toFloat().takeIf { it > 0 } ?: return@post
                val corBase    = cor("accent_gold", prefs)
                val corShimmer = Color.argb(200,
                    minOf(255, (Color.red(corBase)   * 1.4f).toInt()),
                    minOf(255, (Color.green(corBase) * 1.4f).toInt()),
                    minOf(255, (Color.blue(corBase)  * 1.4f).toInt())
                )
                val corBright  = Color.argb(180,
                    minOf(255, (Color.red(corBase)   * 1.2f).toInt()),
                    minOf(255, (Color.green(corBase) * 1.2f).toInt()),
                    minOf(255, (Color.blue(corBase)  * 1.2f).toInt())
                )

                tv.tag?.let { if (it is ValueAnimator) it.cancel() }

                val animator = ValueAnimator.ofFloat(-w, w * 2f).apply {
                    duration     = 2200
                    startDelay   = 600
                    repeatCount  = ValueAnimator.INFINITE
                    repeatMode   = ValueAnimator.RESTART
                    interpolator = android.view.animation.LinearInterpolator()
                    addUpdateListener { anim ->
                        try {
                            val x = anim.animatedValue as Float
                            val shader = LinearGradient(
                                x, 0f, x + w, 0f,
                                intArrayOf(corBase, corBase, corBright, corShimmer, corBright, corBase, corBase),
                                floatArrayOf(0f, 0.25f, 0.4f, 0.5f, 0.6f, 0.75f, 1f),
                                Shader.TileMode.CLAMP
                            )
                            tv.paint.shader = shader
                            tv.invalidate()
                        } catch (_: Exception) {}
                    }
                }
                tv.tag = animator
                animator.start()
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao animar shimmer: ${e.message}")
            }
        }
    }

    fun aplicarTemaBase(
        activity: AppCompatActivity,
        rootViewId: Int,
        toolbarId: Int? = null,
        tituloId: Int?  = null
    ) {
        try {
            val prefs  = activity.getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
            val bgDark = cor("bg_dark",     prefs)
            val bgCard = cor("toolbar",     prefs)
            val accent = cor("accent_gold", prefs)

            try { activity.findViewById<View>(rootViewId)?.setBackgroundColor(bgDark) } catch (e: Exception) { Log.e(TAG, "rootView: ${e.message}") }
            if (toolbarId != null) try { activity.findViewById<View>(toolbarId)?.setBackgroundColor(bgCard) } catch (e: Exception) { Log.e(TAG, "toolbar: ${e.message}") }
            if (tituloId != null) try {
                val tv = activity.findViewById<TextView>(tituloId)
                tv?.setTextColor(accent)
                animarLogoShimmer(tv ?: return, prefs)
            } catch (e: Exception) { Log.e(TAG, "titulo: ${e.message}") }
        } catch (e: Exception) {
            Log.e(TAG, "aplicarTemaBase falhou: ${e.message}", e)
        }
    }

    fun aplicarTema(context: Context, view: View) {
        try {
            val prefs = context.getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
            view.setBackgroundColor(cor("bg_dark", prefs))
        } catch (e: Exception) {
            Log.e(TAG, "aplicarTema: ${e.message}")
        }
    }
}
