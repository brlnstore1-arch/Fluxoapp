package com.fluxoapp

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

object ThemeHelper {

    // ── Cores NOITE (escuro) ──
    private val NOITE = mapOf(
        "bg_dark"     to "#0A0A0F",
        "bg_card"     to "#16161F",
        "bg_section"  to "#1E1E2A",
        "text_white"  to "#F0F0F5",
        "text_gray"   to "#6B6B80",
        "accent_cyan" to "#00E5FF",
        "accent_green"to "#00E676",
        "accent_red"  to "#FF1744",
        "accent_gold" to "#FFD740",
        "border"      to "#2A2A3A"
    )

    // ── Cores DIA (claro) ──
    private val DIA = mapOf(
        "bg_dark"     to "#F0F4F8",
        "bg_card"     to "#FFFFFF",
        "bg_section"  to "#E8EDF2",
        "text_white"  to "#1A1A2E",
        "text_gray"   to "#555570",
        "accent_cyan" to "#0095B3",
        "accent_green"to "#00A550",
        "accent_red"  to "#D32F2F",
        "accent_gold" to "#E6A800",
        "border"      to "#C8D0DC"
    )

    fun isModoNoturno(prefs: SharedPreferences): Boolean {
        // Verifica preferência manual primeiro
        val manual = prefs.getInt("modo_tema", -1) // -1 = auto, 0 = dia, 1 = noite
        return when (manual) {
            0 -> false  // forçado dia
            1 -> true   // forçado noite
            else -> {   // automático por horário
                val hora = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
                hora >= 20 || hora < 6
            }
        }
    }

    fun cor(chave: String, noturno: Boolean): Int {
        val hex = if (noturno) NOITE[chave] else DIA[chave]
        return try { Color.parseColor(hex ?: "#000000") } catch (_: Exception) { Color.BLACK }
    }

    fun aplicarTema(context: Context, view: android.view.View) {
        val prefs = context.getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val noturno = isModoNoturno(prefs)
        view.setBackgroundColor(cor("bg_dark", noturno))
    }
}
