package com.fluxoapp

import android.animation.ValueAnimator
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar

object ThemeHelper {

    // ── AZUL NOITE ──────────────────────────────────────────────────
    private fun corAzulNoite(chave: String): String = when (chave) {
        "bg_dark"      -> "#0A1628"
        "bg_card"      -> "#0F1E36"
        "bg_section"   -> "#132240"
        "text_white"   -> "#F0F0F5"
        "text_gray"    -> "#3A6090"
        "text_light"   -> "#7A9CC0"
        "accent_cyan"  -> "#00C8FF"
        "accent_green" -> "#00E676"
        "accent_red"   -> "#FF4560"
        "accent_gold"  -> "#F0B429"
        "border"       -> "#1A3055"
        "toolbar"      -> "#0F1E36"
        "status_bar"   -> "#09162A"
        else           -> "#000000"
    }

    // ── AZUL DIA ────────────────────────────────────────────────────
    private fun corAzulDia(chave: String): String = when (chave) {
        "bg_dark"      -> "#F0F6FF"
        "bg_card"      -> "#DAEEFF"
        "bg_section"   -> "#C8E4F8"
        "text_white"   -> "#0A2A5E"
        "text_gray"    -> "#4A7AAA"
        "text_light"   -> "#5A8ABB"
        "accent_cyan"  -> "#0066CC"
        "accent_green" -> "#00875A"
        "accent_red"   -> "#C0392B"
        "accent_gold"  -> "#B8860B"
        "border"       -> "#A0C8EC"
        "toolbar"      -> "#E4EFF9"
        "status_bar"   -> "#DAEAF8"
        else           -> "#000000"
    }

    // ── GOLD NOITE ──────────────────────────────────────────────────
    private fun corGoldNoite(chave: String): String = when (chave) {
        "bg_dark"      -> "#0E0E0E"
        "bg_card"      -> "#141414"
        "bg_section"   -> "#1C1C1C"
        "text_white"   -> "#F5F0E8"
        "text_gray"    -> "#5A4A38"
        "text_light"   -> "#7A6A50"
        "accent_cyan"  -> "#C9A84C"
        "accent_green" -> "#4CAF7D"
        "accent_red"   -> "#E05C5C"
        "accent_gold"  -> "#E8C96D"
        "border"       -> "#2A2418"
        "toolbar"      -> "#141414"
        "status_bar"   -> "#0B0B0B"
        else           -> "#000000"
    }

    // ── GOLD DIA ────────────────────────────────────────────────────
    private fun corGoldDia(chave: String): String = when (chave) {
        "bg_dark"      -> "#FAF6EF"
        "bg_card"      -> "#FFF8EC"
        "bg_section"   -> "#F5EFE3"
        "text_white"   -> "#1A1208"
        "text_gray"    -> "#9A8060"
        "text_light"   -> "#7A6040"
        "accent_cyan"  -> "#8A6520"
        "accent_green" -> "#4CAF7D"
        "accent_red"   -> "#C0392B"
        "accent_gold"  -> "#C9A84C"
        "border"       -> "#E0CCAA"
        "toolbar"      -> "#F5EFE3"
        "status_bar"   -> "#F0E8D6"
        else           -> "#000000"
    }

    fun getTema(prefs: SharedPreferences): String =
        prefs.getString("tema_estilo", "azul") ?: "azul"

    fun isModoNoturno(prefs: SharedPreferences): Boolean {
        return when (prefs.getInt("modo_tema", -1)) {
            0    -> false
            1    -> true
            else -> {
                val hora = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
                hora >= 18 || hora < 6
            }
        }
    }

    fun cor(chave: String, prefs: SharedPreferences): Int {
        val noturno = isModoNoturno(prefs)
        val tema    = getTema(prefs)
        val hex = when {
            tema == "gold" && noturno  -> corGoldNoite(chave)
            tema == "gold" && !noturno -> corGoldDia(chave)
            noturno                    -> corAzulNoite(chave)
            else                       -> corAzulDia(chave)
        }
        return try { Color.parseColor(hex) } catch (_: Exception) { Color.BLACK }
    }

    // Retrocompatibilidade
    fun cor(chave: String, noturno: Boolean): Int {
        val hex = if (noturno) corAzulNoite(chave) else corAzulDia(chave)
        return try { Color.parseColor(hex) } catch (_: Exception) { Color.BLACK }
    }

    // ─────────────────────────────────────────────────────────────────
    // SHIMMER DENTRO DAS LETRAS (LinearGradient no paint do TextView)
    // ─────────────────────────────────────────────────────────────────
    fun animarLogoShimmer(tv: TextView, prefs: SharedPreferences) {
        tv.post {
            try {
                val isGold  = getTema(prefs) == "gold"
                val noturno = isModoNoturno(prefs)
                val w = tv.width.toFloat().takeIf { it > 0 } ?: return@post

                // Cores base e shimmer por tema
                val corBase   : Int
                val corShimmer: Int
                val corBright : Int

                if (isGold) {
                    corBase    = Color.parseColor("#C9A84C")
                    corShimmer = Color.parseColor("#FFF0B3")
                    corBright  = Color.parseColor("#E8C96D")
                } else {
                    corBase    = if (noturno) Color.parseColor("#00C8FF") else Color.parseColor("#0066CC")
                    corShimmer = Color.WHITE
                    corBright  = if (noturno) Color.parseColor("#1E90FF") else Color.parseColor("#4499FF")
                }

                // Cancelar animação anterior se houver
                tv.tag?.let { if (it is ValueAnimator) it.cancel() }

                val animator = ValueAnimator.ofFloat(-w, w * 2f).apply {
                    duration     = 2200
                    startDelay   = 600
                    repeatCount  = ValueAnimator.INFINITE
                    repeatMode   = ValueAnimator.RESTART
                    interpolator = LinearInterpolator()
                    addUpdateListener { anim ->
                        val x = anim.animatedValue as Float
                        val shader = LinearGradient(
                            x, 0f, x + w, 0f,
                            intArrayOf(corBase, corBase, corBright, corShimmer, corBright, corBase, corBase),
                            floatArrayOf(0f, 0.25f, 0.4f, 0.5f, 0.6f, 0.75f, 1f),
                            Shader.TileMode.CLAMP
                        )
                        tv.paint.shader = shader
                        tv.invalidate()
                    }
                }
                tv.tag = animator
                animator.start()
            } catch (_: Exception) {}
        }
    }

    // ─────────────────────────────────────────────────────────────────
    // APLICAR TEMA BASE (bg + toolbar + texto do título)
    // Chamado de qualquer Activity
    // ─────────────────────────────────────────────────────────────────
    fun aplicarTemaBase(
        activity: AppCompatActivity,
        rootViewId: Int,
        toolbarId: Int? = null,
        tituloId: Int?  = null
    ) {
        val prefs = activity.getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val bgDark  = cor("bg_dark",   prefs)
        val bgCard  = cor("toolbar",   prefs)
        val cyan    = cor("accent_cyan", prefs)
        val txtW    = cor("text_white", prefs)

        try { activity.findViewById<View>(rootViewId)?.setBackgroundColor(bgDark) } catch (_: Exception) {}
        if (toolbarId != null) {
            try { activity.findViewById<View>(toolbarId)?.setBackgroundColor(bgCard) } catch (_: Exception) {}
        }
        if (tituloId != null) {
            try {
                val tv = activity.findViewById<TextView>(tituloId)
                tv?.setTextColor(cyan)
                animarLogoShimmer(tv ?: return, prefs)
            } catch (_: Exception) {}
        }
    }

    fun aplicarTema(context: Context, view: View) {
        val prefs = context.getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        view.setBackgroundColor(cor("bg_dark", prefs))
    }
}
