package com.fluxoapp

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

object ThemeHelper {

    // ── Cores NOITE (escuro) ──
    private fun corNoite(chave: String): String = when (chave) {
        "bg_dark"      -> "#0A0A0F"
        "bg_card"      -> "#16161F"
        "bg_section"   -> "#1E1E2A"
        "text_white"   -> "#F0F0F5"
        "text_gray"    -> "#6B6B80"
        "accent_cyan"  -> "#00E5FF"
        "accent_green" -> "#00E676"
        "accent_red"   -> "#FF1744"
        "accent_gold"  -> "#FFD740"
        "border"       -> "#2A2A3A"
        else           -> "#000000"
    }

    // ── Cores DIA — estilo app bancario: branco limpo, cyan vibrante ──
    private fun corDia(chave: String): String = when (chave) {
        "bg_dark"      -> "#F5F7FA"   // fundo branco levemente azulado
        "bg_card"      -> "#FFFFFF"   // cards brancos puros
        "bg_section"   -> "#EBF0F5"   // secoes levemente distintas
        "text_white"   -> "#0D1B2A"   // texto principal quase preto
        "text_gray"    -> "#6B7C93"   // texto secundario azul acinzentado
        "accent_cyan"  -> "#0077B6"   // azul bancario profissional
        "accent_green" -> "#00875A"   // verde confirmacao
        "accent_red"   -> "#C0392B"   // vermelho alerta
        "accent_gold"  -> "#B8860B"   // dourado mais seco para dia
        "border"       -> "#DDE3EA"   // borda sutil
        else           -> "#000000"
    }

    fun isModoNoturno(prefs: SharedPreferences): Boolean {
        val manual = prefs.getInt("modo_tema", -1) // -1=auto, 0=dia, 1=noite
        return when (manual) {
            0    -> false
            1    -> true
            else -> {
                val hora = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
                hora >= 20 || hora < 6
            }
        }
    }

    fun cor(chave: String, noturno: Boolean): Int {
        val hex = if (noturno) corNoite(chave) else corDia(chave)
        return try { Color.parseColor(hex) } catch (_: Exception) { Color.BLACK }
    }

    fun aplicarTema(context: Context, view: android.view.View) {
        val prefs = context.getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val noturno = isModoNoturno(prefs)
        view.setBackgroundColor(cor("bg_dark", noturno))
    }
}
