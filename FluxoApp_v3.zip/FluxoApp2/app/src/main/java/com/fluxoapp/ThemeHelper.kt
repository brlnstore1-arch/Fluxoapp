package com.fluxoapp

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

object ThemeHelper {

    // ── Cores NOITE (escuro) ──
    private fun corNoite(chave: String): String = when (chave) {
        "bg_dark"      -> "#0A0A0F"
        "bg_card"      -> "#16161F"
        "bg_section"   -> "#1E1E2A"
        "text_white"   -> "#F0F0F5"
        "text_gray"    -> "#6B6B80"
        "accent_cyan"  -> "#00E5FF"
        "accent_green" -> "#00E676"
        "accent_red"   -> "#FF1744"
        "accent_gold"  -> "#FFD740"
        "border"       -> "#2A2A3A"
        else           -> "#000000"
    }

    // ── Cores DIA (claro) ──
    private fun corDia(chave: String): String = when (chave) {
        "bg_dark"      -> "#F0F4F8"
        "bg_card"      -> "#FFFFFF"
        "bg_section"   -> "#E8EDF2"
        "text_white"   -> "#1A1A2E"
        "text_gray"    -> "#555570"
        "accent_cyan"  -> "#0095B3"
        "accent_green" -> "#00A550"
        "accent_red"   -> "#D32F2F"
        "accent_gold"  -> "#E6A800"
        "border"       -> "#C8D0DC"
        else           -> "#000000"
    }

    fun isModoNoturno(prefs: SharedPreferences): Boolean {
        val manual = prefs.getInt("modo_tema", -1) // -1=auto, 0=dia, 1=noite
        return when (manual) {
            0    -> false
            1    -> true
            else -> {
                val hora = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
                hora >= 20 || hora < 6
            }
        }
    }

    fun cor(chave: String, noturno: Boolean): Int {
        val hex = if (noturno) corNoite(chave) else corDia(chave)
        return try { Color.parseColor(hex) } catch (_: Exception) { Color.BLACK }
    }

    fun aplicarTema(context: Context, view: android.view.View) {
        val prefs = context.getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val noturno = isModoNoturno(prefs)
        view.setBackgroundColor(cor("bg_dark", noturno))
    }
}
