package com.fluxoapp

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

object ThemeHelper {

    // ── AZUL NOITE ──────────────────────────────────────────────────
    private fun corAzulNoite(chave: String): String = when (chave) {
        "bg_dark"      -> "#0A1628"
        "bg_card"      -> "#0F1E36"
        "bg_section"   -> "#132240"
        "text_white"   -> "#F0F0F5"
        "text_gray"    -> "#3A6090"
        "accent_cyan"  -> "#00C8FF"
        "accent_green" -> "#00E676"
        "accent_red"   -> "#FF1744"
        "accent_gold"  -> "#F0B429"
        "border"       -> "#1A3055"
        "toolbar"      -> "#0F1E36"
        "status_bar"   -> "#09162A"
        else           -> "#000000"
    }

    // ── AZUL DIA ────────────────────────────────────────────────────
    private fun corAzulDia(chave: String): String = when (chave) {
        "bg_dark"      -> "#F0F6FF"
        "bg_card"      -> "#DAEEFF"
        "bg_section"   -> "#C8E4F8"
        "text_white"   -> "#0A2A5E"
        "text_gray"    -> "#4A7AAA"
        "accent_cyan"  -> "#0066CC"
        "accent_green" -> "#00875A"
        "accent_red"   -> "#C0392B"
        "accent_gold"  -> "#B8860B"
        "border"       -> "#A0C8EC"
        "toolbar"      -> "#E4EFF9"
        "status_bar"   -> "#DAEAF8"
        else           -> "#000000"
    }

    // ── GOLD NOITE ──────────────────────────────────────────────────
    private fun corGoldNoite(chave: String): String = when (chave) {
        "bg_dark"      -> "#0E0E0E"
        "bg_card"      -> "#141414"
        "bg_section"   -> "#1A1A1A"
        "text_white"   -> "#F0F0F0"
        "text_gray"    -> "#5A4A38"
        "accent_cyan"  -> "#C9A84C"
        "accent_green" -> "#4CAF7D"
        "accent_red"   -> "#FF4444"
        "accent_gold"  -> "#E8C96D"
        "border"       -> "#2A2418"
        "toolbar"      -> "#141414"
        "status_bar"   -> "#0B0B0B"
        else           -> "#000000"
    }

    // ── GOLD DIA ────────────────────────────────────────────────────
    private fun corGoldDia(chave: String): String = when (chave) {
        "bg_dark"      -> "#FAF6EF"
        "bg_card"      -> "#FFF8EC"
        "bg_section"   -> "#F5EFE3"
        "text_white"   -> "#1A1208"
        "text_gray"    -> "#9A8060"
        "accent_cyan"  -> "#8A6520"
        "accent_green" -> "#4CAF7D"
        "accent_red"   -> "#C0392B"
        "accent_gold"  -> "#C9A84C"
        "border"       -> "#E0CCAA"
        "toolbar"      -> "#F5EFE3"
        "status_bar"   -> "#F0E8D6"
        else           -> "#000000"
    }

    fun getTema(prefs: SharedPreferences): String =
        prefs.getString("tema_estilo", "azul") ?: "azul"

    fun isModoNoturno(prefs: SharedPreferences): Boolean {
        return when (prefs.getInt("modo_tema", -1)) {
            0    -> false
            1    -> true
            else -> {
                val hora = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
                hora >= 18 || hora < 6
            }
        }
    }

    fun cor(chave: String, prefs: SharedPreferences): Int {
        val noturno = isModoNoturno(prefs)
        val tema = getTema(prefs)
        val hex = when {
            tema == "gold" && noturno  -> corGoldNoite(chave)
            tema == "gold" && !noturno -> corGoldDia(chave)
            noturno                    -> corAzulNoite(chave)
            else                       -> corAzulDia(chave)
        }
        return try { Color.parseColor(hex) } catch (_: Exception) { Color.BLACK }
    }

    // Retrocompatibilidade
    fun cor(chave: String, noturno: Boolean): Int {
        val hex = if (noturno) corAzulNoite(chave) else corAzulDia(chave)
        return try { Color.parseColor(hex) } catch (_: Exception) { Color.BLACK }
    }

    fun aplicarTema(context: Context, view: android.view.View) {
        val prefs = context.getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        view.setBackgroundColor(cor("bg_dark", prefs))
    }
}
