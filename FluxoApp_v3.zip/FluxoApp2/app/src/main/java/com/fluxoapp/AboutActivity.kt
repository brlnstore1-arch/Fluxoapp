package com.fluxoapp

import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class AboutActivity : AppCompatActivity() {
    override fun attachBaseContext(base: android.content.Context) {
        super.attachBaseContext(FontHelper.wrap(base))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeSelector.aplicar(this)
        setContentView(R.layout.activity_about)
        aplicarTema()
        aplicarTemaGlobal()
        findViewById<ImageButton>(R.id.btnVoltar).setOnClickListener { finish() }
        try {
            val versionName = packageManager.getPackageInfo(packageName, 0).versionName
            val versionCode = packageManager.getPackageInfo(packageName, 0).versionCode
            findViewById<TextView>(R.id.tvVersao)?.text = "Versão $versionName (build $versionCode)"
        } catch (_: Throwable) {
            try { findViewById<TextView>(R.id.tvVersao)?.text = "Versão 3.0" } catch (_: Throwable) {}
        }

        // Diagnóstico — toque e segure no texto da versão pra ver o log
        // de verificação de atualização (últimas 30 etapas), sem precisar
        // de computador/logcat.
        findViewById<TextView>(R.id.tvVersao)?.setOnLongClickListener { mostrarDiagnosticoUpdate(); true }
        // Força uma nova verificação na hora, útil pra testar sem sair do app
        findViewById<TextView>(R.id.tvVersao)?.setOnClickListener {
            UpdateManager.verificar(this)
            android.widget.Toast.makeText(this, "🔄 Verificando atualização...", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    private fun mostrarDiagnosticoUpdate() {
        val prefs = getSharedPreferences("fluxo_config", MODE_PRIVATE)
        val log = prefs.getString("diag_update_log", "")
        val texto = if (log.isNullOrBlank()) {
            "Nenhum evento registrado ainda.\n\nToque uma vez no texto da versão para forçar uma verificação agora, depois segure de novo para ver o resultado."
        } else log

        android.app.AlertDialog.Builder(this)
            .setTitle("Diagnóstico — Verificação de Update")
            .setMessage(texto)
            .setPositiveButton("Fechar", null)
            .setNegativeButton("Limpar log") { _, _ -> prefs.edit().remove("diag_update_log").apply() }
            .show()
    }

    private fun aplicarTema() {
        val p  = getSharedPreferences("FluxoApp", MODE_PRIVATE)
        val bg     = ThemeHelper.cor("bg_dark",    p)
        val bgCard = ThemeHelper.cor("bg_card",    p)
        val accent = ThemeHelper.cor("accent_gold", p)
        val gold   = ThemeHelper.cor("accent_gold", p)
        val txtW   = ThemeHelper.cor("text_white",  p)
        val txtG   = ThemeHelper.cor("text_gray",   p)
        val border = ThemeHelper.cor("border",      p)
        val dp = resources.displayMetrics.density

        try {
            val root = window.decorView.rootView
            root.setBackgroundColor(bg)
        } catch (_: Throwable) {}

        // Tentar achar o layout raiz
        for (idNome in listOf("rootLayout", "rootLayoutAbout", "layoutAbout")) {
            try {
                val id = resources.getIdentifier(idNome, "id", packageName)
                if (id != 0) { findViewById<android.view.View>(id)?.setBackgroundColor(bg); break }
            } catch (_: Throwable) {}
        }

        try { findViewById<ImageButton>(R.id.btnVoltar)?.setColorFilter(accent) } catch (_: Throwable) {}

        // Colorir todos os TextViews da tela
        try {
            val root2 = window.decorView.rootView
            colorirTextViews(root2, txtW, txtG, accent, gold)
        } catch (_: Throwable) {}
    }

    private fun colorirTextViews(v: android.view.View, txtW: Int, txtG: Int, accent: Int, gold: Int) {
        if (v is android.widget.TextView) {
            val tag = v.tag?.toString() ?: ""
            when {
                v.id == R.id.btnVoltar -> { /* skip */ }
                tag == "accent" -> v.setTextColor(accent)
                tag == "gold"   -> v.setTextColor(gold)
                else -> v.setTextColor(txtW)
            }
        }
        // Colorir Views simples usadas como divisores (tag="divider")
        if (v !is android.view.ViewGroup) {
            val tag = v.tag?.toString() ?: ""
            if (tag == "divider") {
                try { v.setBackgroundColor(accent) } catch (_: Throwable) {}
            }
        }
        if (v is android.view.ViewGroup) {
            for (i in 0 until v.childCount) colorirTextViews(v.getChildAt(i), txtW, txtG, accent, gold)
        }
    }
}
