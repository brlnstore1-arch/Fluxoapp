package com.fluxoapp

import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class AboutActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)
        findViewById<ImageButton>(R.id.btnVoltar).setOnClickListener { finish() }
        findViewById<TextView>(R.id.tvVersao).text = "Versão 2.0"
    }
}
