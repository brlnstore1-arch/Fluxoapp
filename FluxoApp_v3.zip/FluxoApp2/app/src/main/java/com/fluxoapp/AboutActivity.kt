package com.fluxoapp

import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class AboutActivity : AppCompatActivity() {
    private var ultimoTemaChave = ""  // evita reaplica tema sem mudança
    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeSelector.aplicar(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)
        aplicarTema()
        aplicarTemaGlobal()
        findViewById<ImageButton>(R.id.btnVoltar).setOnClickListener { finish() }
        try { findViewById<TextView>(R.id.tvVersao)?.text = "Versão 3.0" } catch (_: Throwable) {}
    }

    override fun onResume() {
        super.onResume()
        val temaChave = ThemeSelector.getThemeRes(this).toString()
        if (temaChave != ultimoTemaChave) {
            try { aplicarTema() } catch (_: Throwable) {}
            try { aplicarTemaGlobal() } catch (_: Throwable) {}
            ultimoTemaChave = temaChave
        }
    }

    private fun aplicarTema() {
        val p  = getSharedPreferences("FluxoApp", MODE_PRIVATE)
        val bg     = ThemeHelper.cor("bg_dark",    p)
        val bgCard = ThemeHelper.cor("bg_card",    p)
        val accent = ThemeHelper.cor("accent_gold", p)
        val gold   = ThemeHelper.cor("accent_gold", p)
        val txtW   = ThemeHelper.cor("text_white",  p)
        val txtG   = ThemeHelper.cor("text_gray",   p)
        val border = ThemeHelper.cor("border",      p)
        val dp = resources.displayMetrics.density

        try {
            val root = window.decorView.rootView
            root.setBackgroundColor(bg)
        } catch (_: Throwable) {}

        // Tentar achar o layout raiz
        for (idNome in listOf("rootLayout", "rootLayoutAbout", "layoutAbout")) {
            try {
                val id = resources.getIdentifier(idNome, "id", packageName)
                if (id != 0) { findViewById<android.view.View>(id)?.setBackgroundColor(bg); break }
            } catch (_: Throwable) {}
        }

        try { findViewById<ImageButton>(R.id.btnVoltar)?.setColorFilter(accent) } catch (_: Throwable) {}

        // Colorir todos os TextViews da tela
        try {
            val root2 = window.decorView.rootView
            colorirTextViews(root2, txtW, txtG, accent, gold)
        } catch (_: Throwable) {}
    }

    private fun colorirTextViews(v: android.view.View, txtW: Int, txtG: Int, accent: Int, gold: Int) {
        if (v is android.widget.TextView) {
            val tag = v.tag?.toString() ?: ""
            when {
                v.id == R.id.btnVoltar -> { /* skip */ }
                tag == "accent" -> v.setTextColor(accent)
                tag == "gold"   -> v.setTextColor(gold)
                else -> v.setTextColor(txtW)
            }
        }
        // Colorir Views simples usadas como divisores (tag="divider")
        if (v !is android.view.ViewGroup) {
            val tag = v.tag?.toString() ?: ""
            if (tag == "divider") {
                try { v.setBackgroundColor(accent) } catch (_: Throwable) {}
            }
        }
        if (v is android.view.ViewGroup) {
            for (i in 0 until v.childCount) colorirTextViews(v.getChildAt(i), txtW, txtG, accent, gold)
        }
    }
}
