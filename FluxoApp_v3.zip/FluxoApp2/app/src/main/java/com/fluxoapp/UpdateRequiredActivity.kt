package com.fluxoapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class UpdateRequiredActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeSelector.aplicar(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update_required)
        val msg = intent.getStringExtra("mensagem") ?: "Atualize o app para continuar."
        findViewById<TextView>(R.id.tvUpdateMsg)?.text = msg
        findViewById<Button>(R.id.btnAtualizar)?.setOnClickListener {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName"))) }
            catch (e: Exception) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName"))) }
        }
    }
    @Suppress("DEPRECATION")
    override fun onBackPressed() {}
}
