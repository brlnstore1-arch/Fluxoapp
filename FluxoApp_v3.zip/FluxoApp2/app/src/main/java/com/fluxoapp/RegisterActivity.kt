package com.fluxoapp

import android.content.Context
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest

class RegisterActivity : AppCompatActivity() {

    private val auth by lazy { FirebaseAuth.getInstance() }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeSelector.aplicar(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        aplicarTema()
        configurarBotoes()
    }

    private fun aplicarTema() {
        val prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val dp    = resources.displayMetrics.density

        val bgDark  = ThemeHelper.cor("bg_dark",    prefs)
        val accent  = ThemeHelper.cor("accent",     prefs)
        val txtW    = ThemeHelper.cor("text_white", prefs)
        val txtG    = ThemeHelper.cor("text_gray",  prefs)
        val border  = ThemeHelper.cor("border",     prefs)

        findViewById<View>(R.id.rootRegister).setBackgroundColor(bgDark)

        // Logo
        findViewById<TextView>(R.id.tvLogoRegister).setTextColor(accent)

        // Labels
        listOf(R.id.tvLabelNome, R.id.tvLabelEmailRegister, R.id.tvLabelSenhaRegister).forEach {
            findViewById<TextView>(it).setTextColor(txtG)
        }

        // Campos
        listOf(R.id.etNomeRegister, R.id.etEmailRegister, R.id.etSenhaRegister).forEach {
            val et = findViewById<EditText>(it)
            et.setTextColor(txtW)
            et.setHintTextColor(txtG)
        }

        // Botão cadastrar
        val btnCadastrar = findViewById<Button>(R.id.btnCadastrar)
        btnCadastrar.backgroundTintList = null  // remove tint do Material que sobrescreve o background
        GradientDrawable().apply {
            setColor(accent)
            cornerRadius = 12 * dp
        }.also { btnCadastrar.background = it }
        btnCadastrar.setTextColor(bgDark)

        // Divisor
        findViewById<View>(R.id.viewDivisorRegister).setBackgroundColor(border)

        // Link login
        findViewById<TextView>(R.id.tvVoltarLogin).setTextColor(accent)
    }

    private fun configurarBotoes() {
        val etNome    = findViewById<EditText>(R.id.etNomeRegister)
        val etEmail   = findViewById<EditText>(R.id.etEmailRegister)
        val etSenha   = findViewById<EditText>(R.id.etSenhaRegister)
        val tvErro    = findViewById<TextView>(R.id.tvErroCadastro)
        val btnCad    = findViewById<Button>(R.id.btnCadastrar)

        btnCad.setOnClickListener {
            val nome  = etNome.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val senha = etSenha.text.toString()

            tvErro.visibility = View.GONE

            if (nome.isEmpty())        { mostrarErro(tvErro, "Informe seu nome");          return@setOnClickListener }
            if (email.isEmpty())       { mostrarErro(tvErro, "Informe o e-mail");           return@setOnClickListener }
            if (senha.length < 6)      { mostrarErro(tvErro, "A senha deve ter ao menos 6 caracteres"); return@setOnClickListener }

            btnCad.isEnabled = false
            btnCad.text      = "Criando conta..."
            esconderTeclado()

            auth.createUserWithEmailAndPassword(email, senha)
                .addOnSuccessListener { result ->
                    val user = result.user ?: return@addOnSuccessListener

                    // Salvar nome no perfil Firebase
                    val update = UserProfileChangeRequest.Builder()
                        .setDisplayName(nome)
                        .build()
                    user.updateProfile(update)

                    // Criar documento no Firestore com trial de 7 dias
                    LicenseManager.criarDocumentoTrial(user.uid, email, nome)

                    // Salvar nome localmente também
                    getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
                        .edit()
                        .putString("perfil_nome", nome)
                        .apply()

                    irParaMain()
                }
                .addOnFailureListener { e ->
                    btnCad.isEnabled = true
                    btnCad.text      = "CRIAR CONTA E COMEÇAR"
                    mostrarErro(tvErro, traduzirErroFirebase(e.message))
                }
        }

        findViewById<TextView>(R.id.tvVoltarLogin).setOnClickListener {
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
    }

    private fun mostrarErro(tv: TextView, msg: String) {
        tv.text       = msg
        tv.visibility = View.VISIBLE
    }

    private fun irParaMain() {
        startActivity(Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        })
        finish()
    }

    private fun esconderTeclado() {
        currentFocus?.let {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .hideSoftInputFromWindow(it.windowToken, 0)
        }
    }

    private fun traduzirErroFirebase(msg: String?): String = when {
        msg == null                          -> "Erro desconhecido. Tente novamente."
        msg.contains("email address is already") -> "Este e-mail já está cadastrado."
        msg.contains("badly formatted")      -> "E-mail inválido."
        msg.contains("network")              -> "Sem conexão com a internet."
        else                                 -> "Erro ao criar conta. Tente novamente."
    }
}
