package com.fluxoapp

import android.content.Context
import androidx.appcompat.app.AppCompatActivity

/**
 * Seleciona e aplica o tema XML correto ANTES do setContentView.
 * Isso resolve o crash no MIUI/Xiaomi — o framework aplica as cores
 * corretamente sem precisar percorrer a hierarquia programaticamente.
 *
 * Uso em qualquer Activity:
 *   override fun onCreate(savedInstanceState: Bundle?) {
 *       super.onCreate(savedInstanceState)
 *       ThemeSelector.aplicar(this)
 *       setContentView(R.layout.activity_xxx)
 *       ...
 *   }
 */
object ThemeSelector {

    fun getThemeRes(context: Context): Int {
        val prefs  = context.getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val tema   = ThemeHelper.getTema(prefs)
        val noturno = ThemeHelper.isModoNoturno(prefs)
        return when {
            tema == "gold" && noturno  -> R.style.Theme_FluxoApp_GoldNoite
            tema == "gold" && !noturno -> R.style.Theme_FluxoApp_GoldDia
            noturno                    -> R.style.Theme_FluxoApp_AzulNoite
            else                       -> R.style.Theme_FluxoApp_AzulDia
        }
    }

    fun aplicar(activity: AppCompatActivity) {
        activity.setTheme(getThemeRes(activity))
    }
}
