package com.fluxoapp

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FinanceActivity : AppCompatActivity() {

    private lateinit var tvSaudacao: TextView
    private lateinit var tvDataAtual: TextView
    private lateinit var tvLucroHoje: TextView
    private lateinit var tvGanhoHoje: TextView
    private lateinit var tvCustoHoje: TextView
    private lateinit var tvAtualizado: TextView
    private lateinit var tvPercentualAutonomia: TextView
    private lateinit var tvKmAutonomia: TextView
    private lateinit var tvLitrosRestantes: TextView
    private lateinit var tvAutonomiaEstimada: TextView
    private lateinit var tvDesdeAbastecimento: TextView
    private lateinit var tvConsumoMedio: TextView
    private lateinit var tvOdometro: TextView
    private lateinit var tvKmHoje: TextView
    private lateinit var tvRodape: TextView
    private lateinit var btnEditarCalc: Button
    private lateinit var btnNovoAbastecimento: Button
    private lateinit var btnRegistrarKm: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_finance)

        // Inicializar views
        initViews()

        // Configurar data e saudação
        setupHeader()

        // Configurar dados de exemplo (substituir por dados reais)
        setupSampleData()

        // Configurar listeners dos botões
        setupButtonListeners()
    }

    private fun initViews() {
        tvSaudacao = findViewById(R.id.tvSaudacao)
        tvDataAtual = findViewById(R.id.tvDataAtual)
        tvLucroHoje = findViewById(R.id.tvLucroHoje)
        tvGanhoHoje = findViewById(R.id.tvGanhoHoje)
        tvCustoHoje = findViewById(R.id.tvCustoHoje)
        tvAtualizado = findViewById(R.id.tvAtualizado)
        tvPercentualAutonomia = findViewById(R.id.tvPercentualAutonomia)
        tvKmAutonomia = findViewById(R.id.tvKmAutonomia)
        tvLitrosRestantes = findViewById(R.id.tvLitrosRestantes)
        tvAutonomiaEstimada = findViewById(R.id.tvAutonomiaEstimada)
        tvDesdeAbastecimento = findViewById(R.id.tvDesdeAbastecimento)
        tvConsumoMedio = findViewById(R.id.tvConsumoMedio)
        tvOdometro = findViewById(R.id.tvOdometro)
        tvKmHoje = findViewById(R.id.tvKmHoje)
        tvRodape = findViewById(R.id.tvRodape)
        btnEditarCalc = findViewById(R.id.btnEditarCalc)
        btnNovoAbastecimento = findViewById(R.id.btnNovoAbastecimento)
        btnRegistrarKm = findViewById(R.id.btnRegistrarKm)
    }

    private fun setupHeader() {
        // Formatar data atual
        val dateFormat = SimpleDateFormat("EEEE, d 'de' MMMM", Locale("pt", "BR"))
        val currentDate = dateFormat.format(Date())
        
        // Capitalizar primeira letra do dia da semana
        val formattedDate = currentDate.replaceFirstChar { 
            if (it.isLowerCase()) it.titlecase(Locale("pt", "BR")) else it.toString() 
        }
        
        tvDataAtual.text = formattedDate
    }

    private fun setupSampleData() {
        // Dados de exemplo - substituir por dados reais do seu app
        tvLucroHoje.text = "R$ 0,00"
        tvGanhoHoje.text = "R$ 0,00"
        tvCustoHoje.text = "-R$ 0,00"
        
        // Autonomia
        tvPercentualAutonomia.text = "93%"
        tvKmAutonomia.text = "82 km"
        tvLitrosRestantes.text = "2,7 L"
        tvAutonomiaEstimada.text = "~82 km"
        tvDesdeAbastecimento.text = "5,4 km"
        
        // Métricas
        tvConsumoMedio.text = "30,0 km/L"
        tvOdometro.text = "326"
        tvKmHoje.text = "0,0"
        
        // Rodapé
        tvRodape.text = "0,0 km rodados hoje · Última atualização: agora"
    }

    private fun setupButtonListeners() {
        btnEditarCalc.setOnClickListener {
            // Implementar ação de editar cálculo de combustível
        }

        btnNovoAbastecimento.setOnClickListener {
            // Implementar ação de novo abastecimento
        }

        btnRegistrarKm.setOnClickListener {
            // Implementar ação de registrar hodômetro
        }
    }

    // Método para atualizar dados (chamar quando houver atualização)
    fun atualizarDadosFinanceiros(
        lucro: String,
        ganho: String,
        custo: String,
        autonomiaPercent: Int,
        kmAutonomia: String,
        litrosRestantes: String,
        autonomiaEstimada: String,
        kmDesdeAbastecimento: String,
        consumoMedio: String,
        odometro: String,
        kmHoje: String
    ) {
        tvLucroHoje.text = lucro
        tvGanhoHoje.text = ganho
        tvCustoHoje.text = custo
        tvPercentualAutonomia.text = "$autonomiaPercent%"
        tvKmAutonomia.text = kmAutonomia
        tvLitrosRestantes.text = litrosRestantes
        tvAutonomiaEstimada.text = autonomiaEstimada
        tvDesdeAbastecimento.text = kmDesdeAbastecimento
        tvConsumoMedio.text = consumoMedio
        tvOdometro.text = odometro
        tvKmHoje.text = kmHoje
        
        // Atualizar rodapé com hora atual
        val timeFormat = SimpleDateFormat("HH:mm", Locale("pt", "BR"))
        val currentTime = timeFormat.format(Date())
        tvRodape.text = "$kmHoje km rodados hoje · Última atualização: $currentTime"
    }
}