package com.fluxoapp

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class FinanceActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private lateinit var prefs: android.content.SharedPreferences

    override fun attachBaseContext(base: android.content.Context) {
        super.attachBaseContext(FontHelper.wrap(base))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeSelector.aplicar(this)
        setContentView(R.layout.activity_finance)
        db    = DatabaseHelper(this)
        prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        aplicarTema()
        aplicarTemaGlobal()
        configurarHeader()
        configurarBotoes()
        atualizarResumo()
    }

    override fun onResume() {
        super.onResume()
        configurarHeader()
        atualizarResumo()
    }

    // ── HEADER ────────────────────────────────────────────────
    private fun configurarHeader() {
        try {
            // Nome do motorista
            val nome = prefs.getString("nome_usuario", null)
                ?: com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.displayName
                ?: "Motorista"
            val primeiroNome = nome.split(" ").firstOrNull() ?: nome
            findViewById<TextView>(R.id.tvNomeMotorista)?.text = "Olá, $primeiroNome"
        } catch (_: Throwable) {}
        try {
            // Data de hoje
            val sdf = SimpleDateFormat("EEEE, dd 'de' MMMM", Locale("pt", "BR"))
            val data = sdf.format(Date())
            val dataCapitalizada = data.replaceFirstChar { it.uppercase() }
            findViewById<TextView>(R.id.tvDataHoje)?.text = dataCapitalizada
        } catch (_: Throwable) {}
    }

    // ── RESUMO FINANCEIRO ─────────────────────────────────────
    private fun atualizarResumo() {
        val corridas   = db.buscarHoje()
        val ganhoHoje  = db.resumo(corridas)["total"] ?: 0f

        val consumo    = prefs.getFloat("consumo_km_litro", 35f)
        val precoComb  = prefs.getFloat("preco_combustivel", 6.50f)
        val kmCorridas = db.resumo(corridas)["km_total"] ?: 0f
        val kmGps      = KmTrackerService.kmHoje(this)
        val kmHoje     = if (kmGps > kmCorridas) kmGps else kmCorridas
        val custoHoje  = if (consumo > 0) (kmHoje / consumo) * precoComb else 0f
        val lucroHoje  = ganhoHoje - custoHoje
        val ultimoKm   = db.ultimoKmOdometro()

        try {
            // Card 1 - valores
            findViewById<TextView>(R.id.tvGanhoHoje)?.text  = "R$ ${"%.2f".format(ganhoHoje)}"
            findViewById<TextView>(R.id.tvCustoHoje)?.text  = "- R$ ${"%.2f".format(custoHoje)}"
            findViewById<TextView>(R.id.tvLucroHoje)?.text  = "R$ ${"%.2f".format(lucroHoje)}"

            // Cor do lucro
            val green = ThemeHelper.cor("accent_green", prefs)
            val red   = ThemeHelper.cor("accent_red", prefs)
            findViewById<TextView>(R.id.tvLucroHoje)?.setTextColor(
                if (lucroHoje >= 0) Color.WHITE else red
            )

            // Sub-cards: km/L, Odômetro, Rodado hoje
            val kmLStr = if (consumo > 0) "%.1f".format(consumo) else "—"
            findViewById<TextView>(R.id.tvKmPorLitro)?.text = kmLStr

            val odoStr = if (ultimoKm > 0) "%.0f".format(ultimoKm) else "—"
            findViewById<TextView>(R.id.tvOdometro)?.text = odoStr

            val kmHojeStr = "%.1f".format(kmHoje)
            findViewById<TextView>(R.id.tvKmHoje)?.text = kmHojeStr

            // Footer
            val horaStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            findViewById<TextView>(R.id.tvFooterKm)?.text =
                "$kmHojeStr km rodados hoje · Última atualização: $horaStr"
            findViewById<TextView>(R.id.tvUltimaAtualizacao)?.text = "Atualizado às $horaStr"

            // Autonomia
            calcularAutonomia()

        } catch (_: Throwable) {}
    }

    private fun calcularAutonomia() {
        try {
            val consumo  = prefs.getFloat("consumo_km_litro", 35f)
            val abastecs = db.buscarAbastecimentos()

            if (abastecs.isEmpty() || consumo <= 0f) {
                // Sem dados: mostra zeros
                findViewById<TextView>(R.id.tvPctCircle)?.text      = "0%"
                findViewById<TextView>(R.id.tvKmCircle)?.text       = "sem dados"
                findViewById<TextView>(R.id.tvLitrosRestantes)?.text = "—"
                findViewById<TextView>(R.id.tvAutonomiaEst)?.text   = "—"
                findViewById<TextView>(R.id.tvDesdeAbastec)?.text   = "—"
                findViewById<ProgressBar>(R.id.progressCombustivel)?.progress = 0
                findViewById<ProgressBar>(R.id.progressLitros)?.progress = 0
                return
            }

            val ultimo      = abastecs.first()
            val litros      = ultimo.litros
            val kmAutonom   = litros * consumo  // km que o abastecimento inteiro dá

            // km desde o último abastecimento
            val tsAbast       = ultimo.timestamp
            val corridasDesde = db.buscarTodas().filter { it.timestamp >= tsAbast }
            val kmPercorrido  = corridasDesde.sumOf { it.kmTotal.toDouble() }.toFloat()

            // km e litros restantes estimados
            val kmRestante    = (kmAutonom - kmPercorrido).coerceAtLeast(0f)
            val litrosRestant = if (consumo > 0) kmRestante / consumo else 0f
            val pct           = if (kmAutonom > 0f) ((kmRestante / kmAutonom) * 100).toInt().coerceIn(0, 100) else 0

            // Cor do progresso circular por nível
            val corCircle = when {
                pct > 50 -> ThemeHelper.cor("accent_green", prefs)
                pct > 20 -> Color.parseColor("#FFD740")
                else     -> ThemeHelper.cor("accent_red", prefs)
            }

            // Atualizar views
            findViewById<TextView>(R.id.tvPctCircle)?.text       = "$pct%"
            findViewById<TextView>(R.id.tvKmCircle)?.text        = "${"%.0f".format(kmRestante)} km"
            findViewById<TextView>(R.id.tvLitrosRestantes)?.text = "${"%.1f".format(litrosRestant)} L"
            findViewById<TextView>(R.id.tvAutonomiaEst)?.text    = "~${"%.0f".format(kmRestante)} km"
            findViewById<TextView>(R.id.tvDesdeAbastec)?.text    = "${"%.1f".format(kmPercorrido)} km"

            // Progresso circular
            findViewById<ProgressBar>(R.id.progressCombustivel)?.apply {
                progress = pct
                val drawable = progressDrawable?.mutate()
                val corTint  = android.content.res.ColorStateList.valueOf(corCircle)
                drawable?.let {
                    (it as? android.graphics.drawable.LayerDrawable)
                        ?.findDrawableByLayerId(android.R.id.progress)
                        ?.let { prog ->
                            (prog as? android.graphics.drawable.RotateDrawable)
                                ?.drawable?.setTint(corCircle)
                        }
                }
                progressTintList = corTint
            }

            // Barra horizontal de litros
            findViewById<ProgressBar>(R.id.progressLitros)?.apply {
                progress = pct
                val corTint = when {
                    pct > 50 -> ThemeHelper.cor("accent_green", prefs)
                    pct > 20 -> Color.parseColor("#FFD740")
                    else     -> ThemeHelper.cor("accent_red", prefs)
                }
                progressTintList = android.content.res.ColorStateList.valueOf(corTint)
            }

            // Compat: tvAutonomia (oculto)
            try {
                findViewById<TextView>(R.id.tvAutonomia)?.text =
                    "Autonomia: ${"%.0f".format(kmRestante)} km ($pct%)"
            } catch (_: Throwable) {}

        } catch (_: Throwable) {}
    }

    // ── BOTÕES ────────────────────────────────────────────────
    private fun configurarBotoes() {
        try { findViewById<ImageButton>(R.id.btnVoltar)?.setOnClickListener { finish() } } catch (_: Throwable) {}
        try { findViewById<ImageButton>(R.id.btnNotificacao)?.setOnClickListener {
            FluxoToast.info(this, "Sem notificações novas")
        }} catch (_: Throwable) {}

        // Abastecimento colapsável
        try {
            val cardAbast = findViewById<android.view.View>(R.id.cardAbastecimento)
            findViewById<Button>(R.id.btnNovoAbastecimento)?.setOnClickListener {
                val visible = cardAbast?.visibility == android.view.View.VISIBLE
                if (visible) {
                    cardAbast?.visibility = android.view.View.GONE
                } else {
                    cardAbast?.visibility = android.view.View.VISIBLE
                    cardAbast?.alpha = 0f
                    cardAbast?.animate()?.alpha(1f)?.setDuration(250)?.start()
                    try {
                        val sv = findViewById<ScrollView>(R.id.scrollFinance)
                        sv?.post { sv.smoothScrollTo(0, cardAbast?.top ?: 0) }
                    } catch (_: Throwable) {}
                }
            }
            findViewById<Button>(R.id.btnSalvarAbastecimento)?.setOnClickListener {
                salvarAbastecimento()
                cardAbast?.visibility = android.view.View.GONE
            }
        } catch (_: Throwable) {}

        // Calculadora
        try {
            findViewById<Button>(R.id.btnEditarCalc)?.setOnClickListener {
                mostrarDialogoCalculadora()
            }
        } catch (_: Throwable) {}

        // Hodômetro
        try {
            findViewById<Button>(R.id.btnRegistrarKm)?.setOnClickListener {
                mostrarDialogoRegistrarKm()
            }
        } catch (_: Throwable) {}
    }

    // ── CALCULADORA DE LUCRO REAL ─────────────────────────────
    private fun mostrarDialogoCalculadora() {
        val p      = prefs
        val accent = ThemeHelper.cor("accent_gold", p)
        val bgCard = ThemeHelper.cor("bg_card", p)
        val txtW   = ThemeHelper.cor("text_white", p)
        val dp     = resources.displayMetrics.density

        val consumo   = prefs.getFloat("consumo_km_litro", 35f)
        val precoComb = prefs.getFloat("preco_combustivel", 6.50f)

        val layout = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setBackgroundColor(bgCard)
            setPadding((16*dp).toInt(), (12*dp).toInt(), (16*dp).toInt(), (12*dp).toInt())
        }

        fun label(txt: String) = android.widget.TextView(this).apply {
            text = txt; textSize = 12f
            setTextColor(ThemeHelper.cor("text_gray", p))
            setPadding(0, (8*dp).toInt(), 0, (2*dp).toInt())
        }
        fun campo(valor: String) = android.widget.EditText(this).apply {
            setText(valor)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            textSize = 16f; setTextColor(txtW)
            setBackgroundColor(Color.TRANSPARENT)
        }

        val etConsumo = campo("%.1f".format(consumo))
        val etPreco   = campo("%.2f".format(precoComb))

        layout.addView(label("Consumo da moto (km/litro)"))
        layout.addView(etConsumo)
        layout.addView(label("Preço do combustível (R$/litro)"))
        layout.addView(etPreco)

        android.app.AlertDialog.Builder(this)
            .setTitle("⛽ Calculadora de Lucro Real")
            .setView(layout)
            .setPositiveButton("Salvar") { _, _ ->
                val c  = etConsumo.text.toString().replace(",",".").toFloatOrNull() ?: 35f
                val p2 = etPreco.text.toString().replace(",",".").toFloatOrNull() ?: 6.50f
                prefs.edit()
                    .putFloat("consumo_km_litro", c)
                    .putFloat("preco_combustivel", p2)
                    .apply()
                atualizarResumo()
                FluxoToast.info(this, "Calculadora atualizada")
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ── CORRIDA MANUAL ────────────────────────────────────────
    private fun mostrarDialogoCorridaManual() {
        val p      = prefs
        val bgCard = ThemeHelper.cor("bg_card", p)
        val txtW   = ThemeHelper.cor("text_white", p)
        val txtG   = ThemeHelper.cor("text_gray", p)
        val dp     = resources.displayMetrics.density

        val scroll = android.widget.ScrollView(this)
        val layout = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setBackgroundColor(bgCard)
            setPadding((16*dp).toInt(), (12*dp).toInt(), (16*dp).toInt(), (16*dp).toInt())
        }
        scroll.addView(layout)

        fun label(txt: String) = android.widget.TextView(this).apply {
            text = txt; textSize = 12f; setTextColor(txtG)
            setPadding(0, (10*dp).toInt(), 0, (2*dp).toInt())
        }
        fun campo(hint: String, tipo: Int = android.text.InputType.TYPE_CLASS_TEXT) =
            android.widget.EditText(this).apply {
                this.hint = hint; inputType = tipo
                textSize = 14f; setTextColor(txtW); setHintTextColor(txtG)
                setBackgroundColor(Color.TRANSPARENT)
            }

        val etValor   = campo("Ex: 4.80", android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val etKm      = campo("Ex: 2.50", android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val etOrigem  = campo("Endereço de origem")
        val etDestino = campo("Endereço de destino")
        val etPag     = campo("Dinheiro / PIX / Cartão")

        val sdf  = SimpleDateFormat("HH:mm", Locale.getDefault())
        val sdfD = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val etHora = campo(sdf.format(Date()))
        val etData = campo(sdfD.format(Date()))
        etHora.setText(sdf.format(Date()))
        etData.setText(sdfD.format(Date()))

        layout.addView(label("Valor (R$) *")); layout.addView(etValor)
        layout.addView(label("Distância (km)")); layout.addView(etKm)
        layout.addView(label("Forma de pagamento")); layout.addView(etPag)
        layout.addView(label("Origem")); layout.addView(etOrigem)
        layout.addView(label("Destino")); layout.addView(etDestino)
        layout.addView(label("Hora")); layout.addView(etHora)
        layout.addView(label("Data (dd/MM/yyyy)")); layout.addView(etData)

        android.app.AlertDialog.Builder(this)
            .setTitle("➕ Adicionar Corrida Manual")
            .setView(scroll)
            .setPositiveButton("Salvar") { _, _ ->
                val valor = etValor.text.toString().replace(",",".").toFloatOrNull()
                if (valor == null || valor <= 0f) { FluxoToast.erro(this, "Valor inválido"); return@setPositiveButton }
                val km    = etKm.text.toString().replace(",",".").toFloatOrNull() ?: 0f
                val gkm   = if (km > 0f) valor / km else 0f
                val min   = prefs.getFloat("minimo_km", 1.20f)
                val dataStr = etData.text.toString().ifBlank { sdfD.format(Date()) }
                val horaStr = etHora.text.toString().ifBlank { sdf.format(Date()) }
                val ts = try {
                    SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).parse("$dataStr $horaStr")?.time ?: System.currentTimeMillis()
                } catch (_: Throwable) { System.currentTimeMillis() }
                val cal = Calendar.getInstance().apply { timeInMillis = ts }
                val mes = "%02d/%04d".format(cal.get(Calendar.MONTH)+1, cal.get(Calendar.YEAR))
                val ano = "%04d".format(cal.get(Calendar.YEAR))
                db.inserirCorridaManual(Corrida(
                    valor = valor, kmTotal = km, ganhoPorKm = gkm, valeAPena = gkm >= min,
                    timestamp = ts, data = dataStr, hora = horaStr, mes = mes, ano = ano,
                    origem = etOrigem.text.toString(), destino = etDestino.text.toString(),
                    formaPagamento = etPag.text.toString()
                ))
                atualizarResumo()
                try { startService(android.content.Intent(this, FloatingEarningsService::class.java).apply { action = "ATUALIZAR" }) } catch (_: Throwable) {}
                FluxoToast.sucesso(this, "Corrida adicionada: R$${"%.2f".format(valor)}")
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ── REGISTRO DE QUILOMETRAGEM ─────────────────────────────
    private fun mostrarDialogoRegistrarKm() {
        val p      = prefs
        val bgCard = ThemeHelper.cor("bg_card", p)
        val txtW   = ThemeHelper.cor("text_white", p)
        val txtG   = ThemeHelper.cor("text_gray", p)
        val dp     = resources.displayMetrics.density
        val ultimoKm = db.ultimoKmOdometro()

        val layout = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setBackgroundColor(bgCard)
            setPadding((16*dp).toInt(), (12*dp).toInt(), (16*dp).toInt(), (16*dp).toInt())
        }

        if (ultimoKm > 0f) {
            layout.addView(android.widget.TextView(this).apply {
                text = "Último registro: ${"%.0f".format(ultimoKm)} km"
                textSize = 12f; setTextColor(txtG)
                setPadding(0, 0, 0, (8*dp).toInt())
            })
        }

        val etKm = android.widget.EditText(this).apply {
            hint = "Odômetro atual (km)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            textSize = 18f; setTextColor(txtW); setHintTextColor(txtG)
            setBackgroundColor(Color.TRANSPARENT)
        }
        val etObs = android.widget.EditText(this).apply {
            hint = "Observação (opcional)"
            textSize = 13f; setTextColor(txtW); setHintTextColor(txtG)
            setBackgroundColor(Color.TRANSPARENT)
        }

        layout.addView(android.widget.TextView(this).apply {
            text = "Leitura do odômetro (km)"; textSize = 12f; setTextColor(txtG)
            setPadding(0, 0, 0, (4*dp).toInt())
        })
        layout.addView(etKm)
        layout.addView(android.widget.TextView(this).apply {
            text = "Observação"; textSize = 12f; setTextColor(txtG)
            setPadding(0, (12*dp).toInt(), 0, (4*dp).toInt())
        })
        layout.addView(etObs)

        val registros = db.buscarKm()
        if (registros.isNotEmpty()) {
            layout.addView(android.widget.TextView(this).apply {
                text = "\nÚltimos registros:"; textSize = 12f; setTextColor(txtG)
            })
            registros.take(5).forEach { (_, km, data) ->
                layout.addView(android.widget.TextView(this).apply {
                    text = "  $data → ${"%.0f".format(km)} km"
                    textSize = 12f; setTextColor(txtW)
                })
            }
        }

        android.app.AlertDialog.Builder(this)
            .setTitle("🏍️ Registrar Quilometragem")
            .setView(layout)
            .setPositiveButton("Registrar") { _, _ ->
                val km = etKm.text.toString().replace(",",".").toFloatOrNull()
                if (km == null || km <= 0f) { FluxoToast.aviso(this, "Informe o km do odômetro"); return@setPositiveButton }
                db.registrarKm(km, etObs.text.toString())
                atualizarResumo()
                FluxoToast.sucesso(this, "Km registrado: ${"%.0f".format(km)} km")
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ── ABASTECIMENTO ─────────────────────────────────────────
    private fun salvarAbastecimento() {
        try {
            val litros = findViewById<EditText>(R.id.etLitros)?.text.toString().replace(",",".").toFloatOrNull() ?: 0f
            val valor  = findViewById<EditText>(R.id.etValorAbastecimento)?.text.toString().replace(",",".").toFloatOrNull() ?: 0f
            val km     = findViewById<EditText>(R.id.etKmAtual)?.text.toString().replace(",",".").toFloatOrNull() ?: 0f

            if (litros <= 0f || valor <= 0f) { FluxoToast.aviso(this, "Informe litros e valor"); return }
            val preco = valor / litros
            db.inserirAbastecimento(Abastecimento(litros = litros, valorTotal = valor, precoPorLitro = preco, kmAtual = km))
            if (km > 0f) db.registrarKm(km, "Abastecimento")

            findViewById<EditText>(R.id.etLitros)?.setText("")
            findViewById<EditText>(R.id.etValorAbastecimento)?.setText("")
            findViewById<EditText>(R.id.etKmAtual)?.setText("")
            atualizarResumo()
            FluxoToast.sucesso(this, "⛽ ${litros}L · R$${"%.2f".format(valor)} · R$${"%.2f".format(preco)}/L")
        } catch (_: Throwable) {
            FluxoToast.erro(this, "Erro ao salvar")
        }
    }

    // ── TEMA ─────────────────────────────────────────────────
    private fun aplicarTema() {
        val p      = prefs
        val accent = ThemeHelper.cor("accent_gold", p)
        val bg     = ThemeHelper.cor("bg_dark", p)
        val bgCard = ThemeHelper.cor("bg_card", p)
        val bgSect = ThemeHelper.cor("bg_section", p)
        val txtW   = ThemeHelper.cor("text_white", p)
        val txtG   = ThemeHelper.cor("text_gray", p)
        val green  = ThemeHelper.cor("accent_green", p)
        val dp     = resources.displayMetrics.density

        fun gd(cor: Int, radius: Float = 10f) = GradientDrawable().apply {
            setColor(cor); cornerRadius = radius * dp
        }
        fun gdOutline(radius: Float = 10f) = GradientDrawable().apply {
            setColor(Color.TRANSPARENT); cornerRadius = radius * dp
            setStroke((1.5f * dp).toInt(), accent)
        }
        fun gdCard(radius: Float = 16f) = GradientDrawable().apply {
            setColor(bgCard); cornerRadius = radius * dp
            setStroke((1 * dp).toInt(), ThemeHelper.cor("border", p))
        }
        fun gdSect(radius: Float = 10f) = GradientDrawable().apply {
            setColor(bgSect); cornerRadius = radius * dp
        }

        try { findViewById<android.view.View>(R.id.scrollFinance)?.setBackgroundColor(bg) } catch (_: Throwable) {}
        try { findViewById<ImageButton>(R.id.btnVoltar)?.setColorFilter(green) } catch (_: Throwable) {}

        // Textos
        try { findViewById<TextView>(R.id.tvNomeMotorista)?.setTextColor(txtW) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvDataHoje)?.setTextColor(txtG) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvLucroHoje)?.setTextColor(txtW) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvGanhoHoje)?.setTextColor(green) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvCustoHoje)?.setTextColor(Color.parseColor("#FF5252")) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvUltimaAtualizacao)?.setTextColor(txtG) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvPctCircle)?.setTextColor(txtW) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvKmCircle)?.setTextColor(txtG) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvLitrosRestantes)?.setTextColor(txtW) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvAutonomiaEst)?.setTextColor(txtW) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvDesdeAbastec)?.setTextColor(txtW) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvKmPorLitro)?.setTextColor(txtW) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvOdometro)?.setTextColor(txtW) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvKmHoje)?.setTextColor(txtW) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvFooterKm)?.setTextColor(txtG) } catch (_: Throwable) {}

        // Botões
        try { findViewById<Button>(R.id.btnSalvarAbastecimento)?.apply {
            background = gd(green); setTextColor(Color.BLACK)
        }} catch (_: Throwable) {}
        for (id in listOf(R.id.btnEditarCalc, R.id.btnNovoAbastecimento, R.id.btnRegistrarKm)) {
            try { findViewById<Button>(id)?.apply {
                background = gdOutline(); setTextColor(accent)
            }} catch (_: Throwable) {}
        }
    }
}
