package com.fluxoapp

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class FinanceActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private lateinit var prefs: android.content.SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_finance)
        db    = DatabaseHelper(this)
        prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        aplicarTema()
        aplicarTemaGlobal()
        configurarBotoes()
        atualizarResumo()
    }

    override fun onResume() {
        super.onResume()
        atualizarResumo()
    }

    // ── RESUMO FINANCEIRO ─────────────────────────────────────
    private fun atualizarResumo() {
        val corridas   = db.buscarHoje()
        val ganhoHoje  = db.resumo(corridas)["total"] ?: 0f
        val totalKm    = db.resumo(db.buscarTodas())["km_total"] ?: 0f

        // Lê parâmetros da calculadora de lucro
        val consumo    = prefs.getFloat("consumo_km_litro", 35f)   // km por litro
        val precoComb  = prefs.getFloat("preco_combustivel", 6.50f) // R$/litro
        val kmHoje     = db.resumo(corridas)["km_total"] ?: 0f
        val custoHoje  = if (consumo > 0) (kmHoje / consumo) * precoComb else 0f
        val lucroHoje  = ganhoHoje - custoHoje

        // Odômetro
        val ultimoKm   = db.ultimoKmOdometro()

        try {
            findViewById<TextView>(R.id.tvGanhoHoje)?.text  = "R$ ${"%.2f".format(ganhoHoje)}"
            findViewById<TextView>(R.id.tvCustoHoje)?.text  = "- R$ ${"%.2f".format(custoHoje)}"
            findViewById<TextView>(R.id.tvLucroHoje)?.text  = "R$ ${"%.2f".format(lucroHoje)}"
            findViewById<TextView>(R.id.tvKmHoje)?.text     = "${"%.1f".format(kmHoje)} km rodados hoje"
            findViewById<TextView>(R.id.tvOdometro)?.text   = if (ultimoKm > 0)
                "Odômetro: ${"%.0f".format(ultimoKm)} km" else "Odômetro: não registrado"

            // Cor do lucro: verde se positivo, vermelho se negativo
            val p = prefs
            val green = ThemeHelper.cor("accent_green", p)
            val red   = ThemeHelper.cor("accent_red", p)
            findViewById<TextView>(R.id.tvLucroHoje)?.setTextColor(if (lucroHoje >= 0) green else red)

            // ── AUTONOMIA: km restantes desde o último abastecimento ──
            calcularAutonomia()

        } catch (_: Throwable) {}
    }

    private fun calcularAutonomia() {
        try {
            val consumo   = prefs.getFloat("consumo_km_litro", 35f)
            val abastecs  = db.buscarAbastecimentos()
            if (abastecs.isEmpty() || consumo <= 0f) {
                findViewById<android.widget.TextView>(R.id.tvAutonomia)?.text =
                    "Registre um abastecimento para ver a autonomia"
                return
            }

            // Último abastecimento
            val ultimo = abastecs.first()
            val litros = ultimo.litros
            val kmAutonom = litros * consumo   // km total que aquele abast. dá

            // km das corridas DESDE aquele abastecimento
            val tsAbast = ultimo.timestamp
            val corridasDesdeAbast = db.buscarTodas().filter { it.timestamp >= tsAbast }
            val kmPercorrido = corridasDesdeAbast.sumOf { it.kmTotal.toDouble() }.toFloat()

            // km restantes estimados
            val kmRestante = (kmAutonom - kmPercorrido).coerceAtLeast(0f)
            val pct = if (kmAutonom > 0f) ((kmRestante / kmAutonom) * 100).toInt().coerceIn(0, 100) else 0

            val icone = when {
                pct > 50  -> "🟢"
                pct > 20  -> "🟡"
                else      -> "🔴"
            }

            val texto = buildString {
                append("$icone Autonomia restante: ${"%.0f".format(kmRestante)} km ($pct%)\n")
                append("   Litros: ${"%.1f".format(litros)}L × ${"%.0f".format(consumo)} km/L = ${"%.0f".format(kmAutonom)} km\n")
                append("   Rodado desde abastec.: ${"%.1f".format(kmPercorrido)} km\n")
                if (kmRestante < 10f) {
                    append("   ⚠️ Atenção: combustível quase no fim!")
                } else { }
            }
            findViewById<android.widget.TextView>(R.id.tvAutonomia)?.text = texto
            // Barra de progresso da autonomia
            findViewById<android.widget.ProgressBar>(R.id.progressAutonomia)?.apply {
                progress = pct
                val cor = when {
                    pct > 50 -> ThemeHelper.cor("accent_green", prefs)
                    pct > 20 -> android.graphics.Color.parseColor("#FFD740")
                    else     -> ThemeHelper.cor("accent_red", prefs)
                }
                progressTintList = android.content.res.ColorStateList.valueOf(cor)
            }
        } catch (_: Throwable) {}
    }

    // ── BOTÕES ────────────────────────────────────────────────
    private fun configurarBotoes() {
        try { findViewById<ImageButton>(R.id.btnVoltar)?.setOnClickListener { finish() } } catch (_: Throwable) {}

        // Abastecimento
        try {
            findViewById<Button>(R.id.btnSalvarAbastecimento)?.setOnClickListener {
                salvarAbastecimento()
            }
        } catch (_: Throwable) {}

        // Calculadora de lucro — editar parâmetros
        try {
            findViewById<Button>(R.id.btnEditarCalc)?.setOnClickListener {
                mostrarDialogoCalculadora()
            }
        } catch (_: Throwable) {}

        // Corrida manual
        try {
            findViewById<Button>(R.id.btnCorridaManual)?.setOnClickListener {
                mostrarDialogoCorridaManual()
            }
        } catch (_: Throwable) {}

        // Registro de quilometragem
        try {
            findViewById<Button>(R.id.btnRegistrarKm)?.setOnClickListener {
                mostrarDialogoRegistrarKm()
            }
        } catch (_: Throwable) {}
    }

    // ── CALCULADORA DE LUCRO REAL ─────────────────────────────
    private fun mostrarDialogoCalculadora() {
        val p      = prefs
        val accent = ThemeHelper.cor("accent_gold", p)
        val bgCard = ThemeHelper.cor("bg_card", p)
        val txtW   = ThemeHelper.cor("text_white", p)
        val dp     = resources.displayMetrics.density

        val consumo   = prefs.getFloat("consumo_km_litro", 35f)
        val precoComb = prefs.getFloat("preco_combustivel", 6.50f)

        val layout = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setBackgroundColor(bgCard)
            setPadding((16*dp).toInt(), (12*dp).toInt(), (16*dp).toInt(), (12*dp).toInt())
        }

        fun label(txt: String) = android.widget.TextView(this).apply {
            text = txt; textSize = 12f
            setTextColor(ThemeHelper.cor("text_gray", p))
            setPadding(0, (8*dp).toInt(), 0, (2*dp).toInt())
        }
        fun campo(valor: String) = android.widget.EditText(this).apply {
            setText(valor)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            textSize = 16f; setTextColor(txtW)
            setBackgroundColor(Color.TRANSPARENT)
        }

        val etConsumo = campo("%.1f".format(consumo))
        val etPreco   = campo("%.2f".format(precoComb))

        layout.addView(label("Consumo da moto (km/litro)"))
        layout.addView(etConsumo)
        layout.addView(label("Preço do combustível (R$/litro)"))
        layout.addView(etPreco)

        android.app.AlertDialog.Builder(this)
            .setTitle("⛽ Calculadora de Lucro Real")
            .setView(layout)
            .setPositiveButton("Salvar") { _, _ ->
                val c = etConsumo.text.toString().replace(",",".").toFloatOrNull() ?: 35f
                val p2 = etPreco.text.toString().replace(",",".").toFloatOrNull() ?: 6.50f
                prefs.edit()
                    .putFloat("consumo_km_litro", c)
                    .putFloat("preco_combustivel", p2)
                    .apply()
                atualizarResumo()
                Toast.makeText(this, "Calculadora atualizada", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ── CORRIDA MANUAL ────────────────────────────────────────
    private fun mostrarDialogoCorridaManual() {
        val p      = prefs
        val bgCard = ThemeHelper.cor("bg_card", p)
        val txtW   = ThemeHelper.cor("text_white", p)
        val txtG   = ThemeHelper.cor("text_gray", p)
        val dp     = resources.displayMetrics.density

        val scroll = android.widget.ScrollView(this)
        val layout = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setBackgroundColor(bgCard)
            setPadding((16*dp).toInt(), (12*dp).toInt(), (16*dp).toInt(), (16*dp).toInt())
        }
        scroll.addView(layout)

        fun label(txt: String) = android.widget.TextView(this).apply {
            text = txt; textSize = 12f; setTextColor(txtG)
            setPadding(0, (10*dp).toInt(), 0, (2*dp).toInt())
        }
        fun campo(hint: String, tipo: Int = android.text.InputType.TYPE_CLASS_TEXT) =
            android.widget.EditText(this).apply {
                this.hint = hint; inputType = tipo
                textSize = 14f; setTextColor(txtW)
                setHintTextColor(txtG)
                setBackgroundColor(Color.TRANSPARENT)
            }

        val etValor   = campo("Ex: 4.80", android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val etKm      = campo("Ex: 2.50", android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val etOrigem  = campo("Endereço de origem")
        val etDestino = campo("Endereço de destino")
        val etPag     = campo("Dinheiro / PIX / Cartão")

        // Hora e data com valores padrão
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        val sdfD = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val etHora = campo(sdf.format(Date()))
        val etData = campo(sdfD.format(Date()))
        etHora.setText(sdf.format(Date()))
        etData.setText(sdfD.format(Date()))

        layout.addView(label("Valor (R$) *"))
        layout.addView(etValor)
        layout.addView(label("Distância (km)"))
        layout.addView(etKm)
        layout.addView(label("Forma de pagamento"))
        layout.addView(etPag)
        layout.addView(label("Origem"))
        layout.addView(etOrigem)
        layout.addView(label("Destino"))
        layout.addView(etDestino)
        layout.addView(label("Hora"))
        layout.addView(etHora)
        layout.addView(label("Data (dd/MM/yyyy)"))
        layout.addView(etData)

        android.app.AlertDialog.Builder(this)
            .setTitle("➕ Adicionar Corrida Manual")
            .setView(scroll)
            .setPositiveButton("Salvar") { _, _ ->
                val valor = etValor.text.toString().replace(",",".").toFloatOrNull()
                if (valor == null || valor <= 0f) {
                    Toast.makeText(this, "Valor inválido", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val km    = etKm.text.toString().replace(",",".").toFloatOrNull() ?: 0f
                val gkm   = if (km > 0f) valor / km else 0f
                val min   = prefs.getFloat("minimo_km", 1.20f)
                val dataStr = etData.text.toString().ifBlank { sdfD.format(Date()) }
                val horaStr = etHora.text.toString().ifBlank { sdf.format(Date()) }

                // Converter data+hora em timestamp real
                val ts = try {
                    SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
                        .parse("$dataStr $horaStr")?.time ?: System.currentTimeMillis()
                } catch (_: Exception) { System.currentTimeMillis() }
                val cal = Calendar.getInstance().apply { timeInMillis = ts }
                val mes = "%02d/%04d".format(cal.get(Calendar.MONTH)+1, cal.get(Calendar.YEAR))
                val ano = "%04d".format(cal.get(Calendar.YEAR))

                db.inserirCorridaManual(Corrida(
                    valor = valor, kmTotal = km, ganhoPorKm = gkm,
                    valeAPena = gkm >= min,
                    timestamp = ts, data = dataStr, hora = horaStr,
                    mes = mes, ano = ano,
                    origem = etOrigem.text.toString(),
                    destino = etDestino.text.toString(),
                    formaPagamento = etPag.text.toString()
                ))
                atualizarResumo()
                // Atualizar widget flutuante
                try { androidx.core.content.ContextCompat.startForegroundService(this, android.content.Intent(this, FloatingEarningsService::class.java)
                    .apply { action = "ATUALIZAR" }) } catch (_: Throwable) {}
                Toast.makeText(this, "Corrida adicionada: R$${"%.2f".format(valor)}", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ── REGISTRO DE QUILOMETRAGEM ─────────────────────────────
    private fun mostrarDialogoRegistrarKm() {
        val p      = prefs
        val bgCard = ThemeHelper.cor("bg_card", p)
        val txtW   = ThemeHelper.cor("text_white", p)
        val txtG   = ThemeHelper.cor("text_gray", p)
        val dp     = resources.displayMetrics.density

        val ultimoKm = db.ultimoKmOdometro()

        val layout = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setBackgroundColor(bgCard)
            setPadding((16*dp).toInt(), (12*dp).toInt(), (16*dp).toInt(), (16*dp).toInt())
        }

        if (ultimoKm > 0f) {
            layout.addView(android.widget.TextView(this).apply {
                text = "Último registro: ${"%.0f".format(ultimoKm)} km"
                textSize = 12f; setTextColor(txtG)
                setPadding(0, 0, 0, (8*dp).toInt())
            })
        }

        val etKm = android.widget.EditText(this).apply {
            hint = "Odômetro atual (km)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            textSize = 18f; setTextColor(txtW); setHintTextColor(txtG)
            setBackgroundColor(Color.TRANSPARENT)
        }
        val etObs = android.widget.EditText(this).apply {
            hint = "Observação (opcional)"
            textSize = 13f; setTextColor(txtW); setHintTextColor(txtG)
            setBackgroundColor(Color.TRANSPARENT)
        }

        layout.addView(android.widget.TextView(this).apply {
            text = "Leitura do odômetro (km)"; textSize = 12f; setTextColor(txtG)
            setPadding(0, 0, 0, (4*dp).toInt())
        })
        layout.addView(etKm)
        layout.addView(android.widget.TextView(this).apply {
            text = "Observação"; textSize = 12f; setTextColor(txtG)
            setPadding(0, (12*dp).toInt(), 0, (4*dp).toInt())
        })
        layout.addView(etObs)

        // Mostrar histórico de registros
        val registros = db.buscarKm()
        if (registros.isNotEmpty()) {
            layout.addView(android.widget.TextView(this).apply {
                text = "\nÚltimos registros:"; textSize = 12f; setTextColor(txtG)
            })
            registros.take(5).forEach { (_, km, data) ->
                layout.addView(android.widget.TextView(this).apply {
                    text = "  $data → ${"%.0f".format(km)} km"
                    textSize = 12f; setTextColor(txtW)
                })
            }
        }

        android.app.AlertDialog.Builder(this)
            .setTitle("🏍️ Registrar Quilometragem")
            .setView(layout)
            .setPositiveButton("Registrar") { _, _ ->
                val km = etKm.text.toString().replace(",",".").toFloatOrNull()
                if (km == null || km <= 0f) {
                    Toast.makeText(this, "Informe o km do odômetro", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                db.registrarKm(km, etObs.text.toString())
                atualizarResumo()
                Toast.makeText(this, "Km registrado: ${"%.0f".format(km)} km", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ── ABASTECIMENTO ─────────────────────────────────────────
    private fun salvarAbastecimento() {
        try {
            val litros = findViewById<EditText>(R.id.etLitros)?.text.toString()
                .replace(",",".").toFloatOrNull() ?: 0f
            val valor  = findViewById<EditText>(R.id.etValorAbastecimento)?.text.toString()
                .replace(",",".").toFloatOrNull() ?: 0f
            val km     = findViewById<EditText>(R.id.etKmAtual)?.text.toString()
                .replace(",",".").toFloatOrNull() ?: 0f

            if (litros <= 0f || valor <= 0f) {
                Toast.makeText(this, "Informe litros e valor", Toast.LENGTH_SHORT).show()
                return
            }
            val preco = valor / litros
            db.inserirAbastecimento(Abastecimento(
                litros = litros, valorTotal = valor,
                precoPorLitro = preco, kmAtual = km
            ))
            // Registrar km automaticamente se informado
            if (km > 0f) db.registrarKm(km, "Abastecimento")

            findViewById<EditText>(R.id.etLitros)?.setText("")
            findViewById<EditText>(R.id.etValorAbastecimento)?.setText("")
            findViewById<EditText>(R.id.etKmAtual)?.setText("")
            atualizarResumo()
            Toast.makeText(this, "Abastecimento: ${litros}L · R$${"%.2f".format(valor)} · R$${"%.2f".format(preco)}/L", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Erro ao salvar", Toast.LENGTH_SHORT).show()
        }
    }

    // ── TEMA ─────────────────────────────────────────────────
    private fun aplicarTema() {
        val p      = prefs
        val accent = ThemeHelper.cor("accent_gold", p)
        val bg     = ThemeHelper.cor("bg_dark", p)
        val bgCard = ThemeHelper.cor("bg_card", p)
        val txtW   = ThemeHelper.cor("text_white", p)
        val txtG   = ThemeHelper.cor("text_gray", p)
        val dp     = resources.displayMetrics.density

        fun gd(cor: Int) = GradientDrawable().apply { setColor(cor); cornerRadius = 10f*dp }
        fun gdOutline() = GradientDrawable().apply {
            setColor(Color.TRANSPARENT); cornerRadius = 10f*dp
            setStroke((1.5f*dp).toInt(), accent)
        }

        try { findViewById<android.view.View>(R.id.rootLayoutFinance)?.setBackgroundColor(bg) } catch (_: Throwable) {}
        try { findViewById<ImageButton>(R.id.btnVoltar)?.setColorFilter(accent) } catch (_: Throwable) {}

        // Título
        for (id in listOf(R.id.tvTituloFinance)) {
            try { findViewById<TextView>(id)?.setTextColor(accent) } catch (_: Throwable) {}
        }
        // Textos do card de lucro
        for (id in listOf(R.id.tvGanhoHoje, R.id.tvKmHoje, R.id.tvOdometro)) {
            try { findViewById<TextView>(id)?.setTextColor(txtW) } catch (_: Throwable) {}
        }
        try { findViewById<TextView>(R.id.tvCustoHoje)?.setTextColor(
            android.graphics.Color.parseColor("#FF6B6B")) } catch (_: Throwable) {}

        // Botões
        try { findViewById<Button>(R.id.btnSalvarAbastecimento)?.apply {
            background = gd(accent); setTextColor(android.graphics.Color.BLACK)
        }} catch (_: Throwable) {}
        for (id in listOf(R.id.btnEditarCalc, R.id.btnCorridaManual, R.id.btnRegistrarKm)) {
            try { findViewById<Button>(id)?.apply {
                background = gdOutline(); setTextColor(accent)
            }} catch (_: Throwable) {}
        }
    }
}
