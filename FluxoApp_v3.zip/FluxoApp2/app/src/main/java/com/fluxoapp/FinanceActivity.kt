package com.fluxoapp

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class FinanceActivity : AppCompatActivity() {
    private lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_finance)
        db = DatabaseHelper(this)
        aplicarTema()
        aplicarTemaGlobal()
        findViewById<ImageButton>(R.id.btnVoltar).setOnClickListener { finish() }
        configurar()
    }

    private fun configurar() {
        val etLitros = findViewById<EditText>(R.id.etLitros)
        val etValorTotal = findViewById<EditText>(R.id.etValorTotal)
        val etKmAtual = findViewById<EditText>(R.id.etKmAtual)
        val tvPrecoPorLitro = findViewById<TextView>(R.id.tvPrecoPorLitro)

        etValorTotal.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) calcularPrecoPorLitro(etLitros, etValorTotal, tvPrecoPorLitro)
        }
        etLitros.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) calcularPrecoPorLitro(etLitros, etValorTotal, tvPrecoPorLitro)
        }

        findViewById<Button>(R.id.btnSalvarAbastecimento).setOnClickListener {
            val litros = etLitros.text.toString().replace(",",".").toFloatOrNull() ?: 0f
            val valorTotal = etValorTotal.text.toString().replace(",",".").toFloatOrNull() ?: 0f
            val kmAtual = etKmAtual.text.toString().replace(",",".").toFloatOrNull() ?: 0f
            if (litros <= 0 || valorTotal <= 0) {
                Toast.makeText(this, "⚠️ Preencha litros e valor", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            db.inserirAbastecimento(Abastecimento(
                litros = litros, valorTotal = valorTotal,
                precoPorLitro = if (litros > 0) valorTotal/litros else 0f, kmAtual = kmAtual
            ))
            etLitros.text.clear(); etValorTotal.text.clear(); etKmAtual.text.clear()
            Toast.makeText(this, "✅ Abastecimento salvo!", Toast.LENGTH_SHORT).show()
            atualizarResumo()
        }
        atualizarResumo()
    }

    private fun calcularPrecoPorLitro(etLitros: EditText, etValor: EditText, tvPreco: TextView) {
        val l = etLitros.text.toString().replace(",",".").toFloatOrNull() ?: return
        val v = etValor.text.toString().replace(",",".").toFloatOrNull() ?: return
        if (l > 0) tvPreco.text = "R$ ${"%.3f".format(v/l)}/litro"
    }

    private fun atualizarResumo() {
        val abastecimentos = db.buscarAbastecimentos()
        val ganhoHoje = db.resumo(db.buscarHoje())["total"] ?: 0f
        val totalCombustivel = abastecimentos.sumOf { it.valorTotal.toDouble() }.toFloat()
        val totalKm = db.resumo(db.buscarTodas())["km_total"] ?: 0f
        val custoPorKm = if (totalKm > 0) totalCombustivel / totalKm else 0f

        val tvResumo = findViewById<TextView>(R.id.tvResumoFinanceiro)
        tvResumo.text = buildString {
            append("💰 Ganho hoje: R$ ${"%.2f".format(ganhoHoje)}\n")
            append("⛽ Gasto em combustível: R$ ${"%.2f".format(totalCombustivel)}\n")
            append("📊 Custo/km: R$ ${"%.3f".format(custoPorKm)}\n")
            append("✅ Lucro líquido hoje: R$ ${"%.2f".format(ganhoHoje)}\n\n")
            append("📋 Abastecimentos registrados: ${abastecimentos.size}")
        }

        val itens = abastecimentos.map { a ->
            "${a.data} — ${a.litros}L | R$ ${"%.2f".format(a.valorTotal)} | R$ ${"%.3f".format(a.precoPorLitro)}/L"
        }
        findViewById<ListView>(R.id.listAbastecimentos).adapter =
            ArrayAdapter(this, android.R.layout.simple_list_item_1, itens)
    }

    private fun aplicarTema() {
        val p  = getSharedPreferences("FluxoApp", android.content.Context.MODE_PRIVATE)
        val bg     = ThemeHelper.cor("bg_dark",     p)
        val bgCard = ThemeHelper.cor("bg_card",     p)
        val accent = ThemeHelper.cor("accent_gold", p)
        val gold   = ThemeHelper.cor("accent_gold", p)
        val txtW   = ThemeHelper.cor("text_white",  p)
        val txtG   = ThemeHelper.cor("text_gray",   p)
        val border = ThemeHelper.cor("border",      p)
        val dp = resources.displayMetrics.density
        fun gd(cor: Int) = android.graphics.drawable.GradientDrawable().apply {
            setColor(cor); cornerRadius = 12f * dp; setStroke((1f*dp).toInt(), border)
        }
        fun gdInput(cor: Int) = android.graphics.drawable.GradientDrawable().apply {
            setColor(cor); cornerRadius = 8f * dp; setStroke((1f*dp).toInt(), border)
        }
        try { findViewById<android.view.View>(R.id.rootLayout)?.setBackgroundColor(bg) } catch (_: Exception) {}
        try { findViewById<android.widget.ImageButton>(R.id.btnVoltar)?.setColorFilter(accent) } catch (_: Exception) {}
        try { findViewById<android.widget.TextView>(R.id.tvResumoFinanceiro)?.apply {
            background = gd(bgCard); setTextColor(txtW)
        }} catch (_: Exception) {}
        for (id in listOf(R.id.etLitros, R.id.etValorTotal, R.id.etKmAtual)) {
            try { findViewById<android.widget.EditText>(id)?.apply {
                background = gdInput(bgCard); setTextColor(txtW)
                setHintTextColor(ThemeHelper.cor("text_gray", p))
            }} catch (_: Exception) {}
        }
        try { findViewById<android.widget.TextView>(R.id.tvPrecoPorLitro)?.setTextColor(gold) } catch (_: Exception) {}

        // Botão salvar abastecimento — sólido com cor do tema
        try {
            findViewById<android.widget.Button>(R.id.btnSalvarAbastecimento)?.apply {
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(accent); cornerRadius = 12f * dp
                }
                setTextColor(android.graphics.Color.BLACK)
            }
        } catch (_: Exception) {}
    }
}
