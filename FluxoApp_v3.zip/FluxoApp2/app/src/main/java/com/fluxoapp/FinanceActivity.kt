package com.fluxoapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class FinanceActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private lateinit var prefs: android.content.SharedPreferences

    // Receiver para atualizar o gauge sempre que o GPS mover
    private val kmReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == KmTrackerService.ACTION_KM_ATUALIZADO) {
                calcularAutonomia()
            }
        }
    }

    override fun attachBaseContext(base: android.content.Context) {
        super.attachBaseContext(FontHelper.wrap(base))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeSelector.aplicar(this)
        setContentView(R.layout.activity_finance)
        db    = DatabaseHelper(this)
        prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        aplicarTema()
        aplicarTemaGlobal()
        configurarHeader()
        configurarBotoes()
        atualizarResumo()
        BottomNavHelper.configurar(this, BottomNavHelper.ABA_FINANCAS)
    }

    override fun onResume() {
        super.onResume()
        configurarHeader()
        atualizarResumo()
        // Registrar receiver para atualização em tempo real do gauge
        try {
            registerReceiver(kmReceiver, IntentFilter(KmTrackerService.ACTION_KM_ATUALIZADO))
        } catch (_: Exception) {}
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(kmReceiver) } catch (_: Exception) {}
    }

    // ── HEADER ────────────────────────────────────────────────
    private fun configurarHeader() {
        try {
            val nome = prefs.getString("nome_usuario", null)
                ?: com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.displayName
                ?: "Motorista"
            val primeiroNome = nome.split(" ").firstOrNull() ?: nome
            findViewById<TextView>(R.id.tvNomeMotorista)?.text = "Olá, $primeiroNome"
        } catch (_: Throwable) {}
        try {
            val sdf = SimpleDateFormat("EEEE, dd 'de' MMMM", Locale("pt", "BR"))
            val data = sdf.format(Date()).replaceFirstChar { it.uppercase() }
            findViewById<TextView>(R.id.tvDataHoje)?.text = data
        } catch (_: Throwable) {}
    }

    // ── RESUMO FINANCEIRO ─────────────────────────────────────
    private fun atualizarResumo() {
        val corridas   = db.buscarHoje()
        val ganhoHoje  = db.resumo(corridas)["total"] ?: 0f

        val consumo    = prefs.getFloat("consumo_km_litro", 35f)
        val precoComb  = prefs.getFloat("preco_combustivel", 6.50f)
        val kmCorridas = db.resumo(corridas)["km_total"] ?: 0f
        val kmGps      = KmTrackerService.kmHoje(this)
        val kmHoje     = if (kmGps > kmCorridas) kmGps else kmCorridas
        val custoHoje  = if (consumo > 0) (kmHoje / consumo) * precoComb else 0f
        val lucroHoje  = ganhoHoje - custoHoje
        val ultimoKm   = db.ultimoKmOdometro()

        try {
            findViewById<TextView>(R.id.tvGanhoHoje)?.text = "R$ ${"%.2f".format(ganhoHoje)}"
            findViewById<TextView>(R.id.tvCustoHoje)?.text = "- R$ ${"%.2f".format(custoHoje)}"
            findViewById<TextView>(R.id.tvLucroHoje)?.text = "R$ ${"%.2f".format(lucroHoje)}"

            val red = ThemeHelper.cor("accent_red", prefs)
            findViewById<TextView>(R.id.tvLucroHoje)?.setTextColor(
                if (lucroHoje >= 0) Color.WHITE else red
            )

            val kmLStr = if (consumo > 0) "%.1f".format(consumo) else "—"
            findViewById<TextView>(R.id.tvKmPorLitro)?.text = kmLStr

            val odoStr = if (ultimoKm > 0) "%.0f".format(ultimoKm) else "—"
            findViewById<TextView>(R.id.tvOdometro)?.text = odoStr

            val kmHojeStr = "%.1f".format(kmHoje)
            findViewById<TextView>(R.id.tvKmHoje)?.text = kmHojeStr

            val horaStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            findViewById<TextView>(R.id.tvFooterKm)?.text =
                "$kmHojeStr km rodados hoje · Última atualização: $horaStr"
            findViewById<TextView>(R.id.tvUltimaAtualizacao)?.text = "Atualizado às $horaStr"

            calcularAutonomia()
        } catch (_: Throwable) {}
    }

    // ── AUTONOMIA — fórmula corrigida ─────────────────────────
    //
    // Autonomia Restante = (litros × km/L) − km_desde_abastecimento
    //
    // km_desde_abastecimento = KmTrackerService.kmDesdeAbastec()
    //   → acumula GPS real desde o último abastecimento, entre dias,
    //     e atualiza a cada movimento detectado pelo LocationListener.
    //
    private fun calcularAutonomia() {
        try {
            val consumo  = prefs.getFloat("consumo_km_litro", 35f)
            val abastecs = db.buscarAbastecimentos()

            if (abastecs.isEmpty() || consumo <= 0f) {
                zerarGauge()
                return
            }

            val ultimo     = abastecs.first()
            val litros     = ultimo.litros
            val kmAutonom  = litros * consumo          // autonomia total do tanque

            // ← Distância real desde o abastecimento (GPS, entre dias)
            val kmPercorrido = KmTrackerService.kmDesdeAbastec(this)

            val kmRestante    = (kmAutonom - kmPercorrido).coerceAtLeast(0f)
            val litrosRestant = if (consumo > 0) kmRestante / consumo else 0f
            val pct           = if (kmAutonom > 0f)
                ((kmRestante / kmAutonom) * 100).toInt().coerceIn(0, 100) else 0

            val corCircle = when {
                pct > 50 -> ThemeHelper.cor("accent_green", prefs)
                pct > 20 -> Color.parseColor("#FFD740")
                else     -> ThemeHelper.cor("accent_red", prefs)
            }

            findViewById<TextView>(R.id.tvPctCircle)?.text        = "$pct%"
            findViewById<TextView>(R.id.tvKmCircle)?.text         = "${"%.0f".format(kmRestante)} km"
            findViewById<TextView>(R.id.tvLitrosRestantes)?.text  = "${"%.1f".format(litrosRestant)} L"
            findViewById<TextView>(R.id.tvAutonomiaEst)?.text     = "~${"%.0f".format(kmRestante)} km"
            findViewById<TextView>(R.id.tvDesdeAbastec)?.text     = "${"%.1f".format(kmPercorrido)} km"

            // Gauge circular
            findViewById<ProgressBar>(R.id.progressCombustivel)?.apply {
                progress = pct
                progressTintList = android.content.res.ColorStateList.valueOf(corCircle)
            }

            // Barra horizontal de litros
            val corBar = when {
                pct > 50 -> ThemeHelper.cor("accent_green", prefs)
                pct > 20 -> Color.parseColor("#FFD740")
                else     -> ThemeHelper.cor("accent_red", prefs)
            }
            findViewById<ProgressBar>(R.id.progressLitros)?.apply {
                progress = pct
                progressTintList = android.content.res.ColorStateList.valueOf(corBar)
            }

            try {
                findViewById<TextView>(R.id.tvAutonomia)?.text =
                    "Autonomia: ${"%.0f".format(kmRestante)} km ($pct%)"
            } catch (_: Throwable) {}

        } catch (_: Throwable) {}
    }

    private fun zerarGauge() {
        try {
            findViewById<TextView>(R.id.tvPctCircle)?.text       = "0%"
            findViewById<TextView>(R.id.tvKmCircle)?.text        = "sem dados"
            findViewById<TextView>(R.id.tvLitrosRestantes)?.text = "—"
            findViewById<TextView>(R.id.tvAutonomiaEst)?.text    = "—"
            findViewById<TextView>(R.id.tvDesdeAbastec)?.text    = "—"
            findViewById<ProgressBar>(R.id.progressCombustivel)?.progress = 0
            findViewById<ProgressBar>(R.id.progressLitros)?.progress     = 0
        } catch (_: Throwable) {}
    }

    // ── BOTÕES ────────────────────────────────────────────────
    private fun configurarBotoes() {
        try { findViewById<ImageButton>(R.id.btnVoltar)?.setOnClickListener { finish() } } catch (_: Throwable) {}
        try {
            findViewById<ImageButton>(R.id.btnNotificacao)?.setOnClickListener {
                FluxoToast.info(this, "Sem notificações novas")
            }
        } catch (_: Throwable) {}

        // Abastecimento colapsável
        try {
            val cardAbast = findViewById<android.view.View>(R.id.cardAbastecimento)
            findViewById<Button>(R.id.btnNovoAbastecimento)?.setOnClickListener {
                val visible = cardAbast?.visibility == android.view.View.VISIBLE
                if (visible) {
                    cardAbast?.visibility = android.view.View.GONE
                } else {
                    cardAbast?.visibility = android.view.View.VISIBLE
                    cardAbast?.alpha = 0f
                    cardAbast?.animate()?.alpha(1f)?.setDuration(250)?.start()
                    try {
                        val sv = findViewById<ScrollView>(R.id.scrollFinance)
                        sv?.post { sv.smoothScrollTo(0, cardAbast?.top ?: 0) }
                    } catch (_: Throwable) {}
                }
            }
            findViewById<Button>(R.id.btnSalvarAbastecimento)?.setOnClickListener {
                salvarAbastecimento()
                cardAbast?.visibility = android.view.View.GONE
            }
        } catch (_: Throwable) {}

        try {
            findViewById<Button>(R.id.btnEditarCalc)?.setOnClickListener {
                mostrarDialogoCalculadora()
            }
        } catch (_: Throwable) {}

        try {
            findViewById<Button>(R.id.btnRegistrarKm)?.setOnClickListener {
                mostrarDialogoRegistrarKm()
            }
        } catch (_: Throwable) {}
    }

    // ── CALCULADORA ───────────────────────────────────────────
    private fun mostrarDialogoCalculadora() {
        val p      = prefs
        val accent = ThemeHelper.cor("accent_gold", p)
        val bgCard = ThemeHelper.cor("bg_card", p)
        val txtW   = ThemeHelper.cor("text_white", p)
        val dp     = resources.displayMetrics.density

        val consumo   = prefs.getFloat("consumo_km_litro", 35f)
        val precoComb = prefs.getFloat("preco_combustivel", 6.50f)

        val layout = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setBackgroundColor(bgCard)
            setPadding((16*dp).toInt(), (12*dp).toInt(), (16*dp).toInt(), (12*dp).toInt())
        }

        fun label(txt: String) = android.widget.TextView(this).apply {
            text = txt; textSize = 12f
            setTextColor(ThemeHelper.cor("text_gray", p))
            setPadding(0, (8*dp).toInt(), 0, (2*dp).toInt())
        }
        fun campo(valor: String) = android.widget.EditText(this).apply {
            setText(valor)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            textSize = 16f; setTextColor(txtW)
            setBackgroundColor(Color.TRANSPARENT)
        }

        val etConsumo = campo("%.1f".format(consumo))
        val etPreco   = campo("%.2f".format(precoComb))

        layout.addView(label("Consumo da moto (km/litro)"))
        layout.addView(etConsumo)
        layout.addView(label("Preço do combustível (R$/litro)"))
        layout.addView(etPreco)

        android.app.AlertDialog.Builder(this)
            .setTitle("⛽ Calculadora de Lucro Real")
            .setView(layout)
            .setPositiveButton("Salvar") { _, _ ->
                val c  = etConsumo.text.toString().replace(",",".").toFloatOrNull() ?: 35f
                val p2 = etPreco.text.toString().replace(",",".").toFloatOrNull() ?: 6.50f
                prefs.edit()
                    .putFloat("consumo_km_litro", c)
                    .putFloat("preco_combustivel", p2)
                    .apply()
                atualizarResumo()
                FluxoToast.info(this, "Calculadora atualizada")
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ── REGISTRO DE KM ────────────────────────────────────────
    private fun mostrarDialogoRegistrarKm() {
        val p      = prefs
        val bgCard = ThemeHelper.cor("bg_card", p)
        val txtW   = ThemeHelper.cor("text_white", p)
        val txtG   = ThemeHelper.cor("text_gray", p)
        val dp     = resources.displayMetrics.density
        val ultimoKm = db.ultimoKmOdometro()

        val layout = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setBackgroundColor(bgCard)
            setPadding((16*dp).toInt(), (12*dp).toInt(), (16*dp).toInt(), (16*dp).toInt())
        }

        if (ultimoKm > 0f) {
            layout.addView(android.widget.TextView(this).apply {
                text = "Último registro: ${"%.0f".format(ultimoKm)} km"
                textSize = 12f; setTextColor(txtG)
                setPadding(0, 0, 0, (8*dp).toInt())
            })
        }

        val etKm = android.widget.EditText(this).apply {
            hint = "Odômetro atual (km)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            textSize = 18f; setTextColor(txtW); setHintTextColor(txtG)
            setBackgroundColor(Color.TRANSPARENT)
        }
        val etObs = android.widget.EditText(this).apply {
            hint = "Observação (opcional)"
            textSize = 13f; setTextColor(txtW); setHintTextColor(txtG)
            setBackgroundColor(Color.TRANSPARENT)
        }

        layout.addView(android.widget.TextView(this).apply {
            text = "Leitura do odômetro (km)"; textSize = 12f; setTextColor(txtG)
            setPadding(0, 0, 0, (4*dp).toInt())
        })
        layout.addView(etKm)
        layout.addView(android.widget.TextView(this).apply {
            text = "Observação"; textSize = 12f; setTextColor(txtG)
            setPadding(0, (12*dp).toInt(), 0, (4*dp).toInt())
        })
        layout.addView(etObs)

        val registros = db.buscarKm()
        if (registros.isNotEmpty()) {
            layout.addView(android.widget.TextView(this).apply {
                text = "\nÚltimos registros:"; textSize = 12f; setTextColor(txtG)
            })
            registros.take(5).forEach { (_, km, data) ->
                layout.addView(android.widget.TextView(this).apply {
                    text = "  $data → ${"%.0f".format(km)} km"
                    textSize = 12f; setTextColor(txtW)
                })
            }
        }

        android.app.AlertDialog.Builder(this)
            .setTitle("🏍️ Registrar Quilometragem")
            .setView(layout)
            .setPositiveButton("Registrar") { _, _ ->
                val km = etKm.text.toString().replace(",",".").toFloatOrNull()
                if (km == null || km <= 0f) { FluxoToast.aviso(this, "Informe o km do odômetro"); return@setPositiveButton }
                db.registrarKm(km, etObs.text.toString())
                atualizarResumo()
                FluxoToast.sucesso(this, "Km registrado: ${"%.0f".format(km)} km")
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ── ABASTECIMENTO ─────────────────────────────────────────
    private fun salvarAbastecimento() {
        try {
            val litros = findViewById<EditText>(R.id.etLitros)?.text.toString().replace(",",".").toFloatOrNull() ?: 0f
            val valor  = findViewById<EditText>(R.id.etValorAbastecimento)?.text.toString().replace(",",".").toFloatOrNull() ?: 0f
            val km     = findViewById<EditText>(R.id.etKmAtual)?.text.toString().replace(",",".").toFloatOrNull() ?: 0f

            if (litros <= 0f || valor <= 0f) { FluxoToast.aviso(this, "Informe litros e valor"); return }

            val preco = valor / litros
            db.inserirAbastecimento(Abastecimento(litros = litros, valorTotal = valor, precoPorLitro = preco, kmAtual = km))
            if (km > 0f) db.registrarKm(km, "Abastecimento")

            // ← ZERA o acumulador GPS: a partir de agora conta do zero
            KmTrackerService.zerarKmDesdeAbastec(this)

            findViewById<EditText>(R.id.etLitros)?.setText("")
            findViewById<EditText>(R.id.etValorAbastecimento)?.setText("")
            findViewById<EditText>(R.id.etKmAtual)?.setText("")

            atualizarResumo()
            FluxoToast.sucesso(this, "⛽ ${litros}L · R$${"%.2f".format(valor)} · R$${"%.2f".format(preco)}/L")
        } catch (_: Throwable) {
            FluxoToast.erro(this, "Erro ao salvar")
        }
    }

    // ── TEMA ─────────────────────────────────────────────────
    private fun aplicarTema() {
        val p      = prefs
        val accent = ThemeHelper.cor("accent_gold", p)
        val bg     = ThemeHelper.cor("bg_dark", p)
        val bgCard = ThemeHelper.cor("bg_card", p)
        val txtW   = ThemeHelper.cor("text_white", p)
        val txtG   = ThemeHelper.cor("text_gray", p)
        val green  = ThemeHelper.cor("accent_green", p)
        val dp     = resources.displayMetrics.density

        fun gd(cor: Int, radius: Float = 10f) = GradientDrawable().apply {
            setColor(cor); cornerRadius = radius * dp
        }
        fun gdOutline(radius: Float = 10f) = GradientDrawable().apply {
            setColor(Color.TRANSPARENT); cornerRadius = radius * dp
            setStroke((1.5f * dp).toInt(), accent)
        }

        try { findViewById<android.view.View>(R.id.scrollFinance)?.setBackgroundColor(bg) } catch (_: Throwable) {}
        try { findViewById<ImageButton>(R.id.btnVoltar)?.setColorFilter(green) } catch (_: Throwable) {}

        try { findViewById<TextView>(R.id.tvNomeMotorista)?.setTextColor(txtW) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvDataHoje)?.setTextColor(txtG) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvLucroHoje)?.setTextColor(txtW) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvGanhoHoje)?.setTextColor(green) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvCustoHoje)?.setTextColor(Color.parseColor("#FF5252")) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvUltimaAtualizacao)?.setTextColor(txtG) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvPctCircle)?.setTextColor(txtW) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvKmCircle)?.setTextColor(txtG) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvLitrosRestantes)?.setTextColor(txtW) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvAutonomiaEst)?.setTextColor(txtW) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvDesdeAbastec)?.setTextColor(txtW) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvKmPorLitro)?.setTextColor(txtW) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvOdometro)?.setTextColor(txtW) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvKmHoje)?.setTextColor(txtW) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvFooterKm)?.setTextColor(txtG) } catch (_: Throwable) {}

        try { findViewById<Button>(R.id.btnSalvarAbastecimento)?.apply {
            background = gd(green); setTextColor(Color.BLACK)
        }} catch (_: Throwable) {}
        for (id in listOf(R.id.btnEditarCalc, R.id.btnNovoAbastecimento, R.id.btnRegistrarKm)) {
            try { findViewById<Button>(id)?.apply {
                background = gdOutline(); setTextColor(accent)
            }} catch (_: Throwable) {}
        }
    }
}
