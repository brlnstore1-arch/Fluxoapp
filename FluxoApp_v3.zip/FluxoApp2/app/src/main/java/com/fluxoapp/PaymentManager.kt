package com.fluxoapp

import com.google.firebase.firestore.FirebaseFirestore
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Date
import java.util.concurrent.TimeUnit

object PaymentManager {

    private const val ACCESS_TOKEN = "APP_USR-8739449390616806-032922-fb0d0a38ca1400820a2e99492cf0df77-301061585"
    private const val MP_API_BASE  = "https://api.mercadopago.com"

    data class Plano(
        val id: String,
        val nome: String,
        val preco: Double,
        val duracaoDias: Long,
        val descricao: String
    )

    val planoMensal = Plano(
        id          = LicenseManager.PLANO_MENSAL,
        nome        = "Mensal",
        preco       = 4.99,
        duracaoDias = 30,
        descricao   = "Acesso completo por 30 dias"
    )

    data class PixResult(
        val sucesso: Boolean,
        val paymentId: String    = "",
        val qrCodeBase64: String = "",
        val qrCodeTexto: String  = "",
        val erro: String         = ""
    )

    data class StatusResult(
        val status: String,   // "approved" | "pending" | "rejected" | "erro"
        val erro: String = ""
    )

    /**
     * Cria um pagamento PIX no Mercado Pago.
     * Deve ser chamado em thread de background.
     */
    fun criarPixPagamento(
        nomeUsuario: String,
        emailUsuario: String,
        uid: String,
        descontoPct: Int = 0
    ): PixResult {
        return try {
            val url  = URL("$MP_API_BASE/v1/payments")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Authorization", "Bearer $ACCESS_TOKEN")
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("X-Idempotency-Key", "fluxoapp-$uid-${System.currentTimeMillis()}")
                doOutput = true
                connectTimeout = 15_000
                readTimeout    = 15_000
            }

            val precoFinal = if (descontoPct > 0)
                planoMensal.preco * (1 - descontoPct / 100.0)
            else planoMensal.preco

            val descricao = if (descontoPct > 0)
                "FluxoApp — Plano Mensal (${descontoPct}% OFF)"
            else "FluxoApp — Plano Mensal"

            val body = JSONObject().apply {
                put("transaction_amount", precoFinal)
                put("description", descricao)
                put("payment_method_id", "pix")
                put("payer", JSONObject().apply {
                    put("email", emailUsuario)
                    put("first_name", nomeUsuario.split(" ").firstOrNull() ?: nomeUsuario)
                    put("last_name",  nomeUsuario.split(" ").drop(1).joinToString(" ").ifEmpty { "." })
                })
                // Expiração do PIX: 30 minutos
                put("date_of_expiration", dataExpiracao30min())
                // Referência externa para identificar o pagamento
                put("external_reference", "$uid|${planoMensal.id}|${planoMensal.duracaoDias}")
            }

            conn.outputStream.use { os ->
                os.write(body.toString().toByteArray(Charsets.UTF_8))
            }

            val responseCode = conn.responseCode
            val responseBody = if (responseCode in 200..299)
                conn.inputStream.bufferedReader().readText()
            else
                conn.errorStream?.bufferedReader()?.readText() ?: ""

            conn.disconnect()

            if (responseCode !in 200..299) {
                return PixResult(sucesso = false, erro = "Erro MP: $responseCode — $responseBody")
            }

            val json          = JSONObject(responseBody)
            val paymentId     = json.optString("id", "")
            val pointOfInt    = json.optJSONObject("point_of_interaction")
            val transData     = pointOfInt?.optJSONObject("transaction_data")
            val qrBase64      = transData?.optString("qr_code_base64", "") ?: ""
            val qrTexto       = transData?.optString("qr_code", "")        ?: ""

            if (paymentId.isEmpty() || qrTexto.isEmpty()) {
                return PixResult(sucesso = false, erro = "Resposta inválida do Mercado Pago")
            }

            // Salvar payment_id no Firestore como pendente
            salvarPagamentoPendente(uid, paymentId, planoMensal)

            PixResult(
                sucesso      = true,
                paymentId    = paymentId,
                qrCodeBase64 = qrBase64,
                qrCodeTexto  = qrTexto
            )
        } catch (e: Exception) {
            PixResult(sucesso = false, erro = e.message ?: "Erro desconhecido")
        }
    }

    /**
     * Consulta o status de um pagamento no Mercado Pago.
     * Deve ser chamado em thread de background.
     */
    fun verificarStatusPagamento(paymentId: String): StatusResult {
        return try {
            val url  = URL("$MP_API_BASE/v1/payments/$paymentId")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                setRequestProperty("Authorization", "Bearer $ACCESS_TOKEN")
                connectTimeout = 10_000
                readTimeout    = 10_000
            }

            val responseCode = conn.responseCode
            val responseBody = if (responseCode in 200..299)
                conn.inputStream.bufferedReader().readText()
            else
                conn.errorStream?.bufferedReader()?.readText() ?: ""

            conn.disconnect()

            if (responseCode !in 200..299) {
                return StatusResult(status = "erro", erro = "HTTP $responseCode")
            }

            val json   = JSONObject(responseBody)
            val status = json.optString("status", "pending")
            StatusResult(status = status)

        } catch (e: Exception) {
            StatusResult(status = "erro", erro = e.message ?: "Erro de rede")
        }
    }

    /**
     * Ativa o plano no Firestore após pagamento aprovado.
     */
    fun ativarPlano(uid: String, plano: Plano, paymentId: String, callback: (Boolean) -> Unit) {
        val agora      = Date()
        val expiracao  = Date(agora.time + TimeUnit.DAYS.toMillis(plano.duracaoDias))

        val dados = mapOf(
            "plano"         to plano.id,
            "status"        to LicenseManager.STATUS_ATIVO,
            "dataExpiracao" to expiracao,
            "ultimoPagamento" to mapOf(
                "paymentId" to paymentId,
                "valor"     to plano.preco,
                "data"      to agora
            )
        )

        val db = FirebaseFirestore.getInstance()

        // Registrar no histórico de planos antes de atualizar o documento principal
        val entradaHistorico = mapOf(
            "plano"      to plano.id,
            "valor"      to plano.preco,
            "paymentId"  to paymentId,
            "inicio"     to agora,
            "expiracao"  to expiracao,
            "ativadoEm"  to agora
        )
        db.collection("users").document(uid)
            .collection("historicoPlanos")
            .add(entradaHistorico)

        db.collection("users")
            .document(uid)
            .update(dados)
            .addOnSuccessListener {
                removerPagamentoPendente(uid, paymentId)
                LicenseManager.invalidarCache()
                callback(true)
            }
            .addOnFailureListener { callback(false) }
    }

    // ── Helpers internos ────────────────────────────────────────────────

    private fun salvarPagamentoPendente(uid: String, paymentId: String, plano: Plano) {
        val dados = mapOf(
            "paymentId"  to paymentId,
            "planoId"    to plano.id,
            "dias"       to plano.duracaoDias,
            "valor"      to plano.preco,
            "status"     to "pending",
            "criadoEm"   to Date()
        )
        FirebaseFirestore.getInstance()
            .collection("users").document(uid)
            .collection("pagamentos").document(paymentId)
            .set(dados)
    }

    private fun removerPagamentoPendente(uid: String, paymentId: String) {
        FirebaseFirestore.getInstance()
            .collection("users").document(uid)
            .collection("pagamentos").document(paymentId)
            .delete()
    }

    private fun dataExpiracao30min(): String {
        val cal = java.util.Calendar.getInstance()
        cal.add(java.util.Calendar.MINUTE, 30)
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
            java.util.Locale.getDefault())
        return sdf.format(cal.time)
    }

    fun salvarTransacaoAprovada(uid: String, email: String, nome: String, paymentId: String, valor: Double, plano: String) {
        val tx = hashMapOf(
            "uid"       to uid,
            "userEmail" to email,
            "userName"  to nome,
            "tipo"      to "pix",
            "plano"     to plano,
            "valor"     to valor,
            "status"    to "aprovado",
            "paymentId" to paymentId,
            "criadoEm"  to com.google.firebase.Timestamp.now()
        )
        com.google.firebase.firestore.FirebaseFirestore.getInstance()
            .collection("transacoes").add(tx)
    }

}