package com.fluxoapp

import android.app.*
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

/**
 * RideTrackingService — FluxoApp
 *
 * Serviço foreground que mantém o rastreamento de corrida automática
 * MESMO quando o usuário sai da tela, muda de app ou minimiza.
 *
 * Comunicação com RideTrackerActivity via estado estático (@Volatile).
 */
class RideTrackingService : Service(), LocationListener {

    private val executor = Executors.newSingleThreadExecutor()
    private val handler  = Handler(Looper.getMainLooper())
    private var locationManager: LocationManager? = null

    companion object {
        const val CHANNEL_ID      = "ride_tracking_channel"
        const val NOTIF_ID        = 55
        const val ACTION_INICIAR  = "RIDE_INICIAR"
        const val ACTION_FINALIZAR = "RIDE_FINALIZAR"
        const val ACTION_CANCELAR  = "RIDE_CANCELAR"

        // Estado compartilhado com a Activity (thread-safe)
        @Volatile var rastreando        = false
        @Volatile var distanciaKm       = 0f
        @Volatile var horaInicio        = ""
        @Volatile var tsInicio          = 0L
        @Volatile var enderecoOrigem    = ""
        @Volatile var enderecoDestino   = ""
        @Volatile var latOrigem         = 0.0
        @Volatile var lonOrigem         = 0.0
        @Volatile var latDestino        = 0.0
        @Volatile var lonDestino        = 0.0
        @Volatile var locAnterior: Location? = null
        @Volatile var locAtual: Location?    = null

        // Callback para Activity atualizar UI em tempo real
        var onUpdate: ((distKm: Float, segundos: Long) -> Unit)? = null
        var onOrigemCapturada: ((endereco: String) -> Unit)? = null
        var onFinalizado: (() -> Unit)? = null

        fun instancia(context: Context) = context.applicationContext
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        criarCanal()
        startForeground(NOTIF_ID, criarNotificacao())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_INICIAR   -> iniciarRastreamento()
            ACTION_FINALIZAR -> finalizarRastreamento()
            ACTION_CANCELAR  -> { resetarEstado(); stopSelf() }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        pararGPS()
        executor.shutdownNow()
        handler.removeCallbacksAndMessages(null)
    }

    // ── INICIAR ───────────────────────────────────────────────

    private fun iniciarRastreamento() {
        rastreando   = true
        distanciaKm  = 0f
        locAnterior  = null
        locAtual     = null
        horaInicio   = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        tsInicio     = System.currentTimeMillis()
        enderecoOrigem  = ""
        enderecoDestino = ""

        iniciarGPS()
        atualizarNotificacao()

        // Timer para UI callback — atualiza a cada 1s se Activity estiver aberta
        val timerR = object : Runnable {
            override fun run() {
                if (!rastreando) return
                val seg = (System.currentTimeMillis() - tsInicio) / 1000
                onUpdate?.invoke(distanciaKm, seg)
                atualizarNotificacao()
                handler.postDelayed(this, 1_000)
            }
        }
        handler.post(timerR)

        // Aguardar primeiro fix de GPS (máx 10s) e depois geocodificar origem
        handler.postDelayed({
            executor.execute {
                val loc = locAtual
                if (loc != null && enderecoOrigem.isBlank()) {
                    latOrigem = loc.latitude; lonOrigem = loc.longitude
                    val end = LocationHelper.geocodificarInverso(loc.latitude, loc.longitude)
                    enderecoOrigem = end?.resumo ?: "%.4f, %.4f".format(loc.latitude, loc.longitude)
                    handler.post { onOrigemCapturada?.invoke(enderecoOrigem) }
                } else if (enderecoOrigem.isBlank()) {
                    enderecoOrigem = "Localização não obtida"
                    handler.post { onOrigemCapturada?.invoke(enderecoOrigem) }
                }
            }
        }, 6_000L)  // aguarda 6s para GPS se estabilizar
    }

    // ── FINALIZAR ─────────────────────────────────────────────

    private fun finalizarRastreamento() {
        rastreando = false
        pararGPS()

        val locFim = locAtual
        if (locFim != null) {
            latDestino = locFim.latitude; lonDestino = locFim.longitude
        }

        executor.execute {
            // Geocodificar destino
            val locF = locAtual
            if (locF != null) {
                val end = LocationHelper.geocodificarInverso(locF.latitude, locF.longitude)
                enderecoDestino = end?.resumo ?: "%.4f, %.4f".format(locF.latitude, locF.longitude)
            }

            // Calcular rota via OSRM se tiver origem e destino
            if (latOrigem != 0.0 && latDestino != 0.0) {
                val rota = LocationHelper.calcularRota(latOrigem, lonOrigem, latDestino, lonDestino)
                if (rota.sucesso && rota.distanciaKm > 0.1f) {
                    distanciaKm = rota.distanciaKm
                }
            }

            handler.post {
                onFinalizado?.invoke()
                stopSelf()
            }
        }
    }

    // ── GPS ──────────────────────────────────────────────────

    private fun iniciarGPS() {
        try {
            locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
            val provider = when {
                locationManager!!.isProviderEnabled(LocationManager.GPS_PROVIDER)     -> LocationManager.GPS_PROVIDER
                locationManager!!.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                else -> return
            }
            locationManager!!.requestLocationUpdates(provider, 2_000L, 5f, this)
        } catch (_: SecurityException) {}
        catch (_: Exception) {}
    }

    private fun pararGPS() {
        try { locationManager?.removeUpdates(this) } catch (_: Exception) {}
    }

    override fun onLocationChanged(loc: Location) {
        val ant = locAnterior
        if (ant != null && rastreando) {
            val dist = ant.distanceTo(loc)
            if (dist in 5f..500f) distanciaKm += dist / 1000f
        }
        locAnterior = loc
        locAtual    = loc
    }

    @Deprecated("Deprecated in API 29")
    override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
    override fun onProviderEnabled(p: String) {}
    override fun onProviderDisabled(p: String) {}

    // ── Notificação ───────────────────────────────────────────

    private fun criarNotificacao(): Notification {
        val km  = "%.2f".format(distanciaKm)
        val seg = if (tsInicio > 0) (System.currentTimeMillis() - tsInicio) / 1000 else 0
        val min = seg / 60; val s = seg % 60

        val intentAbrir = Intent(this, RideTrackerActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pi = PendingIntent.getActivity(this, 0, intentAbrir,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("⚡ Corrida em andamento")
            .setContentText("$km km · %02d:%02d".format(min, s))
            .setContentIntent(pi)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun atualizarNotificacao() {
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIF_ID, criarNotificacao())
        } catch (_: Exception) {}
    }

    private fun criarCanal() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Corrida em andamento",
                NotificationManager.IMPORTANCE_LOW).apply {
                description = "Rastreamento de corrida ativa"
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    private fun resetarEstado() {
        rastreando = false; distanciaKm = 0f
        enderecoOrigem = ""; enderecoDestino = ""
        latOrigem = 0.0; lonOrigem = 0.0
        latDestino = 0.0; lonDestino = 0.0
        locAtual = null; locAnterior = null
        onUpdate = null; onOrigemCapturada = null; onFinalizado = null
    }
}
