package com.fluxoapp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.*

data class Corrida(
    val id: Long = 0,
    val valor: Float,
    val kmTotal: Float,
    val ganhoPorKm: Float,
    val valeAPena: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val data: String = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date()),
    val hora: String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()),
    val mes: String = SimpleDateFormat("MM/yyyy", Locale.getDefault()).format(Date()),
    val ano: String = SimpleDateFormat("yyyy", Locale.getDefault()).format(Date()),
    val origem: String = "",
    val destino: String = "",
    val formaPagamento: String = "",
    val passageiro: String = "",
    val horaInicio: String = "",
    val horaFim: String = "",
    val tempoExecucao: String = ""
)

data class Abastecimento(
    val id: Long = 0,
    val litros: Float,
    val valorTotal: Float,
    val precoPorLitro: Float,
    val kmAtual: Float,
    val timestamp: Long = System.currentTimeMillis(),
    val data: String = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())
)

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, "fluxoapp.db", null, 5) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS corridas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                valor REAL, km_total REAL, ganho_por_km REAL,
                vale_a_pena INTEGER, timestamp INTEGER,
                data TEXT, hora TEXT, mes TEXT, ano TEXT,
                origem TEXT DEFAULT '', destino TEXT DEFAULT '',
                forma_pagamento TEXT DEFAULT '',
                passageiro TEXT DEFAULT '',
                hora_inicio TEXT DEFAULT '',
                hora_fim TEXT DEFAULT '',
                tempo_execucao TEXT DEFAULT ''
            )
        """)
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS abastecimentos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                litros REAL, valor_total REAL, preco_por_litro REAL,
                km_atual REAL, timestamp INTEGER, data TEXT
            )
        """)
    }

    override fun onOpen(db: SQLiteDatabase) {
        super.onOpen(db)
        if (!db.isReadOnly) {
            try { db.execSQL("PRAGMA journal_mode=WAL") } catch (_: Exception) {}
        }
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Migração segura — adiciona colunas sem perder dados
        try { db.execSQL("ALTER TABLE corridas ADD COLUMN origem TEXT DEFAULT ''") } catch (_: Exception) {}
        try { db.execSQL("ALTER TABLE corridas ADD COLUMN destino TEXT DEFAULT ''") } catch (_: Exception) {}
        try { db.execSQL("ALTER TABLE corridas ADD COLUMN forma_pagamento TEXT DEFAULT ''") } catch (_: Exception) {}
        try { db.execSQL("ALTER TABLE corridas ADD COLUMN passageiro TEXT DEFAULT ''") } catch (_: Exception) {}
        try { db.execSQL("ALTER TABLE corridas ADD COLUMN hora_inicio TEXT DEFAULT ''") } catch (_: Exception) {}
        try { db.execSQL("ALTER TABLE corridas ADD COLUMN hora_fim TEXT DEFAULT ''") } catch (_: Exception) {}
        try { db.execSQL("ALTER TABLE corridas ADD COLUMN tempo_execucao TEXT DEFAULT ''") } catch (_: Exception) {}
    }

    fun inserirCorrida(corrida: Corrida): Long {
        return try {
            val v = ContentValues().apply {
                put("valor", corrida.valor)
                put("km_total", corrida.kmTotal)
                put("ganho_por_km", corrida.ganhoPorKm)
                put("vale_a_pena", if (corrida.valeAPena) 1 else 0)
                put("timestamp", corrida.timestamp)
                put("data", corrida.data)
                put("hora", corrida.hora)
                put("mes", corrida.mes)
                put("ano", corrida.ano)
                put("origem", corrida.origem)
                put("destino", corrida.destino)
                put("forma_pagamento", corrida.formaPagamento)
                put("passageiro", corrida.passageiro)
                put("hora_inicio", corrida.horaInicio)
                put("hora_fim", corrida.horaFim)
                put("tempo_execucao", corrida.tempoExecucao)
            }
            writableDatabase.insert("corridas", null, v)
        } catch (_: Exception) { -1L }
    }

    fun inserirAbastecimento(a: Abastecimento): Long {
        return try {
            val v = ContentValues().apply {
                put("litros", a.litros)
                put("valor_total", a.valorTotal)
                put("preco_por_litro", a.precoPorLitro)
                put("km_atual", a.kmAtual)
                put("timestamp", a.timestamp)
                put("data", a.data)
            }
            writableDatabase.insert("abastecimentos", null, v)
        } catch (_: Exception) { -1L }
    }

    private fun cursorToCorrida(cursor: android.database.Cursor) = Corrida(
        id = cursor.getLong(cursor.getColumnIndexOrThrow("id")),
        valor = cursor.getFloat(cursor.getColumnIndexOrThrow("valor")),
        kmTotal = cursor.getFloat(cursor.getColumnIndexOrThrow("km_total")),
        ganhoPorKm = cursor.getFloat(cursor.getColumnIndexOrThrow("ganho_por_km")),
        valeAPena = cursor.getInt(cursor.getColumnIndexOrThrow("vale_a_pena")) == 1,
        timestamp = cursor.getLong(cursor.getColumnIndexOrThrow("timestamp")),
        data = cursor.getString(cursor.getColumnIndexOrThrow("data")),
        hora = cursor.getString(cursor.getColumnIndexOrThrow("hora")),
        mes = cursor.getString(cursor.getColumnIndexOrThrow("mes")),
        ano = cursor.getString(cursor.getColumnIndexOrThrow("ano")),
        origem = cursor.getString(cursor.getColumnIndexOrThrow("origem")) ?: "",
        destino = cursor.getString(cursor.getColumnIndexOrThrow("destino")) ?: "",
        formaPagamento = cursor.getString(cursor.getColumnIndexOrThrow("forma_pagamento")) ?: "",
        passageiro = try { cursor.getString(cursor.getColumnIndexOrThrow("passageiro")) ?: "" } catch (_: Exception) { "" },
        horaInicio = try { cursor.getString(cursor.getColumnIndexOrThrow("hora_inicio")) ?: "" } catch (_: Exception) { "" },
        horaFim = try { cursor.getString(cursor.getColumnIndexOrThrow("hora_fim")) ?: "" } catch (_: Exception) { "" },
        tempoExecucao = try { cursor.getString(cursor.getColumnIndexOrThrow("tempo_execucao")) ?: "" } catch (_: Exception) { "" }
    )

    fun buscarPorPeriodo(inicio: Long, fim: Long): List<Corrida> {
        val lista = mutableListOf<Corrida>()
        try {
            val cursor = readableDatabase.query(
                "corridas", null,
                "timestamp >= ? AND timestamp <= ?",
                arrayOf(inicio.toString(), fim.toString()),
                null, null, "timestamp DESC"
            )
            cursor.use { while (it.moveToNext()) lista.add(cursorToCorrida(it)) }
        } catch (_: Exception) {}
        return lista
    }

    fun buscarHoje(): List<Corrida> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        val inicio = cal.timeInMillis
        cal.set(Calendar.HOUR_OF_DAY, 23); cal.set(Calendar.MINUTE, 59); cal.set(Calendar.SECOND, 59)
        return buscarPorPeriodo(inicio, cal.timeInMillis)
    }

    fun buscarSemana(): List<Corrida> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_WEEK, cal.firstDayOfWeek)
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        return buscarPorPeriodo(cal.timeInMillis, System.currentTimeMillis())
    }

    fun buscarMes(mes: Int, ano: Int): List<Corrida> {
        val cal = Calendar.getInstance()
        cal.set(ano, mes, 1, 0, 0, 0); cal.set(Calendar.MILLISECOND, 0)
        val inicio = cal.timeInMillis
        cal.set(ano, mes + 1, 1, 0, 0, 0)
        return buscarPorPeriodo(inicio, cal.timeInMillis)
    }

    fun buscarAno(ano: Int): List<Corrida> {
        val cal = Calendar.getInstance()
        cal.set(ano, 0, 1, 0, 0, 0); cal.set(Calendar.MILLISECOND, 0)
        val inicio = cal.timeInMillis
        cal.set(ano + 1, 0, 1, 0, 0, 0)
        return buscarPorPeriodo(inicio, cal.timeInMillis)
    }

    fun buscarDia(ano: Int, mes: Int, dia: Int): List<Corrida> {
        val cal = Calendar.getInstance()
        cal.set(ano, mes, dia, 0, 0, 0); cal.set(Calendar.MILLISECOND, 0)
        val inicio = cal.timeInMillis
        cal.set(ano, mes, dia, 23, 59, 59); cal.set(Calendar.MILLISECOND, 999)
        return buscarPorPeriodo(inicio, cal.timeInMillis)
    }

    fun buscarOntem(): List<Corrida> {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -1)
        return buscarDia(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH))
    }

    fun buscarTodas(): List<Corrida> = buscarPorPeriodo(0, Long.MAX_VALUE)

    fun limparHoje() {
        try {
            val cal = Calendar.getInstance()
            cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
            writableDatabase.delete("corridas", "timestamp >= ?", arrayOf(cal.timeInMillis.toString()))
        } catch (_: Exception) {}
    }

    fun limparTudo() {
        try { writableDatabase.delete("corridas", null, null) } catch (_: Exception) {}
    }

    fun deletarCorrida(id: Long) {
        try { writableDatabase.delete("corridas", "id = ?", arrayOf(id.toString())) } catch (_: Exception) {}
    }

    fun buscarAbastecimentos(): List<Abastecimento> {
        val lista = mutableListOf<Abastecimento>()
        try {
            val cursor = readableDatabase.query(
                "abastecimentos", null, null, null, null, null, "timestamp DESC"
            )
            cursor.use { c ->
                while (c.moveToNext()) {
                    lista.add(Abastecimento(
                        id = c.getLong(c.getColumnIndexOrThrow("id")),
                        litros = c.getFloat(c.getColumnIndexOrThrow("litros")),
                        valorTotal = c.getFloat(c.getColumnIndexOrThrow("valor_total")),
                        precoPorLitro = c.getFloat(c.getColumnIndexOrThrow("preco_por_litro")),
                        kmAtual = c.getFloat(c.getColumnIndexOrThrow("km_atual")),
                        timestamp = c.getLong(c.getColumnIndexOrThrow("timestamp")),
                        data = c.getString(c.getColumnIndexOrThrow("data"))
                    ))
                }
            }
        } catch (_: Exception) {}
        return lista
    }

    fun resumo(corridas: List<Corrida>): Map<String, Float> {
        val total = corridas.sumOf { it.valor.toDouble() }.toFloat()
        val kmTotal = corridas.sumOf { it.kmTotal.toDouble() }.toFloat()
        return mapOf(
            "total" to total,
            "corridas" to corridas.size.toFloat(),
            "km_total" to kmTotal,
            "media_km" to if (kmTotal > 0) total / kmTotal else 0f,
            "media_corrida" to if (corridas.isNotEmpty()) total / corridas.size else 0f
        )
    }
}
