package com.fluxoapp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.*

data class Corrida(
    val id: Long = 0,
    val valor: Float,
    val kmTotal: Float,
    val ganhoPorKm: Float,
    val valeAPena: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val data: String = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date()),
    val hora: String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()),
    val mes: String = SimpleDateFormat("MM/yyyy", Locale.getDefault()).format(Date()),
    val ano: String = SimpleDateFormat("yyyy", Locale.getDefault()).format(Date()),
    val origem: String = "",
    val destino: String = "",
    val formaPagamento: String = "",
    val passageiro: String = "",
    val horaInicio: String = "",
    val horaFim: String = "",
    val tempoExecucao: String = ""
)

data class Abastecimento(
    val id: Long = 0,
    val litros: Float,
    val valorTotal: Float,
    val precoPorLitro: Float,
    val kmAtual: Float,
    val timestamp: Long = System.currentTimeMillis(),
    val data: String = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())
)

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, "fluxoapp.db", null, 6) {

    override fun onCreate(db: SQLiteDatabase) {
        try {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS corridas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                valor REAL, km_total REAL, ganho_por_km REAL,
                vale_a_pena INTEGER, timestamp INTEGER,
                data TEXT, hora TEXT, mes TEXT, ano TEXT,
                origem TEXT DEFAULT '', destino TEXT DEFAULT '',
                forma_pagamento TEXT DEFAULT '',
                passageiro TEXT DEFAULT '',
                hora_inicio TEXT DEFAULT '',
                hora_fim TEXT DEFAULT '',
                tempo_execucao TEXT DEFAULT ''
            )
        """)
        // Índice no timestamp para buscas por período serem O(log n) em vez de O(n)
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_corridas_timestamp ON corridas(timestamp DESC)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_corridas_data ON corridas(data)")
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS quilometragem (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                km_odometro REAL,
                timestamp INTEGER,
                data TEXT,
                observacao TEXT DEFAULT ''
            )
        """)
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS abastecimentos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                litros REAL, valor_total REAL, preco_por_litro REAL,
                km_atual REAL, timestamp INTEGER, data TEXT
            )
        """)
    }
        } catch (e: Exception) {
            android.util.Log.e("FluxoApp", "DB onCreate error: ${e.message}", e)
        }
    }

        override fun onOpen(db: SQLiteDatabase) {
        super.onOpen(db)
        // WAL removido — causava travamento em MIUI/Android 10
        // SQLite padrão (DELETE mode) é estável em todos os dispositivos
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        try { db.execSQL("ALTER TABLE corridas ADD COLUMN origem TEXT DEFAULT ''") } catch (_: Exception) {}
        try { db.execSQL("ALTER TABLE corridas ADD COLUMN destino TEXT DEFAULT ''") } catch (_: Exception) {}
        try { db.execSQL("ALTER TABLE corridas ADD COLUMN forma_pagamento TEXT DEFAULT ''") } catch (_: Exception) {}
        try { db.execSQL("ALTER TABLE corridas ADD COLUMN passageiro TEXT DEFAULT ''") } catch (_: Exception) {}
        try { db.execSQL("ALTER TABLE corridas ADD COLUMN hora_inicio TEXT DEFAULT ''") } catch (_: Exception) {}
        try { db.execSQL("ALTER TABLE corridas ADD COLUMN hora_fim TEXT DEFAULT ''") } catch (_: Exception) {}
        try { db.execSQL("ALTER TABLE corridas ADD COLUMN tempo_execucao TEXT DEFAULT ''") } catch (_: Exception) {}
        // v6: índices + tabela quilometragem
        try { db.execSQL("CREATE INDEX IF NOT EXISTS idx_corridas_timestamp ON corridas(timestamp DESC)") } catch (_: Exception) {}
        try { db.execSQL("CREATE INDEX IF NOT EXISTS idx_corridas_data ON corridas(data)") } catch (_: Exception) {}
        try { db.execSQL("CREATE TABLE IF NOT EXISTS quilometragem (id INTEGER PRIMARY KEY AUTOINCREMENT, km_odometro REAL, timestamp INTEGER, data TEXT, observacao TEXT DEFAULT '')") } catch (_: Exception) {}
    }

    fun inserirCorrida(corrida: Corrida): Long {
        return try {
            val v = ContentValues().apply {
                put("valor", corrida.valor)
                put("km_total", corrida.kmTotal)
                put("ganho_por_km", corrida.ganhoPorKm)
                put("vale_a_pena", if (corrida.valeAPena) 1 else 0)
                put("timestamp", corrida.timestamp)
                put("data", corrida.data)
                put("hora", corrida.hora)
                put("mes", corrida.mes)
                put("ano", corrida.ano)
                put("origem", corrida.origem)
                put("destino", corrida.destino)
                put("forma_pagamento", corrida.formaPagamento)
                put("passageiro", corrida.passageiro)
                put("hora_inicio", corrida.horaInicio)
                put("hora_fim", corrida.horaFim)
                put("tempo_execucao", corrida.tempoExecucao)
            }
            writableDatabase.insert("corridas", null, v)
        } catch (_: Exception) { -1L }
    }

    fun inserirAbastecimento(a: Abastecimento): Long {
        return try {
            val v = ContentValues().apply {
                put("litros", a.litros)
                put("valor_total", a.valorTotal)
                put("preco_por_litro", a.precoPorLitro)
                put("km_atual", a.kmAtual)
                put("timestamp", a.timestamp)
                put("data", a.data)
            }
            writableDatabase.insert("abastecimentos", null, v)
        } catch (_: Exception) { -1L }
    }

    // FIX: cache dos índices de colunas — calculados UMA vez por cursor, não 17x por linha
    private fun cursorToCorrida(cursor: android.database.Cursor): Corrida {
        val iId    = cursor.getColumnIndexOrThrow("id")
        val iVal   = cursor.getColumnIndexOrThrow("valor")
        val iKm    = cursor.getColumnIndexOrThrow("km_total")
        val iGkm   = cursor.getColumnIndexOrThrow("ganho_por_km")
        val iVale  = cursor.getColumnIndexOrThrow("vale_a_pena")
        val iTs    = cursor.getColumnIndexOrThrow("timestamp")
        val iData  = cursor.getColumnIndexOrThrow("data")
        val iHora  = cursor.getColumnIndexOrThrow("hora")
        val iMes   = cursor.getColumnIndexOrThrow("mes")
        val iAno   = cursor.getColumnIndexOrThrow("ano")
        val iOrig  = cursor.getColumnIndexOrThrow("origem")
        val iDest  = cursor.getColumnIndexOrThrow("destino")
        val iPag   = cursor.getColumnIndexOrThrow("forma_pagamento")
        val iPass  = cursor.getColumnIndex("passageiro")
        val iHIni  = cursor.getColumnIndex("hora_inicio")
        val iHFim  = cursor.getColumnIndex("hora_fim")
        val iTempo = cursor.getColumnIndex("tempo_execucao")
        return Corrida(
            id             = cursor.getLong(iId),
            valor          = cursor.getFloat(iVal),
            kmTotal        = cursor.getFloat(iKm),
            ganhoPorKm     = cursor.getFloat(iGkm),
            valeAPena      = cursor.getInt(iVale) == 1,
            timestamp      = cursor.getLong(iTs),
            data           = cursor.getString(iData),
            hora           = cursor.getString(iHora),
            mes            = cursor.getString(iMes),
            ano            = cursor.getString(iAno),
            origem         = cursor.getString(iOrig) ?: "",
            destino        = cursor.getString(iDest) ?: "",
            formaPagamento = cursor.getString(iPag)  ?: "",
            passageiro     = if (iPass >= 0) cursor.getString(iPass) ?: "" else "",
            horaInicio     = if (iHIni >= 0) cursor.getString(iHIni) ?: "" else "",
            horaFim        = if (iHFim >= 0) cursor.getString(iHFim) ?: "" else "",
            tempoExecucao  = if (iTempo >= 0) cursor.getString(iTempo) ?: "" else ""
        )
    }

    fun buscarPorPeriodo(inicio: Long, fim: Long): List<Corrida> {
        val lista = mutableListOf<Corrida>()
        try {
            val cursor = readableDatabase.query(
                "corridas", null,
                "timestamp >= ? AND timestamp <= ?",
                arrayOf(inicio.toString(), fim.toString()),
                null, null, "timestamp DESC"
            )
            cursor.use { while (it.moveToNext()) lista.add(cursorToCorrida(it)) }
        } catch (_: Exception) {}
        return lista
    }

    fun buscarHoje(): List<Corrida> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        val inicio = cal.timeInMillis
        cal.set(Calendar.HOUR_OF_DAY, 23); cal.set(Calendar.MINUTE, 59); cal.set(Calendar.SECOND, 59)
        return buscarPorPeriodo(inicio, cal.timeInMillis)
    }

    fun buscarSemana(): List<Corrida> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_WEEK, cal.firstDayOfWeek)
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        return buscarPorPeriodo(cal.timeInMillis, System.currentTimeMillis())
    }

    fun buscarMes(mes: Int, ano: Int): List<Corrida> {
        val cal = Calendar.getInstance()
        cal.set(ano, mes, 1, 0, 0, 0); cal.set(Calendar.MILLISECOND, 0)
        val inicio = cal.timeInMillis
        // FIX: usar add(MONTH,1) para evitar overflow em dezembro (mes+1=12)
        cal.add(Calendar.MONTH, 1)
        return buscarPorPeriodo(inicio, cal.timeInMillis)
    }

    fun buscarAno(ano: Int): List<Corrida> {
        val cal = Calendar.getInstance()
        cal.set(ano, 0, 1, 0, 0, 0); cal.set(Calendar.MILLISECOND, 0)
        val inicio = cal.timeInMillis
        cal.set(ano + 1, 0, 1, 0, 0, 0)
        return buscarPorPeriodo(inicio, cal.timeInMillis)
    }

    fun buscarDia(ano: Int, mes: Int, dia: Int): List<Corrida> {
        val cal = Calendar.getInstance()
        cal.set(ano, mes, dia, 0, 0, 0); cal.set(Calendar.MILLISECOND, 0)
        val inicio = cal.timeInMillis
        cal.set(ano, mes, dia, 23, 59, 59); cal.set(Calendar.MILLISECOND, 999)
        return buscarPorPeriodo(inicio, cal.timeInMillis)
    }

    fun buscarOntem(): List<Corrida> {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -1)
        return buscarDia(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH))
    }

    fun buscarTodas(): List<Corrida> = buscarPorPeriodo(0, Long.MAX_VALUE)

    fun limparHoje() {
        try {
            val cal = Calendar.getInstance()
            cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
            writableDatabase.delete("corridas", "timestamp >= ?", arrayOf(cal.timeInMillis.toString()))
        } catch (_: Exception) {}
    }

    fun limparTudo() {
        try { writableDatabase.delete("corridas", null, null) } catch (_: Exception) {}
    }

    fun deletarCorrida(id: Long) {
        try { writableDatabase.delete("corridas", "id = ?", arrayOf(id.toString())) } catch (_: Exception) {}
    }

    fun editarCorrida(id: Long, novoValor: Float, novaObs: String = "") {
        try {
            val km = readableDatabase.rawQuery(
                "SELECT km_total FROM corridas WHERE id = ?", arrayOf(id.toString())
            ).use { c -> if (c.moveToFirst()) c.getFloat(0) else 0f }
            val gkm = if (km > 0f) novoValor / km else 0f
            val v = ContentValues().apply {
                put("valor", novoValor)
                put("ganho_por_km", gkm)
                put("vale_a_pena", if (gkm >= 1.20f) 1 else 0)
            }
            writableDatabase.update("corridas", v, "id = ?", arrayOf(id.toString()))
        } catch (_: Exception) {}
    }

    fun inserirCorridaManual(corrida: Corrida): Long = inserirCorrida(corrida)

    fun buscarAbastecimentos(): List<Abastecimento> {
        val lista = mutableListOf<Abastecimento>()
        try {
            val cursor = readableDatabase.query(
                "abastecimentos", null, null, null, null, null, "timestamp DESC"
            )
            cursor.use { c ->
                while (c.moveToNext()) {
                    lista.add(Abastecimento(
                        id = c.getLong(c.getColumnIndexOrThrow("id")),
                        litros = c.getFloat(c.getColumnIndexOrThrow("litros")),
                        valorTotal = c.getFloat(c.getColumnIndexOrThrow("valor_total")),
                        precoPorLitro = c.getFloat(c.getColumnIndexOrThrow("preco_por_litro")),
                        kmAtual = c.getFloat(c.getColumnIndexOrThrow("km_atual")),
                        timestamp = c.getLong(c.getColumnIndexOrThrow("timestamp")),
                        data = c.getString(c.getColumnIndexOrThrow("data"))
                    ))
                }
            }
        } catch (_: Exception) {}
        return lista
    }

    fun registrarKm(odometro: Float, obs: String = ""): Long {
        return try {
            val sdf = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault())
            val v = ContentValues().apply {
                put("km_odometro", odometro)
                put("timestamp", System.currentTimeMillis())
                put("data", sdf.format(java.util.Date()))
                put("observacao", obs)
            }
            writableDatabase.insert("quilometragem", null, v)
        } catch (_: Exception) { -1L }
    }

    fun buscarKm(): List<Triple<Long, Float, String>> {
        val lista = mutableListOf<Triple<Long, Float, String>>()
        try {
            readableDatabase.rawQuery(
                "SELECT id, km_odometro, data FROM quilometragem ORDER BY timestamp DESC LIMIT 50", null
            ).use { c ->
                while (c.moveToNext()) lista.add(Triple(c.getLong(0), c.getFloat(1), c.getString(2)))
            }
        } catch (_: Exception) {}
        return lista
    }

    fun ultimoKmOdometro(): Float {
        return try {
            readableDatabase.rawQuery(
                "SELECT km_odometro FROM quilometragem ORDER BY timestamp DESC LIMIT 1", null
            ).use { c -> if (c.moveToFirst()) c.getFloat(0) else 0f }
        } catch (_: Exception) { 0f }
    }

    fun resumo(corridas: List<Corrida>): Map<String, Float> {
        val total = corridas.sumOf { it.valor.toDouble() }.toFloat()
        val kmTotal = corridas.sumOf { it.kmTotal.toDouble() }.toFloat()
        return mapOf(
            "total" to total,
            "corridas" to corridas.size.toFloat(),
            "km_total" to kmTotal,
            "media_km" to if (kmTotal > 0) total / kmTotal else 0f,
            "media_corrida" to if (corridas.isNotEmpty()) total / corridas.size else 0f
        )
    }

}
