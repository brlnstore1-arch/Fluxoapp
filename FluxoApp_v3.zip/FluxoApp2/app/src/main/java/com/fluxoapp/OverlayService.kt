package com.fluxoapp

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.TextView
import androidx.core.app.NotificationCompat
import java.text.NumberFormat
import java.util.Locale

class OverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private val moeda = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))

    companion object {
        const val CHANNEL_ID = "fluxoapp_overlay"
        const val NOTIF_ID   = 2
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        criarCanal()
        val notif = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("FluxoApp")
            .setContentText("Aguardando corridas...")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true).build()
        startForeground(NOTIF_ID, notif)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "MOSTRAR" -> mostrarOverlay(
                intent.getFloatExtra("valor", 0f),
                intent.getFloatExtra("km_total", 0f),
                intent.getFloatExtra("ganho_por_km", 0f),
                intent.getBooleanExtra("vale_a_pena", false),
                intent.getBooleanExtra("auto_aceitar", false),
                intent.getBooleanExtra("auto_recusar", false)
            )
            "ESCONDER" -> esconderOverlay()
        }
        return START_STICKY
    }

    private fun mostrarOverlay(valor: Float, kmTotal: Float, ganhoPorKm: Float,
                                valeAPena: Boolean, autoAceitar: Boolean, autoRecusar: Boolean) {
        esconderOverlay()
        try {
            val prefs  = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
            val isGold = prefs.getString("tema_estilo", "azul") == "gold"
            val bgCard = ThemeHelper.cor("bg_card",    prefs)
            val txtW   = ThemeHelper.cor("text_white", prefs)
            val txtG   = ThemeHelper.cor("text_gray",  prefs)
            val gold   = ThemeHelper.cor("accent_gold", prefs)
            val border = ThemeHelper.cor("border",     prefs)
            val dp     = resources.displayMetrics.density

            // Cor de fundo do overlay ajustada por tema
            val bgOverlay = if (isGold)
                Color.parseColor("#F01A1610")   // gold noite: quase preto semi-transparente
            else
                Color.parseColor("#F00A1628")   // azul noite: azul escuro semi-transparente

            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            overlayView   = LayoutInflater.from(this).inflate(R.layout.overlay_layout, null)

            // Fundo dinâmico do overlay
            GradientDrawable().apply {
                setColor(bgOverlay)
                cornerRadius = (16 * dp)
            }.also { overlayView?.background = it }

            // Preencher dados
            overlayView!!.findViewById<TextView>(R.id.tvValor).apply {
                text = moeda.format(valor)
                setTextColor(ThemeHelper.cor("accent_green", prefs))
            }
            overlayView!!.findViewById<TextView>(R.id.tvKmTotal).apply {
                text = "${"%.1f".format(kmTotal)} km"
                setTextColor(txtW)
            }
            overlayView!!.findViewById<TextView>(R.id.tvGanhoPorKm).apply {
                text = "R$ ${"%.2f".format(ganhoPorKm)}/km"
                setTextColor(gold)
            }

            // Labels
            for (id in listOf(
                overlayView!!.findViewById<TextView>(
                    resources.getIdentifier("tvLabelValor", "id", packageName)),
                overlayView!!.findViewById<TextView>(
                    resources.getIdentifier("tvLabelKm", "id", packageName)),
                overlayView!!.findViewById<TextView>(
                    resources.getIdentifier("tvLabelKmRate", "id", packageName))
            )) { try { id?.setTextColor(txtG) } catch (_: Exception) {} }

            val tvValeAPena = overlayView!!.findViewById<TextView>(R.id.tvValeAPena)
            val header      = overlayView!!.findViewById<View>(R.id.headerLayout)
            val tvAuto      = overlayView!!.findViewById<TextView>(R.id.tvAutoAceitar)

            val modoAuto = (valeAPena && autoAceitar) || (!valeAPena && autoRecusar)
            tvAuto.visibility = if (modoAuto) View.VISIBLE else View.GONE
            tvAuto.text       = if (valeAPena) "AUTO-ACEITAR" else "AUTO-RECUSAR"

            // Header e botão veredito — verde/vermelho independente do tema (semântico)
            if (valeAPena) {
                val corHeader = if (isGold) Color.parseColor("#1A4A2A") else Color.parseColor("#00C853")
                header.setBackgroundColor(corHeader)
                tvValeAPena.text = "VALE A PENA!"
                GradientDrawable().apply {
                    setColor(Color.parseColor("#00C853")); cornerRadius = 8 * dp
                }.also { tvValeAPena.background = it }
                tvValeAPena.setTextColor(Color.parseColor("#003300"))
            } else {
                val corHeader = if (isGold) Color.parseColor("#4A1A1A") else Color.parseColor("#FF1744")
                header.setBackgroundColor(corHeader)
                tvValeAPena.text = "NÃO VALE A PENA"
                GradientDrawable().apply {
                    setColor(Color.parseColor("#FF1744")); cornerRadius = 8 * dp
                }.also { tvValeAPena.background = it }
                tvValeAPena.setTextColor(Color.WHITE)
            }

            // Título "FLUXOAPP" no header — cor do tema
            val tvHeaderTitle = overlayView!!.findViewById<TextView>(
                resources.getIdentifier("tvHeaderTitle", "id", packageName))
            val corTitulo = if (isGold) Color.parseColor("#C9A84C") else Color.parseColor("#00C8FF")
            try { tvHeaderTitle?.setTextColor(corTitulo) } catch (_: Exception) {}

            overlayView!!.findViewById<TextView>(R.id.btnFechar).setOnClickListener { esconderOverlay() }

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 0 }

            windowManager?.addView(overlayView, params)
        } catch (_: Exception) {}
    }

    private fun esconderOverlay() {
        overlayView?.let {
            try { windowManager?.removeView(it) } catch (_: Exception) {}
            overlayView = null
        }
    }

    private fun criarCanal() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val canal = NotificationChannel(CHANNEL_ID, "FluxoApp Overlay",
                NotificationManager.IMPORTANCE_MIN
            ).apply { setShowBadge(false) }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(canal)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        esconderOverlay()
        windowManager = null
    }
}
