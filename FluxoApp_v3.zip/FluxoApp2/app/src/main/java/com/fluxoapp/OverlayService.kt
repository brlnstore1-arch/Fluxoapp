package com.fluxoapp

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.TextView
import androidx.core.app.NotificationCompat
import java.text.NumberFormat
import java.util.Locale

class OverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private val moeda = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))

    companion object {
        const val CHANNEL_ID = "fluxoapp_overlay"
        const val NOTIF_ID   = 2
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        criarCanal()
        val notif = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("FluxoApp")
            .setContentText("Aguardando corridas...")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true).build()
        startForeground(NOTIF_ID, notif)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "MOSTRAR" -> mostrarOverlay(
                intent.getFloatExtra("valor", 0f),
                intent.getFloatExtra("km_total", 0f),
                intent.getFloatExtra("ganho_por_km", 0f),
                intent.getBooleanExtra("vale_a_pena", false),
                intent.getBooleanExtra("auto_aceitar", false),
                intent.getBooleanExtra("auto_recusar", false)
            )
            "ESCONDER" -> esconderOverlay()
        }
        return START_STICKY
    }

    private fun mostrarOverlay(valor: Float, kmTotal: Float, ganhoPorKm: Float,
                                valeAPena: Boolean, autoAceitar: Boolean, autoRecusar: Boolean) {
        esconderOverlay()
        try {
            val prefs   = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
            val isGold  = prefs.getString("tema_estilo", "azul") == "gold"
            val isDia   = !ThemeHelper.isModoNoturno(prefs)
            val dp      = resources.displayMetrics.density

            // Cores do tema atual
            val txtW    = ThemeHelper.cor("text_white",  prefs)
            val txtG    = ThemeHelper.cor("text_gray",   prefs)
            val gold    = ThemeHelper.cor("accent_gold", prefs)
            val green   = ThemeHelper.cor("accent_green", prefs)
            val bgCard  = ThemeHelper.cor("bg_card",     prefs)

            // Fundo do overlay — semi-transparente adaptado ao tema/modo
            val bgOverlay = when {
                isGold && !isDia -> Color.parseColor("#F01A1610")  // gold noite: quase preto
                isGold &&  isDia -> Color.parseColor("#F0FAF6EF")  // gold dia: creme
                !isGold && !isDia-> Color.parseColor("#F00A1628")  // azul noite: azul escuro
                else             -> Color.parseColor("#F0E4EFF9")  // azul dia: azul claro
            }

            // Cor do título "FLUXOAPP" no header — acento do tema
            val corTitulo = if (isGold)
                Color.parseColor("#C9A84C")   // dourado
            else
                Color.parseColor("#00C8FF")   // cyan

            // Cor do texto dos labels (VALOR, KM TOTAL, R$/KM)
            val corLabel = if (isDia)
                Color.parseColor("#66000000")  // semi-transparente escuro para fundo claro
            else
                Color.parseColor("#88FFFFFF")  // semi-transparente branco para fundo escuro

            // Cor do botão fechar e texto auto
            val corFechar = if (isDia) Color.parseColor("#333333") else Color.WHITE

            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            overlayView   = LayoutInflater.from(this).inflate(R.layout.overlay_layout, null)

            // Fundo dinâmico
            GradientDrawable().apply {
                setColor(bgOverlay)
                cornerRadius = 16 * dp
                setStroke((1 * dp).toInt(),
                    if (isGold) Color.parseColor("#2A2418") else Color.parseColor("#1A3055"))
            }.also { overlayView?.background = it }

            // Header título "FLUXOAPP"
            overlayView!!.findViewById<TextView>(R.id.tvHeaderTitle).apply {
                setTextColor(corTitulo)
            }

            // Botão fechar e auto
            overlayView!!.findViewById<TextView>(R.id.btnFechar).setTextColor(corFechar)
            overlayView!!.findViewById<TextView>(R.id.tvAutoAceitar).setTextColor(corFechar)

            // Labels
            overlayView!!.findViewById<TextView>(R.id.tvLabelValor).setTextColor(corLabel)
            overlayView!!.findViewById<TextView>(R.id.tvLabelKm).setTextColor(corLabel)
            overlayView!!.findViewById<TextView>(R.id.tvLabelKmRate).setTextColor(corLabel)

            // Valores
            overlayView!!.findViewById<TextView>(R.id.tvValor).apply {
                text = moeda.format(valor)
                setTextColor(green)
            }
            overlayView!!.findViewById<TextView>(R.id.tvKmTotal).apply {
                text = "${"%.1f".format(kmTotal)} km"
                setTextColor(txtW)
            }
            overlayView!!.findViewById<TextView>(R.id.tvGanhoPorKm).apply {
                text = "R$ ${"%.2f".format(ganhoPorKm)}/km"
                setTextColor(gold)
            }

            // Auto-aceitar/recusar
            val tvAuto  = overlayView!!.findViewById<TextView>(R.id.tvAutoAceitar)
            val header  = overlayView!!.findViewById<View>(R.id.headerLayout)
            val modoAuto = (valeAPena && autoAceitar) || (!valeAPena && autoRecusar)
            tvAuto.visibility = if (modoAuto) View.VISIBLE else View.GONE
            tvAuto.text       = if (valeAPena) "AUTO-ACEITAR" else "AUTO-RECUSAR"

            // Header + botão veredito — verde/vermelho (semântico, mesmos para ambos temas)
            val tvValeAPena = overlayView!!.findViewById<TextView>(R.id.tvValeAPena)
            if (valeAPena) {
                val corBg = if (isGold) Color.parseColor("#0D3320") else Color.parseColor("#004D20")
                header.setBackgroundColor(corBg)
                tvValeAPena.text = "✓  VALE A PENA!"
                GradientDrawable().apply {
                    setColor(Color.parseColor("#00C853")); cornerRadius = 10 * dp
                }.also { tvValeAPena.background = it }
                tvValeAPena.setTextColor(Color.parseColor("#003300"))
            } else {
                val corBg = if (isGold) Color.parseColor("#3D0A0A") else Color.parseColor("#5C0011")
                header.setBackgroundColor(corBg)
                tvValeAPena.text = "✕  NÃO VALE A PENA"
                GradientDrawable().apply {
                    setColor(Color.parseColor("#D50000")); cornerRadius = 10 * dp
                }.also { tvValeAPena.background = it }
                tvValeAPena.setTextColor(Color.WHITE)
            }

            overlayView!!.findViewById<TextView>(R.id.btnFechar)
                .setOnClickListener { esconderOverlay() }

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 0 }

            windowManager?.addView(overlayView, params)
        } catch (_: Exception) {}
    }

    private fun esconderOverlay() {
        overlayView?.let {
            try { windowManager?.removeView(it) } catch (_: Exception) {}
            overlayView = null
        }
    }

    private fun criarCanal() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val canal = NotificationChannel(CHANNEL_ID, "FluxoApp Overlay",
                NotificationManager.IMPORTANCE_MIN
            ).apply { setShowBadge(false) }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(canal)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        esconderOverlay()
        windowManager = null
    }
}
