package com.fluxoapp

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.TextView
import androidx.core.app.NotificationCompat
import java.text.NumberFormat
import java.util.Locale

class OverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private val moeda = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))

    companion object {
        const val CHANNEL_ID = "fluxoapp_overlay"
        const val NOTIF_ID   = 2
        @Volatile var instanciaAtiva: OverlayService? = null
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instanciaAtiva = this
        criarCanal()
        val notif = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("FluxoApp")
            .setContentText("Aguardando corridas...")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true).build()
        startForeground(NOTIF_ID, notif)
    }


    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "MOSTRAR" -> mostrarOverlay(
                intent.getFloatExtra("valor", 0f),
                intent.getFloatExtra("km_total", 0f),
                intent.getFloatExtra("ganho_por_km", 0f),
                intent.getBooleanExtra("vale_a_pena", false),
                intent.getBooleanExtra("auto_aceitar", false),
                intent.getBooleanExtra("auto_recusar", false),
                intent.getStringExtra("origem") ?: "",
                intent.getStringExtra("destino") ?: ""
            )
            "ESCONDER" -> esconderOverlay()
        }
        return START_STICKY
    }

    private fun mostrarOverlay(valor: Float, kmTotal: Float, ganhoPorKm: Float,
                                valeAPena: Boolean, autoAceitar: Boolean, autoRecusar: Boolean,
                                origem: String = "", destino: String = "") {
        // Remover overlay anterior e mostrar novo imediatamente
        esconderOverlay()
        try {
            val prefs   = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
            val isGold  = prefs.getString("tema_estilo", "gold") == "gold"
            val isDia   = !ThemeHelper.isModoNoturno(prefs)
            val dp      = resources.displayMetrics.density

            // Cores 100% via ThemeHelper — zero hardcoded
            val txtW    = ThemeHelper.cor("text_white",  prefs)
            val txtG    = ThemeHelper.cor("text_gray",   prefs)
            val gold    = ThemeHelper.cor("accent_gold", prefs)
            val green   = ThemeHelper.cor("accent_green", prefs)
            val bgCard  = ThemeHelper.cor("bg_card",     prefs)
            val bgDark  = ThemeHelper.cor("bg_dark",     prefs)
            val border  = ThemeHelper.cor("border",      prefs)

            // Fundo do overlay acompanha o tema (claro ou escuro)
            val bgOverlay = Color.argb(
                245,
                Color.red(bgDark), Color.green(bgDark), Color.blue(bgDark)
            )
            val corTitulo = gold
            val corLabel  = txtG
            val corFechar = txtW

            if (windowManager == null)
                windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            overlayView = LayoutInflater.from(this).inflate(R.layout.overlay_layout, null)

            // Fundo dinâmico
            GradientDrawable().apply {
                setColor(bgOverlay)
                cornerRadius = 16 * dp
                setStroke((1 * dp).toInt(), border)
            }.also { overlayView?.background = it }

            // Header título "FLUXOAPP"
            overlayView!!.findViewById<TextView>(R.id.tvHeaderTitle).apply {
                setTextColor(corTitulo)
            }

            // Bairro de origem em destaque
            val tvBairro = overlayView!!.findViewById<TextView>(R.id.tvBairroOrigem)
            val tvLabelOrigem = overlayView!!.findViewById<TextView>(R.id.tvLabelOrigem)
            val tvHistorico = overlayView!!.findViewById<TextView>(R.id.tvHistoricoRegiao)

            if (origem.isNotBlank()) {
                // Extrair bairro/nome do local (remover ícones e endereços longos)
                val origemLimpa = origem
                    .replace("🏠 ", "").replace("🏁 ", "")
                    .trim()
                // Pegar o bairro entre parênteses se existir, senão usar os primeiros 40 chars
                val bairroMatch = Regex("\\(([^)]+)\\)").findAll(origemLimpa).lastOrNull()
                val bairroDestaque = bairroMatch?.groupValues?.get(1)?.trim()
                    ?: origemLimpa.substringBefore(",").take(35)
                tvBairro.text = bairroDestaque
                tvBairro.setTextColor(txtW)
                tvLabelOrigem.setTextColor(corLabel)

                // Verificar histórico da região no banco
                try {
                    val db = DatabaseHelper(this)
                    val todasCorridas = db.buscarTodas()
                    val corridasRegiao = todasCorridas.filter { c ->
                        c.origem.contains(bairroDestaque, ignoreCase = true) ||
                        c.destino.contains(bairroDestaque, ignoreCase = true)
                    }
                    if (corridasRegiao.size >= 2) {
                        val totalRegiao = corridasRegiao.sumOf { it.valor.toDouble() }.toFloat()
                        val mediaRegiao = totalRegiao / corridasRegiao.size
                        val mediaTodas = if (todasCorridas.isNotEmpty())
                            todasCorridas.sumOf { it.valor.toDouble() }.toFloat() / todasCorridas.size
                        else 0f
                        val pctBom = corridasRegiao.count { it.valeAPena }.toFloat() / corridasRegiao.size * 100
                        val (icone, textoHist, corHist) = when {
                            pctBom >= 70 -> Triple("✅", "${pctBom.toInt()}% valem a pena nessa região", Color.parseColor("#00E676"))
                            pctBom >= 40 -> Triple("⚡", "${pctBom.toInt()}% valem a pena nessa região", gold)
                            else         -> Triple("⚠️", "Região frequentemente abaixo do mínimo", Color.parseColor("#FF6B6B"))
                        }
                        tvHistorico.text = "$icone $textoHist (${corridasRegiao.size}x)"
                        tvHistorico.setTextColor(corHist)
                        tvHistorico.visibility = View.VISIBLE
                    } else {
                        tvHistorico.visibility = View.GONE
                    }
                } catch (_: Throwable) { tvHistorico.visibility = View.GONE }
            } else {
                tvBairro.text = "Origem não identificada"
                tvBairro.setTextColor(corLabel)
                tvHistorico.visibility = View.GONE
            }

            overlayView!!.findViewById<View>(R.id.viewDivisor).setBackgroundColor(border)

            // Botão fechar e auto
            overlayView!!.findViewById<TextView>(R.id.btnFechar).setTextColor(corFechar)
            overlayView!!.findViewById<TextView>(R.id.tvAutoAceitar).setTextColor(corFechar)

            // Labels
            overlayView!!.findViewById<TextView>(R.id.tvLabelValor).setTextColor(corLabel)
            overlayView!!.findViewById<TextView>(R.id.tvLabelKm).setTextColor(corLabel)
            overlayView!!.findViewById<TextView>(R.id.tvLabelKmRate).setTextColor(corLabel)

            // Valores
            overlayView!!.findViewById<TextView>(R.id.tvValor).apply {
                text = moeda.format(valor)
                setTextColor(green)
            }
            overlayView!!.findViewById<TextView>(R.id.tvKmTotal).apply {
                text = "${"%.1f".format(kmTotal)} km"
                setTextColor(txtW)
            }
            overlayView!!.findViewById<TextView>(R.id.tvGanhoPorKm).apply {
                text = "R$ ${"%.2f".format(ganhoPorKm)}/km"
                setTextColor(gold)
            }

            // Auto-aceitar/recusar
            val tvAuto  = overlayView!!.findViewById<TextView>(R.id.tvAutoAceitar)
            val header  = overlayView!!.findViewById<View>(R.id.headerLayout)
            val modoAuto = (valeAPena && autoAceitar) || (!valeAPena && autoRecusar)
            tvAuto.visibility = if (modoAuto) View.VISIBLE else View.GONE
            tvAuto.text       = if (valeAPena) "AUTO-ACEITAR" else "AUTO-RECUSAR"

            // Header — fundo segue o tema (bg_card), sem hardcode verde/vermelho
            header.setBackgroundColor(bgCard)

            // Botão veredito — único elemento que permanece verde/vermelho (semântico)
            val tvValeAPena = overlayView!!.findViewById<TextView>(R.id.tvValeAPena)
            val corVerde = ThemeHelper.cor("accent_green", prefs)
            val corVerm  = ThemeHelper.cor("accent_red",   prefs)
            if (valeAPena) {
                tvValeAPena.text = "✓  VALE A PENA!"
                GradientDrawable().apply {
                    setColor(corVerde); cornerRadius = 10 * dp
                }.also { tvValeAPena.background = it }
                tvValeAPena.setTextColor(Color.parseColor("#001A00"))
            } else {
                tvValeAPena.text = "✕  NÃO VALE A PENA"
                GradientDrawable().apply {
                    setColor(corVerm); cornerRadius = 10 * dp
                }.also { tvValeAPena.background = it }
                tvValeAPena.setTextColor(Color.WHITE)
            }

            overlayView!!.findViewById<TextView>(R.id.btnFechar)
                .setOnClickListener { esconderOverlay() }

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 0 }

            windowManager?.addView(overlayView, params)
        } catch (e: Throwable) {
            android.util.Log.e("FluxoApp.Overlay", "Erro ao mostrar overlay: ${e.message}", e)
        }
    }

    private fun esconderOverlay() {
        // Síncrono — BUG 1 FIX: Handler.post adiava a remoção causando dois overlays simultâneos
        overlayView?.let {
            try { windowManager?.removeView(it) } catch (_: Exception) {}
            overlayView = null
        }
    }

    private fun criarCanal() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val canal = NotificationChannel(CHANNEL_ID, "FluxoApp Overlay",
                NotificationManager.IMPORTANCE_MIN
            ).apply { setShowBadge(false) }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(canal)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        esconderOverlay()
        windowManager = null
        if (instanciaAtiva == this) instanciaAtiva = null
    }
}
