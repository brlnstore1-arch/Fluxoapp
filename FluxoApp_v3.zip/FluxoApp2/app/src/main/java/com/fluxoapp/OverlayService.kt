package com.fluxoapp

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.TextView
import androidx.core.app.NotificationCompat
import java.text.NumberFormat
import java.util.Locale

class OverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private val moeda = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))

    companion object {
        const val CHANNEL_ID = "fluxoapp_overlay"
        const val NOTIF_ID = 2
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        criarCanal()
        // Foreground mínimo apenas para proteger o serviço
        val notif = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("FluxoApp")
            .setContentText("Aguardando corridas...")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .build()
        startForeground(NOTIF_ID, notif)
    }

    private fun criarCanal() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val canal = NotificationChannel(
                CHANNEL_ID, "FluxoApp Overlay",
                NotificationManager.IMPORTANCE_MIN
            ).apply { setShowBadge(false) }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(canal)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "MOSTRAR" -> mostrarOverlay(
                intent.getFloatExtra("valor", 0f),
                intent.getFloatExtra("km_total", 0f),
                intent.getFloatExtra("ganho_por_km", 0f),
                intent.getBooleanExtra("vale_a_pena", false),
                intent.getBooleanExtra("auto_aceitar", false),
                intent.getBooleanExtra("auto_recusar", false)
            )
            "ESCONDER" -> esconderOverlay()
        }
        return START_STICKY
    }

    private fun mostrarOverlay(valor: Float, kmTotal: Float, ganhoPorKm: Float,
                                valeAPena: Boolean, autoAceitar: Boolean, autoRecusar: Boolean) {
        esconderOverlay()
        try {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            overlayView = LayoutInflater.from(this).inflate(R.layout.overlay_layout, null)

            overlayView!!.findViewById<TextView>(R.id.tvValor).text = moeda.format(valor)
            overlayView!!.findViewById<TextView>(R.id.tvKmTotal).text = "${"%.1f".format(kmTotal)} km"
            overlayView!!.findViewById<TextView>(R.id.tvGanhoPorKm).text = "R$ ${"%.2f".format(ganhoPorKm)}/km"

            val tvValeAPena = overlayView!!.findViewById<TextView>(R.id.tvValeAPena)
            val header = overlayView!!.findViewById<View>(R.id.headerLayout)
            val tvAuto = overlayView!!.findViewById<TextView>(R.id.tvAutoAceitar)

            val modoAuto = (valeAPena && autoAceitar) || (!valeAPena && autoRecusar)
            tvAuto.visibility = if (modoAuto) View.VISIBLE else View.GONE
            tvAuto.text = if (valeAPena) "AUTO-ACEITAR" else "AUTO-RECUSAR"

            if (valeAPena) {
                header.setBackgroundResource(R.drawable.overlay_header_green)
                tvValeAPena.text = "VALE A PENA!"
                tvValeAPena.setBackgroundResource(R.drawable.btn_green)
                tvValeAPena.setTextColor(0xFF003300.toInt())
            } else {
                header.setBackgroundResource(R.drawable.overlay_header_red)
                tvValeAPena.text = "NAO VALE A PENA"
                tvValeAPena.setBackgroundResource(R.drawable.btn_red)
                tvValeAPena.setTextColor(0xFFFFFFFF.toInt())
            }

            overlayView!!.findViewById<TextView>(R.id.btnFechar).setOnClickListener { esconderOverlay() }

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 0 }

            windowManager?.addView(overlayView, params)
        } catch (_: Exception) {}
    }

    private fun esconderOverlay() {
        overlayView?.let {
            try { windowManager?.removeView(it) } catch (_: Exception) {}
            overlayView = null
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        esconderOverlay()
        windowManager = null
    }
}
