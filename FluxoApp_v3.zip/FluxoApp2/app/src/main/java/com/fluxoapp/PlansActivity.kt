package com.fluxoapp

import android.content.Context
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class PlansActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeSelector.aplicar(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_plans)
        aplicarTema()
        configurar()
    }

    private fun aplicarTema() {
        val prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val dp    = resources.displayMetrics.density

        val bgDark  = ThemeHelper.cor("bg_dark",    prefs)
        val bgCard  = ThemeHelper.cor("bg_card",    prefs)
        val accent  = ThemeHelper.cor("accent",     prefs)
        val txtW    = ThemeHelper.cor("text_white", prefs)
        val txtG    = ThemeHelper.cor("text_gray",  prefs)
        val border  = ThemeHelper.cor("border",     prefs)
        val green   = ThemeHelper.cor("accent_green", prefs)

        findViewById<View>(R.id.rootPlans).setBackgroundColor(bgDark)

        // Título
        findViewById<TextView>(R.id.tvTituloPlanos).setTextColor(txtW)
        findViewById<TextView>(R.id.tvSubTituloPlanos).setTextColor(txtG)

        // Card do plano
        val card = findViewById<LinearLayout>(R.id.cardPlanoMensal)
        GradientDrawable().apply {
            setColor(bgCard)
            cornerRadius = 16 * dp
            setStroke((2 * dp).toInt(), accent)
        }.also { card.background = it }

        // Preço em accent
        findViewById<TextView>(R.id.tvNomePlano).setTextColor(accent)
        findViewById<TextView>(R.id.tvPrecoPlano).setTextColor(accent)

        // Benefícios em verde
        val beneficios = listOf(
            "✓  Detecção automática de corridas",
            "✓  Overlay de análise de oferta",
            "✓  Auto-aceitar / Auto-recusar",
            "✓  Histórico e relatórios completos",
            "✓  Botão flutuante de ganhos"
        )
        // Colorir todos os TextViews com "✓" dentro do card
        for (i in 0 until card.childCount) {
            val v = card.getChildAt(i)
            if (v is TextView) {
                val t = v.text.toString()
                when {
                    t.startsWith("✓") -> v.setTextColor(green)
                    t.startsWith("PLANO") -> v.setTextColor(accent)
                    else -> v.setTextColor(txtW)
                }
            }
        }

        // Botão assinar
        val btnAssinar = findViewById<Button>(R.id.btnAssinar)
        btnAssinar.backgroundTintList = null
        GradientDrawable().apply {
            setColor(accent)
            cornerRadius = 14 * dp
        }.also { btnAssinar.background = it }
        btnAssinar.setTextColor(bgDark)

        // Info trial
        findViewById<TextView>(R.id.tvInfoTrial).setTextColor(txtG)
    }

    private fun configurar() {
        // Mostrar dias restantes do trial se ainda ativo
        LicenseManager.verificarLicenca { status ->
            runOnUiThread {
                val tv = findViewById<TextView>(R.id.tvInfoTrial)
                when {
                    status.plano == LicenseManager.PLANO_TRIAL && status.temAcesso ->
                        tv.text = "Seu trial encerra em ${status.diasRestantes} dia(s)"
                    status.status == LicenseManager.STATUS_EXPIRADO ->
                        tv.text = "Seu acesso expirou — assine para continuar"
                    else -> tv.visibility = View.GONE
                }
            }
        }

        findViewById<Button>(R.id.btnAssinar).setOnClickListener {
            startActivity(Intent(this, PixPaymentActivity::class.java))
        }
    }
}
