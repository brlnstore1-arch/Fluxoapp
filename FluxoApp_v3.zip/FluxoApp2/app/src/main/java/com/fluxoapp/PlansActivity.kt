package com.fluxoapp

import android.content.Context
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class PlansActivity : AppCompatActivity() {

    private var cupomValidado: CupomManager.ResultadoCupom? = null

    override fun attachBaseContext(base: android.content.Context) {
        super.attachBaseContext(FontHelper.wrap(base))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeSelector.aplicar(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_plans)
        aplicarTema()
        aplicarTemaGlobal()
        configurar()
    }

    private fun aplicarTema() {
        val prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val dp    = resources.displayMetrics.density
        val bgDark  = ThemeHelper.cor("bg_dark",      prefs)
        val bgCard  = ThemeHelper.cor("bg_card",      prefs)
        val accent  = ThemeHelper.cor("accent",       prefs)
        val txtW    = ThemeHelper.cor("text_white",   prefs)
        val txtG    = ThemeHelper.cor("text_gray",    prefs)
        val green   = ThemeHelper.cor("accent_green", prefs)

        findViewById<View>(R.id.rootPlans).setBackgroundColor(bgDark)
        findViewById<TextView>(R.id.tvTituloPlanos).setTextColor(txtW)
        findViewById<TextView>(R.id.tvSubTituloPlanos).setTextColor(txtG)

        val card = findViewById<LinearLayout>(R.id.cardPlanoMensal)
        GradientDrawable().apply {
            setColor(bgCard); cornerRadius = 16 * dp
            setStroke((2 * dp).toInt(), accent)
        }.also { card.background = it }

        findViewById<TextView>(R.id.tvNomePlano).setTextColor(accent)
        findViewById<TextView>(R.id.tvPrecoPlano).setTextColor(accent)

        for (i in 0 until card.childCount) {
            val v = card.getChildAt(i)
            if (v is TextView) {
                val t = v.text.toString()
                when {
                    t.startsWith("✓")      -> v.setTextColor(green)
                    t.startsWith("PLANO")  -> v.setTextColor(accent)
                    else                   -> v.setTextColor(txtW)
                }
            }
        }

        // Campo cupom
        findViewById<EditText>(R.id.etCupom)?.apply {
            setTextColor(txtW); setHintTextColor(txtG)
            background = GradientDrawable().apply {
                setColor(bgCard); cornerRadius = 10 * dp
                setStroke((1 * dp).toInt(), accent)
            }
        }
        val btnAplicar = findViewById<Button>(R.id.btnAplicarCupom)
        btnAplicar?.backgroundTintList = null
        GradientDrawable().apply {
            setColor(bgCard); cornerRadius = 10 * dp
            setStroke((1 * dp).toInt(), accent)
        }.also { btnAplicar?.background = it }
        btnAplicar?.setTextColor(accent)

        // Botão assinar
        val btnAssinar = findViewById<Button>(R.id.btnAssinar)
        btnAssinar.backgroundTintList = null
        GradientDrawable().apply {
            setColor(accent); cornerRadius = 14 * dp
        }.also { btnAssinar.background = it }
        btnAssinar.setTextColor(bgDark)

        findViewById<TextView>(R.id.tvInfoTrial).setTextColor(txtG)
    }

    private fun configurar() {
        val prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val green = ThemeHelper.cor("accent_green", prefs)
        val red   = ThemeHelper.cor("accent_red",   prefs)

        // Dias restantes do trial
        LicenseManager.verificarLicenca { status ->
            runOnUiThread {
                val tv = findViewById<TextView>(R.id.tvInfoTrial)
                when {
                    status.plano == LicenseManager.PLANO_TRIAL && status.temAcesso ->
                        tv.text = "Seu trial encerra em ${status.diasRestantes} dia(s)"
                    status.status == LicenseManager.STATUS_EXPIRADO ->
                        tv.text = "Seu acesso expirou — assine para continuar"
                    else -> tv.visibility = View.GONE
                }
            }
        }

        val etCupom    = findViewById<EditText>(R.id.etCupom)
        val tvStatus   = findViewById<TextView>(R.id.tvCupomStatus)
        val btnAplicar = findViewById<Button>(R.id.btnAplicarCupom)
        val btnAssinar = findViewById<Button>(R.id.btnAssinar)

        // Aplicar cupom
        btnAplicar?.setOnClickListener {
            val codigo = etCupom?.text?.toString()?.trim() ?: return@setOnClickListener
            if (codigo.isBlank()) { FluxoToast.aviso(this, "Digite o código do cupom"); return@setOnClickListener }

            btnAplicar.isEnabled = false; btnAplicar.text = "..."
            tvStatus?.visibility = View.GONE

            CupomManager.validar(codigo) { resultado ->
                runOnUiThread {
                    btnAplicar.isEnabled = true; btnAplicar.text = "Aplicar"
                    tvStatus?.visibility = View.VISIBLE

                    if (resultado.valido) {
                        cupomValidado = resultado
                        tvStatus?.text = resultado.mensagem
                        tvStatus?.setTextColor(green)

                        when (resultado.tipo) {
                            "dias_gratis", "vitalicio" -> {
                                val uid = LicenseManager.uid() ?: return@runOnUiThread
                                btnAssinar.isEnabled = false
                                CupomManager.aplicar(uid, resultado) { ok, msg ->
                                    runOnUiThread {
                                        btnAssinar.isEnabled = true
                                        if (ok) {
                                            FluxoToast.celebrar(this, msg)
                                            android.os.Handler(android.os.Looper.getMainLooper())
                                                .postDelayed({ finish() }, 2200)
                                        } else {
                                            FluxoToast.erro(this, msg)
                                        }
                                    }
                                }
                            }
                            "desconto" -> {
                                val precoFinal = 4.99 * (1 - resultado.desconto / 100.0)
                                btnAssinar.text = "ASSINAR POR R$ ${"%.2f".format(precoFinal)} — PIX"
                                FluxoToast.sucesso(this, "${resultado.desconto}% de desconto aplicado!")
                            }
                        }
                    } else {
                        cupomValidado = null
                        tvStatus?.text = resultado.mensagem
                        tvStatus?.setTextColor(red)
                        FluxoToast.erro(this, resultado.mensagem)
                    }
                }
            }
        }

        // Botão assinar — passa cupom de desconto para PixPaymentActivity
        btnAssinar.setOnClickListener {
            val intent = Intent(this, PixPaymentActivity::class.java)
            cupomValidado?.takeIf { it.tipo == "desconto" }?.let { c ->
                intent.putExtra("cupom_codigo",   c.codigo)
                intent.putExtra("cupom_desconto", c.desconto)
            }
            startActivity(intent)
        }
    }
}
