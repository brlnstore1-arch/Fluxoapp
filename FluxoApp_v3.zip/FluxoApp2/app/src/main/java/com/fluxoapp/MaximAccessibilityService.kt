package com.fluxoapp

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * MaximAccessibilityService — FluxoApp
 *
 * Módulo EXCLUSIVO do Taxsee/Maxim. Monitora apenas o pacote com.taxsee.driver
 * e detecta corridas automaticamente.
 *
 * ⚠️ Este arquivo não deve conter NENHUMA lógica de outras plataformas
 * (99, Uber, etc). Cada plataforma tem seu próprio serviço de acessibilidade
 * independente — veja NoveNoveAccessibilityService.kt para a 99.
 *
 * ══════════════════════════════════════════════════════════════════════
 * FILA DE CORRIDAS (suporte a corridas sobrepostas)
 * ══════════════════════════════════════════════════════════════════════
 * Diferente da versão anterior (uma corrida por vez), este serviço agora
 * detecta e aceita uma NOVA oferta mesmo com outra(s) corrida(s) já em
 * andamento — como pedido pelo usuário: "toca uma corrida, aceita, e se
 * aparecer outra em cima antes de terminar a primeira, aceita essa também".
 *
 * Modelo usado: FILA FIFO (First In, First Out) — a primeira corrida
 * aceita é a primeira a ser finalizada. Essa suposição existe porque o
 * Taxsee só consegue exibir/navegar UMA rota ativa por vez na tela; não
 * há como o app mostrar duas navegações simultâneas. Então:
 *   - Corrida aceita → entra no fim da fila
 *   - Toast "pedido finalizado" → sempre se refere à corrida na FRENTE
 *     da fila (a mais antiga ainda ativa), que é removida e salva
 *   - A próxima corrida da fila passa a ser "a da frente"
 *
 * ⚠️ Isso é uma suposição sobre o comportamento real do Taxsee com pedidos
 * sobrepostos — não foi validado visualmente contra a tela real do app
 * nesse cenário específico. Se o comportamento observado for diferente,
 * a lógica de qual corrida corresponde a qual evento pode precisar ajuste.
 *
 * Lógica extraída para helpers:
 *   - MaximExtractor.kt  → extração de valor, km, origem, cliente, pagamento
 *   - MaximNodeUtils.kt  → travessia de árvore, cliques, gestos, coleta de texto
 */
class MaximAccessibilityService : AccessibilityService() {

    // ── Estado de LEITURA de popup (não confundir com a fila de corridas) ──
    // IDLE: nenhuma leitura de popup de oferta em andamento agora mesmo
    // LENDO_OFERTA: aguardando o delay de renderização (700ms) pra extrair
    //   os dados do popup que acabou de aparecer — evita reagendar a
    //   mesma leitura várias vezes enquanto o popup ainda está abrindo
    internal enum class Estado { IDLE, LENDO_OFERTA }
    internal var estado = Estado.IDLE

    /** Uma corrida aceita, da oferta até ser finalizada/salva. */
    internal data class CorridaFila(
        val valor: Float,
        val km: Float,
        val ganhoPorKm: Float,
        val valeAPena: Boolean,
        val origem: String,
        val destino: String,
        var cliente: String,
        val forma: String,
        val horaInicio: String,
        var finalValor: Float = 0f,
        var finalKm: Float = 0f,
        var finalTempo: String = "",
        // true assim que a tela confirma "a caminho" (ou os botões
        // Aceitar/Recusar somem) — indica que a corrida está mesmo ativa,
        // não só uma oferta que apareceu e foi recusada/expirou
        var confirmada: Boolean = false,
        // true quando já vimos a "tela de finalizar" pelo menos uma vez,
        // pra não iniciar o timeout de segurança mais de uma vez
        var timeoutIniciado: Boolean = false
    )

    /**
     * Fila de corridas aceitas, ainda não finalizadas. Posição 0 = a mais
     * antiga = a que está sendo navegada/exibida agora na tela do Taxsee.
     */
    internal val filaCorridas = mutableListOf<CorridaFila>()

    // ── Controle de overlay ───────────────────────────────────────────────
    internal var overlayAtivo      = false
    internal var ultimoValorOferta = 0f

    // ── Runnables nomeados ────────────────────────────────────────────────
    internal var runnableAutoAceitar:   Runnable? = null
    internal var runnableAutoRecusar:   Runnable? = null
    internal var runnableLeituraOferta: Runnable? = null

    // ── Handler e debounce ────────────────────────────────────────────────
    internal val handler            = Handler(Looper.getMainLooper())
    internal var ultimoEventoTelaMs = 0L
    internal var timeoutRunnable: Runnable? = null

    companion object {
        internal const val PKG_TAXSEE               = "com.taxsee.driver"
        internal const val DEBOUNCE_TELA_MS          = 350L
        internal const val ATRASO_LEITURA_OFERTA_MS  = 700L
        internal const val TIMEOUT_FINALIZANDO_MS    = 30_000L
        internal const val TIMEOUT_EM_ANDAMENTO_MS   = 720_000L
    }

    // ══════════════════════════════════════════════════════════════════════
    // PONTO DE ENTRADA
    // ══════════════════════════════════════════════════════════════════════

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        if (event.packageName?.toString() != PKG_TAXSEE) return

        if (!LicenseManager.estaLogado()) return
        val prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("servico_ativo", true)) return

        val tipo = event.eventType
        val textoEvento = event.text?.joinToString(" ")?.trim()
            ?.lowercase(Locale.getDefault()) ?: ""

        if (tipo == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED ||
            tipo == AccessibilityEvent.TYPE_ANNOUNCEMENT) {
            if (textoEvento.isNotBlank()) processarToast(textoEvento)
            return
        }

        if (tipo == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            tipo == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            if (textoEvento.isNotBlank()) processarToast(textoEvento)

            val agora = System.currentTimeMillis()
            if (agora - ultimoEventoTelaMs < DEBOUNCE_TELA_MS) return
            ultimoEventoTelaMs = agora

            val raiz = rootInActiveWindow ?: return
            processarTela(raiz)
        }
    }

    override fun onInterrupt() { resetarEstadoCompleto() }

    // ══════════════════════════════════════════════════════════════════════
    // PROCESSAMENTO DE TOAST
    // ══════════════════════════════════════════════════════════════════════

    private fun processarToast(texto: String) {
        val t = texto.lowercase(Locale.getDefault()).trim()

        if (eToastFinalizacao(t)) {
            // A finalização sempre se refere à corrida na FRENTE da fila
            // (suposição FIFO — só existe uma navegação ativa por vez na tela)
            val frente = filaCorridas.firstOrNull() ?: return
            cancelarTimeout()
            filaCorridas.removeAt(0)
            salvarCorrida(frente)
            return
        }

        if (eToastCancelamento(t)) {
            cancelarOfertaOuCorridaMaisRecente()
        }
    }

    /** Toast exato do Taxsee: "Pedido finalizado! Aguarde pelo próximo." */
    private fun eToastFinalizacao(t: String): Boolean =
        t.contains("pedido finalizado")    ||
        t.contains("aguarde pelo próximo") ||
        t.contains("aguarde pelo proximo") ||
        t.contains("viagem finalizada")    ||
        t.contains("corrida finalizada")   ||
        t.contains("entrega conclu")

    /**
     * ⚠️ NÃO usar "cancelad" genérico — o contador "será cancelado em 18s"
     * contém "cancelado" mas não é cancelamento real.
     */
    private fun eToastCancelamento(t: String): Boolean =
        t.contains("pedido cancelado")  ||
        t.contains("corrida cancelada") ||
        t.contains("viagem cancelada")  ||
        t.contains("pedido recusado")   ||
        t.contains("corrida recusada")

    /**
     * Remove da fila a corrida cancelada. Como não há como saber com 100%
     * de certeza QUAL corrida foi cancelada quando há mais de uma na fila,
     * a prioridade é: a que ainda não foi confirmada (mais provável de ser
     * a que acabou de ser oferecida) e, se não houver, a da frente da fila.
     */
    private fun cancelarOfertaOuCorridaMaisRecente() {
        val alvo = filaCorridas.lastOrNull { !it.confirmada } ?: filaCorridas.firstOrNull()
        cancelarAutoAR()
        esconderOverlay()
        fecharDialogCancelamento()
        if (alvo != null) {
            filaCorridas.remove(alvo)
            if (filaCorridas.isEmpty()) cancelarTimeout()
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    // PROCESSAMENTO DE TELA
    // ══════════════════════════════════════════════════════════════════════

    private fun processarTela(raiz: AccessibilityNodeInfo) {
        val textoTela = coletarTextoTela(raiz)

        // Sempre verifica se apareceu uma NOVA oferta — mesmo com corrida(s)
        // já em andamento na fila. É isso que permite aceitar sobreposta.
        if (estado != Estado.LENDO_OFERTA) {
            verificarOferta(raiz, textoTela)
        }

        // Acompanha confirmação de aceite + finalização da corrida na
        // frente da fila (a que está sendo navegada/exibida agora).
        if (filaCorridas.isNotEmpty()) {
            verificarProgressoFila(raiz, textoTela)
        }
    }

    // ── Detecta nova oferta (a qualquer momento, mesmo com fila ativa) ─────

    private fun verificarOferta(raiz: AccessibilityNodeInfo, textoTela: String) {
        val temAceitar = temBotaoVisivel(raiz, "Aceitar")
        val temRecusar = temBotaoVisivel(raiz, "Recusar")
        if (!temAceitar || !temRecusar) { cancelarLeituraOferta(); return }

        if (runnableLeituraOferta != null) return

        estado = Estado.LENDO_OFERTA
        // Aguarda 700ms para o popup renderizar completamente
        runnableLeituraOferta = Runnable {
            runnableLeituraOferta = null
            estado = Estado.IDLE
            val raizAtual = getRaizTaxsee() ?: return@Runnable
            if (!temBotaoVisivel(raizAtual, "Aceitar") ||
                !temBotaoVisivel(raizAtual, "Recusar")) return@Runnable
            executarExtracao(raizAtual)
        }.also { handler.postDelayed(it, ATRASO_LEITURA_OFERTA_MS) }
    }

    private fun executarExtracao(raiz: AccessibilityNodeInfo) {
        val textoTela = coletarTextoTela(raiz)
        val t = textoTela.lowercase(Locale.getDefault())

        val valor = extrairValorOferta(t) ?: return
        val km    = extrairKmOferta(t) ?: 0f
        val ganhoPorKm   = if (km > 0f) valor / km else 0f
        val (orig, dest) = extrairOrigemDestino(raiz)
        val forma        = extrairFormaPagamento(t)

        val prefs       = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val minimoKm    = prefs.getFloat("minimo_km",    1.20f)
        val minimoValor = prefs.getFloat("minimo_valor", 0f)
        val valeAPena   = ganhoPorKm >= minimoKm && (minimoValor <= 0f || valor >= minimoValor)

        // Evita reprocessar a MESMA oferta várias vezes enquanto o popup
        // continua na tela (o mesmo popup gera vários eventos de tela)
        val jaNaFila = filaCorridas.any { !it.confirmada && kotlin.math.abs(it.valor - valor) < 0.01f }
        val mesmaDoOverlay = overlayAtivo && kotlin.math.abs(valor - ultimoValorOferta) < 0.01f
        if (jaNaFila || mesmaDoOverlay) return

        ultimoValorOferta = valor
        overlayAtivo      = true

        val autoAceitar = prefs.getBoolean("auto_aceitar", false)
        val autoRecusar = prefs.getBoolean("auto_recusar", false)

        mostrarOverlay(valor, km, ganhoPorKm, valeAPena, autoAceitar, autoRecusar, orig, dest)
        tocarSom(valeAPena, prefs)

        val novaCorrida = CorridaFila(
            valor = valor, km = km, ganhoPorKm = ganhoPorKm, valeAPena = valeAPena,
            origem = orig, destino = dest, cliente = "", forma = forma,
            horaInicio = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        )
        filaCorridas.add(novaCorrida)

        cancelarAutoAR()
        val tempoAutoMs = prefs.getInt("tempo_auto_aceitar", 3) * 1000L
        when {
            valeAPena && autoAceitar -> {
                runnableAutoAceitar = Runnable {
                    val r = getRaizTaxsee()
                    val clicou = if (r != null) clicarBotaoIgnorandoVisibilidade(r, "Aceitar") else false
                    if (!clicou) realizarTapNoBotao(r, "Aceitar")
                }.also { handler.postDelayed(it, tempoAutoMs) }
            }
            !valeAPena && autoRecusar -> {
                runnableAutoRecusar = Runnable {
                    val r = getRaizTaxsee()
                    if (r != null) clicarBotaoIgnorandoVisibilidade(r, "Recusar")
                    filaCorridas.remove(novaCorrida)
                    esconderOverlay()
                }.also { handler.postDelayed(it, tempoAutoMs) }
            }
            // Sem auto-aceitar/recusar: o motorista decide manualmente.
            // A confirmação (ou remoção se recusada) acontece em
            // verificarProgressoFila, olhando "a caminho" ou os botões
            // sumindo da tela.
        }
    }

    // ── Confirmação de aceite + finalização da corrida da frente ───────────

    private fun verificarProgressoFila(raiz: AccessibilityNodeInfo, textoTela: String) {
        val t = textoTela.lowercase(Locale.getDefault())

        // 1) Confirma a oferta mais recente ainda não confirmada — vira
        //    "corrida ativa de verdade" quando "a caminho" aparece ou os
        //    botões Aceitar/Recusar somem da tela.
        val pendente = filaCorridas.lastOrNull { !it.confirmada }
        if (pendente != null) {
            val aCaminho = t.contains("a caminho")             ||
                           t.contains("já estou chegando")     ||
                           t.contains("cheguei no local")      ||
                           t.contains("aguardando passageiro") ||
                           t.contains("aguardando cliente")
            val botoesForam = !overlayAtivo &&
                              !temBotaoVisivel(raiz, "Aceitar") &&
                              !temBotaoVisivel(raiz, "Recusar")

            if (aCaminho || botoesForam) {
                if (pendente.cliente.isEmpty()) pendente.cliente = extrairCliente(raiz, t)
                pendente.confirmada = true
                cancelarAutoAR()
                esconderOverlay()
            }
        }

        // 2) Cuida da tela de finalização da corrida na FRENTE da fila —
        //    é a única que pode estar sendo exibida/navegada agora.
        val frente = filaCorridas.firstOrNull { it.confirmada } ?: return

        val telaDeFinalizar = t.contains("finalizar pedido")  ||
                              t.contains("finalizar viagem")  ||
                              t.contains("finalizar corrida") ||
                              t.contains("preço total")

        if (!telaDeFinalizar) return

        val novoValor = extrairValorFinal(raiz, t)
        if (novoValor != null && novoValor > 0f) frente.finalValor = novoValor
        val novoKm = extrairKmFinal(t)
        if (novoKm != null && novoKm > 0f) frente.finalKm = novoKm
        if (frente.finalTempo.isEmpty()) frente.finalTempo = extrairTempo(t)

        if (!frente.timeoutIniciado) {
            frente.timeoutIniciado = true
            iniciarTimeout(TIMEOUT_FINALIZANDO_MS) {
                // Timeout de segurança: se o toast de finalização nunca
                // chegar, salva mesmo assim com os últimos dados capturados
                if (filaCorridas.firstOrNull() == frente) {
                    filaCorridas.removeAt(0)
                    salvarCorrida(frente)
                }
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    // SALVAR CORRIDA
    // ══════════════════════════════════════════════════════════════════════

    private fun salvarCorrida(corrida: CorridaFila) {
        try {
            val valorFinal = if (corrida.finalValor > 0f) corrida.finalValor else corrida.valor
            val kmFinal    = if (corrida.finalKm    > 0f) corrida.finalKm    else corrida.km
            val gpkm       = if (kmFinal > 0f) valorFinal / kmFinal else corrida.ganhoPorKm

            val prefs       = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
            val minimoKm    = prefs.getFloat("minimo_km",    1.20f)
            val minimoValor = prefs.getFloat("minimo_valor", 0f)
            val valeAPena   = gpkm >= minimoKm && (minimoValor <= 0f || valorFinal >= minimoValor)
            val horaFim     = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

            DatabaseHelper(this).inserirCorrida(
                Corrida(
                    valor          = valorFinal,
                    kmTotal        = kmFinal,
                    ganhoPorKm     = gpkm,
                    valeAPena      = valeAPena,
                    origem         = corrida.origem,
                    destino        = corrida.destino,
                    formaPagamento = corrida.forma,
                    passageiro     = corrida.cliente,
                    horaInicio     = corrida.horaInicio,
                    horaFim        = horaFim,
                    tempoExecucao  = corrida.finalTempo
                )
            )

            FloatingEarningsService.instanciaAtiva?.atualizarValor()
                ?: startService(Intent(this, FloatingEarningsService::class.java).apply {
                    action = FloatingEarningsService.ACTION_ATUALIZAR
                })

            try {
                val mgr = android.appwidget.AppWidgetManager.getInstance(this)
                val ids = mgr.getAppWidgetIds(
                    android.content.ComponentName(this, FluxoWidgetProvider::class.java))
                if (ids.isNotEmpty()) sendBroadcast(
                    Intent(this, FluxoWidgetProvider::class.java).apply {
                        action = android.appwidget.AppWidgetManager.ACTION_APPWIDGET_UPDATE
                        putExtra(android.appwidget.AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                    })
            } catch (_: Exception) {}

            verificarMeta(valorFinal, prefs)
        } catch (_: Exception) {}

        // Não reseta tudo — a fila pode ter outras corridas ainda ativas.
        // Só limpa o timeout, que é escopado à corrida que acabou de sair.
        cancelarTimeout()

        // Se ainda restarem corridas na fila, a próxima (agora na frente)
        // continua sendo acompanhada normalmente pelos próximos eventos.
        if (filaCorridas.isEmpty()) {
            overlayAtivo = false
            ultimoValorOferta = 0f
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    // OVERLAY
    // ══════════════════════════════════════════════════════════════════════

    private fun mostrarOverlay(
        valor: Float, km: Float, ganhoPorKm: Float,
        valeAPena: Boolean, autoAceitar: Boolean, autoRecusar: Boolean,
        origem: String = "", destino: String = ""
    ) {
        try {
            androidx.core.content.ContextCompat.startForegroundService(
                this, Intent(this, OverlayService::class.java).apply {
                    action = "MOSTRAR"
                    putExtra("valor",        valor)
                    putExtra("km_total",     km)
                    putExtra("ganho_por_km", ganhoPorKm)
                    putExtra("vale_a_pena",  valeAPena)
                    putExtra("auto_aceitar", autoAceitar)
                    putExtra("auto_recusar", autoRecusar)
                    putExtra("origem",       origem)
                    putExtra("destino",      destino)
                }
            )
        } catch (_: Exception) {}
    }

    internal fun esconderOverlay() {
        overlayAtivo = false
        try {
            androidx.core.content.ContextCompat.startForegroundService(
                this, Intent(this, OverlayService::class.java).apply { action = "ESCONDER" }
            )
        } catch (_: Exception) {}
    }

    // ══════════════════════════════════════════════════════════════════════
    // SOM E META
    // ══════════════════════════════════════════════════════════════════════

    private fun tocarSom(valeAPena: Boolean, prefs: android.content.SharedPreferences) {
        if (valeAPena  && !prefs.getBoolean("som_aceitar", true))  return
        if (!valeAPena && !prefs.getBoolean("som_recusar", false)) return
        try {
            val tipo = if (valeAPena) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_NACK
            val tg   = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
            tg.startTone(tipo, 300)
            handler.postDelayed({ try { tg.release() } catch (_: Exception) {} }, 600)
        } catch (_: Exception) {}
    }

    private fun verificarMeta(valorAdicionado: Float, prefs: android.content.SharedPreferences) {
        val meta = prefs.getFloat("meta_diaria", 0f)
        if (meta <= 0f || !prefs.getBoolean("som_meta", true)) return
        try {
            val totalHoje = DatabaseHelper(this).run { resumo(buscarHoje())["total"] ?: 0f }
            if (totalHoje >= meta && (totalHoje - valorAdicionado) < meta) {
                val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100)
                repeat(3) { i ->
                    handler.postDelayed({
                        try { tg.startTone(ToneGenerator.TONE_PROP_BEEP, 200) } catch (_: Exception) {}
                    }, i * 400L)
                }
                handler.postDelayed({ try { tg.release() } catch (_: Exception) {} }, 1800)
            }
        } catch (_: Exception) {}
    }

    // ══════════════════════════════════════════════════════════════════════
    // CONTROLE DE TIMEOUT E ESTADO
    // ══════════════════════════════════════════════════════════════════════

    private fun iniciarTimeout(ms: Long, acao: () -> Unit) {
        cancelarTimeout()
        val r = Runnable { acao() }
        timeoutRunnable = r
        handler.postDelayed(r, ms)
    }

    internal fun cancelarTimeout() {
        timeoutRunnable?.let { handler.removeCallbacks(it) }
        timeoutRunnable = null
    }

    internal fun cancelarAutoAR() {
        runnableAutoAceitar?.let { handler.removeCallbacks(it) }; runnableAutoAceitar = null
        runnableAutoRecusar?.let { handler.removeCallbacks(it) }; runnableAutoRecusar = null
    }

    internal fun cancelarLeituraOferta() {
        runnableLeituraOferta?.let { handler.removeCallbacks(it) }
        runnableLeituraOferta = null
        if (estado == Estado.LENDO_OFERTA) estado = Estado.IDLE
    }

    internal fun cancelarTudo() {
        cancelarTimeout()
        cancelarAutoAR()
        cancelarLeituraOferta()
    }

    /**
     * Reset TOTAL — usado só quando o serviço é interrompido pelo sistema
     * (onInterrupt). Descarta a fila inteira, já que não há como recuperar
     * o estado das corridas em andamento depois que o serviço reinicia.
     */
    internal fun resetarEstadoCompleto() {
        estado            = Estado.IDLE
        filaCorridas.clear()
        overlayAtivo      = false; ultimoValorOferta = 0f
        cancelarTudo()
    }
}
