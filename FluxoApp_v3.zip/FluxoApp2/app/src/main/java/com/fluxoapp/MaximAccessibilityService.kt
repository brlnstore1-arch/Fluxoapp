package com.fluxoapp

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * MaximAccessibilityService — FluxoApp
 *
 * Fluxo de estados:
 *  IDLE → detecta oferta → AGUARDANDO_ACEITE → detecta "A caminho" → EM_ANDAMENTO
 *       → detecta "Finalizar pedido" → FINALIZANDO → detecta toast/timeout → salva → IDLE
 *
 *  Qualquer estado → "Pedido cancelado" → descarta → IDLE
 */
class MaximAccessibilityService : AccessibilityService() {

    private enum class Estado { IDLE, AGUARDANDO_ACEITE, EM_ANDAMENTO, FINALIZANDO }
    private var estado = Estado.IDLE

    // Dados da corrida em andamento
    private var corridaValor      = 0f
    private var corridaKm         = 0f
    private var corridaGanhoPorKm = 0f
    private var corridaValeAPena  = false
    private var corridaOrigem     = ""
    private var corridaDestino    = ""
    private var corridaCliente    = ""
    private var corridaForma      = ""
    private var corridaHoraInicio = ""

    // Dados capturados na tela final
    private var finalValor = 0f
    private var finalKm    = 0f
    private var finalTempo = ""

    private val handler = Handler(Looper.getMainLooper())
    private var ultimoEventoMs = 0L
    private var timeoutFinalizar: Runnable? = null
    private var ultimoTextoProcessado = ""

    companion object {
        private const val DEBOUNCE_MS      = 400L
        private const val TIMEOUT_FINAL_MS = 30_000L
        private const val PKG_TAXSEE       = "com.taxsee.driver"
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        if (event.packageName?.toString() != PKG_TAXSEE) return

        val agora = System.currentTimeMillis()
        if (agora - ultimoEventoMs < DEBOUNCE_MS) return
        ultimoEventoMs = agora

        val tipo = event.eventType
        val textoEvento = event.text?.joinToString(" ")?.lowercase(Locale.getDefault()) ?: ""

        // Toasts e notificações
        if (tipo == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED ||
            tipo == AccessibilityEvent.TYPE_ANNOUNCEMENT
        ) {
            processarToast(textoEvento)
            return
        }

        if (tipo == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            tipo == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        ) {
            // Android 11+: toasts aparecem como nós na árvore de views por ~2s.
            // Checa o texto do evento antes de varrer a tela inteira (mais rápido).
            if (textoEvento.isNotBlank()) processarToast(textoEvento)

            val raiz = rootInActiveWindow ?: return
            processarTela(raiz, textoEvento)
        }
    }

    override fun onInterrupt() { resetarEstado() }

    // ── Toasts ─────────────────────────────────────────────────────────────
    private fun processarToast(texto: String) {
        // Normaliza: minúsculo, sem acentos extras, sem espaços duplos
        val t = texto.lowercase(Locale.getDefault()).trim()
        when {
            // Variações que o Taxsee usa no toast de finalização
            t.contains("pedido finalizado") ||
            t.contains("aguarde pelo pr") ||
            t.contains("aguarde o pr") ||
            t.contains("corrida finalizada") ||
            t.contains("viagem finalizada") -> {
                if (estado == Estado.FINALIZANDO || estado == Estado.EM_ANDAMENTO) {
                    cancelarTimeoutFinalizar()
                    salvarCorrida()
                }
            }
            t.contains("pedido cancelado") ||
            t.contains("corrida cancelada") ||
            t.contains("viagem cancelada") -> {
                if (estado != Estado.IDLE) {
                    fecharDialogCancelamento()
                    resetarEstado()
                }
            }
        }
    }

    // ── Roteador de telas ──────────────────────────────────────────────────
    private fun processarTela(raiz: AccessibilityNodeInfo, textoEvento: String) {
        val textoTela = coletarTextoTela(raiz).lowercase(Locale.getDefault())
        if (textoTela == ultimoTextoProcessado) return
        ultimoTextoProcessado = textoTela

        when (estado) {
            Estado.IDLE -> verificarPedidoNovo(raiz, textoTela)
            Estado.AGUARDANDO_ACEITE -> {
                if (!verificarACaminho(raiz, textoTela))
                    verificarCancelamento(raiz, textoTela)
            }
            Estado.EM_ANDAMENTO -> {
                verificarFinalizarPedido(raiz, textoTela)
                verificarCancelamento(raiz, textoTela)
            }
            Estado.FINALIZANDO -> {
                atualizarValorFinal(raiz)
                verificarCancelamento(raiz, textoTela)
            }
        }
    }

    // ── IDLE: nova oferta ──────────────────────────────────────────────────
    private fun verificarPedidoNovo(raiz: AccessibilityNodeInfo, textoTela: String) {
        // Gatilho: "Aceitar" E "Recusar" visíveis ao mesmo tempo.
        // Mais confiável que texto do título (ex: "Pedido atribuído" nem sempre aparece).
        val temAceitar = encontrarNo(raiz) { no ->
            no.text?.toString()?.equals("Aceitar", ignoreCase = true) == true && no.isVisibleToUser
        } != null
        val temRecusar = encontrarNo(raiz) { no ->
            no.text?.toString()?.equals("Recusar", ignoreCase = true) == true && no.isVisibleToUser
        } != null
        if (!temAceitar || !temRecusar) return

        val valor = extrairValorReais(textoTela) ?: return
        val km    = extrairKm(textoTela) ?: 0f
        val ganhoPorKm = if (km > 0f) valor / km else 0f
        val (origem, destino) = extrairOrigemDestino(raiz)
        val forma = extrairFormaPagamento(textoTela)

        val prefs       = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val minimoKm    = prefs.getFloat("minimo_km", 1.20f)
        val minimoValor = prefs.getFloat("minimo_valor", 0f)
        val valeAPena   = ganhoPorKm >= minimoKm && (minimoValor <= 0f || valor >= minimoValor)

        corridaValor      = valor
        corridaKm         = km
        corridaGanhoPorKm = ganhoPorKm
        corridaValeAPena  = valeAPena
        corridaOrigem     = origem
        corridaDestino    = destino
        corridaForma      = forma
        corridaHoraInicio = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

        val autoAceitar = prefs.getBoolean("auto_aceitar", false)
        val autoRecusar = prefs.getBoolean("auto_recusar", false)
        mostrarOverlay(valor, km, ganhoPorKm, valeAPena, autoAceitar, autoRecusar, origem, destino)
        tocarSom(valeAPena, prefs)

        estado = Estado.AGUARDANDO_ACEITE

        val tempoAuto = prefs.getInt("tempo_auto_aceitar", 3) * 1000L
        when {
            valeAPena && autoAceitar -> handler.postDelayed({
                val raizAtual = rootInActiveWindow
                if (raizAtual != null) clicarBotaoAceitar(raizAtual)
                else realizarTapNoCentro()
            }, tempoAuto)
            !valeAPena && autoRecusar -> handler.postDelayed({
                val raizAtual = rootInActiveWindow
                if (raizAtual != null) clicarBotaoRecusar(raizAtual)
                estado = Estado.IDLE
            }, tempoAuto)
        }
    }

    // ── AGUARDANDO_ACEITE: tela "A caminho" ────────────────────────────────
    private fun verificarACaminho(raiz: AccessibilityNodeInfo, textoTela: String): Boolean {
        val eACaminho = textoTela.contains("a caminho") ||
                        textoTela.contains("já estou chegando") ||
                        textoTela.contains("cheguei no local")
        if (!eACaminho) return false

        if (corridaCliente.isEmpty())
            corridaCliente = extrairCliente(raiz, textoTela)

        esconderOverlay()
        estado = Estado.EM_ANDAMENTO
        return true
    }

    // ── EM_ANDAMENTO: tela "Finalizar pedido" ─────────────────────────────
    private fun verificarFinalizarPedido(raiz: AccessibilityNodeInfo, textoTela: String) {
        if (!textoTela.contains("finalizar pedido")) return
        finalValor = extrairValorFinal(raiz, textoTela) ?: corridaValor
        finalKm    = extrairKmFinal(textoTela) ?: corridaKm
        finalTempo = extrairTempoFinal(textoTela)
        estado = Estado.FINALIZANDO
        iniciarTimeoutFinalizar()
    }

    // ── FINALIZANDO: atualizar valor conforme usuário digita ───────────────
    private fun atualizarValorFinal(raiz: AccessibilityNodeInfo) {
        val novoValor = extrairValorFinal(raiz, "") ?: return
        if (novoValor > 0f) finalValor = novoValor
    }

    // ── Cancelamento em qualquer estado ────────────────────────────────────
    private fun verificarCancelamento(raiz: AccessibilityNodeInfo, textoTela: String) {
        if (!textoTela.contains("pedido cancelado")) return
        fecharDialogCancelamento(raiz)
        cancelarTimeoutFinalizar()
        esconderOverlay()
        resetarEstado()
    }

    // ── Salvar corrida no banco ────────────────────────────────────────────
    private fun salvarCorrida() {
        try {
            val valorFinal      = if (finalValor > 0f) finalValor else corridaValor
            val kmFinal         = if (finalKm    > 0f) finalKm    else corridaKm
            val ganhoPorKmFinal = if (kmFinal    > 0f) valorFinal / kmFinal else corridaGanhoPorKm

            val prefs       = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
            val minimoKm    = prefs.getFloat("minimo_km", 1.20f)
            val minimoValor = prefs.getFloat("minimo_valor", 0f)
            val valeAPena   = ganhoPorKmFinal >= minimoKm &&
                              (minimoValor <= 0f || valorFinal >= minimoValor)
            val horaFim     = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

            val corrida = Corrida(
                valor          = valorFinal,
                kmTotal        = kmFinal,
                ganhoPorKm     = ganhoPorKmFinal,
                valeAPena      = valeAPena,
                origem         = corridaOrigem,
                destino        = corridaDestino,
                formaPagamento = corridaForma,
                passageiro     = corridaCliente,
                horaInicio     = corridaHoraInicio,
                horaFim        = horaFim,
                tempoExecucao  = finalTempo
            )

            DatabaseHelper(this).inserirCorrida(corrida)

            // Atualizar botão flutuante
            FloatingEarningsService.instanciaAtiva?.atualizarValor()
                ?: startService(Intent(this, FloatingEarningsService::class.java).apply {
                    action = FloatingEarningsService.ACTION_ATUALIZAR
                })

            // Atualizar widget
            try {
                val mgr = android.appwidget.AppWidgetManager.getInstance(this)
                val ids = mgr.getAppWidgetIds(android.content.ComponentName(this, FluxoWidgetProvider::class.java))
                if (ids.isNotEmpty()) sendBroadcast(Intent(this, FluxoWidgetProvider::class.java).apply {
                    action = android.appwidget.AppWidgetManager.ACTION_APPWIDGET_UPDATE
                    putExtra(android.appwidget.AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                })
            } catch (_: Exception) {}

            // Som de meta atingida
            verificarMeta(valorFinal, prefs)

        } catch (_: Exception) {}

        resetarEstado()
    }

    // ══════════════════════════════════════════════════════════════════════
    // Extração de dados
    // ══════════════════════════════════════════════════════════════════════

    private fun extrairValorReais(texto: String): Float? {
        val regex = Regex("""r\$\s*([\d]+[,.][\d]{2})|((?<!\d)[\d]+[,.][\d]{2}(?!\d))""")
        val match = regex.find(texto) ?: return null
        val raw = (match.groupValues[1].ifEmpty { match.groupValues[2] }).replace(",", ".")
        return raw.toFloatOrNull()
    }

    /**
     * Extrai o KM TOTAL da tela de oferta somando os dois valores exibidos:
     *   - "X km. Até o endereço"   → km para buscar o cliente
     *   - "Y km. Distância da rota" → km da corrida em si
     * O overlay exibe e o cálculo de R$/km usa essa soma.
     * Se só encontrar um valor, retorna ele sozinho.
     */
    private fun extrairKm(texto: String): Float? {
        val regex = Regex("""([\d]+[,.]?[\d]*)\s*km""")
        val matches = regex.findAll(texto)
            .mapNotNull { it.groupValues[1].replace(",", ".").toFloatOrNull() }
            .filter { it > 0f }
            .toList()
        return when {
            matches.size >= 2 -> matches[0] + matches[1]  // soma: até endereço + distância da rota
            matches.size == 1 -> matches[0]
            else              -> null
        }
    }

    private fun extrairKmFinal(texto: String): Float? {
        val regex = Regex("""([\d]+[,.][\d]+)\s*km""")
        return regex.find(texto)?.groupValues?.get(1)?.replace(",", ".")?.toFloatOrNull()
            ?: extrairKm(texto)
    }

    private fun extrairTempoFinal(texto: String): String {
        val regex = Regex("""(\d+)\s*min""")
        return regex.find(texto)?.let { "${it.groupValues[1]} min" } ?: ""
    }

    private fun extrairValorFinal(raiz: AccessibilityNodeInfo, textoTela: String): Float? {
        // Tenta pelo campo EditText com valor numérico
        val noInput = encontrarNo(raiz) { no ->
            no.className?.contains("EditText") == true &&
            no.isVisibleToUser &&
            no.text?.toString()?.matches(Regex("""[\d]+[,.][\d]{2}""")) == true
        }
        if (noInput != null) {
            val v = noInput.text?.toString()?.replace(",", ".")?.toFloatOrNull()
            if (v != null && v > 0f) return v
        }
        return if (textoTela.isNotEmpty()) extrairValorReais(textoTela) else null
    }

    private fun extrairFormaPagamento(texto: String): String = when {
        texto.contains("dinheiro")                                   -> "Dinheiro"
        texto.contains("cartão") || texto.contains("cartao")        -> "Cartão"
        texto.contains("pix")                                        -> "PIX"
        texto.contains("online")                                     -> "Online"
        else                                                         -> "Dinheiro"
    }

    private fun extrairCliente(raiz: AccessibilityNodeInfo, textoTela: String): String {
        val regex = Regex("""cliente\s+([a-záéíóúàâêîôûãõç]+)""", RegexOption.IGNORE_CASE)
        val match = regex.find(textoTela)
        if (match != null) return match.groupValues[1].replaceFirstChar { it.uppercase() }

        val candidato = encontrarNo(raiz) { no ->
            val txt = no.text?.toString() ?: ""
            txt.length in 3..30 &&
            !txt.contains(Regex("""[\d,.]""")) &&
            !txt.contains("km", ignoreCase = true) &&
            no.isVisibleToUser
        }
        return candidato?.text?.toString()?.replaceFirstChar { it.uppercase() } ?: ""
    }

    private fun extrairOrigemDestino(raiz: AccessibilityNodeInfo): Pair<String, String> {
        val textos = mutableListOf<String>()
        visitarNos(raiz) { no ->
            val txt = no.text?.toString() ?: ""
            if (txt.length > 5 && no.isVisibleToUser &&
                (txt.contains("Travessa", ignoreCase = true) ||
                 txt.contains("Rua ", ignoreCase = true) ||
                 txt.contains("Avenida", ignoreCase = true) ||
                 txt.contains("bairro", ignoreCase = true) ||
                 txt.contains("(") )
            ) textos.add(txt.trim())
        }
        return Pair(textos.getOrNull(0) ?: "", textos.getOrNull(1) ?: "")
    }

    private fun coletarTextoTela(raiz: AccessibilityNodeInfo): String {
        val sb = StringBuilder()
        visitarNos(raiz) { no ->
            if (no.isVisibleToUser) {
                no.text?.toString()?.takeIf { it.isNotBlank() }?.let { sb.append(it).append(" ") }
                no.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { sb.append(it).append(" ") }
            }
        }
        return sb.toString()
    }

    // ══════════════════════════════════════════════════════════════════════
    // Interação com UI
    // ══════════════════════════════════════════════════════════════════════

    private fun clicarBotaoAceitar(raiz: AccessibilityNodeInfo) {
        val no = encontrarNo(raiz) { no ->
            no.text?.toString()?.equals("Aceitar", ignoreCase = true) == true && no.isVisibleToUser
        }
        no?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: realizarTapNoCentro()
    }

    private fun clicarBotaoRecusar(raiz: AccessibilityNodeInfo) {
        encontrarNo(raiz) { no ->
            no.text?.toString()?.equals("Recusar", ignoreCase = true) == true && no.isVisibleToUser
        }?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun fecharDialogCancelamento(raiz: AccessibilityNodeInfo? = null) {
        val r = raiz ?: rootInActiveWindow ?: return
        encontrarNo(r) { no ->
            no.text?.toString()?.equals("Ok", ignoreCase = true) == true && no.isVisibleToUser
        }?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun realizarTapNoCentro() {
        try {
            val metrics = resources.displayMetrics
            val path = Path().apply { moveTo(metrics.widthPixels / 2f, metrics.heightPixels * 0.75f) }
            dispatchGesture(
                GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(path, 0L, 100L))
                    .build(), null, null
            )
        } catch (_: Exception) {}
    }

    // ══════════════════════════════════════════════════════════════════════
    // Overlay
    // ══════════════════════════════════════════════════════════════════════

    private fun mostrarOverlay(
        valor: Float, km: Float, ganhoPorKm: Float,
        valeAPena: Boolean, autoAceitar: Boolean, autoRecusar: Boolean,
        origem: String, destino: String
    ) {
        startService(Intent(this, OverlayService::class.java).apply {
            action = "MOSTRAR"
            putExtra("valor", valor); putExtra("km_total", km)
            putExtra("ganho_por_km", ganhoPorKm); putExtra("vale_a_pena", valeAPena)
            putExtra("auto_aceitar", autoAceitar); putExtra("auto_recusar", autoRecusar)
            putExtra("origem", origem); putExtra("destino", destino)
        })
    }

    private fun esconderOverlay() {
        startService(Intent(this, OverlayService::class.java).apply { action = "ESCONDER" })
    }

    // ══════════════════════════════════════════════════════════════════════
    // Som e meta
    // ══════════════════════════════════════════════════════════════════════

    private fun tocarSom(valeAPena: Boolean, prefs: android.content.SharedPreferences) {
        val somAceitar = prefs.getBoolean("som_aceitar", true)
        val somRecusar = prefs.getBoolean("som_recusar", false)
        if ((valeAPena && !somAceitar) || (!valeAPena && !somRecusar)) return
        try {
            val tipo = if (valeAPena) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_NACK
            val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
            tg.startTone(tipo, 300)
            handler.postDelayed({ try { tg.release() } catch (_: Exception) {} }, 500)
        } catch (_: Exception) {}
    }

    private fun verificarMeta(valorAdicionado: Float, prefs: android.content.SharedPreferences) {
        val meta = prefs.getFloat("meta_diaria", 0f)
        if (meta <= 0f || !prefs.getBoolean("som_meta", true)) return
        try {
            val totalHoje = DatabaseHelper(this).run { resumo(buscarHoje())["total"] ?: 0f }
            if (totalHoje >= meta && (totalHoje - valorAdicionado) < meta) {
                val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100)
                repeat(3) { i ->
                    handler.postDelayed({
                        try { tg.startTone(ToneGenerator.TONE_PROP_BEEP, 200) } catch (_: Exception) {}
                    }, i * 400L)
                }
                handler.postDelayed({ try { tg.release() } catch (_: Exception) {} }, 1500)
            }
        } catch (_: Exception) {}
    }

    // ══════════════════════════════════════════════════════════════════════
    // Timeout e reset
    // ══════════════════════════════════════════════════════════════════════

    private fun iniciarTimeoutFinalizar() {
        cancelarTimeoutFinalizar()
        timeoutFinalizar = Runnable { if (estado == Estado.FINALIZANDO) salvarCorrida() }
        handler.postDelayed(timeoutFinalizar!!, TIMEOUT_FINAL_MS)
    }

    private fun cancelarTimeoutFinalizar() {
        timeoutFinalizar?.let { handler.removeCallbacks(it) }
        timeoutFinalizar = null
    }

    private fun resetarEstado() {
        estado = Estado.IDLE
        corridaValor = 0f; corridaKm = 0f; corridaGanhoPorKm = 0f
        corridaValeAPena = false
        corridaOrigem = ""; corridaDestino = ""; corridaCliente = ""
        corridaForma = ""; corridaHoraInicio = ""
        finalValor = 0f; finalKm = 0f; finalTempo = ""
        ultimoTextoProcessado = ""
        handler.removeCallbacksAndMessages(null)
    }

    // ══════════════════════════════════════════════════════════════════════
    // Utilitários de árvore
    // ══════════════════════════════════════════════════════════════════════

    private fun encontrarNo(
        raiz: AccessibilityNodeInfo,
        predicado: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        if (predicado(raiz)) return raiz
        for (i in 0 until raiz.childCount) {
            val r = encontrarNo(raiz.getChild(i) ?: continue, predicado)
            if (r != null) return r
        }
        return null
    }

    private fun visitarNos(raiz: AccessibilityNodeInfo, visitante: (AccessibilityNodeInfo) -> Unit) {
        visitante(raiz)
        for (i in 0 until raiz.childCount) visitarNos(raiz.getChild(i) ?: continue, visitante)
    }
}
