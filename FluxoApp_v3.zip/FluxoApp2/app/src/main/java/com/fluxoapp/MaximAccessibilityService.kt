package com.fluxoapp

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * MaximAccessibilityService — FluxoApp
 *
 * Coração do app: monitora o Taxsee e detecta corridas automaticamente.
 *
 * Máquina de estados:
 *   IDLE → AGUARDANDO_ACEITE → EM_ANDAMENTO → FINALIZANDO → IDLE
 *
 * Lógica extraída para helpers:
 *   - MaximExtractor.kt  → extração de valor, km, origem, cliente, pagamento
 *   - MaximNodeUtils.kt  → travessia de árvore, cliques, gestos, coleta de texto
 */
class MaximAccessibilityService : AccessibilityService() {

    // ── Máquina de estados ────────────────────────────────────────────────
    internal enum class Estado { IDLE, AGUARDANDO_ACEITE, EM_ANDAMENTO, FINALIZANDO }
    internal var estado = Estado.IDLE

    // ── Dados da corrida ──────────────────────────────────────────────────
    internal var corridaValor      = 0f
    internal var corridaKm         = 0f
    internal var corridaGanhoPorKm = 0f
    internal var corridaValeAPena  = false
    internal var corridaOrigem     = ""
    internal var corridaDestino    = ""
    internal var corridaCliente    = ""
    internal var corridaForma      = ""
    internal var corridaHoraInicio = ""
    internal var finalValor        = 0f
    internal var finalKm           = 0f
    internal var finalTempo        = ""

    // ── Controle de overlay ───────────────────────────────────────────────
    internal var overlayAtivo      = false
    internal var ultimoValorOferta = 0f

    // ── Runnables nomeados ────────────────────────────────────────────────
    internal var runnableAutoAceitar:   Runnable? = null
    internal var runnableAutoRecusar:   Runnable? = null
    internal var runnableLeituraOferta: Runnable? = null

    // ── Handler e debounce ────────────────────────────────────────────────
    internal val handler            = Handler(Looper.getMainLooper())
    internal var ultimoEventoTelaMs = 0L
    internal var timeoutRunnable: Runnable? = null

    companion object {
        internal const val PKG_TAXSEE               = "com.taxsee.driver"
        internal const val DEBOUNCE_TELA_MS          = 350L
        internal const val ATRASO_LEITURA_OFERTA_MS  = 700L
        internal const val TIMEOUT_FINALIZANDO_MS    = 30_000L
        internal const val TIMEOUT_EM_ANDAMENTO_MS   = 720_000L
    }

    // ══════════════════════════════════════════════════════════════════════
    // PONTO DE ENTRADA
    // ══════════════════════════════════════════════════════════════════════

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        if (event.packageName?.toString() != PKG_TAXSEE) return

        if (!LicenseManager.estaLogado()) return
        val prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("servico_ativo", true)) return

        val tipo = event.eventType
        val textoEvento = event.text?.joinToString(" ")?.trim()
            ?.lowercase(Locale.getDefault()) ?: ""

        if (tipo == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED ||
            tipo == AccessibilityEvent.TYPE_ANNOUNCEMENT) {
            if (textoEvento.isNotBlank()) processarToast(textoEvento)
            return
        }

        if (tipo == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            tipo == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            if (textoEvento.isNotBlank()) processarToast(textoEvento)

            val agora = System.currentTimeMillis()
            if (agora - ultimoEventoTelaMs < DEBOUNCE_TELA_MS) return
            ultimoEventoTelaMs = agora

            val raiz = rootInActiveWindow ?: return
            processarTela(raiz)
        }
    }

    override fun onInterrupt() { resetarEstado() }

    // ══════════════════════════════════════════════════════════════════════
    // PROCESSAMENTO DE TOAST
    // ══════════════════════════════════════════════════════════════════════

    private fun processarToast(texto: String) {
        val t = texto.lowercase(Locale.getDefault()).trim()

        if (eToastFinalizacao(t)) {
            if (estado == Estado.FINALIZANDO || estado == Estado.EM_ANDAMENTO) {
                cancelarTimeout()
                salvarCorrida()
            }
            return
        }

        if (eToastCancelamento(t)) {
            if (estado != Estado.IDLE) {
                cancelarTudo()
                esconderOverlay()
                fecharDialogCancelamento()
                resetarEstado()
            }
        }
    }

    /** Toast exato do Taxsee: "Pedido finalizado! Aguarde pelo próximo." */
    private fun eToastFinalizacao(t: String): Boolean =
        t.contains("pedido finalizado")    ||
        t.contains("aguarde pelo próximo") ||
        t.contains("aguarde pelo proximo") ||
        t.contains("viagem finalizada")    ||
        t.contains("corrida finalizada")   ||
        t.contains("entrega conclu")

    /**
     * ⚠️ NÃO usar "cancelad" genérico — o contador "será cancelado em 18s"
     * contém "cancelado" mas não é cancelamento real.
     */
    private fun eToastCancelamento(t: String): Boolean =
        t.contains("pedido cancelado")  ||
        t.contains("corrida cancelada") ||
        t.contains("viagem cancelada")  ||
        t.contains("pedido recusado")   ||
        t.contains("corrida recusada")

    // ══════════════════════════════════════════════════════════════════════
    // PROCESSAMENTO DE TELA
    // ══════════════════════════════════════════════════════════════════════

    private fun processarTela(raiz: AccessibilityNodeInfo) {
        val textoTela = coletarTextoTela(raiz)
        when (estado) {
            Estado.IDLE              -> verificarOferta(raiz, textoTela)
            Estado.AGUARDANDO_ACEITE -> verificarAceite(raiz, textoTela)
            Estado.EM_ANDAMENTO      -> verificarAndamento(raiz, textoTela)
            Estado.FINALIZANDO       -> verificarFinalizando(raiz, textoTela)
        }
    }

    // ── IDLE → AGUARDANDO_ACEITE ──────────────────────────────────────────

    private fun verificarOferta(raiz: AccessibilityNodeInfo, textoTela: String) {
        val temAceitar = temBotaoVisivel(raiz, "Aceitar")
        val temRecusar = temBotaoVisivel(raiz, "Recusar")
        if (!temAceitar || !temRecusar) { cancelarLeituraOferta(); return }

        if (estado == Estado.AGUARDANDO_ACEITE) return
        if (runnableLeituraOferta != null) return

        // Aguarda 700ms para o popup renderizar completamente
        runnableLeituraOferta = Runnable {
            runnableLeituraOferta = null
            val raizAtual = getRaizTaxsee() ?: return@Runnable
            if (!temBotaoVisivel(raizAtual, "Aceitar") ||
                !temBotaoVisivel(raizAtual, "Recusar")) return@Runnable
            executarExtracao(raizAtual)
        }.also { handler.postDelayed(it, ATRASO_LEITURA_OFERTA_MS) }
    }

    private fun executarExtracao(raiz: AccessibilityNodeInfo) {
        val textoTela = coletarTextoTela(raiz)
        val t = textoTela.lowercase(Locale.getDefault())

        // Verificar qual plataforma usar (Taxsee/Maxim ou 99)
        val prefs99 = getSharedPreferences("fluxo_config", Context.MODE_PRIVATE)
        val detectar99 = prefs99.getBoolean("detectar_99", false)
        
        // Prefs padrão do app
        val prefsFluxo = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        
        val (valor, km, plataforma) = if (detectar99 && eh99(t)) {
            Triple(extrairValor99(t), extrairKm99(t) ?: 0f, "99")
        } else {
            Triple(extrairValorOferta(t), extrairKmOferta(t) ?: 0f, "Taxsee")
        }
        
        if (valor == null) return
        
        val kmFinal      = km
        val ganhoPorKm   = if (km > 0f) valor / km else 0f
        val (orig, dest) = extrairOrigemDestino(raiz)
        val forma        = extrairFormaPagamento(t)

        val prefsFluxo  = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val minimoKm    = prefsFluxo.getFloat("minimo_km",    1.20f)
        val minimoValor = prefsFluxo.getFloat("minimo_valor", 0f)
        val valeAPena   = ganhoPorKm >= minimoKm && (minimoValor <= 0f || valor >= minimoValor)

        corridaValor      = valor
        corridaKm         = km
        corridaGanhoPorKm = ganhoPorKm
        corridaValeAPena  = valeAPena
        corridaOrigem     = orig
        corridaDestino    = dest
        corridaForma      = forma
        corridaHoraInicio = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        corridaCliente    = ""

        val autoAceitar = prefsFluxo.getBoolean("auto_aceitar", false)
        val autoRecusar = prefsFluxo.getBoolean("auto_recusar", false)
        val ofertaNova  = !overlayAtivo || kotlin.math.abs(valor - ultimoValorOferta) > 0.01f

        if (ofertaNova) {
            ultimoValorOferta = valor
            overlayAtivo      = true
            estado            = Estado.AGUARDANDO_ACEITE

            mostrarOverlay(valor, km, ganhoPorKm, valeAPena, autoAceitar, autoRecusar, orig, dest)
            tocarSom(valeAPena, prefsFluxo)

            cancelarAutoAR()
            val tempoAutoMs = prefsFluxo.getInt("tempo_auto_aceitar", 3) * 1000L
            when {
                valeAPena && autoAceitar -> {
                    runnableAutoAceitar = Runnable {
                        if (estado == Estado.AGUARDANDO_ACEITE) {
                            val r = getRaizTaxsee()
                            val clicou = if (r != null) clicarBotaoIgnorandoVisibilidade(r, "Aceitar") else false
                            if (!clicou) realizarTapNoBotao(r, "Aceitar")
                        }
                    }.also { handler.postDelayed(it, tempoAutoMs) }
                }
                !valeAPena && autoRecusar -> {
                    runnableAutoRecusar = Runnable {
                        if (estado == Estado.AGUARDANDO_ACEITE) {
                            val r = getRaizTaxsee()
                            if (r != null) clicarBotaoIgnorandoVisibilidade(r, "Recusar")
                            esconderOverlay()
                            estado = Estado.IDLE
                        }
                    }.also { handler.postDelayed(it, tempoAutoMs) }
                }
            }
        } else {
            estado = Estado.AGUARDANDO_ACEITE
        }
    }

    // ── AGUARDANDO_ACEITE → EM_ANDAMENTO ──────────────────────────────────

    private fun verificarAceite(raiz: AccessibilityNodeInfo, textoTela: String) {
        val t = textoTela.lowercase(Locale.getDefault())

        if (eToastCancelamento(t) || t.contains("pedido cancelado")) {
            cancelarTudo(); esconderOverlay(); fecharDialogCancelamento(raiz); resetarEstado(); return
        }

        val aCaminho = t.contains("a caminho")             ||
                       t.contains("já estou chegando")     ||
                       t.contains("cheguei no local")      ||
                       t.contains("aguardando passageiro") ||
                       t.contains("aguardando cliente")

        val botoesForam = !overlayAtivo &&
                          !temBotaoVisivel(raiz, "Aceitar") &&
                          !temBotaoVisivel(raiz, "Recusar")

        if (aCaminho || botoesForam) {
            if (corridaCliente.isEmpty()) corridaCliente = extrairCliente(raiz, t)
            cancelarAutoAR()
            esconderOverlay()
            estado = Estado.EM_ANDAMENTO
        }
    }

    // ── EM_ANDAMENTO → FINALIZANDO ────────────────────────────────────────

    private fun verificarAndamento(raiz: AccessibilityNodeInfo, textoTela: String) {
        val t = textoTela.lowercase(Locale.getDefault())

        if (eToastCancelamento(t) || t.contains("pedido cancelado")) {
            cancelarTudo(); esconderOverlay(); fecharDialogCancelamento(raiz); resetarEstado(); return
        }

        val telaDeFinalizar = t.contains("finalizar pedido")  ||
                              t.contains("finalizar viagem")  ||
                              t.contains("finalizar corrida") ||
                              t.contains("preço total")

        if (!telaDeFinalizar) {
            if (eToastFinalizacao(t)) { cancelarTimeout(); salvarCorrida() }
            return
        }

        finalValor = extrairValorFinal(raiz, t) ?: corridaValor
        finalKm    = extrairKmFinal(t)          ?: corridaKm
        finalTempo = extrairTempo(t)

        cancelarTimeout()
        estado = Estado.FINALIZANDO
        iniciarTimeout(TIMEOUT_FINALIZANDO_MS) {
            if (estado == Estado.FINALIZANDO) salvarCorrida()
        }
    }

    // ── FINALIZANDO → aguarda toast ───────────────────────────────────────

    private fun verificarFinalizando(raiz: AccessibilityNodeInfo, textoTela: String) {
        val t = textoTela.lowercase(Locale.getDefault())

        if (eToastFinalizacao(t)) { cancelarTimeout(); salvarCorrida(); return }

        if (eToastCancelamento(t)) {
            cancelarTudo(); esconderOverlay(); fecharDialogCancelamento(raiz); resetarEstado(); return
        }

        val novoValor = extrairValorFinal(raiz, t)
        if (novoValor != null && novoValor > 0f) finalValor = novoValor
        val novoKm = extrairKmFinal(t)
        if (novoKm != null && novoKm > 0f) finalKm = novoKm
        if (finalTempo.isEmpty()) finalTempo = extrairTempo(t)
    }

    // ══════════════════════════════════════════════════════════════════════
    // SALVAR CORRIDA
    // ══════════════════════════════════════════════════════════════════════

    private fun salvarCorrida() {
        try {
            val valorFinal = if (finalValor > 0f) finalValor else corridaValor
            val kmFinal    = if (finalKm    > 0f) finalKm    else corridaKm
            val gpkm       = if (kmFinal    > 0f) valorFinal / kmFinal else corridaGanhoPorKm

            val prefsFluxo  = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
            val minimoKm    = prefsFluxo.getFloat("minimo_km",    1.20f)
            val minimoValor = prefsFluxo.getFloat("minimo_valor", 0f)
            val valeAPena   = gpkm >= minimoKm && (minimoValor <= 0f || valorFinal >= minimoValor)
            val horaFim     = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

            DatabaseHelper(this).inserirCorrida(
                Corrida(
                    valor          = valorFinal,
                    kmTotal        = kmFinal,
                    ganhoPorKm     = gpkm,
                    valeAPena      = valeAPena,
                    origem         = corridaOrigem,
                    destino        = corridaDestino,
                    formaPagamento = corridaForma,
                    passageiro     = corridaCliente,
                    horaInicio     = corridaHoraInicio,
                    horaFim        = horaFim,
                    tempoExecucao  = finalTempo
                )
            )

            FloatingEarningsService.instanciaAtiva?.atualizarValor()
                ?: startService(Intent(this, FloatingEarningsService::class.java).apply {
                    action = FloatingEarningsService.ACTION_ATUALIZAR
                })

            try {
                val mgr = android.appwidget.AppWidgetManager.getInstance(this)
                val ids = mgr.getAppWidgetIds(
                    android.content.ComponentName(this, FluxoWidgetProvider::class.java))
                if (ids.isNotEmpty()) sendBroadcast(
                    Intent(this, FluxoWidgetProvider::class.java).apply {
                        action = android.appwidget.AppWidgetManager.ACTION_APPWIDGET_UPDATE
                        putExtra(android.appwidget.AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                    })
            } catch (_: Exception) {}

            verificarMeta(valorFinal, prefs)
        } catch (_: Exception) {}

        resetarEstado()
    }

    // ══════════════════════════════════════════════════════════════════════
    // OVERLAY
    // ══════════════════════════════════════════════════════════════════════

    private fun mostrarOverlay(
        valor: Float, km: Float, ganhoPorKm: Float,
        valeAPena: Boolean, autoAceitar: Boolean, autoRecusar: Boolean,
        origem: String = "", destino: String = ""
    ) {
        try {
            androidx.core.content.ContextCompat.startForegroundService(
                this, Intent(this, OverlayService::class.java).apply {
                    action = "MOSTRAR"
                    putExtra("valor",        valor)
                    putExtra("km_total",     km)
                    putExtra("ganho_por_km", ganhoPorKm)
                    putExtra("vale_a_pena",  valeAPena)
                    putExtra("auto_aceitar", autoAceitar)
                    putExtra("auto_recusar", autoRecusar)
                    putExtra("origem",       origem)
                    putExtra("destino",      destino)
                }
            )
        } catch (_: Exception) {}
    }

    internal fun esconderOverlay() {
        overlayAtivo = false
        try {
            androidx.core.content.ContextCompat.startForegroundService(
                this, Intent(this, OverlayService::class.java).apply { action = "ESCONDER" }
            )
        } catch (_: Exception) {}
    }

    // ══════════════════════════════════════════════════════════════════════
    // SOM E META
    // ══════════════════════════════════════════════════════════════════════

    private fun tocarSom(valeAPena: Boolean, prefs: android.content.SharedPreferences) {
        if (valeAPena  && !prefs.getBoolean("som_aceitar", true))  return
        if (!valeAPena && !prefs.getBoolean("som_recusar", false)) return
        try {
            val tipo = if (valeAPena) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_NACK
            val tg   = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
            tg.startTone(tipo, 300)
            handler.postDelayed({ try { tg.release() } catch (_: Exception) {} }, 600)
        } catch (_: Exception) {}
    }

    private fun verificarMeta(valorAdicionado: Float, prefs: android.content.SharedPreferences) {
        val meta = prefs.getFloat("meta_diaria", 0f)
        if (meta <= 0f || !prefs.getBoolean("som_meta", true)) return
        try {
            val totalHoje = DatabaseHelper(this).run { resumo(buscarHoje())["total"] ?: 0f }
            if (totalHoje >= meta && (totalHoje - valorAdicionado) < meta) {
                val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100)
                repeat(3) { i ->
                    handler.postDelayed({
                        try { tg.startTone(ToneGenerator.TONE_PROP_BEEP, 200) } catch (_: Exception) {}
                    }, i * 400L)
                }
                handler.postDelayed({ try { tg.release() } catch (_: Exception) {} }, 1800)
            }
        } catch (_: Exception) {}
    }

    // ══════════════════════════════════════════════════════════════════════
    // CONTROLE DE TIMEOUT E ESTADO
    // ══════════════════════════════════════════════════════════════════════

    private fun iniciarTimeout(ms: Long, acao: () -> Unit) {
        cancelarTimeout()
        val r = Runnable { acao() }
        timeoutRunnable = r
        handler.postDelayed(r, ms)
    }

    internal fun cancelarTimeout() {
        timeoutRunnable?.let { handler.removeCallbacks(it) }
        timeoutRunnable = null
    }

    internal fun cancelarAutoAR() {
        runnableAutoAceitar?.let { handler.removeCallbacks(it) }; runnableAutoAceitar = null
        runnableAutoRecusar?.let { handler.removeCallbacks(it) }; runnableAutoRecusar = null
    }

    internal fun cancelarLeituraOferta() {
        runnableLeituraOferta?.let { handler.removeCallbacks(it) }
        runnableLeituraOferta = null
    }

    internal fun cancelarTudo() {
        cancelarTimeout()
        cancelarAutoAR()
        cancelarLeituraOferta()
    }

    internal fun resetarEstado() {
        estado            = Estado.IDLE
        corridaValor      = 0f; corridaKm = 0f; corridaGanhoPorKm = 0f
        corridaValeAPena  = false
        corridaOrigem     = ""; corridaDestino = ""; corridaCliente = ""
        corridaForma      = ""; corridaHoraInicio = ""
        finalValor        = 0f; finalKm = 0f; finalTempo = ""
        overlayAtivo      = false; ultimoValorOferta = 0f
        cancelarTudo()
    }
}
