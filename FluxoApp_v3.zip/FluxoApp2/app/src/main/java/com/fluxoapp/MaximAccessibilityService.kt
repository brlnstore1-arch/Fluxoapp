package com.fluxoapp

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class MaximAccessibilityService : AccessibilityService() {

    private lateinit var prefs: SharedPreferences
    private lateinit var db: DatabaseHelper
    private var overlayVisivel = false
    private var ultimoHashCorrida = ""
    private var ultimoTempoProcessado = 0L
    private val DEBOUNCE_MS = 4000L
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("FluxoApp", MODE_PRIVATE)
        db = DatabaseHelper(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        if (!prefs.getBoolean("servico_ativo", true)) {
            if (overlayVisivel) esconderOverlay()
            return
        }
        val tipo = event.eventType
        if (tipo != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            tipo != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) return

        val agora = System.currentTimeMillis()
        if (agora - ultimoTempoProcessado < DEBOUNCE_MS) return

        val root = rootInActiveWindow ?: return
        val textos = coletarTextos(root)

        val temPedidoAtribuido = textos.any { t ->
            t.contains("Pedido atribuído", ignoreCase = true) ||
            t.contains("Pedido atribuido", ignoreCase = true)
        }
        val temRecusar = textos.any { it.trim().equals("Recusar", ignoreCase = true) }
        val temCancelamento = textos.any { t ->
            t.contains("pedido será cancelado", ignoreCase = true) ||
            t.contains("pedido sera cancelado", ignoreCase = true)
        }

        val ehNovaCorrida = temPedidoAtribuido || (temRecusar && temCancelamento)

        if (ehNovaCorrida) {
            val dados = extrairDados(textos) ?: return
            val hash = "${dados.valor}_${dados.kmBuscar}_${dados.kmCorrida}"
            if (hash == ultimoHashCorrida) return

            ultimoHashCorrida = hash
            ultimoTempoProcessado = agora

            val kmTotal = dados.kmBuscar + dados.kmCorrida
            val ganhoPorKm = if (kmTotal > 0) dados.valor / kmTotal else 0f
            val minimo = prefs.getFloat("minimo_km", 1.20f)
            val valeAPena = ganhoPorKm >= minimo

            salvarCorrida(dados, kmTotal, ganhoPorKm, valeAPena)
            mostrarOverlay(dados.valor, kmTotal, ganhoPorKm, valeAPena)
            atualizarFlutuante()

            val autoAceitar = prefs.getBoolean("auto_aceitar", false)
            val autoRecusar = prefs.getBoolean("auto_recusar", false)
            val tempoMs = prefs.getInt("tempo_auto_aceitar", 3) * 1000L

            when {
                valeAPena && autoAceitar -> handler.postDelayed({
                    clicarBotao(root, "Aceitar")
                    tocarSom(true)
                }, tempoMs)
                !valeAPena && autoRecusar -> handler.postDelayed({
                    clicarBotao(root, "Recusar")
                    tocarSom(false)
                }, tempoMs)
            }
        } else {
            if (overlayVisivel) {
                ultimoHashCorrida = ""
                esconderOverlay()
            }
        }
    }

    private fun coletarTextos(node: AccessibilityNodeInfo): List<String> {
        val lista = mutableListOf<String>()
        fun percorrer(n: AccessibilityNodeInfo) {
            n.text?.toString()?.trim()?.let { if (it.isNotBlank()) lista.add(it) }
            for (i in 0 until n.childCount) {
                val filho = n.getChild(i) ?: continue
                percorrer(filho)
                filho.recycle()
            }
        }
        percorrer(node)
        return lista
    }

    private fun extrairDados(textos: List<String>): DadosCorrida? {
        val padraoValor = Regex("""R\$\s*(\d+[,\.]\d+)""")
        val padraoKm = Regex("""^(\d+[,\.]\d+)\s*km\.?$""", RegexOption.IGNORE_CASE)

        var valor: Float? = null
        var kmBuscar: Float? = null
        var kmCorrida: Float? = null
        var origem = ""
        var destino = ""
        var formaPagamento = ""
        var encontrouOrigem = false

        for (i in textos.indices) {
            val texto = textos[i].trim()

            // Valor — pega o maior
            padraoValor.find(texto)?.let {
                val v = it.groupValues[1].replace(",", ".").toFloatOrNull()
                if (v != null && v > 0 && (valor == null || v > valor!!)) valor = v
            }

            // KM com contexto
            padraoKm.find(texto)?.let {
                val km = it.groupValues[1].replace(",", ".").toFloatOrNull() ?: return@let
                val proximo = textos.getOrElse(i + 1) { "" }.lowercase()
                when {
                    proximo.contains("até o endereço") || proximo.contains("ate o endereco") -> kmBuscar = km
                    proximo.contains("distância") || proximo.contains("distancia") -> kmCorrida = km
                    kmBuscar == null -> kmBuscar = km
                    kmCorrida == null -> kmCorrida = km
                }
            }

            // Forma de pagamento
            when {
                texto.contains("em dinheiro", ignoreCase = true) -> formaPagamento = "Dinheiro"
                texto.contains("por PIX", ignoreCase = true) || texto.contains("via PIX", ignoreCase = true) -> formaPagamento = "PIX"
            }

            // Endereços
            if (texto.contains("bairro") && !encontrouOrigem) {
                origem = texto; encontrouOrigem = true
            } else if (texto.contains("bairro") && encontrouOrigem && destino.isEmpty()) {
                destino = texto
            }
        }

        return if (valor != null && valor!! > 0)
            DadosCorrida(valor!!, kmBuscar ?: 0f, kmCorrida ?: 0f, origem, destino, formaPagamento)
        else null
    }

    private fun salvarCorrida(dados: DadosCorrida, kmTotal: Float, ganhoPorKm: Float, valeAPena: Boolean) {
        db.inserirCorrida(Corrida(
            valor = dados.valor, kmTotal = kmTotal, ganhoPorKm = ganhoPorKm,
            valeAPena = valeAPena, origem = dados.origem,
            destino = dados.destino, formaPagamento = dados.formaPagamento
        ))
    }

    private fun mostrarOverlay(valor: Float, kmTotal: Float, ganhoPorKm: Float, valeAPena: Boolean) {
        overlayVisivel = true
        startService(Intent(this, OverlayService::class.java).apply {
            action = "MOSTRAR"
            putExtra("valor", valor)
            putExtra("km_total", kmTotal)
            putExtra("ganho_por_km", ganhoPorKm)
            putExtra("vale_a_pena", valeAPena)
            putExtra("auto_aceitar", prefs.getBoolean("auto_aceitar", false))
            putExtra("auto_recusar", prefs.getBoolean("auto_recusar", false))
        })
    }

    private fun esconderOverlay() {
        overlayVisivel = false
        startService(Intent(this, OverlayService::class.java).apply { action = "ESCONDER" })
    }

    private fun atualizarFlutuante() {
        if (prefs.getBoolean("flutuante_ativo", true)) {
            startService(Intent(this, FloatingEarningsService::class.java).apply { action = "ATUALIZAR" })
        }
    }

    private fun clicarBotao(root: AccessibilityNodeInfo, texto: String) {
        fun procurar(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
            if ((node.text?.toString()?.contains(texto, ignoreCase = true) == true ||
                 node.contentDescription?.toString()?.contains(texto, ignoreCase = true) == true) &&
                node.isClickable) return node
            for (i in 0 until node.childCount) {
                val filho = node.getChild(i) ?: continue
                val r = procurar(filho)
                if (r != null) return r
                filho.recycle()
            }
            return null
        }
        procurar(root)?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun tocarSom(aceitar: Boolean) {
        try {
            val toneGen = android.media.ToneGenerator(android.media.AudioManager.STREAM_NOTIFICATION, 100)
            if (aceitar) {
                toneGen.startTone(android.media.ToneGenerator.TONE_PROP_ACK, 200)
                handler.postDelayed({
                    toneGen.startTone(android.media.ToneGenerator.TONE_PROP_ACK, 300)
                    handler.postDelayed({ toneGen.release() }, 400)
                }, 300)
            } else {
                toneGen.startTone(android.media.ToneGenerator.TONE_PROP_NACK, 400)
                handler.postDelayed({ toneGen.release() }, 500)
            }
        } catch (_: Exception) {}
    }

    override fun onInterrupt() {}

    data class DadosCorrida(
        val valor: Float, val kmBuscar: Float, val kmCorrida: Float,
        val origem: String = "", val destino: String = "", val formaPagamento: String = ""
    )
}
