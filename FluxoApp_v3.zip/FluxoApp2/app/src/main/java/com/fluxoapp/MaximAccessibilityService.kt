package com.fluxoapp

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class MaximAccessibilityService : AccessibilityService() {

    private lateinit var prefs: SharedPreferences
    private lateinit var db: DatabaseHelper
    private var overlayVisivel = false

    // ── Controle anti-duplicata reforçado ──
    private var ultimoHashCorrida = ""
    private var ultimoTempoRegistro = 0L
    private var ultimoValorRegistrado = 0f
    private val DEBOUNCE_REGISTRO_MS = 30_000L  // 30 segundos entre registros do mesmo valor
    private val DEBOUNCE_EVENTO_MS   = 2_000L   // 2 segundos entre leituras de tela

    private var ultimoTempoEvento = 0L
    private val handler = Handler(Looper.getMainLooper())
    private var pendingSalvar: Runnable? = null

    override fun onCreate() {
        super.onCreate()
        try {
            prefs = getSharedPreferences("FluxoApp", MODE_PRIVATE)
            db = DatabaseHelper(this)
        } catch (_: Exception) {}
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        try {
            event ?: return
            if (!prefs.getBoolean("servico_ativo", true)) {
                if (overlayVisivel) esconderOverlay()
                return
            }

            val tipo = event.eventType
            if (tipo != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
                tipo != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) return

            val agora = System.currentTimeMillis()
            if (agora - ultimoTempoEvento < DEBOUNCE_EVENTO_MS) return
            ultimoTempoEvento = agora

            val root = try { rootInActiveWindow } catch (_: Exception) { return } ?: return
            val textos = try { coletarTextos(root) } catch (_: Exception) { return }

            val temPedidoAtribuido = textos.any { t ->
                t.contains("Pedido atribu", ignoreCase = true)
            }
            val temBotaoRecusar = textos.any { it.trim().equals("Recusar", ignoreCase = true) }
            val temBotaoAceitar = textos.any { it.trim().equals("Aceitar", ignoreCase = true) }
            val temCancelamento = textos.any { t ->
                t.contains("ser\u00e1 cancelado", ignoreCase = true) ||
                t.contains("sera cancelado", ignoreCase = true)
            }

            // Só detecta se tiver os botões ACEITAR e RECUSAR juntos (tela real de corrida)
            val ehNovaCorrida = temPedidoAtribuido && temBotaoRecusar && temBotaoAceitar && temCancelamento

            if (ehNovaCorrida) {
                val dados = try { extrairDados(textos) } catch (_: Exception) { null } ?: return

                // Rejeitar corridas com km = 0 (dados incompletos)
                if (dados.kmCorrida <= 0f && dados.kmBuscar <= 0f) return
                // Rejeitar valor zero
                if (dados.valor <= 0f) return

                val hash = "${dados.valor}_${dados.kmBuscar}_${dados.kmCorrida}"

                // Anti-duplicata: mesmo hash OU mesmo valor nos últimos 30 segundos
                val mesmoHash = hash == ultimoHashCorrida
                val mesmoValorRecente = dados.valor == ultimoValorRegistrado &&
                        (agora - ultimoTempoRegistro) < DEBOUNCE_REGISTRO_MS
                if (mesmoHash || mesmoValorRecente) {
                    // Mostra overlay mas não salva de novo
                    if (!overlayVisivel) {
                        val kmTotal = dados.kmBuscar + dados.kmCorrida
                        val ganhoPorKm = if (kmTotal > 0) dados.valor / kmTotal else 0f
                        val valeAPena = ganhoPorKm >= prefs.getFloat("minimo_km", 1.20f)
                        mostrarOverlay(dados.valor, kmTotal, ganhoPorKm, valeAPena)
                    }
                    return
                }

                ultimoHashCorrida = hash
                ultimoTempoRegistro = agora
                ultimoValorRegistrado = dados.valor

                val kmTotal = dados.kmBuscar + dados.kmCorrida
                val ganhoPorKm = if (kmTotal > 0) dados.valor / kmTotal else 0f
                val minimo = prefs.getFloat("minimo_km", 1.20f)
                val valeAPena = ganhoPorKm >= minimo

                // Cancela salvar pendente anterior
                pendingSalvar?.let { handler.removeCallbacks(it) }

                // Salva com delay de 1s para garantir que os dados estão completos na tela
                pendingSalvar = Runnable {
                    try {
                        db.inserirCorrida(Corrida(
                            valor = dados.valor, kmTotal = kmTotal, ganhoPorKm = ganhoPorKm,
                            valeAPena = valeAPena, origem = dados.origem,
                            destino = dados.destino, formaPagamento = dados.formaPagamento
                        ))
                        atualizarFlutuante()
                    } catch (_: Exception) {}
                }
                handler.postDelayed(pendingSalvar!!, 1000L)

                mostrarOverlay(dados.valor, kmTotal, ganhoPorKm, valeAPena)

                val autoAceitar = prefs.getBoolean("auto_aceitar", false)
                val autoRecusar = prefs.getBoolean("auto_recusar", false)
                val tempoMs = prefs.getInt("tempo_auto_aceitar", 3) * 1000L

                // Som especial para corrida muito boa (>=2x o mínimo)
                val ehMuitoBoa = ganhoPorKm >= minimo * 2f
                if (ehMuitoBoa) tocarSomEspecial()

                when {
                    valeAPena && autoAceitar -> handler.postDelayed({
                        try {
                            val r = rootInActiveWindow ?: return@postDelayed
                            clicarBotao(r, "Aceitar")
                            if (!ehMuitoBoa) tocarSom(true)
                        } catch (_: Exception) {}
                    }, tempoMs)
                    !valeAPena && autoRecusar -> handler.postDelayed({
                        try {
                            val r = rootInActiveWindow ?: return@postDelayed
                            clicarBotao(r, "Recusar")
                            tocarSom(false)
                        } catch (_: Exception) {}
                    }, tempoMs)
                }

            } else {
                // Não está mais na tela de corrida
                if (overlayVisivel) {
                    esconderOverlay()
                }
            }
        } catch (_: Exception) {}
    }

    private fun coletarTextos(node: AccessibilityNodeInfo): List<String> {
        val lista = mutableListOf<String>()
        fun percorrer(n: AccessibilityNodeInfo) {
            try {
                n.text?.toString()?.trim()?.let { if (it.isNotBlank()) lista.add(it) }
                n.contentDescription?.toString()?.trim()?.let { if (it.isNotBlank() && !lista.contains(it)) lista.add(it) }
                for (i in 0 until n.childCount) {
                    val filho = n.getChild(i) ?: continue
                    percorrer(filho)
                    try { filho.recycle() } catch (_: Exception) {}
                }
            } catch (_: Exception) {}
        }
        percorrer(node)
        return lista
    }

    private fun extrairDados(textos: List<String>): DadosCorrida? {
        val padraoValor = Regex("""R\$\s*(\d+[,\.]\d+)""")
        val padraoKm   = Regex("""^(\d+[,\.]\d+)\s*km\.?$""", RegexOption.IGNORE_CASE)

        var valor: Float? = null
        var kmBuscar: Float? = null
        var kmCorrida: Float? = null
        var origem = ""
        var destino = ""
        var formaPagamento = ""
        var encontrouOrigem = false

        for (i in textos.indices) {
            val texto = textos[i].trim()

            // Valor — pega o primeiro encontrado (valor da corrida, não taxa)
            if (valor == null) {
                padraoValor.find(texto)?.let {
                    val v = it.groupValues[1].replace(",", ".").toFloatOrNull()
                    if (v != null && v > 0) valor = v
                }
            }

            // KM
            padraoKm.find(texto)?.let {
                val km = it.groupValues[1].replace(",", ".").toFloatOrNull() ?: return@let
                if (km <= 0f) return@let
                // Olha o próximo texto para contexto
                val prox1 = textos.getOrElse(i + 1) { "" }.lowercase()
                val prox2 = textos.getOrElse(i + 2) { "" }.lowercase()
                val contexto = "$prox1 $prox2"
                when {
                    contexto.contains("at\u00e9 o endere") || contexto.contains("ate o endere") ||
                    contexto.contains("busca") -> kmBuscar = km
                    contexto.contains("dist\u00e2ncia") || contexto.contains("distancia") ||
                    contexto.contains("rota") -> kmCorrida = km
                    kmBuscar == null -> kmBuscar = km
                    kmCorrida == null -> kmCorrida = km
                }
            }

            // Pagamento
            when {
                texto.contains("em dinheiro", ignoreCase = true) ||
                texto.lowercase() == "dinheiro" -> formaPagamento = "Dinheiro"
                texto.contains("por PIX", ignoreCase = true) ||
                texto.contains("via PIX", ignoreCase = true) ||
                texto.lowercase() == "pix" -> formaPagamento = "PIX"
            }

            // Endereços
            if (texto.length > 5 && !texto.contains("Maxim", ignoreCase = true) &&
                !texto.contains("Pedido", ignoreCase = true) &&
                !texto.contains("cancelado", ignoreCase = true) &&
                !texto.contains("R$") &&
                texto.contains(Regex("[a-zA-Z]{3,}"))) {
                if (!encontrouOrigem && (texto.contains("bairro", ignoreCase = true) ||
                    texto.contains("rua", ignoreCase = true) ||
                    texto.contains("av", ignoreCase = true))) {
                    origem = texto; encontrouOrigem = true
                } else if (encontrouOrigem && destino.isEmpty() &&
                    (texto.contains("bairro", ignoreCase = true) ||
                     texto.contains("rua", ignoreCase = true) ||
                     texto.contains("av", ignoreCase = true))) {
                    destino = texto
                }
            }
        }

        return if (valor != null && valor!! > 0)
            DadosCorrida(valor!!, kmBuscar ?: 0f, kmCorrida ?: 0f, origem, destino, formaPagamento)
        else null
    }

    private fun mostrarOverlay(valor: Float, kmTotal: Float, ganhoPorKm: Float, valeAPena: Boolean) {
        overlayVisivel = true
        try {
            startService(Intent(this, OverlayService::class.java).apply {
                action = "MOSTRAR"
                putExtra("valor", valor); putExtra("km_total", kmTotal)
                putExtra("ganho_por_km", ganhoPorKm); putExtra("vale_a_pena", valeAPena)
                putExtra("auto_aceitar", prefs.getBoolean("auto_aceitar", false))
                putExtra("auto_recusar", prefs.getBoolean("auto_recusar", false))
            })
        } catch (_: Exception) {}
    }

    private fun esconderOverlay() {
        overlayVisivel = false
        try { startService(Intent(this, OverlayService::class.java).apply { action = "ESCONDER" }) } catch (_: Exception) {}
    }

    private fun atualizarFlutuante() {
        if (prefs.getBoolean("flutuante_ativo", true)) {
            try { startService(Intent(this, FloatingEarningsService::class.java).apply { action = "ATUALIZAR" }) } catch (_: Exception) {}
        }
    }

    private fun clicarBotao(root: AccessibilityNodeInfo, texto: String) {
        fun procurar(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
            try {
                if ((node.text?.toString()?.contains(texto, ignoreCase = true) == true ||
                     node.contentDescription?.toString()?.contains(texto, ignoreCase = true) == true) &&
                    node.isClickable) return node
                for (i in 0 until node.childCount) {
                    val filho = node.getChild(i) ?: continue
                    val r = procurar(filho)
                    if (r != null) return r
                    try { filho.recycle() } catch (_: Exception) {}
                }
            } catch (_: Exception) {}
            return null
        }
        procurar(root)?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun tocarSom(aceitar: Boolean) {
        try {
            val toneGen = android.media.ToneGenerator(android.media.AudioManager.STREAM_NOTIFICATION, 100)
            if (aceitar) {
                toneGen.startTone(android.media.ToneGenerator.TONE_PROP_ACK, 200)
                handler.postDelayed({
                    toneGen.startTone(android.media.ToneGenerator.TONE_PROP_ACK, 300)
                    handler.postDelayed({ toneGen.release() }, 400)
                }, 300)
            } else {
                toneGen.startTone(android.media.ToneGenerator.TONE_PROP_NACK, 400)
                handler.postDelayed({ toneGen.release() }, 500)
            }
        } catch (_: Exception) {}
    }

    private fun tocarSomEspecial() {
        // Som diferenciado: 3 bips ascendentes para corrida muito boa
        try {
            val tone = android.media.ToneGenerator(android.media.AudioManager.STREAM_NOTIFICATION, 100)
            tone.startTone(android.media.ToneGenerator.TONE_PROP_ACK, 150)
            handler.postDelayed({ tone.startTone(android.media.ToneGenerator.TONE_PROP_ACK, 150) }, 200)
            handler.postDelayed({ tone.startTone(android.media.ToneGenerator.TONE_CDMA_HIGH_L, 400) }, 400)
            handler.postDelayed({ tone.release() }, 900)
            // Vibrar 2x rápido
            try {
                val v = this.getSystemService(android.content.Context.VIBRATOR_SERVICE) as android.os.Vibrator
                v.vibrate(longArrayOf(0, 100, 80, 100), -1)
            } catch (_: Exception) {}
        } catch (_: Exception) {}
    }

    override fun onInterrupt() {}

    data class DadosCorrida(
        val valor: Float, val kmBuscar: Float, val kmCorrida: Float,
        val origem: String = "", val destino: String = "", val formaPagamento: String = ""
    )
}
