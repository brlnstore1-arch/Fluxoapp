package com.fluxoapp

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.text.SimpleDateFormat
import java.util.*

class MaximAccessibilityService : AccessibilityService() {

    private lateinit var prefs: SharedPreferences
    private lateinit var db: DatabaseHelper
    private var overlayVisivel = false
    private val handler = Handler(Looper.getMainLooper())

    // ── Debounce de eventos ──
    private var ultimoTempoEvento = 0L
    private val DEBOUNCE_EVENTO_MS = 500L   // Reduzido para capturar toasts

    // ── Máquina de estados ──
    // IDLE → OFERTA (chegou corrida) → EM_ANDAMENTO → FINALIZANDO (tela Finalizar pedido)
    // A qualquer momento: CANCELADO → IDLE
    private enum class Estado { IDLE, OFERTA, EM_ANDAMENTO, FINALIZANDO }
    private var estado = Estado.IDLE

    // ── Fila de corridas (suporta corridas sobrepostas) ──
    private val filaCorridas = ArrayDeque<DadosCorridaTemp>()

    // ── Anti-duplicata ──
    private var ultimoHashOferta = ""
    private var ultimoTempoOferta = 0L
    private val DEBOUNCE_OFERTA_MS = 15_000L

    // ── Anti-duplicata de corridas salvas (evita salvar 2x a mesma corrida) ──
    private val hashesCorridasSalvas = mutableSetOf<String>()
    private var ultimaCorridaSalvaMs = 0L
    private val DEBOUNCE_SALVAR_MS = 10_000L  // 10s entre saves do mesmo valor+hora

    override fun onCreate() {
        super.onCreate()
        try {
            prefs = getSharedPreferences("FluxoApp", MODE_PRIVATE)
            db = DatabaseHelper(this)
        } catch (_: Exception) {}
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        try {
            event ?: return
            if (!prefs.getBoolean("servico_ativo", true)) {
                if (overlayVisivel) esconderOverlay()
                return
            }

            val tipo = event.eventType
            val agora = System.currentTimeMillis()

            // Toast/Announcement — processa na hora sem debounce (toasts duram ~2s)
            if (tipo == AccessibilityEvent.TYPE_ANNOUNCEMENT ||
                tipo == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
                val textoEvento = event.text?.joinToString(" ") ?: ""
                if (textoEvento.contains("Pedido finalizado", ignoreCase = true)) {
                    if (filaCorridas.isNotEmpty()) {
                        salvarCorridaFinal()
                        estado = if (filaCorridas.isNotEmpty()) Estado.EM_ANDAMENTO else Estado.IDLE
                    }
                    return
                }
                if (textoEvento.contains("Pedido cancelado", ignoreCase = true)) {
                    if (filaCorridas.isNotEmpty()) filaCorridas.removeLast()
                    estado = Estado.IDLE
                    if (overlayVisivel) esconderOverlay()
                    return
                }
            }

            if (tipo != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
                tipo != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) return

            if (agora - ultimoTempoEvento < DEBOUNCE_EVENTO_MS) return
            ultimoTempoEvento = agora

            val root = try { rootInActiveWindow } catch (_: Exception) { return } ?: return
            val textos = try { coletarTextos(root) } catch (_: Exception) { return }
            val textosJuntos = textos.joinToString(" ")

            processarEstado(textos, textosJuntos, agora)

        } catch (_: Exception) {}
    }

    private fun processarEstado(textos: List<String>, textosJuntos: String, agora: Long) {

        // ── DETECTAR CANCELAMENTO (qualquer estado) ──
        val temCancelamento = textos.any { it.contains("Pedido cancelado", ignoreCase = true) }
        if (temCancelamento) {
            // Cancela a corrida mais recente da fila (a que está em andamento)
            if (filaCorridas.isNotEmpty()) filaCorridas.removeLast()
            estado = Estado.IDLE
            if (overlayVisivel) esconderOverlay()
            return
        }

        // ── DETECTAR FINALIZAÇÃO ── (tela "Finalizar pedido" + toast "Pedido finalizado")
        val telaFinalizarPedido = textos.any { it.contains("Finalizar pedido", ignoreCase = true) }
        val toastFinalizado = textos.any { it.contains("Pedido finalizado", ignoreCase = true) }

        if (telaFinalizarPedido) {
            if (estado != Estado.FINALIZANDO) {
                estado = Estado.FINALIZANDO
                // Captura valor real + km real + tempo da tela de finalização
                atualizarDadosFinalizacao(textos)
                // Agenda salvar como backup: se o toast não for detectado em 60s, salva mesmo assim
                handler.removeCallbacksAndMessages("salvar_backup")
                handler.postDelayed({
                    if (estado == Estado.FINALIZANDO && filaCorridas.isNotEmpty()) {
                        salvarCorridaFinal()
                        estado = if (filaCorridas.isNotEmpty()) Estado.EM_ANDAMENTO else Estado.IDLE
                    }
                }, 60_000L)
            }
            return
        }

        // Toast "Pedido finalizado!" via rootInActiveWindow (fallback da detecção direta no evento)
        if (toastFinalizado && filaCorridas.isNotEmpty()) {
            handler.removeCallbacksAndMessages("salvar_backup")
            salvarCorridaFinal()
            estado = if (filaCorridas.isNotEmpty()) Estado.EM_ANDAMENTO else Estado.IDLE
            return
        }

        // ── DETECTAR CORRIDA EM ANDAMENTO ──
        val emAndamento = textos.any { it.contains("Em andamento", ignoreCase = true) } &&
                          textos.any { it.trim().equals("Finalizar", ignoreCase = true) }
        if (emAndamento) {
            if (estado == Estado.OFERTA || estado == Estado.IDLE) {
                estado = Estado.EM_ANDAMENTO
                if (filaCorridas.isNotEmpty()) filaCorridas.first().horaInicio = horaAtual()
            }
            // Capturar nome do passageiro se ainda não temos
            if (filaCorridas.isNotEmpty() && filaCorridas.first().passageiro.isEmpty()) {
                for (i in textos.indices) {
                    if (textos[i].equals("Cliente", ignoreCase = true) && i + 1 < textos.size) {
                        val nome = textos[i + 1].trim()
                        if (nome.isNotEmpty() && nome.length < 40 && !nome.contains("R$")) {
                            filaCorridas.first().passageiro = nome
                        }
                    }
                }
            }
            if (overlayVisivel) esconderOverlay()
            return
        }

        // ── DETECTAR AGUARDANDO CLIENTE ──
        val aguardando = textos.any { it.contains("espera gratuita", ignoreCase = true) } ||
                         textos.any { it.trim().equals("Iniciar", ignoreCase = true) }
        if (aguardando) {
            if (estado == Estado.OFERTA) estado = Estado.EM_ANDAMENTO
            if (overlayVisivel) esconderOverlay()
            return
        }

        // ── DETECTAR A CAMINHO ──
        val aCaminho = textos.any { it.contains("A caminho", ignoreCase = true) } &&
                       textos.any { it.trim().equals("Cheguei no local", ignoreCase = true) }
        if (aCaminho) {
            if (estado == Estado.OFERTA) estado = Estado.EM_ANDAMENTO
            if (overlayVisivel) esconderOverlay()
            return
        }

        // ── DETECTAR OFERTA (gatilho: botões ACEITAR + RECUSAR juntos) ──
        val temAceitar = textos.any { it.trim().equals("Aceitar", ignoreCase = true) }
        val temRecusar = textos.any { it.trim().equals("Recusar", ignoreCase = true) }

        if (temAceitar && temRecusar) {
            val dados = try { extrairDadosOferta(textos) } catch (_: Exception) { null } ?: return
            if (dados.valor <= 0f) return

            val hash = "${dados.valor}_${dados.kmBuscar}_${dados.kmCorrida}"
            val mesmoHash = hash == ultimoHashOferta
            val recente = (agora - ultimoTempoOferta) < DEBOUNCE_OFERTA_MS

            if (mesmoHash && recente) {
                // Mesma corrida — apenas mostra overlay se não estiver visível
                if (!overlayVisivel) mostrarOverlay(dados)
                return
            }

            ultimoHashOferta = hash
            ultimoTempoOferta = agora

            // ── Limpar entradas duplicadas na fila com o mesmo valor+origem ──
            // Evita que a fila acumule a mesma corrida detectada múltiplas vezes
            filaCorridas.removeAll { c ->
                c.valor == dados.valor && c.origem == dados.origem && c.horaFim.isEmpty()
            }

            // Se tem corrida em andamento, salva ela agora antes de aceitar nova
            if (estado == Estado.EM_ANDAMENTO && filaCorridas.isNotEmpty()) {
                val atual = filaCorridas.first()
                atual.horaFim = horaAtual()
                // Salva com dados que tem (valor da oferta como fallback)
                salvarCorridaEspecifica(atual)
                filaCorridas.removeFirst()
            }

            estado = Estado.OFERTA

            // Adiciona nova corrida na fila — NÃO salva ainda
            filaCorridas.addLast(DadosCorridaTemp(
                valor = dados.valor,
                kmBuscar = dados.kmBuscar,
                kmCorrida = dados.kmCorrida,
                origem = dados.origem,
                destino = dados.destino,
                formaPagamento = dados.formaPagamento,
                passageiro = dados.passageiro,
                horaOferta = horaAtual()
            ))

            mostrarOverlay(dados)
            processarAutoAceitarRecusar(dados)
            return
        }

        // ── Fora de qualquer estado conhecido ──
        if (estado == Estado.IDLE && overlayVisivel) esconderOverlay()
    }

    private fun atualizarDadosFinalizacao(textos: List<String>) {
        val mem = if (filaCorridas.isNotEmpty()) filaCorridas.first() else return
        try {
            val padraoValor = Regex("""R\$\s*(\d+[,.]\d+)""")

            // Estratégia: procura "Preço total" primeiro (tela PIX/cartão)
            // Depois tenta "Recebido em dinheiro", por último pega o primeiro valor
            var valorEncontrado = 0f

            for (i in textos.indices) {
                val t = textos[i].trim()
                // "Preço total" aparece como label — o valor está na mesma string "R$ X,XX  Preço total"
                // ou o valor vem antes e o label depois
                if (t.contains("Preco total", ignoreCase = true) ||
                    t.contains("Preço total", ignoreCase = true) ||
                    t.contains("Preço total", ignoreCase = true)) {
                    // Tenta extrair valor da mesma linha
                    val m = padraoValor.find(t)
                    if (m != null) {
                        valorEncontrado = m.groupValues[1].replace(",", ".").toFloatOrNull() ?: 0f
                    }
                    // Ou tenta linha anterior
                    if (valorEncontrado <= 0f && i > 0) {
                        val prev = padraoValor.find(textos[i-1])
                        if (prev != null) valorEncontrado = prev.groupValues[1].replace(",", ".").toFloatOrNull() ?: 0f
                    }
                    if (valorEncontrado > 0f) break
                }
            }

            // Fallback: "Recebido em dinheiro" ou primeiro valor encontrado
            if (valorEncontrado <= 0f) {
                for (i in textos.indices) {
                    val t = textos[i].trim()
                    if (t.contains("Recebido", ignoreCase = true)) {
                        val m = padraoValor.find(t)
                        if (m != null) { valorEncontrado = m.groupValues[1].replace(",", ".").toFloatOrNull() ?: 0f; break }
                        if (i + 1 < textos.size) {
                            val m2 = padraoValor.find(textos[i+1])
                            if (m2 != null) { valorEncontrado = m2.groupValues[1].replace(",", ".").toFloatOrNull() ?: 0f; break }
                        }
                    }
                }
            }

            // Último fallback: primeiro R$ encontrado
            if (valorEncontrado <= 0f) {
                for (t in textos) {
                    val m = padraoValor.find(t)
                    if (m != null) {
                        valorEncontrado = m.groupValues[1].replace(",", ".").toFloatOrNull() ?: 0f
                        if (valorEncontrado > 0f) break
                    }
                }
            }

            // Valida: so aceita se for pelo menos 50% do valor da oferta
            // Evita capturar valores parciais ou erroneos da tela
            val minimoAceitavel = mem.valor * 0.5f
            if (valorEncontrado >= minimoAceitavel && valorEncontrado > 0f) {
                mem.valorFinal = valorEncontrado
            }
            // Se nao passou na validacao, valorFinal fica 0 e usa valor da oferta como fallback

            // Captura km real
            val padraoKm = Regex("""^(\d+[,.]\d+)\s*km\.?$""", RegexOption.IGNORE_CASE)
            for (t in textos) {
                val match = padraoKm.find(t.trim())
                if (match != null) {
                    val km = match.groupValues[1].replace(",", ".").toFloatOrNull()
                    if (km != null && km > 0f) {
                        mem.kmFinal = km
                        break
                    }
                }
            }

            // Captura tempo de execução (ex: "6 min.", "10 min.")
            val padraoTempo = Regex("""(\d+)\s*min""", RegexOption.IGNORE_CASE)
            for (t in textos) {
                val match = padraoTempo.find(t)
                if (match != null) {
                    mem.tempoExecucao = "${match.groupValues[1]} min"
                    break
                }
            }

            // Hora de fim
            mem.horaFim = horaAtual()

        } catch (_: Exception) {}
    }

    private fun salvarCorridaFinal() {
        val mem = if (filaCorridas.isNotEmpty()) filaCorridas.first() else return
        filaCorridas.removeFirst()
        try {
            val valor = if (mem.valorFinal > 0f) mem.valorFinal else mem.valor
            val km = if (mem.kmFinal > 0f) mem.kmFinal else (mem.kmBuscar + mem.kmCorrida)
            val ganhoPorKm = if (km > 0f) valor / km else 0f
            val valeAPena = ganhoPorKm >= prefs.getFloat("minimo_km", 1.20f)
            val horaFim = if (mem.horaFim.isNotEmpty()) mem.horaFim else horaAtual()
            val horaInicio = if (mem.horaInicio.isNotEmpty()) mem.horaInicio else mem.horaOferta

            // ── Anti-duplicata: bloqueia se mesma corrida (valor+horaOferta) já foi salva ──
            val hashSave = "\${valor}_\${mem.horaOferta}_\${mem.origem.take(10)}"
            val agora = System.currentTimeMillis()
            if (hashSave in hashesCorridasSalvas || (agora - ultimaCorridaSalvaMs) < DEBOUNCE_SALVAR_MS &&
                hashSave == hashesCorridasSalvas.lastOrNull()) {
                return  // já salvou esta corrida
            }
            hashesCorridasSalvas.add(hashSave)
            if (hashesCorridasSalvas.size > 20) hashesCorridasSalvas.clear() // evitar memory leak
            ultimaCorridaSalvaMs = agora

            db.inserirCorrida(Corrida(
                valor = valor,
                kmTotal = km,
                ganhoPorKm = ganhoPorKm,
                valeAPena = valeAPena,
                origem = mem.origem,
                destino = mem.destino,
                formaPagamento = mem.formaPagamento,
                passageiro = mem.passageiro,
                horaInicio = horaInicio,
                horaFim = horaFim,
                tempoExecucao = mem.tempoExecucao
            ))
            atualizarFlutuante()

            val ehMuitoBoa = ganhoPorKm >= prefs.getFloat("minimo_km", 1.20f) * 2f
            if (ehMuitoBoa) tocarSomEspecial() else tocarSomRegistro()

        } catch (_: Exception) {}
    }

    private fun salvarCorridaEspecifica(mem: DadosCorridaTemp) {
        try {
            val valor = if (mem.valorFinal > 0f) mem.valorFinal else mem.valor
            val km = if (mem.kmFinal > 0f) mem.kmFinal else (mem.kmBuscar + mem.kmCorrida)
            val ganhoPorKm = if (km > 0f) valor / km else 0f
            val valeAPena = ganhoPorKm >= prefs.getFloat("minimo_km", 1.20f)
            db.inserirCorrida(Corrida(
                valor = valor, kmTotal = km, ganhoPorKm = ganhoPorKm,
                valeAPena = valeAPena, origem = mem.origem, destino = mem.destino,
                formaPagamento = mem.formaPagamento, passageiro = mem.passageiro,
                horaInicio = mem.horaInicio, horaFim = mem.horaFim,
                tempoExecucao = mem.tempoExecucao
            ))
            atualizarFlutuante()
        } catch (_: Exception) {}
    }

    private fun extrairDadosOferta(textos: List<String>): DadosCorrida? {
        val padraoValor = Regex("""R\$\s*(\d+[,.]\d+)""")
        val padraoKm   = Regex("""^(\d+[,.]\d+)\s*km\.?$""", RegexOption.IGNORE_CASE)

        var valor: Float? = null
        var kmBuscar: Float? = null
        var kmCorrida: Float? = null
        var origem = ""
        var destino = ""
        var formaPagamento = ""
        var passageiro = ""
        var encontrouOrigem = false

        // Primeira passagem: busca valor associado a "em dinheiro" ou "pix" — mais confiável
        for (i in textos.indices) {
            val texto = textos[i].trim()
            val prox = textos.getOrElse(i + 1) { "" }.lowercase()
            val ant  = textos.getOrElse(i - 1) { "" }.lowercase()
            val ctx  = "$ant $prox"
            if (ctx.contains("dinheiro") || ctx.contains("pix")) {
                padraoValor.find(texto)?.let {
                    val v = it.groupValues[1].replace(",", ".").toFloatOrNull()
                    if (v != null && v in 1f..500f) valor = v
                }
            }
        }

        // Segunda passagem: se não achou ainda, pega primeiro valor entre 1 e 200
        // mas ignora valores do FluxoApp (botão flutuante fica em outro package)
        for (i in textos.indices) {
            if (valor != null) break
            val texto = textos[i].trim()
            padraoValor.find(texto)?.let {
                val v = it.groupValues[1].replace(",", ".").toFloatOrNull()
                // Ignora valores que parecem ser total do dia (>= 80) ou centavos isolados
                if (v != null && v in 1f..79f) valor = v
            }
        }

        for (i in textos.indices) {
            val texto = textos[i].trim()

            padraoKm.find(texto)?.let {
                val km = it.groupValues[1].replace(",", ".").toFloatOrNull() ?: return@let
                if (km <= 0f) return@let
                val prox1 = textos.getOrElse(i + 1) { "" }.lowercase()
                val prox2 = textos.getOrElse(i + 2) { "" }.lowercase()
                val ctx = "$prox1 $prox2"
                when {
                    ctx.contains("at\u00e9 o endere") || ctx.contains("busca") -> kmBuscar = km
                    ctx.contains("dist\u00e2ncia") || ctx.contains("distancia") || ctx.contains("rota") -> kmCorrida = km
                    kmBuscar == null -> kmBuscar = km
                    kmCorrida == null -> kmCorrida = km
                }
            }

            when {
                texto.contains("em dinheiro", ignoreCase = true) ||
                texto.lowercase() == "dinheiro" -> formaPagamento = "Dinheiro"
                texto.contains("por PIX", ignoreCase = true) ||
                texto.lowercase() == "pix" -> formaPagamento = "PIX"
            }

            // Nome do passageiro — aparece após "Cliente"
            if (texto.equals("Cliente", ignoreCase = true) && i + 1 < textos.size) {
                val nome = textos[i + 1].trim()
                if (nome.isNotEmpty() && nome.length < 30 && !nome.contains("R$")) {
                    passageiro = nome
                }
            }

            // Endereços
            if (texto.length > 5 &&
                !texto.contains("Maxim", ignoreCase = true) &&
                !texto.contains("Pedido", ignoreCase = true) &&
                !texto.contains("cancelado", ignoreCase = true) &&
                !texto.contains("R$") &&
                !texto.equals("Cliente", ignoreCase = true) &&
                texto.contains(Regex("[a-zA-Z]{3,}"))) {
                if (!encontrouOrigem && (texto.contains("bairro", ignoreCase = true) ||
                    texto.contains("rua", ignoreCase = true) ||
                    texto.contains("av", ignoreCase = true) ||
                    texto.contains("travessa", ignoreCase = true))) {
                    origem = texto; encontrouOrigem = true
                } else if (encontrouOrigem && destino.isEmpty() &&
                    (texto.contains("bairro", ignoreCase = true) ||
                     texto.contains("rua", ignoreCase = true) ||
                     texto.contains("av", ignoreCase = true) ||
                     texto.contains("travessa", ignoreCase = true))) {
                    destino = texto
                }
            }
        }

        return if (valor != null && valor!! > 0)
            DadosCorrida(valor!!, kmBuscar ?: 0f, kmCorrida ?: 0f, origem, destino, formaPagamento, passageiro)
        else null
    }

    private fun processarAutoAceitarRecusar(dados: DadosCorrida) {
        val autoAceitar = prefs.getBoolean("auto_aceitar", false)
        val autoRecusar = prefs.getBoolean("auto_recusar", false)
        val tempoMs = prefs.getInt("tempo_auto_aceitar", 3) * 1000L
        val kmTotal = dados.kmBuscar + dados.kmCorrida
        val ganhoPorKm = if (kmTotal > 0) dados.valor / kmTotal else 0f
        val minimo = prefs.getFloat("minimo_km", 1.20f)
        val valeAPena = ganhoPorKm >= minimo
        val ehMuitoBoa = ganhoPorKm >= minimo * 2f
        if (ehMuitoBoa) tocarSomEspecial()

        when {
            valeAPena && autoAceitar -> handler.postDelayed({
                try {
                    val r = rootInActiveWindow ?: return@postDelayed
                    clicarBotao(r, "Aceitar")
                    if (!ehMuitoBoa) tocarSomAceitar() else tocarSomEspecial()
                    handler.postDelayed({ if (overlayVisivel) esconderOverlay() }, 1500L)
                } catch (_: Exception) {}
            }, tempoMs)
            !valeAPena && autoRecusar -> handler.postDelayed({
                try {
                    val r = rootInActiveWindow ?: return@postDelayed
                    clicarBotao(r, "Recusar")
                    tocarSom(false)
                    handler.postDelayed({ if (overlayVisivel) esconderOverlay() }, 1000L)
                } catch (_: Exception) {}
            }, tempoMs)
        }
    }

    private fun mostrarOverlay(dados: DadosCorrida) {
        val kmTotal = dados.kmBuscar + dados.kmCorrida
        val ganhoPorKm = if (kmTotal > 0) dados.valor / kmTotal else 0f
        val valeAPena = ganhoPorKm >= prefs.getFloat("minimo_km", 1.20f)
        overlayVisivel = true
        try {
            startService(Intent(this, OverlayService::class.java).apply {
                action = "MOSTRAR"
                putExtra("valor", dados.valor)
                putExtra("km_total", kmTotal)
                putExtra("ganho_por_km", ganhoPorKm)
                putExtra("vale_a_pena", valeAPena)
                putExtra("auto_aceitar", prefs.getBoolean("auto_aceitar", false))
                putExtra("auto_recusar", prefs.getBoolean("auto_recusar", false))
            })
        } catch (_: Exception) {}
    }

    private fun esconderOverlay() {
        overlayVisivel = false
        try { startService(Intent(this, OverlayService::class.java).apply { action = "ESCONDER" }) } catch (_: Exception) {}
    }

    private fun atualizarFlutuante() {
        if (prefs.getBoolean("flutuante_ativo", true)) {
            try { startService(Intent(this, FloatingEarningsService::class.java).apply { action = "ATUALIZAR" }) } catch (_: Exception) {}
        }
    }

    private fun horaAtual(): String =
        SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

    private fun clicarBotao(root: AccessibilityNodeInfo, texto: String) {
        fun procurar(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
            try {
                if ((node.text?.toString()?.contains(texto, ignoreCase = true) == true ||
                     node.contentDescription?.toString()?.contains(texto, ignoreCase = true) == true) &&
                    node.isClickable) return node
                for (i in 0 until node.childCount) {
                    val filho = node.getChild(i) ?: continue
                    val r = procurar(filho)
                    if (r != null) return r
                    try { filho.recycle() } catch (_: Exception) {}
                }
            } catch (_: Exception) {}
            return null
        }
        procurar(root)?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun coletarTextos(node: AccessibilityNodeInfo): List<String> {
        val lista = mutableListOf<String>()
        fun percorrer(n: AccessibilityNodeInfo) {
            try {
                n.text?.toString()?.trim()?.let { if (it.isNotBlank()) lista.add(it) }
                n.contentDescription?.toString()?.trim()?.let { if (it.isNotBlank() && !lista.contains(it)) lista.add(it) }
                for (i in 0 until n.childCount) {
                    val filho = n.getChild(i) ?: continue
                    percorrer(filho)
                    try { filho.recycle() } catch (_: Exception) {}
                }
            } catch (_: Exception) {}
        }
        percorrer(node)
        return lista
    }

    private fun tocarSom(aceitar: Boolean) {
        try {
            val tone = android.media.ToneGenerator(android.media.AudioManager.STREAM_NOTIFICATION, 100)
            if (aceitar) {
                tone.startTone(android.media.ToneGenerator.TONE_PROP_ACK, 200)
                handler.postDelayed({
                    tone.startTone(android.media.ToneGenerator.TONE_PROP_ACK, 300)
                    handler.postDelayed({ tone.release() }, 400)
                }, 300)
            } else {
                tone.startTone(android.media.ToneGenerator.TONE_PROP_NACK, 400)
                handler.postDelayed({ tone.release() }, 500)
            }
        } catch (_: Exception) {}
    }

    // Som de aceitar: 3 bips curtos crescentes (beep eletrônico limpo)
    private fun tocarSomAceitar() {
        try {
            val tone = android.media.ToneGenerator(android.media.AudioManager.STREAM_NOTIFICATION, 100)
            tone.startTone(android.media.ToneGenerator.TONE_CDMA_ANSWER, 120)
            handler.postDelayed({ tone.startTone(android.media.ToneGenerator.TONE_CDMA_ANSWER, 120) }, 180)
            handler.postDelayed({ tone.startTone(android.media.ToneGenerator.TONE_CDMA_ANSWER, 200) }, 360)
            handler.postDelayed({ tone.release() }, 650)
        } catch (_: Exception) {}
    }

    // Som de corrida registrada: 2 bips suaves + vibração
    private fun tocarSomRegistro() {
        try {
            val tone = android.media.ToneGenerator(android.media.AudioManager.STREAM_NOTIFICATION, 90)
            tone.startTone(android.media.ToneGenerator.TONE_CDMA_ANSWER, 150)
            handler.postDelayed({ tone.startTone(android.media.ToneGenerator.TONE_CDMA_ANSWER, 250) }, 220)
            handler.postDelayed({ tone.release() }, 560)
            try {
                val v = this.getSystemService(android.content.Context.VIBRATOR_SERVICE) as android.os.Vibrator
                v.vibrate(longArrayOf(0, 80, 60, 120), -1)
            } catch (_: Exception) {}
        } catch (_: Exception) {}
    }

    private fun tocarSomEspecial() {
        try {
            val tone = android.media.ToneGenerator(android.media.AudioManager.STREAM_NOTIFICATION, 100)
            tone.startTone(android.media.ToneGenerator.TONE_CDMA_ANSWER, 120)
            handler.postDelayed({ tone.startTone(android.media.ToneGenerator.TONE_CDMA_ANSWER, 120) }, 180)
            handler.postDelayed({ tone.startTone(android.media.ToneGenerator.TONE_CDMA_ANSWER, 120) }, 360)
            handler.postDelayed({ tone.startTone(android.media.ToneGenerator.TONE_CDMA_HIGH_L, 300) }, 540)
            handler.postDelayed({ tone.release() }, 950)
            try {
                val v = this.getSystemService(android.content.Context.VIBRATOR_SERVICE) as android.os.Vibrator
                v.vibrate(longArrayOf(0, 100, 60, 100), -1)
            } catch (_: Exception) {}
        } catch (_: Exception) {}
    }

    override fun onInterrupt() {}

    // ── Dados imutáveis da oferta ──
    data class DadosCorrida(
        val valor: Float, val kmBuscar: Float, val kmCorrida: Float,
        val origem: String = "", val destino: String = "",
        val formaPagamento: String = "", val passageiro: String = ""
    )

    // ── Dados mutáveis em memória durante a corrida ──
    data class DadosCorridaTemp(
        val valor: Float,           // estimativa da oferta
        val kmBuscar: Float,
        val kmCorrida: Float,
        val origem: String,
        val destino: String,
        val formaPagamento: String,
        var passageiro: String,
        val horaOferta: String,
        var horaInicio: String = "",    // quando começa a corrida
        var horaFim: String = "",       // quando finaliza
        var tempoExecucao: String = "", // capturado da tela de finalização
        var valorFinal: Float = 0f,     // valor real capturado na finalização
        var kmFinal: Float = 0f         // km real capturado na finalização
    )
}
