package com.fluxoapp

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class FluxoWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateWidget(context, mgr, it) }
    }

    companion object {
        fun updateWidget(context: Context, mgr: AppWidgetManager, id: Int) {
            val db = DatabaseHelper(context)
            val prefs = context.getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
            val corridas = db.buscarHoje()
            val resumo = db.resumo(corridas)
            val total = resumo["total"] ?: 0f
            val qtd = (resumo["corridas"] ?: 0f).toInt()
            val meta = prefs.getFloat("meta_diaria", 0f)
            val pct = if (meta > 0) ((total / meta) * 100).toInt().coerceIn(0, 100) else 0

            val views = RemoteViews(context.packageName, R.layout.widget_layout)
            views.setTextViewText(R.id.widgetGanho, "R$ ${"%.2f".format(total)}")
            views.setTextViewText(R.id.widgetCorridas, "$qtd corridas")
            views.setTextViewText(R.id.widgetMeta, if (meta > 0) "Meta: $pct%" else "")
            views.setProgressBar(R.id.widgetProgress, 100, pct, false)

            val intent = Intent(context, MainActivity::class.java)
            val pi = PendingIntent.getActivity(context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widgetRoot, pi)

            mgr.updateAppWidget(id, views)
        }
    }
}
