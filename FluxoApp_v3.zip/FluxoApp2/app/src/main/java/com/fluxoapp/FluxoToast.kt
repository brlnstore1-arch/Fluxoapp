package com.fluxoapp

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * FluxoToast — sistema de notificações visuais do FluxoApp.
 *
 * Substitui o Toast padrão do Android por um card animado,
 * com suporte a 5 tipos: SUCESSO, ERRO, AVISO, INFO, CELEBRAÇÃO.
 *
 * Uso:
 *   FluxoToast.sucesso(activity, "Corrida salva!")
 *   FluxoToast.erro(activity, "Valor inválido")
 *   FluxoToast.aviso(activity, "Permissão necessária")
 *   FluxoToast.info(activity, "Serviço ativado")
 *   FluxoToast.celebrar(activity, "META BATIDA! PARABÉNS! 🏆")
 */
object FluxoToast {

    enum class Tipo { SUCESSO, ERRO, AVISO, INFO, CELEBRACAO }

    private val handler = Handler(Looper.getMainLooper())
    private var toastAtivo: View? = null
    private var hideRunnable: Runnable? = null

    // ── API pública ──────────────────────────────────────────────────────

    fun sucesso(activity: Activity, msg: String, duracao: Long = 2800) =
        show(activity, msg, Tipo.SUCESSO, duracao)

    fun erro(activity: Activity, msg: String, duracao: Long = 3200) =
        show(activity, msg, Tipo.ERRO, duracao)

    fun aviso(activity: Activity, msg: String, duracao: Long = 3000) =
        show(activity, msg, Tipo.AVISO, duracao)

    fun info(activity: Activity, msg: String, duracao: Long = 2800) =
        show(activity, msg, Tipo.INFO, duracao)

    fun celebrar(activity: Activity, msg: String, duracao: Long = 3500) =
        show(activity, msg, Tipo.CELEBRACAO, duracao)

    // ── Implementação ────────────────────────────────────────────────────

    private fun show(activity: Activity, msg: String, tipo: Tipo, duracao: Long) {
        if (activity.isFinishing || activity.isDestroyed) return
        handler.post {
            try {
                // Remover toast anterior se existir
                esconder()

                val prefs = activity.getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
                val dp    = activity.resources.displayMetrics.density

                // ── Cores por tipo ──
                val (iconeTxt, corFundo, corBorda, corTexto) = when (tipo) {
                    Tipo.SUCESSO    -> Quad("✓",  "#1A2E1A", "#4CAF7D", ThemeHelper.cor("accent_green", prefs))
                    Tipo.ERRO       -> Quad("✕",  "#2E1A1A", "#E05C5C", Color.parseColor("#FF6B6B"))
                    Tipo.AVISO      -> Quad("!",  "#2E2410", "#C9A84C", Color.parseColor("#FFD166"))
                    Tipo.INFO       -> Quad("i",  "#0F1E36", "#00C8FF", Color.parseColor("#7DD4F0"))
                    Tipo.CELEBRACAO -> Quad("★",  "#1E1A0A", "#C9A84C", Color.parseColor("#FFD740"))
                }

                val accent = ThemeHelper.cor("accent", prefs)
                val bgCard = ThemeHelper.cor("bg_card", prefs)

                // ── Root container ──
                val root = FrameLayout(activity).apply {
                    layoutParams = FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.WRAP_CONTENT,
                        Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                    ).also {
                        val marginH = (20 * dp).toInt()
                        val marginB = (96 * dp).toInt() // acima da bottom nav
                        it.setMargins(marginH, 0, marginH, marginB)
                    }
                    elevation = 24 * dp
                    translationY = 120 * dp
                    alpha = 0f
                }

                // ── Card principal ──
                val card = LinearLayout(activity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity     = Gravity.CENTER_VERTICAL
                    setPadding(
                        (14 * dp).toInt(),
                        (12 * dp).toInt(),
                        (18 * dp).toInt(),
                        (12 * dp).toInt()
                    )
                    background = GradientDrawable().apply {
                        shape       = GradientDrawable.RECTANGLE
                        cornerRadius = 20 * dp
                        setColor(corFundo)
                        setStroke((1.5f * dp).toInt(), corBorda)
                    }
                    elevation = 12 * dp
                    layoutParams = FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.WRAP_CONTENT
                    )
                }

                // ── Ícone circular ──
                val iconeView = TextView(activity).apply {
                    text      = iconeTxt
                    textSize  = if (tipo == Tipo.CELEBRACAO) 14f else 13f
                    typeface  = android.graphics.Typeface.DEFAULT_BOLD
                    gravity   = Gravity.CENTER
                    setTextColor(corBorda)
                    layoutParams = LinearLayout.LayoutParams(
                        (32 * dp).toInt(),
                        (32 * dp).toInt()
                    ).also { it.marginEnd = (12 * dp).toInt() }
                    background = GradientDrawable().apply {
                        shape       = GradientDrawable.OVAL
                        cornerRadius = 16 * dp
                        setColor(adjustAlpha(corBorda, 0.18f))
                        setStroke((1 * dp).toInt(), adjustAlpha(corBorda, 0.4f))
                    }
                }

                // ── Texto da mensagem ──
                val textoView = TextView(activity).apply {
                    text     = msg
                    textSize = 13.5f
                    setTextColor(Color.parseColor("#F0EDE8"))
                    layoutParams = LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        1f
                    )
                    maxLines = 3
                    lineSpacingMultiplier = 1.2f
                }

                card.addView(iconeView)
                card.addView(textoView)

                // Linha de borda lateral colorida (destaque visual)
                val borda = View(activity).apply {
                    layoutParams = FrameLayout.LayoutParams(
                        (3 * dp).toInt(),
                        FrameLayout.LayoutParams.MATCH_PARENT
                    ).also { it.gravity = Gravity.START or Gravity.CENTER_VERTICAL }
                    background = GradientDrawable().apply {
                        shape       = GradientDrawable.RECTANGLE
                        cornerRadius = 20 * dp
                        setColor(corBorda)
                    }
                }

                // Envolver card em FrameLayout para a borda
                val wrapper = FrameLayout(activity).apply {
                    layoutParams = FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.WRAP_CONTENT
                    )
                }
                wrapper.addView(card)

                root.addView(wrapper)

                // ── Adicionar ao DecorView ──
                val decorView = activity.window.decorView as FrameLayout
                decorView.addView(root)
                toastAtivo = root

                // ── Animação de entrada ──
                val animY = ObjectAnimator.ofFloat(root, "translationY", 120 * dp, 0f).apply {
                    duration     = 380
                    interpolator = OvershootInterpolator(0.8f)
                }
                val animA = ObjectAnimator.ofFloat(root, "alpha", 0f, 1f).apply {
                    duration     = 280
                    interpolator = DecelerateInterpolator()
                }

                if (tipo == Tipo.CELEBRACAO) {
                    val animS = ObjectAnimator.ofFloat(root, "scaleX", 0.85f, 1f).apply { duration = 380; interpolator = OvershootInterpolator(1.2f) }
                    val animSY = ObjectAnimator.ofFloat(root, "scaleY", 0.85f, 1f).apply { duration = 380; interpolator = OvershootInterpolator(1.2f) }
                    AnimatorSet().apply { playTogether(animY, animA, animS, animSY); start() }
                } else {
                    AnimatorSet().apply { playTogether(animY, animA); start() }
                }

                // ── Auto-fechar ──
                val hideR = Runnable { esconderAnimado(root, decorView) }
                hideRunnable = hideR
                handler.postDelayed(hideR, duracao)

                // Fechar ao toque
                root.setOnClickListener { esconderAnimado(root, decorView) }

            } catch (_: Throwable) {
                // Fallback para toast padrão se algo der errado
                android.widget.Toast.makeText(activity, msg, android.widget.Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun esconder() {
        hideRunnable?.let { handler.removeCallbacks(it) }
        hideRunnable = null
        toastAtivo?.let { v ->
            try {
                val parent = v.parent as? ViewGroup
                parent?.removeView(v)
            } catch (_: Throwable) {}
        }
        toastAtivo = null
    }

    private fun esconderAnimado(view: View, parent: ViewGroup) {
        if (view.parent == null) return
        val dp = view.context.resources.displayMetrics.density
        AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(view, "translationY", 0f, 80 * dp).apply { duration = 260 },
                ObjectAnimator.ofFloat(view, "alpha", 1f, 0f).apply { duration = 220 }
            )
            start()
        }
        handler.postDelayed({
            try { parent.removeView(view) } catch (_: Throwable) {}
            if (toastAtivo === view) toastAtivo = null
        }, 280)
    }

    private fun adjustAlpha(color: Int, factor: Float): Int {
        val a = Math.round(Color.alpha(color) * factor)
        return Color.argb(a, Color.red(color), Color.green(color), Color.blue(color))
    }

    // Kotlin data class simples para 4 valores
    private data class Quad<A, B, C, D>(val a: A, val b: B, val c: C, val d: D)
    private operator fun <A, B, C, D> Quad<A, B, C, D>.component1() = a
    private operator fun <A, B, C, D> Quad<A, B, C, D>.component2() = b
    private operator fun <A, B, C, D> Quad<A, B, C, D>.component3() = c
    private operator fun <A, B, C, D> Quad<A, B, C, D>.component4() = d
}
