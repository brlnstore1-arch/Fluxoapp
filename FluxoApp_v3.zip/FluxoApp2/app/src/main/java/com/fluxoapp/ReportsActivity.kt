package com.fluxoapp

import android.content.Intent
import android.graphics.*
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.github.mikephil.charting.formatter.ValueFormatter
import java.io.File
import java.io.FileOutputStream
import java.util.Calendar
import kotlin.math.roundToInt

class ReportsActivity : AppCompatActivity() {
    private lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reports)
        db = DatabaseHelper(this)
        aplicarTema()
        aplicarTemaGlobal()
        findViewById<ImageButton>(R.id.btnVoltar).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnCompartilhar).setOnClickListener {
            try { compartilharResultado() } catch (e: Exception) {
                Toast.makeText(this, "Erro ao compartilhar: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
        try { gerarRelatorio() } catch (e: Exception) { e.printStackTrace() }
    }

    private fun gerarRelatorio() {
        val todas = db.buscarTodas()
        val hoje = db.buscarHoje()
        val semana = db.buscarSemana()
        val cal = Calendar.getInstance()
        val mes = db.buscarMes(cal.get(Calendar.MONTH), cal.get(Calendar.YEAR))
        val rHoje = db.resumo(hoje); val rSemana = db.resumo(semana)
        val rMes = db.resumo(mes); val rTodas = db.resumo(todas)

        findViewById<TextView>(R.id.tvRelatorioResumo)?.text = buildString {
            append("HOJE\n  R$ ${"%.2f".format(rHoje["total"])} em ${(rHoje["corridas"]?:0f).toInt()} corridas\n\n")
            append("ESTA SEMANA\n  R$ ${"%.2f".format(rSemana["total"])} em ${(rSemana["corridas"]?:0f).toInt()} corridas\n\n")
            append("ESTE MES\n  R$ ${"%.2f".format(rMes["total"])} em ${(rMes["corridas"]?:0f).toInt()} corridas\n\n")
            append("GERAL\n  Total: R$ ${"%.2f".format(rTodas["total"])}\n")
            append("  Corridas: ${(rTodas["corridas"]?:0f).toInt()}\n")
            append("  Media/km: R$ ${"%.2f".format(rTodas["media_km"])}")
        }

        try { configurarGraficoHoras(todas) } catch (_: Exception) {}
        try { configurarGraficoDias(todas) } catch (_: Exception) {}
        try { configurarComparativo() } catch (_: Exception) {}
        try { configurarPrevisao(mes, cal) } catch (_: Exception) {}
        try { configurarBairros(todas) } catch (_: Exception) {}
        try { configurarDicas(todas) } catch (_: Exception) {}
    }

    private fun configurarGraficoHoras(corridas: List<Corrida>) {
        val chart = findViewById<LineChart>(R.id.chartHoras) ?: return
        val ganhos = Array(24) { 0f }
        corridas.forEach { c ->
            val h = c.hora.split(":").firstOrNull()?.toIntOrNull() ?: return@forEach
            ganhos[h] += c.valor
        }
        val entries = ganhos.indices.map { Entry(it.toFloat(), ganhos[it]) }
        val dataset = LineDataSet(entries, "R$/hora").apply {
            color = Color.parseColor("#C9A84C"); setCircleColor(Color.parseColor("#C9A84C"))
            lineWidth = 2.5f; circleRadius = 3f; setDrawFilled(true)
            fillColor = Color.parseColor("#C9A84C"); fillAlpha = 40
            mode = LineDataSet.Mode.CUBIC_BEZIER; setDrawValues(false)
        }
        chart.apply {
            data = LineData(dataset); description.isEnabled = false; legend.isEnabled = false
            setBackgroundColor(Color.parseColor("#16161F"))
            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM; textColor = Color.parseColor("#6B6B80")
                textSize = 9f; granularity = 1f; setDrawGridLines(false)
                valueFormatter = object : ValueFormatter() { override fun getFormattedValue(v: Float) = "${v.toInt()}h" }
            }
            axisLeft.apply {
                textColor = Color.parseColor("#6B6B80"); textSize = 9f
                gridColor = Color.parseColor("#2A2A3A")
                valueFormatter = object : ValueFormatter() { override fun getFormattedValue(v: Float) = "R$${"%.0f".format(v)}" }
            }
            axisRight.isEnabled = false; setTouchEnabled(true); setScaleEnabled(false); animateX(800); invalidate()
        }
        val melhorHora = ganhos.indices.maxByOrNull { ganhos[it] } ?: 0
        findViewById<TextView>(R.id.tvMelhorHora)?.text =
            if (ganhos[melhorHora] > 0) "Pico: ${melhorHora}h-${melhorHora+1}h  |  R$ ${"%.2f".format(ganhos[melhorHora])}"
            else "Faca corridas para ver o horario de pico"
    }

    private fun configurarGraficoDias(corridas: List<Corrida>) {
        val chart = findViewById<BarChart>(R.id.chartDias) ?: return
        val labels = arrayOf("Dom","Seg","Ter","Qua","Qui","Sex","Sab")
        val ganhos = Array(7) { 0f }
        corridas.forEach { c ->
            try {
                val sdf = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault())
                val d = sdf.parse(c.data) ?: return@forEach
                val cal = Calendar.getInstance().apply { time = d }
                ganhos[cal.get(Calendar.DAY_OF_WEEK) - 1] += c.valor
            } catch (_: Exception) {}
        }
        val maxGanho = ganhos.maxOrNull() ?: 0f
        val entries = ganhos.indices.map { BarEntry(it.toFloat(), ganhos[it]) }
        val cores = ganhos.map { if (it == maxGanho && it > 0) Color.parseColor("#00E676") else Color.parseColor("#C9A84C") }
        val dataset = BarDataSet(entries, "Ganho/dia").apply {
            colors = cores; valueTextColor = Color.parseColor("#9090A8"); valueTextSize = 9f
            valueFormatter = object : ValueFormatter() { override fun getFormattedValue(v: Float) = if (v > 0) "R$${"%.0f".format(v)}" else "" }
        }
        chart.apply {
            data = BarData(dataset).apply { barWidth = 0.6f }; description.isEnabled = false; legend.isEnabled = false
            setBackgroundColor(Color.parseColor("#16161F"))
            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM; textColor = Color.parseColor("#6B6B80")
                textSize = 10f; granularity = 1f; setDrawGridLines(false)
                valueFormatter = IndexAxisValueFormatter(labels)
            }
            axisLeft.apply {
                textColor = Color.parseColor("#6B6B80"); gridColor = Color.parseColor("#2A2A3A")
                valueFormatter = object : ValueFormatter() { override fun getFormattedValue(v: Float) = "R$${"%.0f".format(v)}" }
            }
            axisRight.isEnabled = false; setTouchEnabled(false); animateY(800); invalidate()
        }
        val melhorDia = ganhos.indices.maxByOrNull { ganhos[it] } ?: 0
        val nomes = arrayOf("Domingo","Segunda","Terca","Quarta","Quinta","Sexta","Sabado")
        findViewById<TextView>(R.id.tvMelhorDia)?.text =
            if (ganhos[melhorDia] > 0) "Melhor dia: ${nomes[melhorDia]}" else "Faca corridas para ver o melhor dia"
    }

    private fun configurarComparativo() {
        val calIni = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_WEEK, firstDayOfWeek)
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val inicioSemana = calIni.timeInMillis
        val inicioAnterior = inicioSemana - 7 * 24 * 60 * 60 * 1000L
        val atual = db.resumo(db.buscarPorPeriodo(inicioSemana, System.currentTimeMillis()))["total"] ?: 0f
        val anterior = db.resumo(db.buscarPorPeriodo(inicioAnterior, inicioSemana - 1))["total"] ?: 0f
        val diff = if (anterior > 0) ((atual - anterior) / anterior * 100).roundToInt() else 0
        val sinal = if (diff >= 0) "+" else ""
        findViewById<TextView>(R.id.tvComparativo)?.text = buildString {
            append("SEMANA ATUAL: R$ ${"%.2f".format(atual)}\n")
            append("SEMANA ANTERIOR: R$ ${"%.2f".format(anterior)}\n")
            if (anterior > 0) append("\nVariacao: $sinal$diff%")
            else append("\nPrimeira semana registrada!")
        }
    }

    private fun configurarPrevisao(mes: List<Corrida>, cal: Calendar) {
        val totalMes = db.resumo(mes)["total"] ?: 0f
        val diaAtual = cal.get(Calendar.DAY_OF_MONTH)
        val diasNoMes = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val mediaDiaria = if (diaAtual > 0) totalMes / diaAtual else 0f
        val previsao = mediaDiaria * diasNoMes
        val diasRestantes = diasNoMes - diaAtual
        findViewById<TextView>(R.id.tvPrevisao)?.text = buildString {
            append("PREVISAO PARA O MES\n\n")
            append("Ja ganhou: R$ ${"%.2f".format(totalMes)}\n")
            append("Media diaria: R$ ${"%.2f".format(mediaDiaria)}\n")
            append("Dias restantes: $diasRestantes\n")
            append("Previsao total: R$ ${"%.2f".format(previsao)}")
        }
        val pct = if (diasNoMes > 0) ((diaAtual.toFloat() / diasNoMes) * 100).toInt() else 0
        findViewById<ProgressBar>(R.id.progressPrevisao)?.progress = pct.coerceIn(0, 100)
        findViewById<TextView>(R.id.tvProgressPrevisao)?.text = "Dia $diaAtual de $diasNoMes ($pct% do mes)"
    }

    private fun configurarBairros(corridas: List<Corrida>) {
        val mapa = mutableMapOf<String, Pair<Float, Int>>()
        corridas.forEach { c ->
            val dest = c.destino.trim()
            if (dest.length > 3) {
                val atual = mapa[dest] ?: Pair(0f, 0)
                mapa[dest] = Pair(atual.first + c.valor, atual.second + 1)
            }
        }
        val tv = findViewById<TextView>(R.id.tvBairros)
        if (mapa.isEmpty()) { tv?.text = "Ainda sem dados de destinos.\nFaca corridas para ver o ranking!"; return }
        val top = mapa.entries.sortedByDescending { it.value.first }.take(5)
        tv?.text = buildString {
            append("TOP DESTINOS MAIS RENTAVEIS\n\n")
            top.forEachIndexed { i, (bairro, dados) ->
                val medal = when(i) { 0 -> "1o"; 1 -> "2o"; 2 -> "3o"; else -> "${i+1}." }
                val media = if (dados.second > 0) dados.first / dados.second else 0f
                append("$medal $bairro\n   R$ ${"%.2f".format(dados.first)} | ${dados.second} corrida(s) | R$ ${"%.2f".format(media)} media\n\n")
            }
        }
    }

    private fun configurarDicas(corridas: List<Corrida>) {
        val tv = findViewById<TextView>(R.id.tvDicas)
        if (corridas.size < 5) { tv?.text = "Faca pelo menos 5 corridas para receber dicas personalizadas!"; return }
        val dicas = mutableListOf<String>()
        val ganhosPorHora = Array(24) { 0f }; val qtdPorHora = Array(24) { 0 }
        corridas.forEach { c ->
            val h = c.hora.split(":").firstOrNull()?.toIntOrNull() ?: return@forEach
            ganhosPorHora[h] += c.valor; qtdPorHora[h]++
        }
        val mediaPorHora = ganhosPorHora.indices.map { if (qtdPorHora[it] > 0) ganhosPorHora[it] / qtdPorHora[it] else 0f }
        val mediaGeral = corridas.sumOf { it.valor.toDouble() }.toFloat() / corridas.size
        val melhorHora = mediaPorHora.indices.maxByOrNull { mediaPorHora[it] } ?: 0
        if (mediaPorHora[melhorHora] > mediaGeral * 1.2f)
            dicas.add("Voce ganha ${"%.0f".format((mediaPorHora[melhorHora]/mediaGeral-1)*100)}% mais entre ${melhorHora}h e ${melhorHora+1}h!")
        val taxa = corridas.count { it.valeAPena }.toFloat() / corridas.size * 100
        if (taxa < 50) dicas.add("So ${"%.0f".format(taxa)}% das corridas valem a pena. Considere aumentar o minimo.")
        else if (taxa > 85) dicas.add("${"%.0f".format(taxa)}% das corridas valem a pena. Seu minimo esta bem calibrado!")
        val melhorCorrida = corridas.maxByOrNull { it.valor }
        if (melhorCorrida != null) dicas.add("Sua melhor corrida foi R$ ${"%.2f".format(melhorCorrida.valor)} em ${melhorCorrida.data}!")
        tv?.text = if (dicas.isEmpty()) "Continue fazendo corridas para receber dicas!" else dicas.joinToString("\n\n")
    }

    private fun compartilharResultado() {
        val corridas = db.buscarHoje()
        val resumo = db.resumo(corridas)
        val total = resumo["total"] ?: 0f
        val qtd = (resumo["corridas"] ?: 0f).toInt()
        val mediaKm = resumo["media_km"] ?: 0f
        val w = 900; val h = 500
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val bgPaint = Paint().apply {
            shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(),
                Color.parseColor("#0A0A0F"), Color.parseColor("#16161F"), Shader.TileMode.CLAMP)
        }
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bgPaint)
        canvas.drawRoundRect(4f, 4f, w-4f, h-4f, 24f, 24f, Paint().apply {
            style = Paint.Style.STROKE; color = Color.parseColor("#C9A84C"); strokeWidth = 4f
        })
        canvas.drawText("FLUXOAPP", 40f, 42f, Paint().apply { color = Color.parseColor("#C9A84C"); textSize = 28f; isFakeBoldText = true; isAntiAlias = true })
        val hoje = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(java.util.Date())
        canvas.drawText(hoje, w-180f, 42f, Paint().apply { color = Color.parseColor("#6B6B80"); textSize = 20f; isAntiAlias = true })
        canvas.drawLine(0f, 60f, w.toFloat(), 60f, Paint().apply {
            shader = LinearGradient(0f,0f,w.toFloat(),0f, Color.TRANSPARENT, Color.parseColor("#C9A84C"), Shader.TileMode.CLAMP)
            strokeWidth = 3f; style = Paint.Style.STROKE
        })
        canvas.drawText("R$ ${"%.2f".format(total)}", 40f, 200f, Paint().apply {
            shader = LinearGradient(0f,0f,0f,200f, Color.parseColor("#00E676"), Color.parseColor("#C9A84C"), Shader.TileMode.CLAMP)
            textSize = 96f; isFakeBoldText = true; isAntiAlias = true
        })
        canvas.drawText("GANHO DO DIA", 40f, 235f, Paint().apply { color = Color.parseColor("#9090A8"); textSize = 22f; isAntiAlias = true })
        canvas.drawLine(40f, 270f, w-40f, 270f, Paint().apply { color = Color.parseColor("#2A2A3A"); strokeWidth = 1f })
        val stP = Paint().apply { color = Color.parseColor("#6B6B80"); textSize = 18f; isAntiAlias = true }
        val svP = Paint().apply { color = Color.parseColor("#F0F0F5"); textSize = 26f; isFakeBoldText = true; isAntiAlias = true }
        canvas.drawText("CORRIDAS", 40f, 320f, stP); canvas.drawText("$qtd", 40f, 355f, svP)
        canvas.drawText("MEDIA/KM", 250f, 320f, stP); canvas.drawText("R$ ${"%.2f".format(mediaKm)}", 250f, 355f, svP)
        val boas = corridas.count { it.valeAPena }
        val taxa = if (qtd > 0) (boas * 100 / qtd) else 0
        canvas.drawText("APROVEITAMENTO", 480f, 320f, stP); canvas.drawText("$taxa%", 480f, 355f, svP)
        canvas.drawRoundRect(40f, 380f, w-40f, 398f, 8f, 8f, Paint().apply { color = Color.parseColor("#2A2A3A") })
        if (taxa > 0) canvas.drawRoundRect(40f, 380f, (40+(w-80)*taxa/100).toFloat(), 398f, 8f, 8f, Paint().apply {
            shader = LinearGradient(40f,0f,(40+(w-80)*taxa/100).toFloat(),0f, Color.parseColor("#00E676"), Color.parseColor("#C9A84C"), Shader.TileMode.CLAMP)
        })
        canvas.drawText("Gerado pelo FluxoApp | Motorista Taxsee/Maxim", 40f, h-20f, Paint().apply { color = Color.parseColor("#2A2A3A"); textSize = 16f; isAntiAlias = true })

        val file = File(cacheDir, "resultado_fluxoapp.png")
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.provider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"; putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, "Meu resultado de hoje no Taxsee/Maxim!\nGerado pelo FluxoApp")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Compartilhar resultado"))
    }

    private fun aplicarTema() {
        val p  = getSharedPreferences("FluxoApp", android.content.Context.MODE_PRIVATE)
        val bg     = ThemeHelper.cor("bg_dark",    p)
        val bgCard = ThemeHelper.cor("bg_card",    p)
        val accent = ThemeHelper.cor("accent_gold", p)
        val green  = ThemeHelper.cor("accent_green", p)
        val gold   = ThemeHelper.cor("accent_gold", p)
        val txtW   = ThemeHelper.cor("text_white",  p)
        val toolbar= ThemeHelper.cor("toolbar",     p)
        val dp = resources.displayMetrics.density
        fun gd(cor: Int) = android.graphics.drawable.GradientDrawable().apply {
            setColor(cor); cornerRadius = 12f * dp
        }
        try { findViewById<android.view.View>(R.id.rootLayout)?.setBackgroundColor(bg) } catch (_: Exception) {}
        try { findViewById<android.widget.ImageButton>(R.id.btnVoltar)?.setColorFilter(accent) } catch (_: Exception) {}
        for (id in listOf(R.id.tvRelatorioResumo, R.id.tvComparativo, R.id.tvPrevisao, R.id.tvBairros, R.id.tvDicas)) {
            try { findViewById<android.widget.TextView>(id)?.apply {
                background = gd(bgCard); setTextColor(txtW)
            }} catch (_: Exception) {}
        }
        try { findViewById<android.widget.TextView>(R.id.tvMelhorHora)?.setTextColor(gold) } catch (_: Exception) {}
        try { findViewById<android.widget.TextView>(R.id.tvMelhorDia)?.setTextColor(green) } catch (_: Exception) {}
        try { findViewById<android.widget.TextView>(R.id.tvComparativo)?.setTextColor(green) } catch (_: Exception) {}
        try {
            val cl = android.content.res.ColorStateList.valueOf(accent)
            findViewById<android.widget.ProgressBar>(R.id.progressPrevisao)?.progressTintList = cl
        } catch (_: Exception) {}

        // Botão compartilhar — sólido com cor do tema
        try {
            findViewById<android.widget.Button>(R.id.btnCompartilhar)?.apply {
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(accent); cornerRadius = 10f * dp
                }
                setTextColor(android.graphics.Color.BLACK)
            }
        } catch (_: Exception) {}

        // Títulos de seção — cor do tema
        for (id in listOf(
            R.id.tvTituloHoras, R.id.tvTituloDias, R.id.tvTituloComparativo,
            R.id.tvTituloPrevisao, R.id.tvTituloBairros, R.id.tvTituloDicas
        )) {
            try { findViewById<android.widget.TextView>(id)?.setTextColor(accent) } catch (_: Exception) {}
        }
    }
}
