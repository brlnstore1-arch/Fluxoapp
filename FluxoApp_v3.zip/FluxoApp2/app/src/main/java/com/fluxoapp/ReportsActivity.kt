package com.fluxoapp

import android.content.Intent
import android.graphics.*
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.github.mikephil.charting.formatter.ValueFormatter
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

class ReportsActivity : AppCompatActivity() {
    private lateinit var db: DatabaseHelper
    // FIX: SimpleDateFormat NÃO é thread-safe — criar instâncias locais em cada uso
    private fun sdfData()    = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    private fun sdfDisplay() = SimpleDateFormat("dd/MM/yyyy EEE", Locale("pt","BR"))

    // Calendário para navegação do gráfico de horas
    private val calHoras = Calendar.getInstance()

    override fun attachBaseContext(base: android.content.Context) {
        super.attachBaseContext(FontHelper.wrap(base))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeSelector.aplicar(this)
        setContentView(R.layout.activity_reports)
        db = DatabaseHelper(this)
        aplicarTema()
        aplicarTemaGlobal()

        findViewById<ImageButton>(R.id.btnVoltar).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnCompartilhar).setOnClickListener {
            try { compartilharResultado() } catch (e: Throwable) {
                FluxoToast.erro(this, "Erro ao compartilhar: ${e.message}")
            }
        }

        // Seletor de data para gráfico de horas
        configurarSeletorDataHoras()
        BottomNavHelper.configurar(this, BottomNavHelper.ABA_RELATORIOS)

        Thread {
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                try { gerarRelatorio() } catch (_: Throwable) {}
            }
        }.start()
    }

    // ── SELETOR DE DATA PARA GRÁFICO DE HORAS ──────────────────
    private fun configurarSeletorDataHoras() {
        atualizarLabelDataHoras()

        findViewById<ImageButton>(R.id.btnDiaAnteriorHoras)?.setOnClickListener {
            calHoras.add(Calendar.DAY_OF_YEAR, -1)
            atualizarLabelDataHoras()
            atualizarGraficoHoras()
        }
        findViewById<ImageButton>(R.id.btnDiaProximoHoras)?.setOnClickListener {
            val hoje = Calendar.getInstance()
            if (!isMesmoDia(calHoras, hoje)) {
                calHoras.add(Calendar.DAY_OF_YEAR, 1)
                atualizarLabelDataHoras()
                atualizarGraficoHoras()
            }
        }
        // Clique longo na label → DatePicker
        findViewById<TextView>(R.id.tvDataHoras)?.setOnLongClickListener {
            android.app.DatePickerDialog(this, { _, ano, mes, dia ->
                calHoras.set(ano, mes, dia)
                atualizarLabelDataHoras()
                atualizarGraficoHoras()
            }, calHoras.get(Calendar.YEAR), calHoras.get(Calendar.MONTH),
               calHoras.get(Calendar.DAY_OF_MONTH)).show()
            true
        }

        // Bloquear botão próximo se já é hoje
        atualizarBotaoProximo()
    }

    private fun atualizarLabelDataHoras() {
        val hoje  = Calendar.getInstance()
        val ontem = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
        val label = when {
            isMesmoDia(calHoras, hoje)  -> "HOJE · ${sdfDisplay().format(calHoras.time).uppercase()}"
            isMesmoDia(calHoras, ontem) -> "ONTEM · ${sdfDisplay().format(calHoras.time).uppercase()}"
            else -> sdfDisplay().format(calHoras.time).uppercase()
        }
        findViewById<TextView>(R.id.tvDataHoras)?.text = label
        atualizarBotaoProximo()
    }

    private fun atualizarBotaoProximo() {
        val hoje = Calendar.getInstance()
        val ehHoje = isMesmoDia(calHoras, hoje)
        try {
            findViewById<ImageButton>(R.id.btnDiaProximoHoras)?.alpha = if (ehHoje) 0.3f else 1.0f
            findViewById<ImageButton>(R.id.btnDiaProximoHoras)?.isEnabled = !ehHoje
        } catch (_: Throwable) {}
    }

    private fun atualizarGraficoHoras() {
        val prefs = getSharedPreferences("FluxoApp", android.content.Context.MODE_PRIVATE)
        val accentHex = "#%06X".format(0xFFFFFF and ThemeHelper.cor("accent_gold", prefs))
        val bgHex     = "#%06X".format(0xFFFFFF and ThemeHelper.cor("bg_card", prefs))
        val txtHex    = "#%06X".format(0xFFFFFF and ThemeHelper.cor("text_gray", prefs))
        val corridas  = db.buscarDia(
            calHoras.get(Calendar.YEAR),
            calHoras.get(Calendar.MONTH),
            calHoras.get(Calendar.DAY_OF_MONTH)
        )
        configurarGraficoHoras(corridas, accentHex, bgHex, txtHex)
    }

    private fun isMesmoDia(a: Calendar, b: Calendar) =
        a.get(Calendar.YEAR) == b.get(Calendar.YEAR) &&
        a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)

    // ── RELATÓRIO PRINCIPAL ────────────────────────────────────
    private fun gerarRelatorio() {
        val prefs = getSharedPreferences("FluxoApp", android.content.Context.MODE_PRIVATE)
        val accentHex = "#%06X".format(0xFFFFFF and ThemeHelper.cor("accent_gold", prefs))
        val bgHex     = "#%06X".format(0xFFFFFF and ThemeHelper.cor("bg_card", prefs))
        val txtHex    = "#%06X".format(0xFFFFFF and ThemeHelper.cor("text_gray", prefs))

        val todas  = db.buscarTodas()
        val hoje   = db.buscarHoje()
        val semana = db.buscarSemana()
        val cal    = Calendar.getInstance()
        val mes    = db.buscarMes(cal.get(Calendar.MONTH), cal.get(Calendar.YEAR))
        val rHoje  = db.resumo(hoje); val rSemana = db.resumo(semana)
        val rMes   = db.resumo(mes);  val rTodas  = db.resumo(todas)

        // Resumo por período
        findViewById<TextView>(R.id.tvRelatorioResumo)?.text = buildString {
            append("HOJE\n  R$ ${"%.2f".format(rHoje["total"])} em ${(rHoje["corridas"]?:0f).toInt()} corridas\n\n")
            append("ESTA SEMANA\n  R$ ${"%.2f".format(rSemana["total"])} em ${(rSemana["corridas"]?:0f).toInt()} corridas\n\n")
            append("ESTE MÊS\n  R$ ${"%.2f".format(rMes["total"])} em ${(rMes["corridas"]?:0f).toInt()} corridas\n\n")
            append("GERAL\n  Total: R$ ${"%.2f".format(rTodas["total"])}\n")
            append("  Corridas: ${(rTodas["corridas"]?:0f).toInt()}\n")
            append("  Média/km: R$ ${"%.2f".format(rTodas["media_km"])}")
        }

        // Gráfico de horas — dia selecionado (padrão = hoje)
        val corridasHoje = db.buscarDia(
            calHoras.get(Calendar.YEAR),
            calHoras.get(Calendar.MONTH),
            calHoras.get(Calendar.DAY_OF_MONTH)
        )
        try { configurarGraficoHoras(corridasHoje, accentHex, bgHex, txtHex) } catch (_: Throwable) {}

        // Demais análises com todas as corridas
        try { configurarGraficoDias(todas, accentHex, bgHex, txtHex) }   catch (_: Throwable) {}
        try { configurarComparativo() }                                    catch (_: Throwable) {}
        try { configurarGraficoMeses(todas, accentHex, bgHex, txtHex) }  catch (_: Throwable) {}
        try { configurarPrevisao(mes, cal) }                              catch (_: Throwable) {}
        try { configurarBairros(todas) }                                  catch (_: Throwable) {}
        try { configurarDicas(todas) }                                    catch (_: Throwable) {}
    }

    // ── GRÁFICO 1: GANHOS POR HORÁRIO (DIA ESPECÍFICO) ─────────
    private fun configurarGraficoHoras(
        corridas: List<Corrida>,
        accentHex: String = "#C9A84C",
        bgHex: String = "#16161F",
        txtHex: String = "#6B6B80"
    ) {
        val chart = findViewById<LineChart>(R.id.chartHoras) ?: return
        val ganhos = Array(24) { 0f }
        corridas.forEach { c ->
            val h = c.hora.split(":").firstOrNull()?.toIntOrNull() ?: return@forEach
            if (h in 0..23) ganhos[h] += c.valor
        }
        val entries = ganhos.indices.map { Entry(it.toFloat(), ganhos[it]) }
        val dataset = LineDataSet(entries, "R$/hora").apply {
            color = Color.parseColor(accentHex); setCircleColor(Color.parseColor(accentHex))
            lineWidth = 2.5f; circleRadius = 3f; setDrawFilled(true)
            fillColor = Color.parseColor(accentHex); fillAlpha = 40
            mode = LineDataSet.Mode.CUBIC_BEZIER; setDrawValues(false)
        }
        chart.apply {
            data = LineData(dataset); description.isEnabled = false; legend.isEnabled = false
            setBackgroundColor(Color.parseColor(bgHex))
            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM; textColor = Color.parseColor(txtHex)
                textSize = 9f; granularity = 1f; setDrawGridLines(false)
                valueFormatter = object : ValueFormatter() {
                    override fun getFormattedValue(v: Float) = "${v.toInt()}h"
                }
            }
            axisLeft.apply {
                textColor = Color.parseColor(txtHex); textSize = 9f
                gridColor = Color.parseColor("#2A2A3A")
                valueFormatter = object : ValueFormatter() {
                    override fun getFormattedValue(v: Float) = "R$${"%.0f".format(v)}"
                }
            }
            axisRight.isEnabled = false
            setTouchEnabled(true); setScaleEnabled(false); animateX(600); invalidate()
        }

        val temDados = ganhos.any { it > 0 }
        val melhorHora = if (temDados) ganhos.indices.maxByOrNull { ganhos[it] } ?: 0 else -1
        val dataLabel = sdfData().format(calHoras.time)
        findViewById<TextView>(R.id.tvMelhorHora)?.text = when {
            !temDados -> "Sem corridas em $dataLabel"
            melhorHora >= 0 -> "Pico: ${melhorHora}h-${melhorHora+1}h  |  R$ ${"%.2f".format(ganhos[melhorHora])}"
            else -> ""
        }
    }

    // ── GRÁFICO 2: GANHOS POR DIA DA SEMANA ATUAL ─────────────
    // Mostra os ganhos REAIS de cada dia na semana corrente
    private fun configurarGraficoDias(
        todasCorridas: List<Corrida>,
        accentHex: String = "#C9A84C",
        bgHex: String = "#16161F",
        txtHex: String = "#6B6B80"
    ) {
        val chart = findViewById<BarChart>(R.id.chartDias) ?: return
        val labels = arrayOf("Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sab")
        val nomes  = arrayOf("Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado")

        // Calcular início e fim da semana atual
        val calIni = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_WEEK, firstDayOfWeek)
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val calFim = calIni.clone() as Calendar
        calFim.add(Calendar.DAY_OF_YEAR, 6)
        calFim.set(Calendar.HOUR_OF_DAY, 23); calFim.set(Calendar.MINUTE, 59)
        calFim.set(Calendar.SECOND, 59)

        val sdf = sdfData()
        val iniTs = calIni.timeInMillis
        val fimTs = calFim.timeInMillis

        // Filtrar corridas da semana atual e somar por dia
        val ganhosPorDia = Array(7) { 0f }
        todasCorridas.forEach { c ->
            try {
                val d = sdf.parse(c.data) ?: return@forEach
                val cal = Calendar.getInstance().apply { time = d }
                if (cal.timeInMillis in iniTs..fimTs) {
                    val diaSemana = cal.get(Calendar.DAY_OF_WEEK) - 1 // 0=Dom..6=Sab
                    ganhosPorDia[diaSemana] += c.valor
                }
            } catch (_: Throwable) {}
        }

        // Se semana atual não tem dados, buscar a semana mais recente com dados
        val temDadosSemanaAtual = ganhosPorDia.any { it > 0 }
        val ganhosMostrar: Array<Float>
        val labelSemana: String
        val sdfCurto = SimpleDateFormat("dd/MM", Locale.getDefault())

        if (temDadosSemanaAtual) {
            ganhosMostrar = ganhosPorDia
            labelSemana = "${sdfCurto.format(calIni.time)} – ${sdfCurto.format(calFim.time)}"
        } else {
            // Buscar semana anterior com dados
            val calIniAnt = calIni.clone() as Calendar
            calIniAnt.add(Calendar.DAY_OF_YEAR, -7)
            val calFimAnt = calFim.clone() as Calendar
            calFimAnt.add(Calendar.DAY_OF_YEAR, -7)
            val iniAntTs  = calIniAnt.timeInMillis
            val fimAntTs  = calFimAnt.timeInMillis
            val ganhosAnt = Array(7) { 0f }
            todasCorridas.forEach { c ->
                try {
                    val d = sdf.parse(c.data) ?: return@forEach
                    val cal = Calendar.getInstance().apply { time = d }
                    if (cal.timeInMillis in iniAntTs..fimAntTs) {
                        ganhosAnt[cal.get(Calendar.DAY_OF_WEEK) - 1] += c.valor
                    }
                } catch (_: Throwable) {}
            }
            ganhosMostrar = ganhosAnt
            labelSemana = "${sdfCurto.format(calIniAnt.time)} – ${sdfCurto.format(calFimAnt.time)}"
        }

        val maxGanho = ganhosMostrar.maxOrNull() ?: 0f
        val entries = ganhosMostrar.indices.map { BarEntry(it.toFloat(), ganhosMostrar[it]) }
        val cores = ganhosMostrar.map {
            if (it == maxGanho && it > 0) Color.parseColor("#00E676")
            else Color.parseColor(accentHex)
        }

        val dataset = BarDataSet(entries, "Ganho/dia").apply {
            colors = cores
            valueTextColor = Color.parseColor(txtHex)
            valueTextSize = 9f
            valueFormatter = object : ValueFormatter() {
                override fun getFormattedValue(v: Float) =
                    if (v > 0) "R$${"%.0f".format(v)}" else ""
            }
        }

        chart.apply {
            data = BarData(dataset).apply { barWidth = 0.6f }
            description.isEnabled = false; legend.isEnabled = false
            setBackgroundColor(Color.parseColor(bgHex))
            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                textColor = Color.parseColor(txtHex)
                textSize = 10f; granularity = 1f; setDrawGridLines(false)
                valueFormatter = IndexAxisValueFormatter(labels)
            }
            axisLeft.apply {
                textColor = Color.parseColor(txtHex)
                gridColor = Color.parseColor("#2A2A3A")
                valueFormatter = object : ValueFormatter() {
                    override fun getFormattedValue(v: Float) = "R$${"%.0f".format(v)}"
                }
            }
            axisRight.isEnabled = false; setTouchEnabled(false); animateY(800); invalidate()
        }

        // Subtítulo e label do melhor dia
        val semLabel = if (temDadosSemanaAtual) "Semana atual · $labelSemana" else "Semana anterior · $labelSemana"
        try { findViewById<TextView>(R.id.tvSubtituloDias)?.text = semLabel } catch (_: Throwable) {}

        val melhorIdx = ganhosMostrar.indices.maxByOrNull { ganhosMostrar[it] } ?: 0
        val totalSemana = ganhosMostrar.sum()
        val textoMelhor = if (ganhosMostrar.any { it > 0 })
            "Melhor: ${nomes[melhorIdx]}  ·  R$${"%.2f".format(ganhosMostrar[melhorIdx])}  ·  Total semana: R$${"%.2f".format(totalSemana)}"
        else "Sem corridas nesta semana"
        findViewById<TextView>(R.id.tvMelhorDia)?.text = textoMelhor
    }

    // ── COMPARATIVO DE SEMANAS ─────────────────────────────────
    // Mostra as 2 semanas mais recentes com dados (não necessariamente a semana atual)
    private fun configurarComparativo() {
        val sdfCurto = SimpleDateFormat("dd/MM", Locale.getDefault())
        val cal = Calendar.getInstance()

        // Início da semana atual
        val calIniAtual = cal.clone() as Calendar
        calIniAtual.set(Calendar.DAY_OF_WEEK, calIniAtual.firstDayOfWeek)
        calIniAtual.set(Calendar.HOUR_OF_DAY, 0); calIniAtual.set(Calendar.MINUTE, 0)
        calIniAtual.set(Calendar.SECOND, 0); calIniAtual.set(Calendar.MILLISECOND, 0)

        // Tentar semana atual, senão recuar até achar semanas com dados
        var inicioBusca = calIniAtual.timeInMillis
        var fimBusca    = System.currentTimeMillis()
        var semanaA     = 0f
        var semanaB     = 0f
        var labelA      = ""
        var labelB      = ""
        var tentativas  = 0

        // Percorre para trás até achar 2 semanas consecutivas com dados
        while (tentativas < 12) {
            val totalSemana = db.resumo(db.buscarPorPeriodo(inicioBusca, fimBusca))["total"] ?: 0f
            val fimLabel = Calendar.getInstance().apply { timeInMillis = fimBusca }
            val iniLabel = Calendar.getInstance().apply { timeInMillis = inicioBusca }
            val label = "${sdfCurto.format(iniLabel.time)} – ${sdfCurto.format(fimLabel.time)}"

            if (semanaA == 0f && totalSemana > 0f) {
                semanaA = totalSemana; labelA = label
            } else if (semanaA > 0f && labelA.isNotEmpty()) {
                semanaB = totalSemana; labelB = label
                break
            } else if (semanaA == 0f && tentativas == 0) {
                // Semana atual sem dados — anotar mesmo assim como semana A
                semanaA = 0f; labelA = "Esta semana ($label)"
            }

            // Recuar uma semana
            fimBusca    = inicioBusca - 1L
            inicioBusca = fimBusca - 7L * 24 * 60 * 60 * 1000L
            tentativas++
        }

        val prefs = getSharedPreferences("FluxoApp", android.content.Context.MODE_PRIVATE)
        val green = ThemeHelper.cor("accent_green", prefs)
        val red   = ThemeHelper.cor("accent_red",   prefs)
        val gold  = ThemeHelper.cor("accent_gold",  prefs)
        val tv    = findViewById<TextView>(R.id.tvComparativo) ?: return

        val diff  = if (semanaB > 0) ((semanaA - semanaB) / semanaB * 100).toInt() else 0
        val sinal = if (diff >= 0) "+" else ""
        val emoji = when { diff > 10 -> "📈"; diff < -10 -> "📉"; else -> "➡️" }

        tv.text = buildString {
            append("SEMANA MAIS RECENTE\n")
            append("  $labelA\n")
            append("  R$ ${"%.2f".format(semanaA)}\n\n")
            append("SEMANA ANTERIOR\n")
            append("  $labelB\n")
            append("  R$ ${"%.2f".format(semanaB)}\n\n")
            when {
                semanaB <= 0f -> append("📊 Histórico insuficiente para comparar")
                semanaA == 0f -> append("⏳ Sem corridas na semana mais recente ainda")
                else          -> append("$emoji Variação: $sinal$diff%")
            }
        }
        tv.setTextColor(when {
            semanaA == 0f || diff < 0 -> red
            diff > 0                   -> green
            else                       -> gold
        })
    }

    // ── GRÁFICO 3: GANHOS POR MÊS (NOVO) ──────────────────────
    private fun configurarGraficoMeses(
        todas: List<Corrida>,
        accentHex: String = "#C9A84C",
        bgHex: String = "#16161F",
        txtHex: String = "#6B6B80"
    ) {
        val chart = findViewById<BarChart>(R.id.chartMeses) ?: return
        val labels = arrayOf("Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez")

        // Agrupar por mês do ano ATUAL + ano ANTERIOR para ter histórico
        val anoAtual = Calendar.getInstance().get(Calendar.YEAR)

        // Mapa: "MM/yyyy" → total
        val ganhoPorMes = mutableMapOf<String, Float>()
        todas.forEach { c ->
            try {
                val d = sdfData().parse(c.data) ?: return@forEach
                val cal = Calendar.getInstance().apply { time = d }
                val ano = cal.get(Calendar.YEAR)
                val mes = cal.get(Calendar.MONTH) + 1
                val chave = "$mes/$ano"
                ganhoPorMes[chave] = (ganhoPorMes[chave] ?: 0f) + c.valor
            } catch (_: Throwable) {}
        }

        // Anos distintos com dados
        val anosComDados = todas.mapNotNull {
            try { sdfData().parse(it.data)?.let { d ->
                Calendar.getInstance().apply { time = d }.get(Calendar.YEAR)
            }} catch (_: Throwable) { null }
        }.toSet().sorted()

        // Mostrar apenas o ano com mais dados (geralmente o atual ou o que tiver mais corridas)
        val anoMostrar = anosComDados.maxByOrNull { ano ->
            (1..12).sumOf { mes -> (ganhoPorMes["$mes/$ano"] ?: 0f).toInt() }
        } ?: anoAtual

        val ganhosMeses = Array(12) { mes -> ganhoPorMes["${mes+1}/$anoMostrar"] ?: 0f }

        val maxGanho = ganhosMeses.maxOrNull() ?: 0f
        val entries = ganhosMeses.indices.map { BarEntry(it.toFloat(), ganhosMeses[it]) }
        val cores = ganhosMeses.map {
            if (it == maxGanho && it > 0) Color.parseColor("#00E676")
            else Color.parseColor(accentHex)
        }

        val dataset = BarDataSet(entries, "Ganho/mês").apply {
            colors = cores
            valueTextColor = Color.parseColor(txtHex)
            valueTextSize = 8f
            valueFormatter = object : ValueFormatter() {
                override fun getFormattedValue(v: Float) =
                    if (v > 0) "R$${"%.0f".format(v)}" else ""
            }
        }

        chart.apply {
            data = BarData(dataset).apply { barWidth = 0.7f }
            description.isEnabled = false; legend.isEnabled = false
            setBackgroundColor(Color.parseColor(bgHex))
            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                textColor = Color.parseColor(txtHex)
                textSize = 10f; granularity = 1f; setDrawGridLines(false)
                valueFormatter = IndexAxisValueFormatter(labels)
            }
            axisLeft.apply {
                textColor = Color.parseColor(txtHex)
                gridColor = Color.parseColor("#2A2A3A")
                valueFormatter = object : ValueFormatter() {
                    override fun getFormattedValue(v: Float) = "R$${"%.0f".format(v)}"
                }
            }
            axisRight.isEnabled = false; setTouchEnabled(false); animateY(800); invalidate()
        }

        // Atualizar subtítulo e label
        try {
            val anosLabel = if (anosComDados.size > 1)
                "Exibindo $anoMostrar (com mais dados)"
            else
                "Ano $anoMostrar"
            findViewById<TextView>(R.id.tvSubtituloMeses)?.text = anosLabel
        } catch (_: Throwable) {}

        val melhorMesIdx = ganhosMeses.indices.maxByOrNull { ganhosMeses[it] } ?: 0
        val temDados = ganhosMeses.any { it > 0 }
        val melhorMesTexto = if (temDados)
            "Melhor mês: ${labels[melhorMesIdx]}  ·  R$${"%.2f".format(ganhosMeses[melhorMesIdx])}"
        else "Sem dados de meses completos ainda"

        // Calcular total do ano
        val totalAno = ganhosMeses.sum()
        val mesesComDados = ganhosMeses.count { it > 0 }
        val mediaMsg = if (mesesComDados > 0)
            "\nTotal $anoMostrar: R$${"%.2f".format(totalAno)}  ·  Média: R$${"%.2f".format(totalAno/mesesComDados)}/mês"
        else ""

        findViewById<TextView>(R.id.tvMelhorMes)?.text = melhorMesTexto + mediaMsg
    }

    // ── PREVISÃO MENSAL ────────────────────────────────────────
    private fun configurarPrevisao(mes: List<Corrida>, cal: Calendar) {
        val totalMes   = db.resumo(mes)["total"] ?: 0f
        val diaAtual   = cal.get(Calendar.DAY_OF_MONTH)
        val diasNoMes  = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val mediaDiaria = if (diaAtual > 0) totalMes / diaAtual else 0f
        val previsao   = mediaDiaria * diasNoMes
        val diasRest   = diasNoMes - diaAtual
        findViewById<TextView>(R.id.tvPrevisao)?.text = buildString {
            append("PREVISÃO PARA O MÊS\n\n")
            append("Já ganhou: R$ ${"%.2f".format(totalMes)}\n")
            append("Média diária: R$ ${"%.2f".format(mediaDiaria)}\n")
            append("Dias restantes: $diasRest\n")
            append("Previsão total: R$ ${"%.2f".format(previsao)}")
        }
        val pct = if (diasNoMes > 0) ((diaAtual.toFloat() / diasNoMes) * 100).toInt() else 0
        findViewById<ProgressBar>(R.id.progressPrevisao)?.progress = pct.coerceIn(0, 100)
        findViewById<TextView>(R.id.tvProgressPrevisao)?.text = "Dia $diaAtual de $diasNoMes ($pct% do mês)"
    }

    // ── DESTINOS MAIS RENTÁVEIS ────────────────────────────────
    private fun configurarBairros(corridas: List<Corrida>) {
        val mapa = mutableMapOf<String, Pair<Float, Int>>()
        corridas.forEach { c ->
            val dest = c.destino.trim()
            if (dest.length > 3) {
                val atual = mapa[dest] ?: Pair(0f, 0)
                mapa[dest] = Pair(atual.first + c.valor, atual.second + 1)
            }
        }
        val tv = findViewById<TextView>(R.id.tvBairros)
        if (mapa.isEmpty()) { tv?.text = "Ainda sem dados de destinos.\nFaça corridas para ver o ranking!"; return }
        val top = mapa.entries.sortedByDescending { it.value.first }.take(5)
        tv?.text = buildString {
            append("TOP DESTINOS MAIS RENTÁVEIS\n\n")
            top.forEachIndexed { i, (bairro, dados) ->
                val medal = when(i) { 0 -> "🥇"; 1 -> "🥈"; 2 -> "🥉"; else -> "${i+1}." }
                val media = if (dados.second > 0) dados.first / dados.second else 0f
                append("$medal $bairro\n   R$ ${"%.2f".format(dados.first)} | ${dados.second} corrida(s) | R$ ${"%.2f".format(media)} média\n\n")
            }
        }
    }

    // ── DICAS PERSONALIZADAS ───────────────────────────────────
    private fun configurarDicas(corridas: List<Corrida>) {
        val tv = findViewById<TextView>(R.id.tvDicas)
        if (corridas.size < 5) { tv?.text = "Faça pelo menos 5 corridas para receber dicas personalizadas!"; return }
        val dicas = mutableListOf<String>()
        val ganhosPorHora = Array(24) { 0f }; val qtdPorHora = Array(24) { 0 }
        corridas.forEach { c ->
            val h = c.hora.split(":").firstOrNull()?.toIntOrNull() ?: return@forEach
            if (h in 0..23) { ganhosPorHora[h] += c.valor; qtdPorHora[h]++ }
        }
        val mediaPorHora = ganhosPorHora.indices.map { if (qtdPorHora[it] > 0) ganhosPorHora[it] / qtdPorHora[it] else 0f }
        val mediaGeral = corridas.sumOf { it.valor.toDouble() }.toFloat() / corridas.size
        val melhorHora = mediaPorHora.indices.maxByOrNull { mediaPorHora[it] } ?: 0
        if (mediaPorHora[melhorHora] > mediaGeral * 1.2f)
            dicas.add("⏰ Você ganha ${"%.0f".format((mediaPorHora[melhorHora]/mediaGeral-1)*100)}% mais entre ${melhorHora}h e ${melhorHora+1}h!")
        val taxa = corridas.count { it.valeAPena }.toFloat() / corridas.size * 100
        if (taxa < 50) dicas.add("⚠️ Só ${"%.0f".format(taxa)}% das corridas valem a pena. Considere aumentar o mínimo R$/km.")
        else if (taxa > 85) dicas.add("✅ ${"%.0f".format(taxa)}% das corridas valem a pena. Seu mínimo está bem calibrado!")
        val melhorCorrida = corridas.maxByOrNull { it.valor }
        if (melhorCorrida != null) dicas.add("🏆 Sua melhor corrida foi R$ ${"%.2f".format(melhorCorrida.valor)} em ${melhorCorrida.data}!")
        val totalGanho = corridas.sumOf { it.valor.toDouble() }
        val mediaCorr = totalGanho / corridas.size
        dicas.add("📊 Média por corrida: R$ ${"%.2f".format(mediaCorr)} em ${corridas.size} corridas no total.")
        tv?.text = if (dicas.isEmpty()) "Continue fazendo corridas para receber dicas!" else dicas.joinToString("\n\n")
    }

    // ── COMPARTILHAR ───────────────────────────────────────────
    private fun compartilharResultado() {
        val p = getSharedPreferences("FluxoApp", android.content.Context.MODE_PRIVATE)
        val themeAccent    = ThemeHelper.cor("accent_gold", p)
        val themeBg        = ThemeHelper.cor("bg_dark",     p)
        val themeBg2       = ThemeHelper.cor("bg_card",     p)
        val themeTxt       = ThemeHelper.cor("text_white",  p)
        val themeGray      = ThemeHelper.cor("text_gray",   p)
        val themeAccentHex = "#%06X".format(0xFFFFFF and themeAccent)
        val themeBgHex     = "#%06X".format(0xFFFFFF and themeBg)
        val themeBg2Hex    = "#%06X".format(0xFFFFFF and themeBg2)
        val themeTxtHex    = "#%06X".format(0xFFFFFF and themeTxt)
        val themeGrayHex   = "#%06X".format(0xFFFFFF and themeGray)

        val corridas = db.buscarHoje()
        val resumo   = db.resumo(corridas)
        val total    = resumo["total"] ?: 0f
        val qtd      = (resumo["corridas"] ?: 0f).toInt()
        val mediaKm  = resumo["media_km"] ?: 0f
        val w = 900; val h = 500
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val bgPaint = Paint().apply {
            shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(),
                Color.parseColor(themeBgHex), Color.parseColor(themeBg2Hex), Shader.TileMode.CLAMP)
        }
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bgPaint)
        canvas.drawRoundRect(4f, 4f, w-4f, h-4f, 24f, 24f, Paint().apply {
            style = Paint.Style.STROKE; color = Color.parseColor(themeAccentHex); strokeWidth = 4f
        })
        canvas.drawText("FLUXOAPP", 40f, 42f, Paint().apply { color = Color.parseColor(themeAccentHex); textSize = 28f; isFakeBoldText = true; isAntiAlias = true })
        val hoje = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())
        canvas.drawText(hoje, w-180f, 42f, Paint().apply { color = Color.parseColor(themeGrayHex); textSize = 20f; isAntiAlias = true })
        canvas.drawLine(0f, 60f, w.toFloat(), 60f, Paint().apply {
            shader = LinearGradient(0f,0f,w.toFloat(),0f, Color.TRANSPARENT, Color.parseColor(themeAccentHex), Shader.TileMode.CLAMP)
            strokeWidth = 3f; style = Paint.Style.STROKE
        })
        canvas.drawText("R$ ${"%.2f".format(total)}", 40f, 200f, Paint().apply {
            shader = LinearGradient(0f,0f,0f,200f, Color.parseColor("#00E676"), Color.parseColor(themeAccentHex), Shader.TileMode.CLAMP)
            textSize = 96f; isFakeBoldText = true; isAntiAlias = true
        })
        canvas.drawText("GANHO DO DIA", 40f, 235f, Paint().apply { color = Color.parseColor(themeGrayHex); textSize = 22f; isAntiAlias = true })
        canvas.drawLine(40f, 270f, w-40f, 270f, Paint().apply { color = Color.parseColor("#2A2A3A"); strokeWidth = 1f })
        val stP = Paint().apply { color = Color.parseColor(themeGrayHex); textSize = 18f; isAntiAlias = true }
        val svP = Paint().apply { color = Color.parseColor(themeTxtHex); textSize = 26f; isFakeBoldText = true; isAntiAlias = true }
        canvas.drawText("CORRIDAS", 40f, 320f, stP); canvas.drawText("$qtd", 40f, 355f, svP)
        canvas.drawText("MÉDIA/KM", 250f, 320f, stP); canvas.drawText("R$ ${"%.2f".format(mediaKm)}", 250f, 355f, svP)
        val boas = corridas.count { it.valeAPena }
        val taxa = if (qtd > 0) (boas * 100 / qtd) else 0
        canvas.drawText("APROVEITAMENTO", 480f, 320f, stP); canvas.drawText("$taxa%", 480f, 355f, svP)
        canvas.drawRoundRect(40f, 380f, w-40f, 398f, 8f, 8f, Paint().apply { color = Color.parseColor("#2A2A3A") })
        if (taxa > 0) canvas.drawRoundRect(40f, 380f, (40+(w-80)*taxa/100).toFloat(), 398f, 8f, 8f, Paint().apply {
            shader = LinearGradient(40f,0f,(40+(w-80)*taxa/100).toFloat(),0f, Color.parseColor("#00E676"), Color.parseColor(themeAccentHex), Shader.TileMode.CLAMP)
        })
        canvas.drawText("Gerado pelo FluxoApp | Motorista Taxsee/Maxim", 40f, h-20f, Paint().apply { color = Color.parseColor("#2A2A3A"); textSize = 16f; isAntiAlias = true })

        val file = File(cacheDir, "resultado_fluxoapp.png")
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.provider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"; putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, "Meu resultado de hoje no Taxsee/Maxim!\nGerado pelo FluxoApp")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Compartilhar resultado"))
    }

    // ── TEMA ───────────────────────────────────────────────────
    private fun aplicarTema() {
        val p      = getSharedPreferences("FluxoApp", android.content.Context.MODE_PRIVATE)
        val bg     = ThemeHelper.cor("bg_dark",     p)
        val bgCard = ThemeHelper.cor("bg_card",     p)
        val accent = ThemeHelper.cor("accent_gold", p)
        val green  = ThemeHelper.cor("accent_green", p)
        val txtW   = ThemeHelper.cor("text_white",   p)
        val dp = resources.displayMetrics.density
        fun gd(cor: Int) = android.graphics.drawable.GradientDrawable().apply {
            setColor(cor); cornerRadius = 12f * dp
        }
        try { findViewById<android.view.View>(R.id.rootLayout)?.setBackgroundColor(bg) } catch (_: Throwable) {}
        try { findViewById<android.widget.ImageButton>(R.id.btnVoltar)?.setColorFilter(accent) } catch (_: Throwable) {}
        try { findViewById<android.widget.ImageButton>(R.id.btnDiaAnteriorHoras)?.setColorFilter(accent) } catch (_: Throwable) {}
        try { findViewById<android.widget.ImageButton>(R.id.btnDiaProximoHoras)?.setColorFilter(accent) } catch (_: Throwable) {}
        try { findViewById<android.widget.TextView>(R.id.tvDataHoras)?.setTextColor(accent) } catch (_: Throwable) {}
        for (id in listOf(R.id.tvRelatorioResumo, R.id.tvComparativo, R.id.tvPrevisao, R.id.tvBairros, R.id.tvDicas)) {
            try { findViewById<android.widget.TextView>(id)?.apply {
                background = gd(bgCard); setTextColor(txtW)
            }} catch (_: Throwable) {}
        }
        try { findViewById<android.widget.TextView>(R.id.tvMelhorHora)?.setTextColor(accent)   } catch (_: Throwable) {}
        try { findViewById<android.widget.TextView>(R.id.tvMelhorDia)?.setTextColor(green)     } catch (_: Throwable) {}
        try { findViewById<android.widget.TextView>(R.id.tvMelhorMes)?.setTextColor(accent)    } catch (_: Throwable) {}
        try { findViewById<android.widget.TextView>(R.id.tvComparativo)?.setTextColor(green)   } catch (_: Throwable) {}
        try { findViewById<android.widget.ProgressBar>(R.id.progressPrevisao)?.progressTintList =
            android.content.res.ColorStateList.valueOf(accent) } catch (_: Throwable) {}
        try { findViewById<android.widget.Button>(R.id.btnCompartilhar)?.apply {
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(accent); cornerRadius = 10f * dp
            }
            setTextColor(android.graphics.Color.BLACK)
        }} catch (_: Throwable) {}
    }
}
