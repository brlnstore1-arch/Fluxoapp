package com.fluxoapp

import android.content.Intent
import android.graphics.*
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.github.mikephil.charting.formatter.ValueFormatter
import java.io.File
import java.io.FileOutputStream
import java.util.Calendar
import kotlin.math.roundToInt

class ReportsActivity : AppCompatActivity() {
    private lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reports)
        db = DatabaseHelper(this)
        findViewById<ImageButton>(R.id.btnVoltar).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnCompartilhar).setOnClickListener { compartilharResultado() }
        gerarRelatorio()
    }

    private fun gerarRelatorio() {
        val todas = db.buscarTodas()
        val hoje = db.buscarHoje()
        val semana = db.buscarSemana()
        val cal = Calendar.getInstance()
        val mes = db.buscarMes(cal.get(Calendar.MONTH), cal.get(Calendar.YEAR))

        val rHoje  = db.resumo(hoje)
        val rSemana = db.resumo(semana)
        val rMes   = db.resumo(mes)
        val rTodas = db.resumo(todas)

        // ── Resumo por período ──
        findViewById<TextView>(R.id.tvRelatorioResumo).text = buildString {
            append("📅 HOJE\n  R$ ${"%.2f".format(rHoje["total"])} em ${(rHoje["corridas"]?:0f).toInt()} corridas\n\n")
            append("📅 ESTA SEMANA\n  R$ ${"%.2f".format(rSemana["total"])} em ${(rSemana["corridas"]?:0f).toInt()} corridas\n\n")
            append("📅 ESTE MÊS\n  R$ ${"%.2f".format(rMes["total"])} em ${(rMes["corridas"]?:0f).toInt()} corridas\n\n")
            append("📊 GERAL\n  Total histórico: R$ ${"%.2f".format(rTodas["total"])}\n")
            append("  Total de corridas: ${(rTodas["corridas"]?:0f).toInt()}\n")
            append("  Média geral/km: R$ ${"%.2f".format(rTodas["media_km"])}")
        }

        // ── Gráfico de ganhos por hora ──
        configurarGraficoHoras(todas)

        // ── Gráfico de ganhos por dia da semana ──
        configurarGraficoDias(todas)

        // ── Comparativo semana atual x anterior ──
        configurarComparativo()

        // ── Previsão mensal ──
        configurarPrevisao(mes, cal)

        // ── Bairros mais rentáveis ──
        configurarBairros(todas)

        // ── Dicas inteligentes ──
        configurarDicas(todas)
    }

    // ════════════════════════════════════════
    // GRÁFICO DE GANHOS POR HORA (LineChart)
    // ════════════════════════════════════════
    private fun configurarGraficoHoras(corridas: List<Corrida>) {
        val chart = findViewById<LineChart>(R.id.chartHoras)
        val ganhos = Array(24) { 0f }
        corridas.forEach { c ->
            val h = c.hora.split(":").firstOrNull()?.toIntOrNull() ?: return@forEach
            ganhos[h] += c.valor
        }

        val entries = ganhos.indices.map { Entry(it.toFloat(), ganhos[it]) }
        val dataset = LineDataSet(entries, "R$ por hora").apply {
            color = Color.parseColor("#00E5FF")
            setCircleColor(Color.parseColor("#00E5FF"))
            lineWidth = 2.5f; circleRadius = 3f
            setDrawFilled(true)
            fillColor = Color.parseColor("#00E5FF")
            fillAlpha = 40
            valueTextColor = Color.parseColor("#9090A8")
            valueTextSize = 8f
            mode = LineDataSet.Mode.CUBIC_BEZIER
            setDrawValues(false)
        }

        chart.apply {
            data = LineData(dataset)
            description.isEnabled = false
            legend.isEnabled = false
            setBackgroundColor(Color.parseColor("#16161F"))
            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                textColor = Color.parseColor("#6B6B80")
                textSize = 9f
                granularity = 1f
                setDrawGridLines(false)
                valueFormatter = object : ValueFormatter() {
                    override fun getFormattedValue(value: Float) = "${value.toInt()}h"
                }
            }
            axisLeft.apply {
                textColor = Color.parseColor("#6B6B80")
                textSize = 9f
                setDrawGridLines(true)
                gridColor = Color.parseColor("#2A2A3A")
                valueFormatter = object : ValueFormatter() {
                    override fun getFormattedValue(v: Float) = "R$${"%.0f".format(v)}"
                }
            }
            axisRight.isEnabled = false
            setTouchEnabled(true)
            isDragEnabled = true
            setScaleEnabled(false)
            animateX(800)
            invalidate()
        }

        // Label do melhor horário
        val melhorHora = ganhos.indices.maxByOrNull { ganhos[it] } ?: 0
        if (ganhos[melhorHora] > 0) {
            findViewById<TextView>(R.id.tvMelhorHora).text =
                "🕐 Pico: ${melhorHora}h–${melhorHora+1}h   R$ ${"%.2f".format(ganhos[melhorHora])}"
        } else {
            findViewById<TextView>(R.id.tvMelhorHora).text = "Faça corridas para ver o horário de pico"
        }
    }

    // ════════════════════════════════════════
    // GRÁFICO POR DIA DA SEMANA (BarChart)
    // ════════════════════════════════════════
    private fun configurarGraficoDias(corridas: List<Corrida>) {
        val chart = findViewById<BarChart>(R.id.chartDias)
        val labels = arrayOf("Dom","Seg","Ter","Qua","Qui","Sex","Sáb")
        val ganhos = Array(7) { 0f }
        corridas.forEach { c ->
            try {
                val sdf = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault())
                val d = sdf.parse(c.data) ?: return@forEach
                val cal = Calendar.getInstance().apply { time = d }
                ganhos[cal.get(Calendar.DAY_OF_WEEK) - 1] += c.valor
            } catch (_: Exception) {}
        }

        val entries = ganhos.indices.map { BarEntry(it.toFloat(), ganhos[it]) }
        val cores = ganhos.map { v ->
            if (v == ganhos.max() && v > 0) Color.parseColor("#00E676")
            else Color.parseColor("#00B8CC")
        }

        val dataset = BarDataSet(entries, "Ganho por dia").apply {
            colors = cores
            valueTextColor = Color.parseColor("#9090A8")
            valueTextSize = 9f
            valueFormatter = object : ValueFormatter() {
                override fun getFormattedValue(v: Float) = if (v > 0) "R$${"%.0f".format(v)}" else ""
            }
        }

        chart.apply {
            data = BarData(dataset).apply { barWidth = 0.6f }
            description.isEnabled = false
            legend.isEnabled = false
            setBackgroundColor(Color.parseColor("#16161F"))
            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                textColor = Color.parseColor("#6B6B80")
                textSize = 10f
                granularity = 1f
                setDrawGridLines(false)
                valueFormatter = IndexAxisValueFormatter(labels)
            }
            axisLeft.apply {
                textColor = Color.parseColor("#6B6B80")
                textSize = 9f
                gridColor = Color.parseColor("#2A2A3A")
                valueFormatter = object : ValueFormatter() {
                    override fun getFormattedValue(v: Float) = "R$${"%.0f".format(v)}"
                }
            }
            axisRight.isEnabled = false
            setTouchEnabled(false)
            animateY(800)
            invalidate()
        }

        val melhorDia = ganhos.indices.maxByOrNull { ganhos[it] } ?: 0
        findViewById<TextView>(R.id.tvMelhorDia).text =
            if (ganhos[melhorDia] > 0) "🏆 Melhor dia: ${arrayOf("Domingo","Segunda","Terça","Quarta","Quinta","Sexta","Sábado")[melhorDia]}"
            else "Faça corridas para ver o melhor dia"
    }

    // ════════════════════════════════════════
    // COMPARATIVO SEMANA ATUAL X ANTERIOR
    // ════════════════════════════════════════
    private fun configurarComparativo() {
        val calIni = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_WEEK, firstDayOfWeek)
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val inicioSemana = calIni.timeInMillis
        val fimSemana = System.currentTimeMillis()

        val inicioAnterior = inicioSemana - 7 * 24 * 60 * 60 * 1000L
        val fimAnterior = inicioSemana - 1

        val atual = db.resumo(db.buscarPorPeriodo(inicioSemana, fimSemana))["total"] ?: 0f
        val anterior = db.resumo(db.buscarPorPeriodo(inicioAnterior, fimAnterior))["total"] ?: 0f

        val diff = if (anterior > 0) ((atual - anterior) / anterior * 100).roundToInt() else 0
        val emoji = when {
            atual > anterior -> "📈"
            atual < anterior -> "📉"
            else -> "➡️"
        }
        val cor = when {
            atual > anterior -> "#00E676"
            atual < anterior -> "#FF1744"
            else -> "#9090A8"
        }

        val tv = findViewById<TextView>(R.id.tvComparativo)
        tv.text = buildString {
            append("$emoji SEMANA ATUAL: R$ ${"%.2f".format(atual)}\n")
            append("📋 SEMANA ANTERIOR: R$ ${"%.2f".format(anterior)}\n")
            if (anterior > 0) {
                val sinal = if (diff >= 0) "+" else ""
                append("\n${if (atual >= anterior) "✅" else "⚠️"} Variação: $sinal$diff%")
            } else {
                append("\nPrimeira semana registrada!")
            }
        }
        tv.setTextColor(Color.parseColor(cor))
    }

    // ════════════════════════════════════════
    // PREVISÃO MENSAL
    // ════════════════════════════════════════
    private fun configurarPrevisao(mes: List<Corrida>, cal: Calendar) {
        val totalMes = db.resumo(mes)["total"] ?: 0f
        val diaAtual = cal.get(Calendar.DAY_OF_MONTH)
        val diasNoMes = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val mediaDiaria = if (diaAtual > 0) totalMes / diaAtual else 0f
        val previsao = mediaDiaria * diasNoMes
        val diasRestantes = diasNoMes - diaAtual
        val faltaGanhar = previsao - totalMes

        val prefs = getSharedPreferences("FluxoApp", MODE_PRIVATE)
        val metaMensal = prefs.getFloat("meta_semanal", 0f) * 4

        findViewById<TextView>(R.id.tvPrevisao).text = buildString {
            append("🔮 PREVISÃO PARA O MÊS\n\n")
            append("Já ganhou: R$ ${"%.2f".format(totalMes)}\n")
            append("Média diária: R$ ${"%.2f".format(mediaDiaria)}\n")
            append("Dias restantes: $diasRestantes\n")
            append("Previsão total: R$ ${"%.2f".format(previsao)}\n")
            if (faltaGanhar > 0) append("\nFalta ganhar: R$ ${"%.2f".format(faltaGanhar)}")
            if (metaMensal > 0) {
                val pct = (previsao / metaMensal * 100).roundToInt()
                append("\n\n${if (pct >= 100) "🎯 Meta mensal atingida!" else "📊 Meta mensal: $pct% previsto"}")
            }
        }

        // Barra de progresso da previsão
        val progress = findViewById<ProgressBar>(R.id.progressPrevisao)
        val pct = if (diasNoMes > 0) ((diaAtual.toFloat() / diasNoMes) * 100).toInt() else 0
        progress.progress = pct.coerceIn(0, 100)
        findViewById<TextView>(R.id.tvProgressPrevisao).text = "Dia $diaAtual de $diasNoMes ($pct% do mês)"
    }

    // ════════════════════════════════════════
    // BAIRROS MAIS RENTÁVEIS
    // ════════════════════════════════════════
    private fun configurarBairros(corridas: List<Corrida>) {
        val bairroMap = mutableMapOf<String, Pair<Float, Int>>() // nome -> (total, qtd)
        corridas.forEach { c ->
            val dest = c.destino.trim()
            if (dest.isNotEmpty() && dest.length > 3) {
                val atual = bairroMap[dest] ?: Pair(0f, 0)
                bairroMap[dest] = Pair(atual.first + c.valor, atual.second + 1)
            }
        }

        val tv = findViewById<TextView>(R.id.tvBairros)
        if (bairroMap.isEmpty()) {
            tv.text = "Ainda sem dados de destinos.\nFaça corridas para ver o ranking! 🗺️"
            return
        }

        val top = bairroMap.entries
            .sortedByDescending { it.value.first }
            .take(5)

        tv.text = buildString {
            append("🏘️ TOP DESTINOS MAIS RENTÁVEIS\n\n")
            top.forEachIndexed { i, (bairro, dados) ->
                val medal = when(i) { 0 -> "🥇"; 1 -> "🥈"; 2 -> "🥉"; else -> "${i+1}." }
                val media = if (dados.second > 0) dados.first / dados.second else 0f
                append("$medal $bairro\n")
                append("   R$ ${"%.2f".format(dados.first)} total | ${dados.second} corrida(s) | R$ ${"%.2f".format(media)} média\n\n")
            }
        }
    }

    // ════════════════════════════════════════
    // DICAS INTELIGENTES
    // ════════════════════════════════════════
    private fun configurarDicas(corridas: List<Corrida>) {
        val tv = findViewById<TextView>(R.id.tvDicas)
        if (corridas.size < 5) {
            tv.text = "💡 Faça pelo menos 5 corridas para receber dicas personalizadas!"
            return
        }

        val dicas = mutableListOf<String>()

        // Horário de pico
        val ganhosPorHora = Array(24) { 0f }
        val qtdPorHora = Array(24) { 0 }
        corridas.forEach { c ->
            val h = c.hora.split(":").firstOrNull()?.toIntOrNull() ?: return@forEach
            ganhosPorHora[h] += c.valor; qtdPorHora[h]++
        }
        val mediaPorHora = ganhosPorHora.indices.map { if (qtdPorHora[it] > 0) ganhosPorHora[it] / qtdPorHora[it] else 0f }
        val mediaGeral = if (corridas.isNotEmpty()) corridas.sumOf { it.valor.toDouble() }.toFloat() / corridas.size else 0f
        val melhorHora = mediaPorHora.indices.maxByOrNull { mediaPorHora[it] } ?: 0
        if (mediaPorHora[melhorHora] > mediaGeral * 1.2f) {
            dicas.add("⚡ Você ganha ${"%.0f".format((mediaPorHora[melhorHora]/mediaGeral - 1)*100)}% mais entre ${melhorHora}h e ${melhorHora+1}h. Vale a pena focar nesse horário!")
        }

        // Taxa de aceitação
        val taxaAceit = corridas.count { it.valeAPena }.toFloat() / corridas.size * 100
        if (taxaAceit < 50) {
            dicas.add("⚠️ Só ${"%.0f".format(taxaAceit)}% das corridas valem a pena. Considere aumentar o R$/km mínimo.")
        } else if (taxaAceit > 85) {
            dicas.add("✅ ${"%.0f".format(taxaAceit)}% das corridas valem a pena. Seu mínimo está bem calibrado!")
        }

        // Melhor dia da semana
        val ganhosDia = Array(7) { 0f }; val qtdDia = Array(7) { 0 }
        val diasNome = arrayOf("Domingo","Segunda","Terça","Quarta","Quinta","Sexta","Sábado")
        corridas.forEach { c ->
            try {
                val sdf = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault())
                val d = sdf.parse(c.data) ?: return@forEach
                val cal = Calendar.getInstance().apply { time = d }
                val dw = cal.get(Calendar.DAY_OF_WEEK) - 1
                ganhosDia[dw] += c.valor; qtdDia[dw]++
            } catch (_: Exception) {}
        }
        val mediaDia = ganhosDia.indices.map { if (qtdDia[it] > 0) ganhosDia[it] / qtdDia[it] else 0f }
        val melhorDia = mediaDia.indices.maxByOrNull { mediaDia[it] } ?: 0
        val piorDia = mediaDia.indices.filter { mediaDia[it] > 0 }.minByOrNull { mediaDia[it] }
        if (mediaDia[melhorDia] > 0) {
            dicas.add("📆 ${diasNome[melhorDia]} é seu dia mais lucrativo! Média de R$ ${"%.2f".format(mediaDia[melhorDia])}/dia.")
        }
        if (piorDia != null && piorDia != melhorDia && mediaDia[piorDia] > 0) {
            dicas.add("😴 ${diasNome[piorDia]} tende a render menos (R$ ${"%.2f".format(mediaDia[piorDia])}/dia). Talvez seja um bom dia de descanso.")
        }

        // Média por km vs mínimo
        val mediaKm = corridas.filter { it.valeAPena }.let { boas ->
            if (boas.isEmpty()) 0f else boas.sumOf { it.ganhoPorKm.toDouble() }.toFloat() / boas.size
        }
        if (mediaKm > 0) dicas.add("💰 Sua média real nas corridas boas é R$ ${"%.2f".format(mediaKm)}/km.")

        // Melhor corrida
        val melhorCorrida = corridas.maxByOrNull { it.valor }
        if (melhorCorrida != null) dicas.add("🏆 Sua melhor corrida foi R$ ${"%.2f".format(melhorCorrida.valor)} em ${melhorCorrida.data}!")

        tv.text = if (dicas.isEmpty()) "💡 Continue fazendo corridas para receber dicas personalizadas!"
        else dicas.joinToString("\n\n")
    }

    // ════════════════════════════════════════
    // COMPARTILHAR RESULTADO
    // ════════════════════════════════════════
    private fun compartilharResultado() {
        val corridas = db.buscarHoje()
        val resumo = db.resumo(corridas)
        val total = resumo["total"] ?: 0f
        val qtd = (resumo["corridas"] ?: 0f).toInt()
        val mediaKm = resumo["media_km"] ?: 0f

        val w = 900; val h = 500
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Fundo gradiente escuro
        val bgPaint = Paint()
        val gradBg = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(),
            Color.parseColor("#0A0A0F"), Color.parseColor("#16161F"), Shader.TileMode.CLAMP)
        bgPaint.shader = gradBg
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bgPaint)

        // Borda cyan
        val borderPaint = Paint().apply {
            style = Paint.Style.STROKE
            color = Color.parseColor("#00E5FF")
            strokeWidth = 4f
        }
        canvas.drawRoundRect(4f, 4f, w-4f, h-4f, 24f, 24f, borderPaint)

        // Linha decorativa topo
        val linePaint = Paint().apply {
            shader = LinearGradient(0f, 0f, w.toFloat(), 0f,
                Color.TRANSPARENT, Color.parseColor("#00E5FF"), Shader.TileMode.CLAMP)
            strokeWidth = 3f; style = Paint.Style.STROKE
        }
        canvas.drawLine(0f, 60f, w.toFloat(), 60f, linePaint)

        // FLUXOAPP logo
        val logoP = Paint().apply { color = Color.parseColor("#00E5FF"); textSize = 28f; isFakeBoldText = true; isAntiAlias = true }
        canvas.drawText("⚡ FLUXOAPP", 40f, 42f, logoP)

        // Data
        val dateP = Paint().apply { color = Color.parseColor("#6B6B80"); textSize = 20f; isAntiAlias = true }
        val hoje = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(java.util.Date())
        canvas.drawText(hoje, w - 180f, 42f, dateP)

        // Ganho principal
        val ganhoP = Paint().apply {
            shader = LinearGradient(0f, 0f, 0f, 200f, Color.parseColor("#00E676"), Color.parseColor("#00B8CC"), Shader.TileMode.CLAMP)
            textSize = 96f; isFakeBoldText = true; isAntiAlias = true
        }
        canvas.drawText("R$ ${"%.2f".format(total)}", 40f, 200f, ganhoP)

        // Label ganho
        val labelP = Paint().apply { color = Color.parseColor("#9090A8"); textSize = 22f; isAntiAlias = true }
        canvas.drawText("GANHO DO DIA", 40f, 235f, labelP)

        // Divisor
        val divP = Paint().apply { color = Color.parseColor("#2A2A3A"); strokeWidth = 1f }
        canvas.drawLine(40f, 270f, w - 40f, 270f, divP)

        // Stats
        val statTitleP = Paint().apply { color = Color.parseColor("#6B6B80"); textSize = 18f; isAntiAlias = true }
        val statValueP = Paint().apply { color = Color.parseColor("#F0F0F5"); textSize = 26f; isFakeBoldText = true; isAntiAlias = true }

        // Corridas
        canvas.drawText("CORRIDAS", 40f, 320f, statTitleP)
        canvas.drawText("$qtd", 40f, 355f, statValueP)

        // Média/km
        canvas.drawText("MÉDIA/KM", 250f, 320f, statTitleP)
        canvas.drawText("R$ ${"%.2f".format(mediaKm)}", 250f, 355f, statValueP)

        // Taxa aproveitamento
        val boas = corridas.count { it.valeAPena }
        val taxa = if (qtd > 0) (boas * 100 / qtd) else 0
        canvas.drawText("APROVEITAMENTO", 480f, 320f, statTitleP)
        canvas.drawText("$taxa%", 480f, 355f, statValueP)

        // Barra de aproveitamento
        val barBg = Paint().apply { color = Color.parseColor("#2A2A3A") }
        canvas.drawRoundRect(40f, 380f, w-40f, 398f, 8f, 8f, barBg)
        if (taxa > 0) {
            val barFill = Paint().apply {
                shader = LinearGradient(40f, 0f, (40 + (w-80) * taxa / 100).toFloat(), 0f,
                    Color.parseColor("#00E676"), Color.parseColor("#00E5FF"), Shader.TileMode.CLAMP)
            }
            canvas.drawRoundRect(40f, 380f, (40 + (w-80) * taxa / 100).toFloat(), 398f, 8f, 8f, barFill)
        }

        // Rodapé
        val footP = Paint().apply { color = Color.parseColor("#2A2A3A"); textSize = 16f; isAntiAlias = true }
        canvas.drawText("Gerado pelo FluxoApp 🚀 | Motorista Taxsee/Maxim", 40f, h-20f, footP)

        // Salvar e compartilhar
        try {
            val file = File(cacheDir, "resultado_fluxoapp.png")
            FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            val uri = FileProvider.getUriForFile(this, "$packageName.provider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, "📊 Meu resultado de hoje no Taxsee/Maxim!\n⚡ Gerado pelo FluxoApp")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "Compartilhar resultado"))
        } catch (e: Exception) {
            Toast.makeText(this, "Erro ao gerar imagem: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
