package com.fluxoapp

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ProgressBar
import android.widget.TextView

class FloatingEarningsService : Service() {
    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private var db: DatabaseHelper? = null
    private var params: WindowManager.LayoutParams? = null
    private var initialX = 0; private var initialY = 0
    private var initialTouchX = 0f; private var initialTouchY = 0f
    private var lastTouchDownTime = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        db = DatabaseHelper(this)
        mostrarBotao()
    }

    private fun mostrarBotao() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        floatingView = LayoutInflater.from(this).inflate(R.layout.floating_earnings, null)

        val prefs = getSharedPreferences("FluxoApp", MODE_PRIVATE)
        val posicao = prefs.getString("flutuante_posicao", "esquerda")
        val gravidade = if (posicao == "direita") Gravity.TOP or Gravity.END else Gravity.TOP or Gravity.START

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = gravidade; x = 0; y = 300 }

        atualizarValor()

        floatingView!!.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params!!.x; initialY = params!!.y
                    initialTouchX = event.rawX; initialTouchY = event.rawY
                    lastTouchDownTime = System.currentTimeMillis(); true
                }
                MotionEvent.ACTION_MOVE -> {
                    params!!.x = initialX + (event.rawX - initialTouchX).toInt()
                    params!!.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager?.updateViewLayout(floatingView, params); true
                }
                MotionEvent.ACTION_UP -> {
                    val duration = System.currentTimeMillis() - lastTouchDownTime
                    val notMoved = Math.abs(event.rawX - initialTouchX) < 10 && Math.abs(event.rawY - initialTouchY) < 10
                    if (duration < 300 && notMoved) {
                        startActivity(Intent(this, MainActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                        })
                    }
                    true
                }
                else -> false
            }
        }
        windowManager?.addView(floatingView, params)
    }

    fun atualizarValor() {
        val db = db ?: return
        val prefs = getSharedPreferences("FluxoApp", MODE_PRIVATE)
        val corridas = db.buscarHoje()
        val resumo = db.resumo(corridas)
        val total = resumo["total"] ?: 0f
        val meta = prefs.getFloat("meta_diaria", 0f)

        floatingView?.findViewById<TextView>(R.id.tvFloatingEarnings)
            ?.text = "R$ ${"%.2f".format(total)}"

        val progressBar = floatingView?.findViewById<ProgressBar>(R.id.progressMeta)
        val tvMeta = floatingView?.findViewById<TextView>(R.id.tvMetaPercent)
        if (meta > 0) {
            progressBar?.visibility = View.VISIBLE
            tvMeta?.visibility = View.VISIBLE
            val percent = ((total / meta) * 100).toInt().coerceIn(0, 100)
            progressBar?.progress = percent
            tvMeta?.text = "$percent%"
        } else {
            progressBar?.visibility = View.GONE
            tvMeta?.visibility = View.GONE
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "ATUALIZAR") atualizarValor()
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        floatingView?.let { try { windowManager?.removeView(it) } catch (_: Exception) {} }
    }
}
