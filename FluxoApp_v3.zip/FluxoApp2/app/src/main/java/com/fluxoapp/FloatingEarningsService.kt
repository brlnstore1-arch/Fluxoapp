package com.fluxoapp

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat

class FloatingEarningsService : Service() {
    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private var db: DatabaseHelper? = null
    private var params: WindowManager.LayoutParams? = null
    private var initialX = 0; private var initialY = 0
    private var initialTouchX = 0f; private var initialTouchY = 0f
    private var lastTouchDownTime = 0L

    // Receptor para mudança de tema
    private val temaReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            reiniciarComNovoTema()
        }
    }

    companion object {
        const val CHANNEL_ID = "fluxoapp_running"
        const val NOTIF_ID   = 1
        const val ACTION_ATUALIZAR = "ATUALIZAR"
        const val ACTION_TEMA      = "com.fluxoapp.TEMA_MUDOU"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        criarCanalNotificacao()
        iniciarForeground()
        db = DatabaseHelper(this)
        // Registrar receptor de tema
        try {
            val filter = IntentFilter(ACTION_TEMA)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                registerReceiver(temaReceiver, filter, RECEIVER_NOT_EXPORTED)
            else
                registerReceiver(temaReceiver, filter)
        } catch (_: Exception) {}
        mostrarBotao()
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(temaReceiver) } catch (_: Exception) {}
        removerView()
        windowManager = null
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_ATUALIZAR -> atualizarValor()
            ACTION_TEMA      -> reiniciarComNovoTema()
        }
        return START_STICKY
    }

    // ── Reinicia o botão do zero com o novo tema ──
    private fun reiniciarComNovoTema() {
        val posY = params?.y ?: 300
        removerView()
        mostrarBotao(posY)
    }

    private fun removerView() {
        floatingView?.let {
            try { windowManager?.removeView(it) } catch (_: Exception) {}
        }
        floatingView = null
    }

    // ── Cria o botão na tela ──
    private fun mostrarBotao(posY: Int = 300) {
        try {
            if (windowManager == null)
                windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

            floatingView = LayoutInflater.from(this).inflate(R.layout.floating_earnings, null)
            aplicarEstiloTema()
            configurarPosicao(posY)
            atualizarValor()
            configurarToque()
            windowManager?.addView(floatingView, params)
        } catch (_: Exception) {}
    }

    // ── Aplica as cores do tema atual no botão ──
    private fun aplicarEstiloTema() {
        val prefs  = getSharedPreferences("FluxoApp", MODE_PRIVATE)
        val isGold = prefs.getString("tema_estilo", "azul") == "gold"
        val noite  = ThemeHelper.isModoNoturno(prefs)
        val root   = floatingView?.findViewById<View>(R.id.floatingRoot)

        if (isGold) {
            // Gold: fundo escuro com borda dourada
            root?.setBackgroundResource(R.drawable.floating_earnings_gold)
            val corTexto = if (noite)
                android.graphics.Color.parseColor("#E8C96D")
            else
                android.graphics.Color.parseColor("#C9A84C")
            floatingView?.findViewById<TextView>(R.id.tvFloatingEarnings)?.setTextColor(corTexto)
            floatingView?.findViewById<TextView>(R.id.tvMetaPercent)
                ?.setTextColor(android.graphics.Color.parseColor("#997A50"))
            floatingView?.findViewById<ProgressBar>(R.id.progressMeta)?.apply {
                progressTintList = android.content.res.ColorStateList.valueOf(
                    android.graphics.Color.parseColor("#C9A84C"))
                progressBackgroundTintList = android.content.res.ColorStateList.valueOf(
                    android.graphics.Color.parseColor("#33C9A84C"))
            }
        } else {
            // Azul: gradiente azul→cyan
            root?.setBackgroundResource(R.drawable.floating_earnings_bg)
            floatingView?.findViewById<TextView>(R.id.tvFloatingEarnings)
                ?.setTextColor(android.graphics.Color.WHITE)
            floatingView?.findViewById<TextView>(R.id.tvMetaPercent)
                ?.setTextColor(android.graphics.Color.parseColor("#BBFFFFFF"))
            floatingView?.findViewById<ProgressBar>(R.id.progressMeta)?.apply {
                progressTintList = android.content.res.ColorStateList.valueOf(
                    android.graphics.Color.parseColor("#CCFFFFFF"))
                progressBackgroundTintList = android.content.res.ColorStateList.valueOf(
                    android.graphics.Color.parseColor("#33FFFFFF"))
            }
        }
    }

    private fun configurarPosicao(posY: Int = 300) {
        val prefs   = getSharedPreferences("FluxoApp", MODE_PRIVATE)
        val posicao = prefs.getString("flutuante_posicao", "direita")
        val grav    = if (posicao == "esquerda") Gravity.TOP or Gravity.START else Gravity.TOP or Gravity.END
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = grav; x = 12; y = posY }
    }

    private fun configurarToque() {
        floatingView?.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params!!.x; initialY = params!!.y
                    initialTouchX = event.rawX; initialTouchY = event.rawY
                    lastTouchDownTime = System.currentTimeMillis(); true
                }
                MotionEvent.ACTION_MOVE -> {
                    params!!.x = initialX + (event.rawX - initialTouchX).toInt()
                    params!!.y = initialY + (event.rawY - initialTouchY).toInt()
                    try { windowManager?.updateViewLayout(floatingView, params) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val dur   = System.currentTimeMillis() - lastTouchDownTime
                    val quiet = Math.abs(event.rawX - initialTouchX) < 12 &&
                                Math.abs(event.rawY - initialTouchY) < 12
                    if (dur < 350 && quiet)
                        startActivity(Intent(this, MainActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                        })
                    true
                }
                else -> false
            }
        }
    }

    fun atualizarValor() {
        try {
            val prefs    = getSharedPreferences("FluxoApp", MODE_PRIVATE)
            val corridas = db?.buscarHoje() ?: return
            val resumo   = db?.resumo(corridas) ?: return
            val total    = resumo["total"] ?: 0f
            val meta     = prefs.getFloat("meta_diaria", 0f)

            floatingView?.findViewById<TextView>(R.id.tvFloatingEarnings)?.text =
                "R$ ${"%.2f".format(total).replace(".", ",")}"

            val pb    = floatingView?.findViewById<ProgressBar>(R.id.progressMeta)
            val tvPct = floatingView?.findViewById<TextView>(R.id.tvMetaPercent)

            if (meta > 0) {
                val pct = ((total / meta) * 100).toInt().coerceIn(0, 100)
                pb?.progress = pct
                pb?.visibility = View.VISIBLE
                tvPct?.text = "$pct%"
                tvPct?.visibility = View.VISIBLE
            } else {
                pb?.visibility = View.GONE
                tvPct?.visibility = View.GONE
            }
            atualizarNotificacao(total, corridas.size)
        } catch (_: Exception) {}
    }

    private fun criarCanalNotificacao() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val canal = NotificationChannel(CHANNEL_ID, "FluxoApp Ativo",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Monitorando corridas"; setShowBadge(false) }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(canal)
        }
    }

    private fun iniciarForeground() {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notif = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("FluxoApp")
            .setContentText("Monitorando corridas...")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pi).setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW).build()
        startForeground(NOTIF_ID, notif)
    }

    fun atualizarNotificacao(total: Float, corridas: Int) {
        try {
            val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val notif = NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("FluxoApp — R$ ${"%.2f".format(total).replace(".", ",")}")
                .setContentText("$corridas corridas hoje | Toque para abrir")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentIntent(pi).setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW).build()
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, notif)
        } catch (_: Exception) {}
    }
}
