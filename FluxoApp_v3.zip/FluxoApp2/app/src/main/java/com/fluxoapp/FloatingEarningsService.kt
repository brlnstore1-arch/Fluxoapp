package com.fluxoapp

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat

class FloatingEarningsService : Service() {
    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private var db: DatabaseHelper? = null
    private var params: WindowManager.LayoutParams? = null
    private var initialX = 0; private var initialY = 0
    private var initialTouchX = 0f; private var initialTouchY = 0f
    private var lastTouchDownTime = 0L
    // Animação de gradiente do botão flutuante
    private var gradientAnimator: android.animation.ValueAnimator? = null
    private var gradientAngle = 0f

    // FIX 10: cache do total do dia para evitar query ao banco a cada atualização
    private var cachedTotal = 0f
    private var cachedCount = 0
    private var cacheDataHoje = "" 

    // Receptor para mudança de tema
    private val temaReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            reiniciarComNovoTema()
        }
    }

    companion object {
        const val CHANNEL_ID = "fluxoapp_running"
        const val NOTIF_ID   = 1
        const val ACTION_ATUALIZAR = "ATUALIZAR"
        const val ACTION_TEMA      = "com.fluxoapp.TEMA_MUDOU"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        criarCanalNotificacao()
        iniciarForeground()
        db = DatabaseHelper(this)
        // Registrar receptor de tema
        try {
            val filter = IntentFilter(ACTION_TEMA)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                registerReceiver(temaReceiver, filter, RECEIVER_NOT_EXPORTED)
            else
                registerReceiver(temaReceiver, filter)
        } catch (_: Exception) {}
        mostrarBotao()
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(temaReceiver) } catch (_: Exception) {}
        removerView()
        windowManager = null
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_ATUALIZAR -> atualizarValor()
            ACTION_TEMA      -> reiniciarComNovoTema()
            else             -> if (floatingView == null) mostrarBotao() // restart safety
        }
        return START_STICKY
    }

    // ── Reinicia o botão do zero com o novo tema ──
    private fun reiniciarComNovoTema() {
        val posY = params?.y ?: 300
        removerView()
        mostrarBotao(posY)
    }

    private fun removerView() {
        floatingView?.let {
            try { windowManager?.removeView(it) } catch (_: Exception) {}
        }
        floatingView = null
    }

    // ── Cria o botão na tela ──
    private fun mostrarBotao(posY: Int = 300) {
        try {
            if (windowManager == null)
                windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

            floatingView = LayoutInflater.from(this).inflate(R.layout.floating_earnings, null)
            aplicarEstiloTema()
            configurarPosicao(posY)
            atualizarValor()
            configurarToque()
            windowManager?.addView(floatingView, params)
        } catch (_: Exception) {}
    }

    // ── Aplica as cores do tema atual no botão ──
    private fun aplicarEstiloTema() {
        val prefs  = getSharedPreferences("FluxoApp", MODE_PRIVATE)
        val accent = ThemeHelper.cor("accent_gold", prefs)
        val txtG   = ThemeHelper.cor("text_gray",   prefs)
        val bgDark = ThemeHelper.cor("bg_dark",      prefs)
        val bgCard = ThemeHelper.cor("bg_card",      prefs)
        val noite  = ThemeHelper.isModoNoturno(prefs)
        val isGold = ThemeHelper.getTema(prefs) == "gold"
        val dp     = resources.displayMetrics.density

        val root = floatingView?.findViewById<android.view.View>(R.id.floatingRoot)

        // Cores do gradiente baseadas no tema
        val gradStart: Int
        val gradMid: Int
        val gradEnd: Int
        val borderColor: Int
        val borderWidth: Float

        if (isGold) {
            // Gold: escuro com shimmer dourado, borda dourada grossa
            gradStart = android.graphics.Color.parseColor(if (noite) "#1E1A0E" else "#2C2215")
            gradMid   = android.graphics.Color.parseColor(if (noite) "#2C2410" else "#3A2E18")
            gradEnd   = android.graphics.Color.parseColor(if (noite) "#1A1608" else "#241A0A")
            borderColor = accent
            borderWidth = 2.5f
        } else {
            // Azul: escuro com shimmer ciano, borda ciano grossa
            gradStart = android.graphics.Color.parseColor(if (noite) "#0A1628" else "#0D1E3A")
            gradMid   = android.graphics.Color.parseColor(if (noite) "#0F1E36" else "#152840")
            gradEnd   = android.graphics.Color.parseColor(if (noite) "#081220" else "#0A1628")
            borderColor = accent
            borderWidth = 2.5f
        }

        // Criar GradientDrawable com gradiente de 3 cores
        val gd = android.graphics.drawable.GradientDrawable(
            android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
            intArrayOf(gradStart, gradMid, gradEnd)
        ).apply {
            cornerRadius = 22f * dp
            setStroke((borderWidth * dp).toInt(), borderColor)
        }
        root?.background = gd

        // Iniciar animação de shimmer no gradiente
        iniciarAnimacaoGradiente(root, gradStart, gradMid, gradEnd, gradEnd, gradMid, gradStart)

        val accentList = android.content.res.ColorStateList.valueOf(accent)
        val accentAlpha = android.graphics.Color.argb(70,
            android.graphics.Color.red(accent),
            android.graphics.Color.green(accent),
            android.graphics.Color.blue(accent))

        floatingView?.findViewById<TextView>(R.id.tvFloatingEarnings)?.setTextColor(accent)
        floatingView?.findViewById<TextView>(R.id.tvMetaPercent)?.setTextColor(txtG)
        floatingView?.findViewById<ProgressBar>(R.id.progressMeta)?.apply {
            progressTintList = accentList
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(accentAlpha)
        }
    }

    private fun iniciarAnimacaoGradiente(
        view: android.view.View?,
        c1: Int, c2: Int, c3: Int,
        c4: Int, c5: Int, c6: Int
    ) {
        gradientAnimator?.cancel()
        view ?: return
        val dp = resources.displayMetrics.density

        // Alterna suavemente entre dois gradientes (forward e reverse)
        gradientAnimator = android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2500L
            repeatCount = android.animation.ValueAnimator.INFINITE
            repeatMode  = android.animation.ValueAnimator.REVERSE
            addUpdateListener { anim ->
                val t = anim.animatedValue as Float
                val prefs2 = getSharedPreferences("FluxoApp", MODE_PRIVATE)
                val accent2 = ThemeHelper.cor("accent_gold", prefs2)
                val isGold2 = ThemeHelper.getTema(prefs2) == "gold"
                val noite2  = ThemeHelper.isModoNoturno(prefs2)
                val bw = 2.5f

                // Interpolar entre gradiente normal e reverso
                fun lerp(a: Int, b: Int, f: Float): Int {
                    val ar = android.graphics.Color.red(a);   val br = android.graphics.Color.red(b)
                    val ag = android.graphics.Color.green(a); val bg = android.graphics.Color.green(b)
                    val ab = android.graphics.Color.blue(a);  val bb = android.graphics.Color.blue(b)
                    return android.graphics.Color.rgb(
                        (ar + (br - ar) * f).toInt(),
                        (ag + (bg - ag) * f).toInt(),
                        (ab + (bb - ab) * f).toInt()
                    )
                }
                val i1 = lerp(c1, c4, t)
                val i2 = lerp(c2, c5, t)
                val i3 = lerp(c3, c6, t)

                val newGd = android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                    intArrayOf(i1, i2, i3)
                ).apply {
                    cornerRadius = 22f * dp
                    setStroke((bw * dp).toInt(), accent2)
                }
                try { view.background = newGd } catch (_: Exception) {}
            }
            start()
        }
    }

    private fun configurarPosicao(posY: Int = 300) {
        val prefs   = getSharedPreferences("FluxoApp", MODE_PRIVATE)
        val posicao = prefs.getString("flutuante_posicao", "direita")
        val grav    = if (posicao == "esquerda") Gravity.TOP or Gravity.START else Gravity.TOP or Gravity.END
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = grav; x = 12; y = posY }
    }

    private fun configurarToque() {
        floatingView?.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params!!.x; initialY = params!!.y
                    initialTouchX = event.rawX; initialTouchY = event.rawY
                    lastTouchDownTime = System.currentTimeMillis(); true
                }
                MotionEvent.ACTION_MOVE -> {
                    params!!.x = initialX + (event.rawX - initialTouchX).toInt()
                    params!!.y = initialY + (event.rawY - initialTouchY).toInt()
                    try { windowManager?.updateViewLayout(floatingView, params) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val dur   = System.currentTimeMillis() - lastTouchDownTime
                    val quiet = Math.abs(event.rawX - initialTouchX) < 12 &&
                                Math.abs(event.rawY - initialTouchY) < 12
                    if (dur < 350 && quiet)
                        startActivity(Intent(this, MainActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                        })
                    true
                }
                else -> false
            }
        }
    }

    fun atualizarValor() {
        try {
            val prefs    = getSharedPreferences("FluxoApp", MODE_PRIVATE)
            // FIX TEMA: reaplicar estilo sempre que atualiza (captura mudança de tema/modo)
            if (floatingView != null) aplicarEstiloTema()
            // FIX 10: só vai ao banco se mudou de dia ou é a primeira vez
            val sdfD = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault())
            val hoje  = sdfD.format(java.util.Date())
            if (hoje != cacheDataHoje) {
                // Novo dia — busca do banco e reseta cache
                val corridas = db?.buscarHoje() ?: return
                val resumo   = db?.resumo(corridas) ?: return
                cachedTotal    = resumo["total"] ?: 0f
                cachedCount    = corridas.size
                cacheDataHoje  = hoje
            }
            val total    = cachedTotal
            val meta     = prefs.getFloat("meta_diaria", 0f)

            floatingView?.findViewById<TextView>(R.id.tvFloatingEarnings)?.text =
                "R$ ${"%.2f".format(total).replace(".", ",")}"

            val pb    = floatingView?.findViewById<ProgressBar>(R.id.progressMeta)
            val tvPct = floatingView?.findViewById<TextView>(R.id.tvMetaPercent)

            if (meta > 0) {
                val pct = ((total / meta) * 100).toInt().coerceIn(0, 100)
                pb?.progress = pct
                pb?.visibility = View.VISIBLE
                tvPct?.text = "$pct%"
                tvPct?.visibility = View.VISIBLE
            } else {
                pb?.visibility = View.GONE
                tvPct?.visibility = View.GONE
            }
            atualizarNotificacao(total, cachedCount)
        } catch (_: Exception) {}
    }

    private fun criarCanalNotificacao() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val canal = NotificationChannel(CHANNEL_ID, "FluxoApp Ativo",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Monitorando corridas"; setShowBadge(false) }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(canal)
        }
    }

    private fun iniciarForeground() {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notif = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("FluxoApp")
            .setContentText("Monitorando corridas...")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pi).setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW).build()
        startForeground(NOTIF_ID, notif)
    }

    fun incrementarCache(valor: Float) {
        cachedTotal += valor
        cachedCount += 1
    }

    fun atualizarNotificacao(total: Float, corridas: Int) {
        try {
            val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val notif = NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("FluxoApp — R$ ${"%.2f".format(total).replace(".", ",")}")
                .setContentText("$corridas corridas hoje | Toque para abrir")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentIntent(pi).setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW).build()
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, notif)
        } catch (_: Exception) {}
    }
}
