package com.fluxoapp

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat

class FloatingEarningsService : Service() {
    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private var db: DatabaseHelper? = null
    private var params: WindowManager.LayoutParams? = null
    private var initialX = 0; private var initialY = 0
    private var initialTouchX = 0f; private var initialTouchY = 0f
    private var lastTouchDownTime = 0L
    // Animação de gradiente do botão flutuante
    private var gradientAnimator: android.animation.ValueAnimator? = null
    private var gradientAngle = 0f

    // FIX 10: cache do total do dia para evitar query ao banco a cada atualização
    private var cachedTotal = 0f
    private var cachedCount = 0
    private var cacheDataHoje = "" 

    // Receptor para mudança de tema
    private val temaReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            reiniciarComNovoTema()
        }
    }

    companion object {
        const val CHANNEL_ID = "fluxoapp_running"
        const val NOTIF_ID   = 1
        const val ACTION_ATUALIZAR = "ATUALIZAR"
        const val ACTION_TEMA      = "com.fluxoapp.TEMA_MUDOU"
        @Volatile var instanciaAtiva: FloatingEarningsService? = null
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instanciaAtiva = this
        criarCanalNotificacao()
        iniciarForeground()
        db = DatabaseHelper(this)
        // Registrar receptor de tema
        try {
            val filter = IntentFilter(ACTION_TEMA)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                registerReceiver(temaReceiver, filter, RECEIVER_NOT_EXPORTED)
            else
                registerReceiver(temaReceiver, filter)
        } catch (_: Throwable) {}
        mostrarBotao()
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(temaReceiver) } catch (_: Throwable) {}
        removerView()
        windowManager = null
        if (instanciaAtiva == this) instanciaAtiva = null
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_ATUALIZAR -> atualizarValor()
            ACTION_TEMA      -> reiniciarComNovoTema()
            else             -> if (floatingView == null) mostrarBotao() // restart safety
        }
        return START_STICKY
    }

    // ── Reinicia o botão do zero com o novo tema ──
    private fun reiniciarComNovoTema() {
        val posY = params?.y ?: 300
        removerView()
        mostrarBotao(posY)
    }

    private fun removerView() {
        floatingView?.let {
            try { windowManager?.removeView(it) } catch (_: Throwable) {}
        }
        floatingView = null
    }

    // ── Cria o botão na tela ──
    private fun mostrarBotao(posY: Int = 300) {
        try {
            if (windowManager == null)
                windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

            floatingView = LayoutInflater.from(this).inflate(R.layout.floating_earnings, null)
            aplicarEstiloTema()
            configurarPosicao(posY)
            atualizarValor()
            configurarToque()
            windowManager?.addView(floatingView, params)
        } catch (_: Throwable) {}
    }

    // ── Aplica as cores do tema atual no botão ──
    private fun aplicarEstiloTema() {
        val prefs  = getSharedPreferences("FluxoApp", MODE_PRIVATE)
        val accent = ThemeHelper.cor("accent_gold", prefs)
        val txtG   = ThemeHelper.cor("text_gray",   prefs)
        val bgDark = ThemeHelper.cor("bg_dark",      prefs)
        val bgCard = ThemeHelper.cor("bg_card",      prefs)
        val noite  = ThemeHelper.isModoNoturno(prefs)
        val isGold = ThemeHelper.getTema(prefs) == "gold"
        val dp     = resources.displayMetrics.density

        val root = floatingView?.findViewById<android.view.View>(R.id.floatingRoot)

        // Cores do gradiente baseadas no tema
        val gradStart: Int
        val gradMid: Int
        val gradEnd: Int
        val borderColor: Int
        val borderWidth: Float

        // Cores do flutuante variam por tema E modo dia/noite
        if (isGold && !noite) {
            // Gold Dia: fundo creme, borda dourada, texto preto
            gradStart   = android.graphics.Color.parseColor("#FFF8EC")
            gradMid     = android.graphics.Color.parseColor("#FAF0D7")
            gradEnd     = android.graphics.Color.parseColor("#F5E8C0")
            borderColor = accent  // dourado
        } else if (isGold && noite) {
            // Gold Noite: fundo escuro dourado, borda dourada
            gradStart   = android.graphics.Color.parseColor("#1E1A0E")
            gradMid     = android.graphics.Color.parseColor("#2C2410")
            gradEnd     = android.graphics.Color.parseColor("#1A1608")
            borderColor = accent
        } else if (!isGold && !noite) {
            // Azul Dia: fundo ciano, borda azul profundo, texto preto
            gradStart   = android.graphics.Color.parseColor("#00C8FF")
            gradMid     = android.graphics.Color.parseColor("#00A8D8")
            gradEnd     = android.graphics.Color.parseColor("#0090BB")
            borderColor = android.graphics.Color.parseColor("#003366")  // azul profundo
        } else {
            // Azul Noite: fundo azul escuro, borda ciano
            gradStart   = android.graphics.Color.parseColor("#0A1628")
            gradMid     = android.graphics.Color.parseColor("#0F1E36")
            gradEnd     = android.graphics.Color.parseColor("#081220")
            borderColor = accent  // ciano
        }
        borderWidth = 2.5f

        // Criar GradientDrawable com gradiente de 3 cores
        val gd = android.graphics.drawable.GradientDrawable(
            android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
            intArrayOf(gradStart, gradMid, gradEnd)
        ).apply {
            cornerRadius = 22f * dp
            setStroke((borderWidth * dp).toInt(), borderColor)
        }
        root?.background = gd

        // Iniciar animação de shimmer no gradiente
        iniciarAnimacaoGradiente(root, gradStart, gradMid, gradEnd, gradEnd, gradMid, gradStart)

        val accentList = android.content.res.ColorStateList.valueOf(accent)
        val accentAlpha = android.graphics.Color.argb(70,
            android.graphics.Color.red(accent),
            android.graphics.Color.green(accent),
            android.graphics.Color.blue(accent))

        // Texto preto nos temas claros (dia), accent nos escuros (noite)
        val isDiaClaro = !noite
        val corTexto = if (isDiaClaro) android.graphics.Color.BLACK else accent
        val corSecundario = if (isDiaClaro)
            android.graphics.Color.argb(160, 0, 0, 0)
        else txtG

        floatingView?.findViewById<TextView>(R.id.tvFloatingEarnings)?.setTextColor(corTexto)
        floatingView?.findViewById<TextView>(R.id.tvMetaPercent)?.setTextColor(corSecundario)

        val barraColor = if (isDiaClaro) android.graphics.Color.BLACK else accent
        val barraColorAlpha = android.graphics.Color.argb(40,
            android.graphics.Color.red(barraColor),
            android.graphics.Color.green(barraColor),
            android.graphics.Color.blue(barraColor))
        floatingView?.findViewById<ProgressBar>(R.id.progressMeta)?.apply {
            progressTintList = android.content.res.ColorStateList.valueOf(barraColor)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(barraColorAlpha)
        }
    }

    private fun iniciarAnimacaoGradiente(
        view: android.view.View?,
        c1: Int, c2: Int, c3: Int,
        c4: Int, c5: Int, c6: Int
    ) {
        gradientAnimator?.cancel()
        view ?: return
        val dp = resources.displayMetrics.density

        // Alterna suavemente entre dois gradientes (forward e reverse)
        gradientAnimator = android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2500L
            repeatCount = android.animation.ValueAnimator.INFINITE
            repeatMode  = android.animation.ValueAnimator.REVERSE
            addUpdateListener { anim ->
                val t = anim.animatedValue as Float
                val prefs2 = getSharedPreferences("FluxoApp", MODE_PRIVATE)
                val accent2 = ThemeHelper.cor("accent_gold", prefs2)
                val isGold2 = ThemeHelper.getTema(prefs2) == "gold"
                val noite2  = ThemeHelper.isModoNoturno(prefs2)
                val bw = 2.5f

                // Interpolar entre gradiente normal e reverso
                fun lerp(a: Int, b: Int, f: Float): Int {
                    val ar = android.graphics.Color.red(a);   val br = android.graphics.Color.red(b)
                    val ag = android.graphics.Color.green(a); val bg = android.graphics.Color.green(b)
                    val ab = android.graphics.Color.blue(a);  val bb = android.graphics.Color.blue(b)
                    return android.graphics.Color.rgb(
                        (ar + (br - ar) * f).toInt(),
                        (ag + (bg - ag) * f).toInt(),
                        (ab + (bb - ab) * f).toInt()
                    )
                }
                val i1 = lerp(c1, c4, t)
                val i2 = lerp(c2, c5, t)
                val i3 = lerp(c3, c6, t)

                val newGd = android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                    intArrayOf(i1, i2, i3)
                ).apply {
                    cornerRadius = 22f * dp
                    setStroke((bw * dp).toInt(), accent2)
                }
                try { view.background = newGd } catch (_: Throwable) {}
            }
            start()
        }
    }

    private fun configurarPosicao(posY: Int = 300) {
        val prefs   = getSharedPreferences("FluxoApp", MODE_PRIVATE)
        val posicao = prefs.getString("flutuante_posicao", "direita")
        val grav    = if (posicao == "esquerda") Gravity.TOP or Gravity.START else Gravity.TOP or Gravity.END
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = grav; x = 12; y = posY }
    }

    private fun configurarToque() {
        floatingView?.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params!!.x; initialY = params!!.y
                    initialTouchX = event.rawX; initialTouchY = event.rawY
                    lastTouchDownTime = System.currentTimeMillis(); true
                }
                MotionEvent.ACTION_MOVE -> {
                    params!!.x = initialX + (event.rawX - initialTouchX).toInt()
                    params!!.y = initialY + (event.rawY - initialTouchY).toInt()
                    try { windowManager?.updateViewLayout(floatingView, params) } catch (_: Throwable) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val dur   = System.currentTimeMillis() - lastTouchDownTime
                    val quiet = Math.abs(event.rawX - initialTouchX) < 12 &&
                                Math.abs(event.rawY - initialTouchY) < 12
                    if (dur < 350 && quiet)
                        startActivity(Intent(this, MainActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                        })
                    true
                }
                else -> false
            }
        }
    }

    fun atualizarValor() {
        try {
            val prefs = getSharedPreferences("FluxoApp", MODE_PRIVATE)
            if (floatingView != null) aplicarEstiloTema()

            // SEMPRE busca do banco ao receber ATUALIZAR
            // (corrida nova adicionada — cache precisa ser renovado)
            val corridas = db?.buscarHoje() ?: return
            val resumo   = db?.resumo(corridas) ?: return
            cachedTotal   = resumo["total"] ?: 0f
            cachedCount   = corridas.size
            val sdfD      = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault())
            cacheDataHoje = sdfD.format(java.util.Date())
            val total    = cachedTotal
            val meta     = prefs.getFloat("meta_diaria", 0f)

            floatingView?.findViewById<TextView>(R.id.tvFloatingEarnings)?.text =
                "R$ ${"%.2f".format(total).replace(".", ",")}"

            val pb    = floatingView?.findViewById<ProgressBar>(R.id.progressMeta)
            val tvPct = floatingView?.findViewById<TextView>(R.id.tvMetaPercent)

            if (meta > 0) {
                val pct = ((total / meta) * 100).toInt().coerceIn(0, 100)
                pb?.progress = pct
                pb?.visibility = View.VISIBLE
                tvPct?.text = "$pct%"
                tvPct?.visibility = View.VISIBLE
            } else {
                pb?.visibility = View.GONE
                tvPct?.visibility = View.GONE
            }
            atualizarNotificacao(total, cachedCount)
        } catch (_: Throwable) {}
    }

    private fun criarCanalNotificacao() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val canal = NotificationChannel(CHANNEL_ID, "FluxoApp Ativo",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Monitorando corridas"; setShowBadge(false) }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(canal)
        }
    }

    private fun iniciarForeground() {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notif = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("FluxoApp")
            .setContentText("Monitorando corridas...")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pi).setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW).build()
        startForeground(NOTIF_ID, notif)
    }

    fun incrementarCache(valor: Float) {
        cachedTotal += valor
        cachedCount += 1
    }

    fun atualizarNotificacao(total: Float, corridas: Int) {
        try {
            val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val notif = NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("FluxoApp — R$ ${"%.2f".format(total).replace(".", ",")}")
                .setContentText("$corridas corridas hoje | Toque para abrir")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentIntent(pi).setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW).build()
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, notif)
        } catch (_: Throwable) {}
    }
}
