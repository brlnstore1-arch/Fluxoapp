package com.fluxoapp

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat

class FloatingEarningsService : Service() {
    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private var db: DatabaseHelper? = null
    private var params: WindowManager.LayoutParams? = null
    private var initialX = 0; private var initialY = 0
    private var initialTouchX = 0f; private var initialTouchY = 0f
    private var lastTouchDownTime = 0L

    companion object {
        const val CHANNEL_ID = "fluxoapp_running"
        const val NOTIF_ID = 1
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        criarCanalNotificacao()
        iniciarForeground()
        db = DatabaseHelper(this)
        mostrarBotao()
    }

    private fun criarCanalNotificacao() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val canal = NotificationChannel(
                CHANNEL_ID, "FluxoApp Ativo",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Monitorando corridas"
                setShowBadge(false)
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(canal)
        }
    }

    private fun iniciarForeground() {
        val intent = Intent(this, MainActivity::class.java)
        val pi = PendingIntent.getActivity(this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val notif = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("FluxoApp")
            .setContentText("Monitorando corridas...")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        startForeground(NOTIF_ID, notif)
    }

    fun atualizarNotificacao(total: Float, corridas: Int) {
        try {
            val intent = Intent(this, MainActivity::class.java)
            val pi = PendingIntent.getActivity(this, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val notif = NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("FluxoApp — R$ ${"%.2f".format(total)}")
                .setContentText("$corridas corridas hoje | Toque para abrir")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentIntent(pi)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build()
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .notify(NOTIF_ID, notif)
        } catch (_: Exception) {}
    }

    private fun mostrarBotao() {
        try {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            floatingView = LayoutInflater.from(this).inflate(R.layout.floating_earnings, null)
            val prefs = getSharedPreferences("FluxoApp", MODE_PRIVATE)
            val posicao = prefs.getString("flutuante_posicao", "esquerda")
            val gravidade = if (posicao == "direita") Gravity.TOP or Gravity.END else Gravity.TOP or Gravity.START
            params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = gravidade; x = 0; y = 300 }
            atualizarValor()
            floatingView!!.setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params!!.x; initialY = params!!.y
                        initialTouchX = event.rawX; initialTouchY = event.rawY
                        lastTouchDownTime = System.currentTimeMillis(); true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params!!.x = initialX + (event.rawX - initialTouchX).toInt()
                        params!!.y = initialY + (event.rawY - initialTouchY).toInt()
                        windowManager?.updateViewLayout(floatingView, params); true
                    }
                    MotionEvent.ACTION_UP -> {
                        val duration = System.currentTimeMillis() - lastTouchDownTime
                        val notMoved = Math.abs(event.rawX - initialTouchX) < 10 &&
                                       Math.abs(event.rawY - initialTouchY) < 10
                        if (duration < 300 && notMoved) {
                            startActivity(Intent(this, MainActivity::class.java).apply {
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                            })
                        }
                        true
                    }
                    else -> false
                }
            }
            windowManager?.addView(floatingView, params)
        } catch (_: Exception) {}
    }

    fun atualizarValor() {
        try {
            val prefs = getSharedPreferences("FluxoApp", MODE_PRIVATE)
            val corridas = db?.buscarHoje() ?: return
            val resumo = db?.resumo(corridas) ?: return
            val total = resumo["total"] ?: 0f
            val meta = prefs.getFloat("meta_diaria", 0f)
            val qtd = corridas.size

            floatingView?.findViewById<TextView>(R.id.tvFloatingEarnings)
                ?.text = "R$ ${"%.2f".format(total)}"

            val progressBar = floatingView?.findViewById<ProgressBar>(R.id.progressMeta)
            val tvMeta = floatingView?.findViewById<TextView>(R.id.tvMetaPercent)
            if (meta > 0) {
                progressBar?.visibility = android.view.View.VISIBLE
                tvMeta?.visibility = android.view.View.VISIBLE
                val percent = ((total / meta) * 100).toInt().coerceIn(0, 100)
                progressBar?.progress = percent
                tvMeta?.text = "$percent%"
            } else {
                progressBar?.visibility = android.view.View.GONE
                tvMeta?.visibility = android.view.View.GONE
            }
            atualizarNotificacao(total, qtd)
        } catch (_: Exception) {}
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "ATUALIZAR") atualizarValor()
        return START_STICKY  // reinicia automaticamente se for morto
    }

    override fun onDestroy() {
        super.onDestroy()
        floatingView?.let { try { windowManager?.removeView(it) } catch (_: Exception) {} }
        floatingView = null
        windowManager = null
    }
}
