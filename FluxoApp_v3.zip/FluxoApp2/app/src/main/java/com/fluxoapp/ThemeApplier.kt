package com.fluxoapp

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar

/**
 * Aplica o tema atual (azul/gold, dia/noite) na activity.
 * Chama de qualquer Activity em onCreate() e onResume().
 */
fun AppCompatActivity.aplicarTemaGlobal() {
    val prefs   = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
    val bgDark  = ThemeHelper.cor("bg_dark",    prefs)
    val bgCard  = ThemeHelper.cor("bg_card",    prefs)
    val bgSect  = ThemeHelper.cor("bg_section", prefs)
    val toolbar = ThemeHelper.cor("toolbar",    prefs)
    val txtW    = ThemeHelper.cor("text_white", prefs)
    val txtG    = ThemeHelper.cor("text_gray",  prefs)
    val txtL    = ThemeHelper.cor("text_light", prefs)
    val cyan    = ThemeHelper.cor("accent_cyan",  prefs)
    val green   = ThemeHelper.cor("accent_green", prefs)
    val red     = ThemeHelper.cor("accent_red",   prefs)
    val gold    = ThemeHelper.cor("accent_gold",  prefs)
    val border  = ThemeHelper.cor("border",       prefs)
    val dp      = resources.displayMetrics.density

    fun card(bg: Int, radius: Float, strokeColor: Int = 0, sw: Float = 0f) =
        GradientDrawable().apply {
            setColor(bg); cornerRadius = radius * dp
            if (sw > 0) setStroke((sw * dp).toInt(), strokeColor)
        }

    // Root background
    try { findViewById<View>(R.id.rootLayout)?.setBackgroundColor(bgDark) } catch (_: Exception) {}
    try { findViewById<View>(R.id.rootLayoutHistory)?.setBackgroundColor(bgDark) } catch (_: Exception) {}

    // Toolbar / header bar
    try {
        val tb = findViewById<View>(R.id.toolbar)
        tb?.setBackgroundColor(toolbar)
    } catch (_: Exception) {}
    // Toolbar genérica (LinearLayout de 56dp que serve de header)
    try {
        val headerBar = findHeaderBar()
        headerBar?.setBackgroundColor(toolbar)
    } catch (_: Exception) {}

    // Botão voltar
    try { findViewById<ImageButton>(R.id.btnVoltar)?.setColorFilter(cyan) } catch (_: Exception) {}

    // Textos de título
    for (id in listOf(R.id.tvTitulo, R.id.tvVersao)) {
        try { findViewById<TextView>(id)?.setTextColor(cyan) } catch (_: Exception) {}
    }

    // Todos os TextViews principais
    varreTextViews(window.decorView, bgDark, bgCard, bgSect, txtW, txtG, txtL, cyan, green, gold, red, border, dp)
}

private fun AppCompatActivity.findHeaderBar(): View? {
    // Tenta encontrar o primeiro LinearLayout filho direto do root com altura 56dp
    val root = try { findViewById<View>(android.R.id.content) } catch (_: Exception) { null } ?: return null
    return null // Deixa o varreTextViews cuidar
}

private fun AppCompatActivity.varreTextViews(
    root: View,
    bgDark: Int, bgCard: Int, bgSect: Int,
    txtW: Int, txtG: Int, txtL: Int,
    cyan: Int, green: Int, gold: Int, red: Int,
    border: Int, dp: Float
) {
    if (root !is android.view.ViewGroup) return
    for (i in 0 until root.childCount) {
        val v = root.getChildAt(i)
        aplicarCoresView(v, bgDark, bgCard, bgSect, txtW, txtG, txtL, cyan, green, gold, red, border, dp)
        if (v is android.view.ViewGroup) varreTextViews(v, bgDark, bgCard, bgSect, txtW, txtG, txtL, cyan, green, gold, red, border, dp)
    }
}

private fun aplicarCoresView(
    v: View,
    bgDark: Int, bgCard: Int, bgSect: Int,
    txtW: Int, txtG: Int, txtL: Int,
    cyan: Int, green: Int, gold: Int, red: Int,
    border: Int, dp: Float
) {
    try {
        val tag = v.tag?.toString() ?: ""
        when {
            tag.contains("header")  -> v.setBackgroundColor(bgCard)
            tag.contains("card")    -> v.setBackgroundColor(bgCard)
            tag.contains("section") -> v.setBackgroundColor(bgSect)
        }
    } catch (_: Exception) {}

    // ScrollView e LinearLayout principais → bg_dark
    if (v is ScrollView || v is android.widget.ListView) {
        try { v.setBackgroundColor(bgDark) } catch (_: Exception) {}
    }

    if (v is TextView) {
        try {
            val cur = v.currentTextColor
            when {
                cur == Color.WHITE || cur == Color.parseColor("#F0F0F5") ||
                cur == Color.parseColor("#E8F0FE") || cur == Color.parseColor("#F5F0E8")
                    -> v.setTextColor(txtW)
                cur == Color.parseColor("#7A9CC0") || cur == Color.parseColor("#7A6A50")
                    -> v.setTextColor(txtL)
            }
        } catch (_: Exception) {}
    }

    // CardView
    if (v is androidx.cardview.widget.CardView) {
        try { v.setCardBackgroundColor(bgCard) } catch (_: Exception) {}
    }
}
