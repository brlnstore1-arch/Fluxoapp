package com.fluxoapp

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.widget.Toolbar
import androidx.cardview.widget.CardView
import com.google.android.material.navigation.NavigationView

/**
 * ThemeApplier — varredura completa de todas as views.
 * Cobre 100% dos casos: temas claros e escuros, botões, inputs,
 * switches, progress bars, radio buttons, drawables coloridos.
 */
fun androidx.appcompat.app.AppCompatActivity.aplicarTemaGlobal() {
    try {
        val prefs  = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val t      = Cores(prefs, resources.displayMetrics.density)
        val raiz   = findViewById<View>(android.R.id.content) ?: return
        val fila   = ArrayDeque<View>()
        fila.add(raiz)
        while (fila.isNotEmpty()) {
            val v = fila.removeFirst()
            try { aplicarNaView(v, t) } catch (_: Throwable) {}
            if (v is NavigationView) continue
            if (v is ViewGroup) {
                for (i in 0 until v.childCount) {
                    try { v.getChildAt(i)?.let { fila.add(it) } } catch (_: Throwable) {}
                }
            }
        }
        // Aplicar escala de fonte global
        ThemeHelper.aplicarEscalaFonte(raiz, prefs)
    } catch (_: Throwable) {}
}

/** Agrupa todas as cores do tema atual em um objeto único. */
private data class Cores(
    val bgDark: Int, val bgCard: Int, val bgSect: Int, val toolbar: Int,
    val txtW: Int, val txtG: Int, val txtL: Int,
    val accent: Int, val green: Int, val red: Int, val border: Int,
    val dp: Float, val isGold: Boolean, val isNoturno: Boolean
) {
    constructor(prefs: android.content.SharedPreferences, dp: Float) : this(
        bgDark   = ThemeHelper.cor("bg_dark",      prefs),
        bgCard   = ThemeHelper.cor("bg_card",      prefs),
        bgSect   = ThemeHelper.cor("bg_section",   prefs),
        toolbar  = ThemeHelper.cor("toolbar",      prefs),
        txtW     = ThemeHelper.cor("text_white",   prefs),
        txtG     = ThemeHelper.cor("text_gray",    prefs),
        txtL     = ThemeHelper.cor("text_light",   prefs),
        accent   = ThemeHelper.cor("accent",       prefs),
        green    = ThemeHelper.cor("accent_green", prefs),
        red      = ThemeHelper.cor("accent_red",   prefs),
        border   = ThemeHelper.cor("border",       prefs),
        dp       = dp,
        isGold   = ThemeHelper.getTema(prefs) == "gold",
        isNoturno = ThemeHelper.isModoNoturno(prefs)
    )
}

/** Cores de texto de TODOS os temas — para detectar e remapear. */
private val ACCENT_COLORS = setOf(
    0xFF00C8FF.toInt(), 0xFF0055BB.toInt(), // Azul noite/dia
    0xFFC9A84C.toInt(), 0xFF8A6010.toInt()  // Gold noite/dia
)
private val WHITE_COLORS = setOf(
    0xFFE8F0FE.toInt(), 0xFF0A1E3C.toInt(), // Azul noite/dia
    0xFFF0EAD6.toInt(), 0xFF1C1408.toInt()  // Gold noite/dia
)
private val GRAY_COLORS = setOf(
    0xFF3A6090.toInt(), 0xFF4A7AAA.toInt(), // Azul noite/dia
    0xFF8A7A60.toInt(), 0xFF7A6040.toInt()  // Gold noite/dia
)
private val LIGHT_COLORS = setOf(
    0xFF7A9CC0.toInt(), 0xFF5A8ABB.toInt(), // Azul noite/dia
    0xFFA09070.toInt(), 0xFF9A8060.toInt()  // Gold noite/dia
)
private val GREEN_COLORS = setOf(
    0xFF00E676.toInt(), 0xFF00875A.toInt(),
    0xFF4CAF7D.toInt(), 0xFF3A8A5A.toInt()
)
private val RED_COLORS = setOf(
    0xFFFF4560.toInt(), 0xFFC0392B.toInt(), 0xFFE05C5C.toInt()
)
/** Cores de fundo de todos os temas → qual slot pertencem. */
private val BG_CORES = mapOf(
    0xFF0A1628.toInt() to "dark", 0xFF0F1E36.toInt() to "card", 0xFF132240.toInt() to "sect",
    0xFFE8F2FF.toInt() to "dark", 0xFFD0E8FF.toInt() to "card", 0xFFB8D8F8.toInt() to "sect",
    0xFF111111.toInt() to "dark", 0xFF1C1C1C.toInt() to "card", 0xFF262626.toInt() to "sect",
    0xFFF5F0E8.toInt() to "dark", 0xFFEDE8DC.toInt() to "card", 0xFFE0D8C8.toInt() to "sect"
)

private fun aplicarNaView(v: View, t: Cores) {
    val tag = try { v.tag?.toString() ?: "" } catch (_: Throwable) { "" }

    // ── Tags explícitas no XML ───────────────────────────────────────────
    when (tag) {
        "bg_dark"    -> { v.setBackgroundColor(t.bgDark); return }
        "bg_card", "card" -> { v.setBackgroundColor(t.bgCard); return }
        "bg_section", "section" -> { v.setBackgroundColor(t.bgSect); return }
        "toolbar_bg" -> { v.setBackgroundColor(t.toolbar); return }
        "divider"    -> { v.setBackgroundColor(t.accent); return }
        "accent"     -> { if (v is TextView) v.setTextColor(t.accent); return }
        "text_gray"  -> { if (v is TextView) v.setTextColor(t.txtG); return }
        "text_white" -> { if (v is TextView) v.setTextColor(t.txtW); return }
        "btn_solid"  -> {
            v.background = gd(t.accent, 10f, t.dp)
            if (v is TextView) v.setTextColor(Color.BLACK)
            return
        }
        "btn_outline" -> {
            v.background = gdOutline(t.accent, 10f, t.dp)
            if (v is TextView) v.setTextColor(t.accent)
            return
        }
        "btn_red"    -> {
            v.background = gd(t.red, 10f, t.dp)
            if (v is TextView) v.setTextColor(Color.WHITE)
            return
        }
        "btn_green"  -> {
            v.background = gd(t.green, 10f, t.dp)
            if (v is TextView) v.setTextColor(Color.WHITE)
            return
        }
    }

    // ── CardView ─────────────────────────────────────────────────────────
    if (v is CardView) {
        try { v.setCardBackgroundColor(t.bgCard) } catch (_: Throwable) {}
        return
    }

    // ── Toolbar ──────────────────────────────────────────────────────────
    if (v is Toolbar) {
        try { v.setBackgroundColor(t.toolbar) } catch (_: Throwable) {}
        return
    }

    // ── NavigationView ───────────────────────────────────────────────────
    if (v is NavigationView) {
        try {
            v.setBackgroundColor(t.bgCard)
            val cl = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(t.accent, t.txtW)
            )
            v.itemTextColor    = cl
            v.itemIconTintList = ColorStateList.valueOf(t.accent)
        } catch (_: Throwable) {}
        return
    }

    // ── ScrollView / ListView ────────────────────────────────────────────
    if (v is ScrollView || v is ListView) {
        try { v.setBackgroundColor(t.bgDark) } catch (_: Throwable) {}
    }

    // ── Fundo ColorDrawable — remapear cores de tema ──────────────────────
    try {
        val bg = v.background
        if (bg is ColorDrawable && v !is Button && v !is TextView) {
            val slot = BG_CORES[bg.color]
            if (slot != null) {
                v.setBackgroundColor(when (slot) {
                    "dark" -> t.bgDark
                    "card" -> t.bgCard
                    "sect" -> t.bgSect
                    else   -> return
                })
            }
        }
    } catch (_: Throwable) {}

    // ── EditText ──────────────────────────────────────────────────────────
    if (v is EditText) {
        try {
            v.setTextColor(t.txtW)
            v.setHintTextColor(t.txtG)
            // Fundo do campo
            try {
                val bg = v.background
                if (bg is ColorDrawable || BG_CORES.containsKey((bg as? ColorDrawable)?.color)) {
                    v.background = GradientDrawable().apply {
                        setColor(t.bgCard)
                        cornerRadius = 8f * t.dp
                        setStroke((1f * t.dp).toInt(), t.border)
                    }
                }
            } catch (_: Throwable) {}
        } catch (_: Throwable) {}
        return
    }

    // ── TextView simples (não Button, RadioButton, CheckBox, Switch) ──────
    if (v is TextView && v !is Button && v !is RadioButton
        && v !is CheckBox && v !is Switch) {
        try {
            when (val cur = v.currentTextColor) {
                in ACCENT_COLORS -> v.setTextColor(t.accent)
                in WHITE_COLORS  -> v.setTextColor(t.txtW)
                in GRAY_COLORS   -> v.setTextColor(t.txtG)
                in LIGHT_COLORS  -> v.setTextColor(t.txtL)
                in GREEN_COLORS  -> v.setTextColor(t.green)
                in RED_COLORS    -> v.setTextColor(t.red)
            }
        } catch (_: Throwable) {}
        return
    }

    // ── Button ────────────────────────────────────────────────────────────
    if (v is Button && v !is RadioButton && v !is CheckBox && v !is Switch) {
        try {
            val txtCor = v.currentTextColor
            val bgDrw  = v.background

            // Botão vermelho (apagar/excluir) — identificar pelo drawable btn_red
            // ou pelo texto em vermelho
            val isRed = txtCor in RED_COLORS ||
                        (bgDrw is GradientDrawable &&
                         try { bgDrw.color?.defaultColor?.let { it in RED_COLORS } == true }
                         catch(_: Throwable) { false })

            val isGreen = txtCor in GREEN_COLORS ||
                          (bgDrw is ColorDrawable && bgDrw.color in GREEN_COLORS)

            when {
                isRed -> {
                    v.background = gd(t.red, 10f, t.dp)
                    v.setTextColor(Color.WHITE)
                }
                isGreen -> {
                    v.background = gd(t.green, 10f, t.dp)
                    v.setTextColor(Color.WHITE)
                }
                // Botão outline (texto na cor accent, fundo transparente)
                txtCor in ACCENT_COLORS -> {
                    v.setTextColor(t.accent)
                    v.background = gdOutline(t.accent, 10f, t.dp)
                }
                // Botão sólido (texto preto → fundo accent)
                txtCor == Color.BLACK || txtCor == 0xFF000000.toInt() ||
                txtCor == 0xFF001A00.toInt() -> {
                    v.setTextColor(Color.BLACK)
                    v.background = gd(t.accent, 10f, t.dp)
                }
                // Botão com texto branco/cinza — manter cor mas atualizar
                txtCor in WHITE_COLORS -> v.setTextColor(t.txtW)
                txtCor in GRAY_COLORS  -> v.setTextColor(t.txtG)
            }
        } catch (_: Throwable) {}
        return
    }

    // ── ImageButton / ImageView tint ──────────────────────────────────────
    if (v is ImageButton || v is ImageView) {
        try {
            val tl  = (v as? ImageButton)?.imageTintList ?: (v as? ImageView)?.imageTintList
            val cur = tl?.defaultColor ?: return
            if (cur in ACCENT_COLORS) {
                val cl = ColorStateList.valueOf(t.accent)
                (v as? ImageButton)?.imageTintList = cl
                (v as? ImageView)?.imageTintList   = cl
            }
        } catch (_: Throwable) {}
        return
    }

    // ── Switch ────────────────────────────────────────────────────────────
    if (v is Switch) {
        try {
            val on  = t.accent
            val off = if (t.isNoturno) 0xFF555555.toInt() else 0xFFAAAAAA.toInt()
            val cl  = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(on, off)
            )
            v.thumbTintList = cl
            v.trackTintList = cl
            v.setTextColor(t.txtW)
        } catch (_: Throwable) {}
        return
    }

    // ── RadioButton ───────────────────────────────────────────────────────
    if (v is RadioButton) {
        try {
            v.setTextColor(t.txtW)
            v.buttonTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(t.accent, t.txtG)
            )
        } catch (_: Throwable) {}
        return
    }

    // ── CheckBox ──────────────────────────────────────────────────────────
    if (v is CheckBox) {
        try {
            v.setTextColor(t.txtW)
            v.buttonTintList = ColorStateList.valueOf(t.accent)
        } catch (_: Throwable) {}
        return
    }

    // ── SeekBar ───────────────────────────────────────────────────────────
    if (v is SeekBar) {
        try {
            val cl = ColorStateList.valueOf(t.accent)
            v.progressTintList = cl
            v.thumbTintList    = cl
            v.progressBackgroundTintList = ColorStateList.valueOf(t.border)
        } catch (_: Throwable) {}
        return
    }

    // ── ProgressBar ───────────────────────────────────────────────────────
    if (v is ProgressBar) {
        try { v.progressTintList = ColorStateList.valueOf(t.accent) } catch (_: Throwable) {}
        return
    }
}

// ── Helpers de drawable ────────────────────────────────────────────────────
private fun gd(cor: Int, radius: Float, dp: Float) =
    GradientDrawable().apply { setColor(cor); cornerRadius = radius * dp }

private fun gdOutline(cor: Int, radius: Float, dp: Float) =
    GradientDrawable().apply {
        setColor(Color.TRANSPARENT)
        cornerRadius = radius * dp
        setStroke((1.5f * dp).toInt(), cor)
    }
