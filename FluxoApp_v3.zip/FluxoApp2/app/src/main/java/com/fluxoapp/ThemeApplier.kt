package com.fluxoapp

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.widget.Toolbar
import androidx.cardview.widget.CardView
import com.google.android.material.navigation.NavigationView

fun androidx.appcompat.app.AppCompatActivity.aplicarTemaGlobal() {
    try {
        val prefs  = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val t      = Cores(prefs, resources.displayMetrics.density)
        val raiz   = findViewById<View>(android.R.id.content) ?: return
        val fila   = ArrayDeque<View>()
        fila.add(raiz)
        while (fila.isNotEmpty()) {
            val v = fila.removeFirst()
            try { aplicarNaView(v, t) } catch (_: Throwable) {}
            if (v is NavigationView) continue
            if (v is ViewGroup) {
                for (i in 0 until v.childCount) {
                    try { v.getChildAt(i)?.let { fila.add(it) } } catch (_: Throwable) {}
                }
            }
        }
        ThemeHelper.aplicarEscalaFonte(raiz, prefs)
    } catch (_: Throwable) {}
}

private data class Cores(
    val bgDark: Int, val bgCard: Int, val bgSect: Int, val toolbar: Int,
    val txtW: Int, val txtG: Int, val txtL: Int,
    val accent: Int, val green: Int, val red: Int, val border: Int,
    val dp: Float, val isGold: Boolean, val isNoturno: Boolean
) {
    constructor(prefs: android.content.SharedPreferences, dp: Float) : this(
        bgDark   = ThemeHelper.cor("bg_dark",      prefs),
        bgCard   = ThemeHelper.cor("bg_card",      prefs),
        bgSect   = ThemeHelper.cor("bg_section",   prefs),
        toolbar  = ThemeHelper.cor("toolbar",      prefs),
        txtW     = ThemeHelper.cor("text_white",   prefs),
        txtG     = ThemeHelper.cor("text_gray",    prefs),
        txtL     = ThemeHelper.cor("text_light",   prefs),
        accent   = ThemeHelper.cor("accent",       prefs),
        green    = ThemeHelper.cor("accent_green", prefs),
        red      = ThemeHelper.cor("accent_red",   prefs),
        border   = ThemeHelper.cor("border",       prefs),
        dp       = dp,
        isGold   = ThemeHelper.getTema(prefs) == "gold",
        isNoturno = ThemeHelper.isModoNoturno(prefs)
    )
}

private val ACCENT_COLORS = setOf(
    0xFF00C8FF.toInt(), 0xFF0055BB.toInt(),
    0xFFC9A84C.toInt(), 0xFF8A6010.toInt()
)
private val WHITE_COLORS = setOf(
    0xFFE8F0FE.toInt(), 0xFF0A1E3C.toInt(),
    0xFFF0EAD6.toInt(), 0xFF1C1408.toInt()
)
private val GRAY_COLORS = setOf(
    0xFF3A6090.toInt(), 0xFF3A6690.toInt(),
    0xFF8A7A60.toInt(), 0xFF6A5030.toInt()
)
private val LIGHT_COLORS = setOf(
    0xFF7A9CC0.toInt(), 0xFF5A8ABB.toInt(),
    0xFFA09070.toInt(), 0xFF9A8060.toInt()
)
private val GREEN_COLORS = setOf(
    0xFF00E676.toInt(), 0xFF00875A.toInt(),
    0xFF4CAF7D.toInt(), 0xFF3A8A5A.toInt()
)
private val RED_COLORS = setOf(
    0xFFFF4560.toInt(), 0xFFC0392B.toInt(), 0xFFE05C5C.toInt()
)

/**
 * Mapa de todas as cores de fundo de todos os temas + cores hardcoded
 * que devem ser remapeadas para o slot correto do tema ativo.
 */
private val BG_CORES = mapOf(
    // Azul Noite
    0xFF0A1628.toInt() to "dark", 0xFF0F1E36.toInt() to "card", 0xFF132240.toInt() to "sect",
    // Azul Dia
    0xFFE8F2FF.toInt() to "dark", 0xFFD0E8FF.toInt() to "card", 0xFFA8CCF0.toInt() to "sect",
    // Gold Noite
    0xFF111111.toInt() to "dark", 0xFF1C1C1C.toInt() to "card", 0xFF262626.toInt() to "sect",
    // Gold Dia
    0xFFF5F0E8.toInt() to "dark", 0xFFEDE8DC.toInt() to "card", 0xFFD4C8B0.toInt() to "sect",
    // Hardcoded escuros → mapeados para "card" (origem: drawables antigos)
    0xFF111108.toInt() to "card",
    0xFF1A1610.toInt() to "card",
    0xFF1A1600.toInt() to "card",
    0xFF0E0E0E.toInt() to "dark",
    0xFF16161F.toInt() to "card",
    0xFF1A1A2A.toInt() to "card"
)

/** Resolve o slot → cor do tema atual */
private fun Cores.resolverSlot(slot: String): Int = when (slot) {
    "dark" -> bgDark
    "card" -> bgCard
    "sect" -> bgSect
    else   -> bgCard
}

/** Tenta remapear uma GradientDrawable (shape XML) para as cores do tema */
private fun remapearGradientDrawable(bg: GradientDrawable, t: Cores) {
    try {
        val fillColor = bg.color?.defaultColor ?: return
        val slot = BG_CORES[fillColor] ?: return
        bg.mutate()
        bg.setColor(t.resolverSlot(slot))
        // Atualiza a cor do stroke para a borda do tema atual
        try { bg.setStroke((1f * t.dp).toInt(), t.border) } catch (_: Throwable) {}
    } catch (_: Throwable) {}
}

/** Tenta remapear qualquer drawable (ColorDrawable ou GradientDrawable) */
private fun remapearBackground(v: View, t: Cores) {
    try {
        when (val bg = v.background) {
            is ColorDrawable -> {
                val slot = BG_CORES[bg.color] ?: return
                v.setBackgroundColor(t.resolverSlot(slot))
            }
            is GradientDrawable -> {
                remapearGradientDrawable(bg, t)
            }
            is LayerDrawable -> {
                // Percorre as camadas do LayerDrawable (ex: card com stroke)
                for (i in 0 until bg.numberOfLayers) {
                    val layer = bg.getDrawable(i)
                    if (layer is GradientDrawable) remapearGradientDrawable(layer, t)
                }
            }
            is StateListDrawable -> {
                // StateListDrawable (ex: qa_card_bg selector) — tentar via reflexão no estado padrão
                try {
                    val m = StateListDrawable::class.java.getDeclaredMethod("getStateDrawable", Int::class.java)
                    m.isAccessible = true
                    val count = bg.stateCount
                    for (i in 0 until count) {
                        val d = m.invoke(bg, i)
                        if (d is GradientDrawable) remapearGradientDrawable(d, t)
                    }
                } catch (_: Throwable) {}
            }
        }
    } catch (_: Throwable) {}
}

private fun aplicarNaView(v: View, t: Cores) {
    val tag = try { v.tag?.toString() ?: "" } catch (_: Throwable) { "" }

    // Item 4 — proteção explícita: views marcadas assim já têm seu estado
    // visual controlado por lógica própria (ex: botão Salvar com estado
    // dinâmico de "alterações pendentes"). A repintura heurística genérica
    // NUNCA deve sobrescrever esses casos.
    if (tag == "no_theme_override") return

    // ── Tags explícitas no XML ──────────────────────────────────
    when (tag) {
        "bg_dark"    -> { v.setBackgroundColor(t.bgDark); return }
        "bg_card", "card" -> { v.setBackgroundColor(t.bgCard); return }
        "bg_section", "section" -> { v.setBackgroundColor(t.bgSect); return }
        "toolbar_bg" -> { v.setBackgroundColor(t.toolbar); return }
        "divider"    -> { v.setBackgroundColor(t.accent); return }
        "accent"     -> { if (v is TextView) v.setTextColor(t.accent); return }
        "text_gray"  -> { if (v is TextView) v.setTextColor(t.txtG); return }
        "text_white" -> { if (v is TextView) v.setTextColor(t.txtW); return }
        "btn_solid"  -> {
            v.background = gd(t.accent, 10f, t.dp)
            if (v is TextView) v.setTextColor(Color.BLACK)
            return
        }
        "btn_outline" -> {
            v.background = gdOutline(t.accent, 10f, t.dp)
            if (v is TextView) v.setTextColor(t.accent)
            return
        }
        "btn_red"    -> {
            v.background = gd(t.red, 10f, t.dp)
            if (v is TextView) v.setTextColor(Color.WHITE)
            return
        }
        "btn_green"  -> {
            v.background = gd(t.green, 10f, t.dp)
            if (v is TextView) v.setTextColor(Color.WHITE)
            return
        }
    }

    // ── CardView ─────────────────────────────────────────────────
    if (v is CardView) {
        try { v.setCardBackgroundColor(t.bgCard) } catch (_: Throwable) {}
        return
    }

    // ── Toolbar ──────────────────────────────────────────────────
    if (v is Toolbar) {
        try { v.setBackgroundColor(t.toolbar) } catch (_: Throwable) {}
        return
    }

    // ── NavigationView ───────────────────────────────────────────
    if (v is NavigationView) {
        try {
            v.setBackgroundColor(t.bgCard)
            val cl = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(t.accent, t.txtW)
            )
            v.itemTextColor    = cl
            v.itemIconTintList = ColorStateList.valueOf(t.accent)
        } catch (_: Throwable) {}
        return
    }

    // ── ScrollView / ListView ─────────────────────────────────────
    if (v is ScrollView || v is ListView) {
        try { v.setBackgroundColor(t.bgDark) } catch (_: Throwable) {}
    }

    // ── EditText ──────────────────────────────────────────────────
    if (v is EditText) {
        try {
            v.setTextColor(t.txtW)
            v.setHintTextColor(t.txtG)
            try {
                val bg = v.background
                if (bg is ColorDrawable && BG_CORES.containsKey(bg.color)) {
                    v.background = GradientDrawable().apply {
                        setColor(t.bgCard)
                        cornerRadius = 8f * t.dp
                        setStroke((1f * t.dp).toInt(), t.border)
                    }
                } else if (bg is GradientDrawable) {
                    val fillColor = try { bg.color?.defaultColor } catch (_: Throwable) { null }
                    if (fillColor != null && BG_CORES.containsKey(fillColor)) {
                        bg.mutate()
                        bg.setColor(t.bgCard)
                        bg.setStroke((1f * t.dp).toInt(), t.border)
                    }
                }
            } catch (_: Throwable) {}
        } catch (_: Throwable) {}
        return
    }

    // ── Button ────────────────────────────────────────────────────
    if (v is Button && v !is RadioButton && v !is CheckBox && v !is Switch) {
        try {
            val txtCor = v.currentTextColor
            val bgDrw  = v.background

            val isRed = txtCor in RED_COLORS ||
                        (bgDrw is GradientDrawable &&
                         try { bgDrw.color?.defaultColor?.let { it in RED_COLORS } == true }
                         catch(_: Throwable) { false })

            val isGreen = txtCor in GREEN_COLORS ||
                          (bgDrw is ColorDrawable && bgDrw.color in GREEN_COLORS)

            when {
                isRed -> {
                    v.background = gd(t.red, 10f, t.dp)
                    v.setTextColor(Color.WHITE)
                }
                isGreen -> {
                    v.background = gd(t.green, 10f, t.dp)
                    v.setTextColor(Color.WHITE)
                }
                txtCor in ACCENT_COLORS -> {
                    v.setTextColor(t.accent)
                    v.background = gdOutline(t.accent, 10f, t.dp)
                }
                txtCor == Color.BLACK || txtCor == 0xFF000000.toInt() ||
                txtCor == 0xFF001A00.toInt() -> {
                    v.setTextColor(Color.BLACK)
                    v.background = gd(t.accent, 10f, t.dp)
                }
                txtCor in WHITE_COLORS -> v.setTextColor(t.txtW)
                txtCor in GRAY_COLORS  -> v.setTextColor(t.txtG)
            }
        } catch (_: Throwable) {}
        return
    }

    // ── TextView simples ──────────────────────────────────────────
    if (v is TextView && v !is Button && v !is RadioButton
        && v !is CheckBox && v !is Switch) {
        try {
            when (val cur = v.currentTextColor) {
                in ACCENT_COLORS -> v.setTextColor(t.accent)
                in WHITE_COLORS  -> v.setTextColor(t.txtW)
                in GRAY_COLORS   -> v.setTextColor(t.txtG)
                in LIGHT_COLORS  -> v.setTextColor(t.txtL)
                in GREEN_COLORS  -> v.setTextColor(t.green)
                in RED_COLORS    -> v.setTextColor(t.red)
            }
        } catch (_: Throwable) {}
        // TextView também pode ter background drawable que precisa ser remapeado
        try { remapearBackground(v, t) } catch (_: Throwable) {}
        return
    }

    // ── ImageButton / ImageView tint ──────────────────────────────
    if (v is ImageButton || v is ImageView) {
        try {
            val tl  = (v as? ImageButton)?.imageTintList ?: (v as? ImageView)?.imageTintList
            val cur = tl?.defaultColor ?: return
            if (cur in ACCENT_COLORS) {
                val cl = ColorStateList.valueOf(t.accent)
                (v as? ImageButton)?.imageTintList = cl
                (v as? ImageView)?.imageTintList   = cl
            }
        } catch (_: Throwable) {}
        return
    }

    // ── Switch ────────────────────────────────────────────────────
    if (v is Switch) {
        try {
            val on  = t.accent
            val off = if (t.isNoturno) 0xFF555555.toInt() else 0xFFAAAAAA.toInt()
            val cl  = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(on, off)
            )
            v.thumbTintList = cl
            v.trackTintList = cl
            v.setTextColor(t.txtW)
        } catch (_: Throwable) {}
        return
    }

    // ── RadioButton ───────────────────────────────────────────────
    if (v is RadioButton) {
        try {
            v.setTextColor(t.txtW)
            v.buttonTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(t.accent, t.txtG)
            )
        } catch (_: Throwable) {}
        return
    }

    // ── CheckBox ──────────────────────────────────────────────────
    if (v is CheckBox) {
        try {
            v.setTextColor(t.txtW)
            v.buttonTintList = ColorStateList.valueOf(t.accent)
        } catch (_: Throwable) {}
        return
    }

    // ── SeekBar ───────────────────────────────────────────────────
    if (v is SeekBar) {
        try {
            val cl = ColorStateList.valueOf(t.accent)
            v.progressTintList = cl
            v.thumbTintList    = cl
            v.progressBackgroundTintList = ColorStateList.valueOf(t.border)
        } catch (_: Throwable) {}
        return
    }

    // ── ProgressBar ───────────────────────────────────────────────
    if (v is ProgressBar) {
        try { v.progressTintList = ColorStateList.valueOf(t.accent) } catch (_: Throwable) {}
        return
    }

    // ── Qualquer outro View: tentar remapear background ───────────
    if (v !is ViewGroup) {
        try { remapearBackground(v, t) } catch (_: Throwable) {}
    } else {
        // ViewGroup: remapear se tiver background de cor de tema
        try { remapearBackground(v, t) } catch (_: Throwable) {}
    }
}

private fun gd(cor: Int, radius: Float, dp: Float) =
    GradientDrawable().apply { setColor(cor); cornerRadius = radius * dp }

private fun gdOutline(cor: Int, radius: Float, dp: Float) =
    GradientDrawable().apply {
        setColor(Color.TRANSPARENT)
        cornerRadius = radius * dp
        setStroke((1.5f * dp).toInt(), cor)
    }
