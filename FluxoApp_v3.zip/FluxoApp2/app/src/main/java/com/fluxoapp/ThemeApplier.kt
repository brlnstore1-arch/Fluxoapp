package com.fluxoapp

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.widget.Toolbar
import androidx.cardview.widget.CardView
import com.google.android.material.navigation.NavigationView

/**
 * Aplica o tema percorrendo a hierarquia de views por ITERAÇÃO (sem recursão).
 * Usa o ThemeHelper para obter as cores certas do tema atual.
 * NÃO usa mapa de cores — aplica diretamente via tag ou tipo de view.
 */
fun androidx.appcompat.app.AppCompatActivity.aplicarTemaGlobal() {
    try {
        val prefs   = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val bgDark  = ThemeHelper.cor("bg_dark",      prefs)
        val bgCard  = ThemeHelper.cor("bg_card",      prefs)
        val bgSect  = ThemeHelper.cor("bg_section",   prefs)
        val toolbar = ThemeHelper.cor("toolbar",      prefs)
        val txtW    = ThemeHelper.cor("text_white",   prefs)
        val txtG    = ThemeHelper.cor("text_gray",    prefs)
        val txtL    = ThemeHelper.cor("text_light",   prefs)
        val accent  = ThemeHelper.cor("accent",       prefs)
        val green   = ThemeHelper.cor("accent_green", prefs)
        val red     = ThemeHelper.cor("accent_red",   prefs)
        val border  = ThemeHelper.cor("border",       prefs)
        val dp      = resources.displayMetrics.density

        // Percorre apenas o conteúdo do app, nunca o sistema
        val raiz = findViewById<View>(android.R.id.content) ?: return
        val fila = ArrayDeque<View>()
        fila.add(raiz)

        while (fila.isNotEmpty()) {
            val v = fila.removeFirst()

            try { aplicarNaView(v, bgDark, bgCard, bgSect, toolbar,
                txtW, txtG, txtL, accent, green, red, border, dp) }
            catch (_: Throwable) {}

            if (v is NavigationView) continue  // não percorrer internamente
            if (v is ViewGroup) {
                for (i in 0 until v.childCount) {
                    try { v.getChildAt(i)?.let { fila.add(it) } } catch (_: Throwable) {}
                }
            }
        }
    } catch (_: Throwable) {}
}

private fun aplicarNaView(
    v: View,
    bgDark: Int, bgCard: Int, bgSect: Int, toolbar: Int,
    txtW: Int, txtG: Int, txtL: Int,
    accent: Int, green: Int, red: Int,
    border: Int, dp: Float
) {
    val tag = try { v.tag?.toString() ?: "" } catch (_: Throwable) { "" }

    // ── Tag explícita (mais confiável) ──
    when (tag) {
        "bg_dark"    -> { v.setBackgroundColor(bgDark); return }
        "bg_card"    -> { v.setBackgroundColor(bgCard); return }
        "bg_section" -> { v.setBackgroundColor(bgSect); return }
        "toolbar_bg" -> { v.setBackgroundColor(toolbar); return }
        "accent"     -> { if (v is TextView) v.setTextColor(accent); return }
        "text_gray"  -> { if (v is TextView) v.setTextColor(txtG); return }
        "divider"    -> { v.setBackgroundColor(accent); return }
    }

    // ── CardView → bgCard ──
    if (v is CardView) {
        try { v.setCardBackgroundColor(bgCard) } catch (_: Throwable) {}
        return
    }

    // ── Toolbar → toolbar ──
    if (v is Toolbar) {
        try { v.setBackgroundColor(toolbar) } catch (_: Throwable) {}
        return
    }

    // ── NavigationView ──
    if (v is NavigationView) {
        try {
            v.setBackgroundColor(bgCard)
            val cl = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(accent, txtW)
            )
            v.itemTextColor    = cl
            v.itemIconTintList = ColorStateList.valueOf(accent)
        } catch (_: Throwable) {}
        return
    }

    // ── ScrollView / ListView → bgDark ──
    if (v is ScrollView || v is ListView) {
        try { v.setBackgroundColor(bgDark) } catch (_: Throwable) {}
    }

    // ── Fundo ColorDrawable — só troca se for cor de bg conhecida ──
    try {
        val bg = v.background
        if (bg is ColorDrawable && v !is TextView && v !is Button) {
            when (bg.color) {
                // Azul noite
                Color.parseColor("#0A1628") -> v.setBackgroundColor(bgDark)
                Color.parseColor("#0F1E36") -> v.setBackgroundColor(bgCard)
                Color.parseColor("#132240") -> v.setBackgroundColor(bgSect)
                // Azul dia
                Color.parseColor("#E8F2FF") -> v.setBackgroundColor(bgDark)
                Color.parseColor("#D0E8FF") -> v.setBackgroundColor(bgCard)
                Color.parseColor("#B8D8F8") -> v.setBackgroundColor(bgSect)
                // Gold noite
                Color.parseColor("#111111") -> v.setBackgroundColor(bgDark)
                Color.parseColor("#1C1C1C") -> v.setBackgroundColor(bgCard)
                Color.parseColor("#262626") -> v.setBackgroundColor(bgSect)
                // Gold dia
                Color.parseColor("#F5F0E8") -> v.setBackgroundColor(bgDark)
                Color.parseColor("#EDE8DC") -> v.setBackgroundColor(bgCard)
                Color.parseColor("#E0D8C8") -> v.setBackgroundColor(bgSect)
            }
        }
    } catch (_: Throwable) {}

    // ── TextView simples ──
    if (v is TextView && v !is Button && v !is RadioButton
        && v !is CheckBox && v !is Switch) {
        try {
            // Não tocar em TextViews sem cor definida (cor padrão do sistema)
            val cur = v.currentTextColor
            when (cur) {
                // Accent de qualquer tema
                Color.parseColor("#00C8FF"),
                Color.parseColor("#0055BB"),
                Color.parseColor("#C9A84C"),
                Color.parseColor("#8A6010") -> v.setTextColor(accent)
                // text_white de qualquer tema
                Color.parseColor("#E8F0FE"),
                Color.parseColor("#0A1E3C"),
                Color.parseColor("#F0EAD6"),
                Color.parseColor("#1C1408") -> v.setTextColor(txtW)
                // text_gray de qualquer tema
                Color.parseColor("#3A6090"),
                Color.parseColor("#4A7AAA"),
                Color.parseColor("#8A7A60"),
                Color.parseColor("#7A6040") -> v.setTextColor(txtG)
                // green
                Color.parseColor("#00E676"),
                Color.parseColor("#00875A"),
                Color.parseColor("#4CAF7D"),
                Color.parseColor("#3A8A5A") -> v.setTextColor(green)
                // red
                Color.parseColor("#FF4560"),
                Color.parseColor("#C0392B"),
                Color.parseColor("#E05C5C") -> v.setTextColor(red)
            }
        } catch (_: Throwable) {}
    }

    // ── Button ──
    if (v is Button) {
        try {
            val cur = v.currentTextColor
            when (cur) {
                Color.parseColor("#00C8FF"),
                Color.parseColor("#0055BB"),
                Color.parseColor("#C9A84C"),
                Color.parseColor("#8A6010") -> {
                    // Botão outline
                    v.setTextColor(accent)
                    v.background = GradientDrawable().apply {
                        setColor(Color.TRANSPARENT)
                        cornerRadius = 10f * dp
                        setStroke((1.5f * dp).toInt(), accent)
                    }
                }
                Color.BLACK,
                0xFF000000.toInt(),
                0xFF001A00.toInt() -> {
                    // Botão sólido
                    v.setTextColor(Color.BLACK)
                    v.background = GradientDrawable().apply {
                        setColor(accent); cornerRadius = 10f * dp
                    }
                }
                else -> {
                    // Texto normal do botão
                    val chave = when (cur) {
                        Color.parseColor("#E8F0FE"),
                        Color.parseColor("#0A1E3C"),
                        Color.parseColor("#F0EAD6"),
                        Color.parseColor("#1C1408") -> txtW
                        Color.parseColor("#3A6090"),
                        Color.parseColor("#4A7AAA"),
                        Color.parseColor("#8A7A60"),
                        Color.parseColor("#7A6040") -> txtG
                        else -> return
                    }
                    v.setTextColor(chave)
                }
            }
        } catch (_: Throwable) {}
    }

    // ── ImageButton / ImageView tint ──
    if (v is ImageButton || v is ImageView) {
        try {
            val tl = (v as? ImageButton)?.imageTintList
                ?: (v as? ImageView)?.imageTintList
            val cur = tl?.defaultColor ?: return
            when (cur) {
                Color.parseColor("#00C8FF"),
                Color.parseColor("#0055BB"),
                Color.parseColor("#C9A84C"),
                Color.parseColor("#8A6010") -> {
                    val cl = ColorStateList.valueOf(accent)
                    (v as? ImageButton)?.imageTintList = cl
                    (v as? ImageView)?.imageTintList   = cl
                }
            }
        } catch (_: Throwable) {}
    }

    // ── Switch ──
    if (v is Switch) {
        try {
            val cl = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(accent, Color.parseColor("#888888"))
            )
            v.thumbTintList = cl
            v.trackTintList = cl
        } catch (_: Throwable) {}
    }

    // ── SeekBar ──
    if (v is SeekBar) {
        try {
            val cl = ColorStateList.valueOf(accent)
            v.progressTintList = cl
            v.thumbTintList    = cl
        } catch (_: Throwable) {}
    }

    // ── ProgressBar ──
    if (v is ProgressBar && v !is SeekBar) {
        try { v.progressTintList = ColorStateList.valueOf(accent) } catch (_: Throwable) {}
    }

    // ── RadioButton ──
    if (v is RadioButton) {
        try {
            v.setTextColor(txtW)
            v.buttonTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(accent, txtG)
            )
        } catch (_: Throwable) {}
    }

    // ── EditText ──
    if (v is EditText) {
        try {
            v.setTextColor(txtW)
            v.setHintTextColor(txtG)
        } catch (_: Throwable) {}
    }
}
