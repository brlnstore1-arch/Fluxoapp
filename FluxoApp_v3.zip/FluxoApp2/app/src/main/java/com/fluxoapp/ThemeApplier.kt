package com.fluxoapp

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

/**
 * Aplica o tema atual (azul/gold, dia/noite) em toda a activity.
 * Chame em onCreate() e onResume() de qualquer Activity.
 */
fun AppCompatActivity.aplicarTemaGlobal() {
    val prefs  = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
    val bgDark = ThemeHelper.cor("bg_dark",     prefs)
    val bgCard = ThemeHelper.cor("bg_card",     prefs)
    val bgSect = ThemeHelper.cor("bg_section",  prefs)
    val toolbar= ThemeHelper.cor("toolbar",     prefs)
    val txtW   = ThemeHelper.cor("text_white",  prefs)
    val txtG   = ThemeHelper.cor("text_gray",   prefs)
    val txtL   = ThemeHelper.cor("text_light",  prefs)
    val accent = ThemeHelper.cor("accent_gold", prefs)
    val green  = ThemeHelper.cor("accent_green",prefs)
    val red    = ThemeHelper.cor("accent_red",  prefs)
    val border = ThemeHelper.cor("border",      prefs)
    val dp     = resources.displayMetrics.density

    fun gdSolid(cor: Int, r: Float, bCor: Int = 0, bw: Float = 0f) =
        GradientDrawable().apply {
            setColor(cor); cornerRadius = r * dp
            if (bw > 0) setStroke((bw * dp).toInt(), bCor)
        }
    fun gdOutline(r: Float) =
        GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            cornerRadius = r * dp
            setStroke((1.5f * dp).toInt(), accent)
        }

    // Root backgrounds
    try { findViewById<View>(R.id.rootLayout)?.setBackgroundColor(bgDark) } catch (_: Exception) {}
    try { findViewById<View>(R.id.rootLayoutHistory)?.setBackgroundColor(bgDark) } catch (_: Exception) {}

    // Toolbar
    try { findViewById<View>(R.id.toolbar)?.setBackgroundColor(toolbar) } catch (_: Exception) {}

    // Botão voltar
    try { findViewById<ImageButton>(R.id.btnVoltar)?.setColorFilter(accent) } catch (_: Exception) {}

    // Títulos
    for (id in listOf(R.id.tvVersao)) {
        try { findViewById<TextView>(id)?.setTextColor(accent) } catch (_: Exception) {}
    }

    // Varredura completa da hierarquia de views
    try {
        varreHierarquia(
            window.decorView,
            bgDark, bgCard, bgSect, toolbar,
            txtW, txtG, txtL,
            accent, green, red, border, dp,
            ::gdSolid, ::gdOutline
        )
    } catch (_: Exception) {}
}

private fun varreHierarquia(
    root: View,
    bgDark: Int, bgCard: Int, bgSect: Int, toolbar: Int,
    txtW: Int, txtG: Int, txtL: Int,
    accent: Int, green: Int, red: Int,
    border: Int, dp: Float,
    gdSolid: (Int, Float, Int, Float) -> GradientDrawable,
    gdOutline: (Float) -> GradientDrawable
) {
    aplicarNaView(root, bgDark, bgCard, bgSect, toolbar, txtW, txtG, txtL, accent, green, red, border, dp, gdSolid, gdOutline)
    if (root !is android.view.ViewGroup) return
    for (i in 0 until root.childCount) {
        varreHierarquia(
            root.getChildAt(i),
            bgDark, bgCard, bgSect, toolbar,
            txtW, txtG, txtL,
            accent, green, red, border, dp,
            gdSolid, gdOutline
        )
    }
}

private fun aplicarNaView(
    v: View,
    bgDark: Int, bgCard: Int, bgSect: Int, toolbar: Int,
    txtW: Int, txtG: Int, txtL: Int,
    accent: Int, green: Int, red: Int,
    border: Int, dp: Float,
    gdSolid: (Int, Float, Int, Float) -> GradientDrawable,
    gdOutline: (Float) -> GradientDrawable
) {
    try {
        val tag = v.tag?.toString() ?: ""
        when {
            tag == "divider" -> v.setBackgroundColor(accent)
            tag == "header"  -> v.setBackgroundColor(toolbar)
            tag == "card"    -> v.setBackgroundColor(bgCard)
            tag == "section" -> v.setBackgroundColor(bgSect)
        }
    } catch (_: Exception) {}

    // CardView
    if (v is CardView) {
        try { v.setCardBackgroundColor(bgCard) } catch (_: Exception) {}
        return
    }

    // ScrollView / ListView
    if (v is ScrollView || v is ListView) {
        try { v.setBackgroundColor(bgDark) } catch (_: Exception) {}
    }

    // TextView — detectar pela cor atual e remapear
    if (v is TextView && v !is Button && v !is RadioButton && v !is CheckBox && v !is Switch) {
        try {
            val cur = v.currentTextColor
            // Todas as cores de acento possíveis dos 4 temas
            val accentColors = setOf(
                // Azul noite / dia
                Color.parseColor("#00C8FF"), Color.parseColor("#0066CC"),
                Color.parseColor("#00E5FF"), Color.parseColor("#1E90FF"),
                Color.parseColor("#007BB5"),
                // Gold noite / dia
                Color.parseColor("#C9A84C"), Color.parseColor("#8A6520"),
                Color.parseColor("#E8C96D"), Color.parseColor("#B8860B"),
                Color.parseColor("#997A50")
            )
            // Todas as cores de texto principal dos 4 temas
            val whiteColors = setOf(
                Color.WHITE, Color.parseColor("#FFFFFF"),
                Color.parseColor("#F0F0F5"), Color.parseColor("#F5F0E8"),
                Color.parseColor("#E8F0FE"), Color.parseColor("#DAEEFF"),
                Color.parseColor("#F0F6FF"), Color.parseColor("#FAF6EF"),
                Color.parseColor("#1A1208"), Color.parseColor("#0A2A5E"),
                Color.parseColor("#0E0E0E")
            )
            // Todas as cores de texto secundário dos 4 temas
            val grayColors = setOf(
                Color.parseColor("#3A6090"), Color.parseColor("#7A6040"),
                Color.parseColor("#4A7AAA"), Color.parseColor("#9A8060"),
                Color.parseColor("#5A4A38"), Color.parseColor("#7A6A50"),
                Color.parseColor("#6B6B80"), Color.parseColor("#8888AA"),
                Color.parseColor("#9090A8")
            )
            when (cur) {
                in accentColors -> v.setTextColor(accent)
                in whiteColors  -> v.setTextColor(txtW)
                in grayColors   -> v.setTextColor(txtG)
            }
        } catch (_: Exception) {}
    }

    // RadioButton / Switch — tint
    if (v is RadioButton) {
        try { v.setTextColor(txtW) } catch (_: Exception) {}
        try {
            v.buttonTintList = android.content.res.ColorStateList.valueOf(accent)
        } catch (_: Exception) {}
    }
    if (v is Switch) {
        try {
            v.thumbTintList  = android.content.res.ColorStateList.valueOf(accent)
            v.trackTintList  = android.content.res.ColorStateList.valueOf(
                android.graphics.Color.argb(80,
                    android.graphics.Color.red(accent),
                    android.graphics.Color.green(accent),
                    android.graphics.Color.blue(accent))
            )
        } catch (_: Exception) {}
    }

    // SeekBar
    if (v is SeekBar) {
        try { v.progressTintList = android.content.res.ColorStateList.valueOf(accent) } catch (_: Exception) {}
        try { v.thumbTintList    = android.content.res.ColorStateList.valueOf(accent) } catch (_: Exception) {}
    }

    // ProgressBar
    if (v is ProgressBar && v !is SeekBar) {
        try { v.progressTintList = android.content.res.ColorStateList.valueOf(accent) } catch (_: Exception) {}
    }

    // Button com background drawable (btn_cyan / btn_outline_cyan)
    if (v is Button) {
        try {
            val bg = v.background
            val isSolid   = bg is GradientDrawable
            val isColorDr = bg is ColorDrawable
            // Detectar cor atual do background
            val currentBg: Int? = when {
                isColorDr -> (bg as ColorDrawable).color
                isSolid   -> try { (bg as GradientDrawable).color?.defaultColor } catch (_: Exception) { null }
                else      -> null
            }
            val solidCyanColors = setOf(
                Color.parseColor("#00E5FF"), Color.parseColor("#00C8FF"),
                Color.parseColor("#C9A84C")  // dourado que colocamos antes
            )
            val outlineCyanColors = setOf(
                Color.TRANSPARENT, Color.parseColor("#00000000")
            )
            val textColor = v.currentTextColor
            val accentTextColors = setOf(
                Color.parseColor("#00C8FF"), Color.parseColor("#00E5FF"),
                Color.parseColor("#C9A84C"), Color.parseColor("#0066CC")
            )

            when {
                // Botão sólido (btn_cyan) → sólido com accent
                textColor == Color.BLACK || textColor == Color.parseColor("#FF000000") -> {
                    v.background = GradientDrawable().apply {
                        setColor(accent); cornerRadius = 12f * dp
                    }
                    v.setTextColor(Color.BLACK)
                }
                // Botão outline (btn_outline_cyan) → outline com accent
                textColor in accentTextColors -> {
                    v.background = GradientDrawable().apply {
                        setColor(Color.TRANSPARENT)
                        cornerRadius = 12f * dp
                        setStroke((1.5f * dp).toInt(), accent)
                    }
                    v.setTextColor(accent)
                }
            }
        } catch (_: Exception) {}
    }
}
