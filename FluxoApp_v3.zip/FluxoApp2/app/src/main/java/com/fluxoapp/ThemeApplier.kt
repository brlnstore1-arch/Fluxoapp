package com.fluxoapp

import android.content.Context
import android.util.Log
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.widget.Toolbar
import androidx.cardview.widget.CardView
import com.google.android.material.navigation.NavigationView

/**
 * Aplica o tema atual em TODA a hierarquia de views da Activity.
 * Usa iteração (fila) em vez de recursão — sem risco de StackOverflow.
 * Só percorre o conteúdo do app (android.R.id.content), nunca views do sistema.
 */
private const val TAG_APPLIER = "FluxoApp.ThemeApplier"

fun androidx.appcompat.app.AppCompatActivity.aplicarTemaGlobal() {
    val prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
    ThemeHelper.aplicarTemaComFallback(prefs) {
    try {
        val bgDark = ThemeHelper.cor("bg_dark",     prefs)
        val bgCard = ThemeHelper.cor("bg_card",     prefs)
        val bgSect = ThemeHelper.cor("bg_section",  prefs)
        val toolbar= ThemeHelper.cor("toolbar",     prefs)
        val txtW   = ThemeHelper.cor("text_white",  prefs)
        val txtG   = ThemeHelper.cor("text_gray",   prefs)
        val txtL   = ThemeHelper.cor("text_light",  prefs)
        val accent = ThemeHelper.cor("accent_gold", prefs)
        val green  = ThemeHelper.cor("accent_green",prefs)
        val red    = ThemeHelper.cor("accent_red",  prefs)
        val border = ThemeHelper.cor("border",      prefs)
        val dp     = resources.displayMetrics.density

        // Percorre APENAS o conteúdo do app — nunca views do sistema
        val raiz = findViewById<View>(android.R.id.content) ?: window.decorView
        percorrerViews(raiz, bgDark, bgCard, bgSect, toolbar, txtW, txtG, txtL,
                       accent, green, red, border, dp)
    } catch (e: Throwable) { Log.e(TAG_APPLIER, "aplicarTemaGlobal: ${e.message}", e) }
    } // fechamento do aplicarTemaComFallback
}

/**
 * Iteração via fila — sem recursão, sem StackOverflow.
 */
private fun percorrerViews(
    raiz: View,
    bgDark: Int, bgCard: Int, bgSect: Int, toolbar: Int,
    txtW: Int, txtG: Int, txtL: Int,
    accent: Int, green: Int, red: Int,
    border: Int, dp: Float
) {
    val fila = ArrayDeque<View>()
    fila.add(raiz)

    while (fila.isNotEmpty()) {
        val v = fila.removeFirst()
        try {
            aplicarNaView(v, bgDark, bgCard, bgSect, toolbar,
                          txtW, txtG, txtL, accent, green, red, border, dp)
        } catch (e: Throwable) { Log.e(TAG_APPLIER, "Erro em view: ${e.javaClass.simpleName}: ${e.message}") }

        // Adicionar filhos à fila (NavigationView: não percorrer internamente)
        if (v is NavigationView) continue
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) {
                try { v.getChild(i)?.let { fila.add(it) } } catch (_: Throwable) {}
            }
        }
    }
}

private fun ViewGroup.getChild(i: Int): View? = try { getChildAt(i) } catch (_: Throwable) { null }

private fun aplicarNaView(
    v: View,
    bgDark: Int, bgCard: Int, bgSect: Int, toolbar: Int,
    txtW: Int, txtG: Int, txtL: Int,
    accent: Int, green: Int, red: Int,
    border: Int, dp: Float
) {
    // ── Tag customizada ──
    try {
        when (v.tag?.toString()) {
            "divider"  -> v.setBackgroundColor(accent)
            "header"   -> v.setBackgroundColor(toolbar)
            "card"     -> v.setBackgroundColor(bgCard)
            "section"  -> v.setBackgroundColor(bgSect)
        }
    } catch (e: Throwable) { Log.e(TAG_APPLIER, "Erro em view: ${e.javaClass.simpleName}: ${e.message}") }

    // ── CardView ──
    if (v is CardView) {
        try { v.setCardBackgroundColor(bgCard) } catch (_: Throwable) {}
        return
    }

    // ── Toolbar ──
    if (v is Toolbar) {
        try { v.setBackgroundColor(toolbar) } catch (_: Throwable) {}
        return
    }

    // ── NavigationView ──
    if (v is NavigationView) {
        try {
            v.setBackgroundColor(bgCard)
            val cl = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(accent, txtW)
            )
            v.itemTextColor    = cl
            v.itemIconTintList = ColorStateList.valueOf(accent)
        } catch (e: Throwable) { Log.e(TAG_APPLIER, "Erro em view: ${e.javaClass.simpleName}: ${e.message}") }
        return
    }

    // ── ScrollView / ListView ──
    if (v is ScrollView || v is ListView) {
        try { v.setBackgroundColor(bgDark) } catch (_: Throwable) {}
    }

    // ── Fundo ColorDrawable ──
    try {
        val bg = v.background
        if (bg is ColorDrawable) {
            val chave = mapaBg[bg.color]
            if (chave != null) {
                val nova = when (chave) {
                    "bg_dark"    -> bgDark
                    "bg_card"    -> bgCard
                    "bg_section" -> bgSect
                    "toolbar"    -> toolbar
                    else         -> return
                }
                v.setBackgroundColor(nova)
            }
        }
    } catch (e: Throwable) { Log.e(TAG_APPLIER, "Erro em view: ${e.javaClass.simpleName}: ${e.message}") }

    // ── TextView (não Button/RadioButton/Switch) ──
    if (v is TextView && v !is Button && v !is RadioButton && v !is CheckBox && v !is Switch) {
        try {
            val cor = v.currentTextColor
            val nova = mapaTexto[cor]
            if (nova != null) {
                val novaCor = when (nova) {
                    "accent"      -> accent
                    "text_white"  -> txtW
                    "text_gray"   -> txtG
                    "text_light"  -> txtL
                    "green"       -> green
                    "red"         -> red
                    else          -> return
                }
                v.setTextColor(novaCor)
            }
        } catch (e: Throwable) { Log.e(TAG_APPLIER, "Erro em view: ${e.javaClass.simpleName}: ${e.message}") }
    }

    // ── Button ──
    if (v is Button) {
        try {
            val txtCor = v.currentTextColor
            val nova = mapaTexto[txtCor]
            if (nova != null) v.setTextColor(
                when (nova) {
                    "accent" -> accent; "text_white" -> txtW
                    "text_gray" -> txtG; else -> txtCor
                }
            )
            // Botão sólido (texto escuro = fundo colorido)
            if (txtCor == Color.BLACK ||
                txtCor == 0xFF000000.toInt() ||
                txtCor == 0xFF0A1628.toInt() ||
                txtCor == 0xFF0E0E0E.toInt() ||
                txtCor == 0xFF001A00.toInt()) {
                v.background = GradientDrawable().apply {
                    setColor(accent); cornerRadius = 12f * dp
                }
                v.setTextColor(Color.BLACK)
            }
        } catch (e: Throwable) { Log.e(TAG_APPLIER, "Erro em view: ${e.javaClass.simpleName}: ${e.message}") }
    }

    // ── ImageButton / ImageView ──
    if (v is ImageButton || v is ImageView) {
        try {
            val tl = (v as? ImageButton)?.imageTintList
                ?: (v as? ImageView)?.imageTintList
            val cor = tl?.defaultColor ?: return
            val nova = mapaTexto[cor] ?: return
            if (nova == "accent") {
                (v as? ImageButton)?.imageTintList = ColorStateList.valueOf(accent)
                (v as? ImageView)?.imageTintList   = ColorStateList.valueOf(accent)
            }
        } catch (e: Throwable) { Log.e(TAG_APPLIER, "Erro em view: ${e.javaClass.simpleName}: ${e.message}") }
    }

    // ── Switch ──
    if (v is Switch) {
        try {
            val cl = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(accent, 0xFF888888.toInt())
            )
            v.thumbTintList = cl
            v.trackTintList = cl
        } catch (e: Throwable) { Log.e(TAG_APPLIER, "Erro em view: ${e.javaClass.simpleName}: ${e.message}") }
    }

    // ── SeekBar ──
    if (v is SeekBar) {
        try {
            val cl = ColorStateList.valueOf(accent)
            v.progressTintList = cl
            v.thumbTintList    = cl
        } catch (e: Throwable) { Log.e(TAG_APPLIER, "Erro em view: ${e.javaClass.simpleName}: ${e.message}") }
    }

    // ── ProgressBar ──
    if (v is ProgressBar && v !is SeekBar) {
        try {
            v.progressTintList = ColorStateList.valueOf(accent)
        } catch (e: Throwable) { Log.e(TAG_APPLIER, "Erro em view: ${e.javaClass.simpleName}: ${e.message}") }
    }

    // ── RadioButton ──
    if (v is RadioButton) {
        try {
            v.setTextColor(txtW)
            v.buttonTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(accent, txtG)
            )
        } catch (e: Throwable) { Log.e(TAG_APPLIER, "Erro em view: ${e.javaClass.simpleName}: ${e.message}") }
    }

    // ── EditText ──
    if (v is EditText) {
        try {
            val cor   = v.currentTextColor
            val nova  = mapaTexto[cor]
            if (nova != null) v.setTextColor(if (nova == "text_white") txtW else txtG)
            v.setHintTextColor(txtG)
        } catch (e: Throwable) { Log.e(TAG_APPLIER, "Erro em view: ${e.javaClass.simpleName}: ${e.message}") }
    }
}

// ── Mapa de cores de fundo (cores estáticas do colors.xml → chave) ──
private val mapaBg = mapOf(
    // Azul noite
    0xFF0A1628.toInt() to "bg_dark",
    0xFF0F1E36.toInt() to "bg_card",
    0xFF132240.toInt() to "bg_section",
    // Azul dia
    0xFFF0F6FF.toInt() to "bg_dark",
    0xFFDAEEFF.toInt() to "bg_card",
    0xFFC8E4F8.toInt() to "bg_section",
    // Gold noite
    0xFF0E0E0E.toInt() to "bg_dark",
    0xFF141414.toInt() to "bg_card",
    0xFF1C1C1C.toInt() to "bg_section",
    // Gold dia
    0xFFFAF6EF.toInt() to "bg_dark",
    0xFFFFF8EC.toInt() to "bg_card",
    0xFFF5EFE3.toInt() to "bg_section"
)

// ── Mapa de cores de texto (cores estáticas → chave interna) ──
private val mapaTexto = mapOf(
    // Accent (todas as variações)
    0xFF00C8FF.toInt() to "accent",
    0xFF00E5FF.toInt() to "accent",
    0xFF1E90FF.toInt() to "accent",
    0xFF0066CC.toInt() to "accent",
    0xFFC9A84C.toInt() to "accent",
    0xFF8A6520.toInt() to "accent",
    0xFFE8C96D.toInt() to "accent",
    0xFFB8860B.toInt() to "accent",
    // text_white
    0xFFF0F0F5.toInt() to "text_white",
    0xFFF5F0E8.toInt() to "text_white",
    0xFF0A2A5E.toInt() to "text_white",
    0xFF1A1208.toInt() to "text_white",
    0xFFE8F0FE.toInt() to "text_white",
    // text_gray
    0xFF3A6090.toInt() to "text_gray",
    0xFF4A7AAA.toInt() to "text_gray",
    0xFF5A4A38.toInt() to "text_gray",
    0xFF7A6040.toInt() to "text_gray",
    0xFF9A8060.toInt() to "text_gray",
    0xFF6B6B80.toInt() to "text_gray",
    // text_light
    0xFF7A9CC0.toInt() to "text_light",
    0xFF5A8ABB.toInt() to "text_light",
    0xFF7A6A50.toInt() to "text_light",
    // green
    0xFF00E676.toInt() to "green",
    0xFF00875A.toInt() to "green",
    0xFF4CAF7D.toInt() to "green",
    // red
    0xFFFF4560.toInt() to "red",
    0xFFFF1744.toInt() to "red",
    0xFFE05C5C.toInt() to "red"
)
