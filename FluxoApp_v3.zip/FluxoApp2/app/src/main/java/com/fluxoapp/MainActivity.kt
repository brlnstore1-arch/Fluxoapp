package com.fluxoapp

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.cardview.widget.CardView
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var db: DatabaseHelper
    private var drawerLayout: DrawerLayout? = null
    private val handler = Handler(Looper.getMainLooper())

    private val DICAS = listOf(
        "Cada km rodado é um passo a mais para seu sonho!",
        "Motorista de sucesso é aquele que nunca desiste!",
        "Hoje é um ótimo dia para bater sua meta!",
        "Sua dedicação é o combustível do seu sucesso!",
        "O melhor horário para trabalhar é agora!",
        "Cada corrida bem feita é um cliente fiel!",
        "Sucesso é a soma de pequenas conquistas diárias!",
        "Você está no caminho certo, continue!",
        "Foco, força e fé! Seu esforço tem valor!",
        "Cada corrida aceita é uma oportunidade de ganhar mais!"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // PASSO 1: inflar layout — se falhar, não há nada a fazer
        try {
            setContentView(R.layout.activity_main)
        } catch (e: Throwable) {
            Toast.makeText(this, "Erro ao carregar tela: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        // PASSO 2: inicializar dados básicos
        try {
            prefs = getSharedPreferences("FluxoApp", MODE_PRIVATE)
            db    = DatabaseHelper(this)
        } catch (e: Throwable) {
            Toast.makeText(this, "Erro ao inicializar dados: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        // PASSO 3: verificar onboarding
        try {
            if (!prefs.getBoolean("onboarding_ok", false)) {
                startActivity(Intent(this, OnboardingActivity::class.java))
                finish()
                return
            }
        } catch (_: Throwable) {}

        // PASSOS 4+: UI — cada um isolado, falha não impede os outros
        try { configurarToolbarEDrawer() }  catch (_: Throwable) {}
        try { configurarBotaoTema() }       catch (_: Throwable) {}
        try { configurarNavegacao() }       catch (_: Throwable) {}
        try { iniciarShimmer() }            catch (_: Throwable) {}
        try { aplicarTema() }               catch (_: Throwable) {}
        try { aplicarTemaGlobal() }         catch (_: Throwable) {}
        try { atualizarStats() }            catch (_: Throwable) {}
        try { exibirDica() }                catch (_: Throwable) {}

        // SERVIÇOS: só sobem se o usuário já deu permissão E após 2s de delay
        // NUNCA automático, sempre verificando permissão antes
        handler.postDelayed({ tentarIniciarServico() }, 2000)
    }

    // Inicia o serviço flutuante SOMENTE se tiver permissão e estiver ativo
    private fun tentarIniciarServico() {
        try {
            val ativo  = prefs.getBoolean("servico_ativo", false) // false por padrão
            val temOverlay = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Settings.canDrawOverlays(this)
            } else true

            if (ativo && temOverlay) {
                androidx.core.content.ContextCompat.startForegroundService(
                    this, Intent(this, FloatingEarningsService::class.java)
                )
            }
        } catch (_: Throwable) {}
    }

    override fun onResume() {
        super.onResume()
        try { atualizarStats() }     catch (_: Throwable) {}
        try { aplicarTema() }        catch (_: Throwable) {}
        try { aplicarTemaGlobal() }  catch (_: Throwable) {}
        try { atualizarIconeTema() } catch (_: Throwable) {}
        try { iniciarShimmer() }     catch (_: Throwable) {}
        try {
            val navView = findViewById<NavigationView>(R.id.navView)
            if (navView != null) configurarHeaderDrawer(navView)
        } catch (_: Throwable) {}
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }

    // ── TOOLBAR + DRAWER ──────────────────────────────────────────
    private fun configurarToolbarEDrawer() {
        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        if (toolbar != null) {
            try { setSupportActionBar(toolbar) } catch (_: Throwable) {}
            try { supportActionBar?.setDisplayShowTitleEnabled(false) } catch (_: Throwable) {}
        }

        drawerLayout = findViewById(R.id.drawerLayout)
        val navView  = findViewById<NavigationView>(R.id.navView)
        try { navView?.setNavigationItemSelectedListener(this) } catch (_: Throwable) {}

        findViewById<View>(R.id.btnMenu)?.setOnClickListener {
            val dl = drawerLayout ?: return@setOnClickListener
            if (dl.isDrawerOpen(GravityCompat.START)) dl.closeDrawer(GravityCompat.START)
            else dl.openDrawer(GravityCompat.START)
        }

        if (navView != null) try { configurarHeaderDrawer(navView) } catch (_: Throwable) {}
    }

    private fun configurarHeaderDrawer(navView: NavigationView) {
        val header = navView.getHeaderView(0) ?: return
        val p      = prefs
        val accent = ThemeHelper.cor("accent_gold", p)
        val bgDark = ThemeHelper.cor("bg_dark", p)
        val txtW   = ThemeHelper.cor("text_white", p)
        val txtG   = ThemeHelper.cor("text_gray", p)
        val dp     = resources.displayMetrics.density

        try {
            header.findViewById<LinearLayout>(R.id.navHeaderBg)?.background =
                android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                    intArrayOf(android.graphics.Color.argb(80,
                        android.graphics.Color.red(accent),
                        android.graphics.Color.green(accent),
                        android.graphics.Color.blue(accent)), bgDark)
                )
        } catch (_: Throwable) {}

        val nome    = p.getString("perfil_nome",   "Motorista") ?: "Motorista"
        val cidade  = p.getString("perfil_cidade", "Bragança - PA") ?: "Bragança - PA"
        val status  = p.getString("perfil_status", "🚀 Trabalhando duro!") ?: "🚀 Trabalhando duro!"
        val veiculo = p.getString("perfil_veiculo", "moto") ?: "moto"
        val icone   = when(veiculo) { "carro" -> "🚗"; "bike" -> "🚴"; else -> "🏍️" }

        try { header.findViewById<TextView>(R.id.tvNomePerfil)?.apply { text = "$icone  $nome"; setTextColor(txtW) } } catch (_: Throwable) {}
        try { header.findViewById<TextView>(R.id.tvCidadePerfil)?.apply { text = "📍 $cidade"; setTextColor(txtG) } } catch (_: Throwable) {}
        try { header.findViewById<TextView>(R.id.tvStatusPerfil)?.apply { text = status; setTextColor(accent) } } catch (_: Throwable) {}

        try {
            header.findViewById<TextView>(R.id.tvEditarFoto)?.apply {
                setBackgroundColor(accent)
                setTextColor(android.graphics.Color.parseColor("#001A00"))
                setOnClickListener {
                    drawerLayout?.closeDrawer(GravityCompat.START)
                    startActivity(Intent(this@MainActivity, ProfileActivity::class.java))
                }
            }
        } catch (_: Throwable) {}

        Thread {
            try {
                val cal = java.util.Calendar.getInstance()
                val mes = db.buscarMes(cal.get(java.util.Calendar.MONTH), cal.get(java.util.Calendar.YEAR))
                val resumo   = db.resumo(mes)
                val total    = resumo["total"] ?: 0f
                val corridas = (resumo["corridas"] ?: 0f).toInt()
                val media    = if (corridas > 0) total / corridas else 0f
                runOnUiThread {
                    try { header.findViewById<TextView>(R.id.tvStatMesValor)?.apply { text = "R$${if (total >= 1000) "%.0f".format(total/1000)+"k" else "%.0f".format(total)}"; setTextColor(accent) } } catch (_: Throwable) {}
                    try { header.findViewById<TextView>(R.id.tvStatCorridasValor)?.apply { text = "$corridas"; setTextColor(accent) } } catch (_: Throwable) {}
                    try { header.findViewById<TextView>(R.id.tvStatMediaValor)?.apply { text = "R$${"%0f".format(media)}"; setTextColor(accent) } } catch (_: Throwable) {}
                }
            } catch (_: Throwable) {}
        }.start()
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        drawerLayout?.closeDrawer(GravityCompat.START)
        try {
            when (item.itemId) {
                R.id.nav_perfil        -> startActivity(Intent(this, ProfileActivity::class.java))
                R.id.nav_configuracoes -> startActivity(Intent(this, SettingsActivity::class.java))
                R.id.nav_sobre         -> startActivity(Intent(this, AboutActivity::class.java))
            }
        } catch (_: Throwable) {}
        return true
    }

    override fun onBackPressed() {
        val dl = drawerLayout
        if (dl != null && dl.isDrawerOpen(GravityCompat.START))
            dl.closeDrawer(GravityCompat.START)
        else
            super.onBackPressed()
    }

    // ── NAVEGAÇÃO ─────────────────────────────────────────────────
    private fun configurarNavegacao() {
        try { findViewById<View>(R.id.btnBottomCorridas)?.setOnClickListener { startActivity(Intent(this, HistoryActivity::class.java)) } } catch (_: Throwable) {}
        try { findViewById<View>(R.id.btnBottomMetricas)?.setOnClickListener { startActivity(Intent(this, ReportsActivity::class.java)) } } catch (_: Throwable) {}
        try { findViewById<View>(R.id.btnBottomFinancas)?.setOnClickListener { startActivity(Intent(this, FinanceActivity::class.java)) } } catch (_: Throwable) {}
        try { findViewById<View>(R.id.cardGanhos)?.setOnClickListener { startActivity(Intent(this, HistoryActivity::class.java)) } } catch (_: Throwable) {}
        configurarBotaoServico()
    }

    // ── BOTÃO DE SERVIÇO ──────────────────────────────────────────
    private fun configurarBotaoServico() {
        try { atualizarBotaoServico() } catch (_: Throwable) {}
        findViewById<View>(R.id.btnServico)?.setOnClickListener {
            try {
                val ativo = prefs.getBoolean("servico_ativo", false)
                if (!ativo) {
                    // Verificar permissão de overlay (API 23+)
                    val temOverlay = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                        Settings.canDrawOverlays(this) else true

                    if (!temOverlay) {
                        Toast.makeText(this, "Permita a sobreposição de tela", Toast.LENGTH_LONG).show()
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:$packageName")))
                        }
                        return@setOnClickListener
                    }

                    if (!isAccessibilityEnabled()) {
                        mostrarDialogAcessibilidade()
                        return@setOnClickListener
                    }

                    prefs.edit().putBoolean("servico_ativo", true).apply()
                    try {
                        androidx.core.content.ContextCompat.startForegroundService(
                            this, Intent(this, FloatingEarningsService::class.java))
                    } catch (_: Throwable) {}
                    Toast.makeText(this, "Serviço ativado!", Toast.LENGTH_SHORT).show()
                } else {
                    prefs.edit().putBoolean("servico_ativo", false).apply()
                    try { stopService(Intent(this, FloatingEarningsService::class.java)) } catch (_: Throwable) {}
                    Toast.makeText(this, "Serviço desativado", Toast.LENGTH_SHORT).show()
                }
                atualizarBotaoServico()
            } catch (_: Throwable) {}
        }
    }

    private fun atualizarBotaoServico() {
        val btn    = try { findViewById<FrameLayout>(R.id.btnServico) }  catch (_: Throwable) { null } ?: return
        val tvPrin = try { findViewById<TextView>(R.id.tvStatusBar) }    catch (_: Throwable) { null }
        val tvSub  = try { findViewById<TextView>(R.id.tvStatusSub) }    catch (_: Throwable) { null }
        val dot    = try { findViewById<View>(R.id.dotServico) }          catch (_: Throwable) { null }
        val ativo  = prefs.getBoolean("servico_ativo", false)
        val temOverlay = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            Settings.canDrawOverlays(this) else true
        val permOk = isAccessibilityEnabled() && temOverlay

        when {
            !ativo -> {
                try { btn.setBackgroundResource(R.drawable.btn_servico_inativo) } catch (_: Throwable) {}
                tvPrin?.text = "SERVIÇO DESATIVADO"
                tvSub?.text  = "Toque para ativar o monitoramento"
                dot?.setBackgroundColor(android.graphics.Color.parseColor("#FF4560"))
            }
            !permOk -> {
                try { btn.setBackgroundResource(R.drawable.btn_servico_inativo) } catch (_: Throwable) {}
                tvPrin?.text = "PERMISSÃO NECESSÁRIA"
                tvSub?.text  = "Toque para configurar"
                dot?.setBackgroundColor(android.graphics.Color.parseColor("#F0B429"))
            }
            else -> {
                try { btn.setBackgroundResource(R.drawable.btn_servico_ativo) } catch (_: Throwable) {}
                tvPrin?.text = "SERVIÇO ATIVO"
                tvSub?.text  = "Monitorando corridas automaticamente"
                try { dot?.setBackgroundResource(R.drawable.dot_status) } catch (_: Throwable) {
                    dot?.setBackgroundColor(android.graphics.Color.parseColor("#00E676"))
                }
            }
        }
    }

    // ── TEMA ──────────────────────────────────────────────────────
    private fun configurarBotaoTema() {
        try { atualizarIconeTema() } catch (_: Throwable) {}
        findViewById<ImageButton>(R.id.btnTema)?.setOnClickListener {
            try {
                val atual = prefs.getInt("modo_tema", -1)
                val novo  = when (atual) { -1 -> 0; 0 -> 1; else -> -1 }
                prefs.edit().putInt("modo_tema", novo).apply()
                try { aplicarTema() }         catch (_: Throwable) {}
                try { aplicarTemaGlobal() }   catch (_: Throwable) {}
                try { atualizarIconeTema() }  catch (_: Throwable) {}
                val msg = when (novo) { 0 -> "Modo DIA"; 1 -> "Modo NOITE"; else -> "Modo AUTO" }
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
            } catch (_: Throwable) {}
        }
    }

    private fun atualizarIconeTema() {
        val modo    = prefs.getInt("modo_tema", -1)
        val noturno = ThemeHelper.isModoNoturno(prefs)
        val lbl     = when { modo == 0 -> "dia"; modo == 1 -> "noite"; noturno -> "noite"; else -> "dia" }
        try { findViewById<TextView>(R.id.tvTemaLabel)?.text = lbl } catch (_: Throwable) {}
        try { findViewById<ImageButton>(R.id.btnTema)?.setColorFilter(ThemeHelper.cor("accent_gold", prefs)) } catch (_: Throwable) {}
    }

    // ── APLICAR TEMA ──────────────────────────────────────────────
    private fun gdSolid(color: Int, radius: Float, strokeColor: Int = 0, sw: Float = 0f): android.graphics.drawable.GradientDrawable {
        val dp = resources.displayMetrics.density
        return android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius * dp
            if (sw > 0) setStroke((sw * dp).toInt(), strokeColor)
        }
    }

    private fun aplicarTema() {
        val bgDark  = ThemeHelper.cor("bg_dark",    prefs)
        val bgCard  = ThemeHelper.cor("bg_card",    prefs)
        val bgSect  = ThemeHelper.cor("bg_section", prefs)
        val toolbar = ThemeHelper.cor("toolbar",    prefs)
        val txtG    = ThemeHelper.cor("text_gray",  prefs)
        val txtW    = ThemeHelper.cor("text_white", prefs)
        val accent  = ThemeHelper.cor("accent_gold", prefs)
        val gold    = ThemeHelper.cor("accent_gold", prefs)
        val border  = ThemeHelper.cor("border",      prefs)
        val isGold  = ThemeHelper.getTema(prefs) == "gold"

        try { findViewById<FrameLayout>(R.id.rootLayout)?.setBackgroundColor(bgDark) } catch (_: Throwable) {}
        try { findViewById<Toolbar>(R.id.toolbar)?.setBackgroundColor(toolbar) } catch (_: Throwable) {}
        try {
            findViewById<NavigationView>(R.id.navView)?.apply {
                setBackgroundColor(bgDark)
                itemTextColor    = android.content.res.ColorStateList.valueOf(txtW)
                itemIconTintList = android.content.res.ColorStateList.valueOf(accent)
            }
        } catch (_: Throwable) {}
        try { configurarHeaderDrawer(findViewById(R.id.navView) ?: return) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvLogo)?.setTextColor(accent) } catch (_: Throwable) {}
        for (id in listOf(R.id.menuLine1, R.id.menuLine2, R.id.menuLine3))
            try { findViewById<View>(id)?.setBackgroundColor(accent) } catch (_: Throwable) {}
        try {
            val cv = findViewById<CardView>(R.id.cardGanhos)
            cv?.setCardBackgroundColor(bgCard)
            val inner = cv?.getChildAt(0)
            inner?.setBackgroundResource(if (isGold) R.drawable.earnings_card_gold else R.drawable.earnings_card_bg)
        } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvLabelGanhos)?.setTextColor(txtG) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvGanhoHoje)?.setTextColor(accent) } catch (_: Throwable) {}
        for (id in listOf(R.id.statCorridas, R.id.statKm, R.id.statMedia))
            try { findViewById<View>(id)?.background = gdSolid(bgSect, 10f, border, 1f) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvStatCorridas)?.setTextColor(accent) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvStatKm)?.setTextColor(gold) }        catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvStatMedia)?.setTextColor(gold) }     catch (_: Throwable) {}
        try { findViewById<CardView>(R.id.cardMeta)?.setCardBackgroundColor(bgCard) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvMetaInfo)?.setTextColor(txtG) }      catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvMetaPercent)?.setTextColor(gold) }   catch (_: Throwable) {}
        try { findViewById<ProgressBar>(R.id.progressMetaDia)?.progressTintList = android.content.res.ColorStateList.valueOf(accent) } catch (_: Throwable) {}
        try { findViewById<LinearLayout>(R.id.layoutDica)?.background = gdSolid(bgCard, 8f, border, 1f) } catch (_: Throwable) {}
        try { findViewById<View>(R.id.dicaBorder)?.setBackgroundColor(accent) }  catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvDica)?.setTextColor(txtG) }          catch (_: Throwable) {}
        try { findViewById<LinearLayout>(R.id.bottomNav)?.setBackgroundColor(bgCard) } catch (_: Throwable) {}
        try { findViewById<View>(R.id.indicadorInicio)?.setBackgroundColor(accent) }   catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvBotInicio)?.setTextColor(accent) }         catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvBotCorridas)?.setTextColor(txtG) }         catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvBotMetricas)?.setTextColor(txtG) }         catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvBotFinancas)?.setTextColor(txtG) }         catch (_: Throwable) {}
        try { atualizarBotaoServico() } catch (_: Throwable) {}
    }

    // ── STATS ─────────────────────────────────────────────────────
    private fun atualizarStats() {
        val corridas = try { db.buscarHoje() } catch (_: Throwable) { emptyList() }
        val resumo   = try { db.resumo(corridas) } catch (_: Throwable) { mapOf() }
        val total    = resumo["total"]         ?: 0f
        val km       = resumo["km_total"]      ?: 0f
        val media    = resumo["media_corrida"] ?: 0f
        val qtd      = (resumo["corridas"]     ?: 0f).toInt()
        val meta     = prefs.getFloat("meta_diaria", 0f)
        val accent   = ThemeHelper.cor("accent_gold", prefs)

        try { findViewById<TextView>(R.id.tvGanhoHoje)?.text   = "%.2f".format(total).replace(".", ",") } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvStatCorridas)?.text = "$qtd" }                                catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvStatKm)?.text       = "%.1f km".format(km).replace(".", ",") } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvStatMedia)?.text    = "R$ %.2f".format(media).replace(".", ",") } catch (_: Throwable) {}

        val cardMeta = try { findViewById<CardView>(R.id.cardMeta) } catch (_: Throwable) { null }
        if (meta > 0f) {
            val pct = ((total / meta) * 100).toInt().coerceIn(0, 100)
            cardMeta?.visibility = View.VISIBLE
            try { findViewById<TextView>(R.id.tvMetaInfo)?.text    = "META DIÁRIA · R$ %.0f".format(meta) } catch (_: Throwable) {}
            try { findViewById<TextView>(R.id.tvMetaPercent)?.text = "$pct%" }                               catch (_: Throwable) {}
            try { findViewById<ProgressBar>(R.id.progressMetaDia)?.progress = pct }                         catch (_: Throwable) {}
        } else {
            cardMeta?.visibility = View.GONE
        }

        try { exibirDica() }       catch (_: Throwable) {}
        try { atualizarWidget() }  catch (_: Throwable) {}
        try { atualizarBotaoServico() } catch (_: Throwable) {}
    }

    // ── SHIMMER ───────────────────────────────────────────────────
    private fun iniciarShimmer() {
        try {
            findViewById<View>(R.id.viewShimmer)?.visibility = View.INVISIBLE
            val tvLogo = findViewById<TextView>(R.id.tvLogo) ?: return
            ThemeHelper.animarLogoShimmer(tvLogo, prefs)
        } catch (_: Throwable) {}
    }

    // ── DICA ──────────────────────────────────────────────────────
    private fun exibirDica() {
        try {
            val qtd  = try { db.buscarHoje().size } catch (_: Throwable) { 0 }
            val day  = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR)
            val dica = when {
                qtd == 0 -> DICAS[day % DICAS.size]
                qtd < 3  -> "Você já fez $qtd corrida${if (qtd > 1) "s" else ""} hoje. Continue assim!"
                qtd < 10 -> "Você já fez $qtd corridas hoje. Ótimo ritmo!"
                else     -> "Dia incrível! $qtd corridas completas!"
            }
            findViewById<TextView>(R.id.tvDica)?.text = dica
        } catch (_: Throwable) {}
    }

    // ── WIDGET ────────────────────────────────────────────────────
    fun atualizarWidget() {
        try {
            val mgr = android.appwidget.AppWidgetManager.getInstance(this)
            android.appwidget.AppWidgetManager.getInstance(this)
                .getAppWidgetIds(android.content.ComponentName(this, FluxoWidgetProvider::class.java))
                .forEach { FluxoWidgetProvider.updateWidget(this, mgr, it) }
        } catch (_: Throwable) {}
    }

    // ── ACESSIBILIDADE ────────────────────────────────────────────
    private fun mostrarDialogAcessibilidade() {
        try {
            android.app.AlertDialog.Builder(this)
                .setTitle("Ativar Monitoramento")
                .setMessage(
                    "Para monitorar corridas automaticamente:\n\n" +
                    "1. Toque em 'Ir para Acessibilidade'\n" +
                    "2. Localize 'FluxoApp' na lista\n" +
                    "3. Ative o serviço\n" +
                    "4. Volte aqui e toque em Ativar novamente"
                )
                .setPositiveButton("Ir para Acessibilidade") { _, _ ->
                    try {
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        })
                    } catch (_: Throwable) {}
                }
                .setNegativeButton("Cancelar", null)
                .show()
        } catch (_: Throwable) {}
    }

    private fun isAccessibilityEnabled(): Boolean {
        return try {
            val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            s.contains("fluxoapp", ignoreCase = true) || s.contains("MaximAccessibilityService", ignoreCase = true)
        } catch (_: Throwable) { false }
    }
}
