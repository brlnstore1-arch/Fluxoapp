package com.fluxoapp

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.MenuItem
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.*
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    private lateinit var prefs: SharedPreferences
    private lateinit var db: DatabaseHelper
    private lateinit var drawerLayout: DrawerLayout
    private var metaJaCelebrada = false
    private val handler = Handler(Looper.getMainLooper())

    private val FRASES = listOf(
        "Cada km rodado e um passo a mais para seu sonho!",
        "Motorista de sucesso e aquele que nunca desiste!",
        "Hoje e um otimo dia para bater sua meta!",
        "Sua dedicacao e o combustivel do seu sucesso!",
        "O melhor horario para trabalhar e agora!",
        "Cada corrida bem feita e um cliente fiel!",
        "Sucesso e a soma de pequenas conquistas diarias!",
        "Voce esta no caminho certo, continue!"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("FluxoApp", MODE_PRIVATE)
        db = DatabaseHelper(this)

        configurarToolbarEDrawer()
        configurarBotoes()
        atualizarStatus()
        atualizarStats()
        exibirFrase()
        verificarModoNoturno()

        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else if (prefs.getBoolean("flutuante_ativo", true)) {
            try { startService(Intent(this, FloatingEarningsService::class.java)) } catch (_: Exception) {}
        }
    }

    override fun onResume() {
        super.onResume()
        atualizarStatus()
        atualizarStats()
    }

    private fun verificarModoNoturno() {
        val hora = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val tvModo = findViewById<TextView>(R.id.tvModoNoturno)
        if (hora >= 20 || hora < 6) {
            tvModo?.visibility = View.VISIBLE
            tvModo?.text = "Modo noturno ativo"
        } else {
            tvModo?.visibility = View.GONE
        }
    }

    private fun verificarCelebracao(total: Float, meta: Float) {
        if (meta <= 0 || metaJaCelebrada) return
        if (total >= meta) { metaJaCelebrada = true; celebrarMeta() }
    }

    private fun celebrarMeta() {
        try {
            val tvGanho = findViewById<TextView>(R.id.tvGanhoHoje) ?: return
            val scaleX = ObjectAnimator.ofFloat(tvGanho, "scaleX", 1f, 1.3f, 1f)
            val scaleY = ObjectAnimator.ofFloat(tvGanho, "scaleY", 1f, 1.3f, 1f)
            AnimatorSet().apply { playTogether(scaleX, scaleY); duration = 600; interpolator = AccelerateDecelerateInterpolator(); start() }
            repeat(6) { i ->
                handler.postDelayed({
                    tvGanho.setTextColor(if (i % 2 == 0) Color.parseColor("#FFD740") else Color.parseColor("#00E676"))
                }, i * 300L)
            }
            handler.postDelayed({ tvGanho.setTextColor(Color.parseColor("#FFD740")) }, 1800)
            try {
                val v = getSystemService(VIBRATOR_SERVICE) as android.os.Vibrator
                v.vibrate(longArrayOf(0, 200, 100, 200, 100, 400), -1)
            } catch (_: Exception) {}
            handler.postDelayed({ Toast.makeText(this, "PARABENS! Voce bateu sua meta!", Toast.LENGTH_LONG).show() }, 500)
            try {
                val tone = android.media.ToneGenerator(android.media.AudioManager.STREAM_NOTIFICATION, 100)
                tone.startTone(android.media.ToneGenerator.TONE_PROP_ACK, 300)
                handler.postDelayed({ tone.startTone(android.media.ToneGenerator.TONE_PROP_ACK, 500) }, 400)
                handler.postDelayed({ tone.release() }, 1000)
            } catch (_: Exception) {}
            atualizarWidget()
        } catch (e: Exception) { e.printStackTrace() }
    }

    fun atualizarWidget() {
        try {
            val mgr = AppWidgetManager.getInstance(this)
            val ids = mgr.getAppWidgetIds(ComponentName(this, FluxoWidgetProvider::class.java))
            ids.forEach { FluxoWidgetProvider.updateWidget(this, mgr, it) }
        } catch (_: Exception) {}
    }

    private fun configurarToolbarEDrawer() {
        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        drawerLayout = findViewById(R.id.drawerLayout)
        val navView = findViewById<NavigationView>(R.id.navView)
        navView.setNavigationItemSelectedListener(this)
        val toggle = ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.app_name, R.string.app_name)
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()
        try { toggle.drawerArrowDrawable.color = getColor(R.color.accent_cyan) } catch (_: Exception) {}
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        drawerLayout.closeDrawer(GravityCompat.START)
        when (item.itemId) {
            R.id.nav_configuracoes -> startActivity(Intent(this, SettingsActivity::class.java))
            R.id.nav_relatorios   -> startActivity(Intent(this, ReportsActivity::class.java))
            R.id.nav_financas     -> startActivity(Intent(this, FinanceActivity::class.java))
            R.id.nav_historico    -> startActivity(Intent(this, HistoryActivity::class.java))
            R.id.nav_sobre        -> startActivity(Intent(this, AboutActivity::class.java))
            R.id.nav_sair -> {
                prefs.edit().putBoolean("servico_ativo", false).apply()
                try { stopService(Intent(this, FloatingEarningsService::class.java)) } catch (_: Exception) {}
                Toast.makeText(this, "Servico desativado", Toast.LENGTH_SHORT).show()
                atualizarStatus()
            }
        }
        return true
    }

    private fun configurarBotoes() {
        findViewById<Button>(R.id.btnPermissaoAcessibilidade)?.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.btnPermissaoOverlay)?.setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        val switchServico = findViewById<Switch>(R.id.switchServico)
        switchServico?.isChecked = prefs.getBoolean("servico_ativo", true)
        switchServico?.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("servico_ativo", isChecked).apply()
            if (isChecked && prefs.getBoolean("flutuante_ativo", true))
                try { startService(Intent(this, FloatingEarningsService::class.java)) } catch (_: Exception) {}
            else if (!isChecked)
                try { stopService(Intent(this, FloatingEarningsService::class.java)) } catch (_: Exception) {}
            Toast.makeText(this, if (isChecked) "Servico ATIVADO" else "Servico PAUSADO", Toast.LENGTH_SHORT).show()
            atualizarStatus()
        }
        val switchAuto = findViewById<Switch>(R.id.switchAutoAceitar)
        switchAuto?.isChecked = prefs.getBoolean("auto_aceitar", false)
        switchAuto?.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("auto_aceitar", isChecked).apply()
        }
        val etMinimo = findViewById<EditText>(R.id.etMinimoPorKm)
        etMinimo?.setText("%.2f".format(prefs.getFloat("minimo_km", 1.20f)))
        findViewById<Button>(R.id.btnSalvar)?.setOnClickListener {
            val v = etMinimo?.text.toString().replace(",", ".").toFloatOrNull()
            if (v != null && v > 0) {
                prefs.edit().putFloat("minimo_km", v).apply()
                Toast.makeText(this, "R$ ${"%.2f".format(v)}/km salvo!", Toast.LENGTH_SHORT).show()
            } else Toast.makeText(this, "Valor invalido", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnHistorico)?.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        findViewById<TextView>(R.id.btnHistorico2)?.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
    }

    private fun exibirFrase() {
        val dayOfYear = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR)
        findViewById<TextView>(R.id.tvFraseDia)?.text = FRASES[dayOfYear % FRASES.size]
    }

    private fun atualizarStatus() {
        val tvStatus = findViewById<TextView>(R.id.tvStatus)
        val btnAcess = findViewById<Button>(R.id.btnPermissaoAcessibilidade)
        val btnOverlay = findViewById<Button>(R.id.btnPermissaoOverlay)
        val servicoAtivo = prefs.getBoolean("servico_ativo", true)
        val acessAtivo = isAccessibilityEnabled()
        val overlayAtivo = Settings.canDrawOverlays(this)
        btnAcess?.visibility = View.GONE
        btnOverlay?.visibility = View.GONE
        when {
            !servicoAtivo -> tvStatus?.text = "Servico pausado"
            !acessAtivo && !overlayAtivo -> {
                tvStatus?.text = "Ative Acessibilidade e Sobreposicao!"
                btnAcess?.visibility = View.VISIBLE; btnOverlay?.visibility = View.VISIBLE
            }
            !acessAtivo -> { tvStatus?.text = "Ative a Acessibilidade!"; btnAcess?.visibility = View.VISIBLE }
            !overlayAtivo -> { tvStatus?.text = "Ative a sobreposicao!"; btnOverlay?.visibility = View.VISIBLE }
            else -> tvStatus?.text = "Monitorando o Maxim!"
        }
    }

    private fun atualizarStats() {
        val corridas = db.buscarHoje()
        val resumo = db.resumo(corridas)
        val total = resumo["total"] ?: 0f
        val meta = prefs.getFloat("meta_diaria", 0f)
        findViewById<TextView>(R.id.tvGanhoHoje)?.text = "R$ ${"%.2f".format(total)}"
        findViewById<TextView>(R.id.tvTotalCorridas)?.text = "${(resumo["corridas"] ?: 0f).toInt()}"
        findViewById<TextView>(R.id.tvMediaKm)?.text = "R$ ${"%.2f".format(resumo["media_km"] ?: 0f)}"
        findViewById<TextView>(R.id.tvMediaCorrida)?.text = "R$ ${"%.2f".format(resumo["media_corrida"] ?: 0f)}"
        val progressMeta = findViewById<ProgressBar>(R.id.progressMetaDia)
        val tvMeta = findViewById<TextView>(R.id.tvMetaDia)
        if (meta > 0) {
            val percent = ((total / meta) * 100).toInt().coerceIn(0, 100)
            progressMeta?.progress = percent
            try {
                val cor = if (percent >= 100) "#FFD740" else if (percent >= 75) "#00E676" else "#00E5FF"
                progressMeta?.progressTintList = android.content.res.ColorStateList.valueOf(Color.parseColor(cor))
            } catch (_: Exception) {}
            tvMeta?.text = "Meta: R$ ${"%.0f".format(meta)} ($percent%)"
            progressMeta?.visibility = View.VISIBLE
            tvMeta?.visibility = View.VISIBLE
            verificarCelebracao(total, meta)
        } else {
            progressMeta?.visibility = View.GONE
            tvMeta?.visibility = View.GONE
        }
        atualizarWidget()
    }

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.contains("fluxoapp", ignoreCase = true) ||
               enabled.contains("MaximAccessibilityService", ignoreCase = true)
    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) drawerLayout.closeDrawer(GravityCompat.START)
        else super.onBackPressed()
    }
}
