package com.fluxoapp

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.MenuItem
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.*
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    private lateinit var prefs: SharedPreferences
    private lateinit var db: DatabaseHelper
    private lateinit var drawerLayout: DrawerLayout
    private val handler = Handler(Looper.getMainLooper())

    private val FRASES = listOf(
        "Cada km rodado e um passo a mais para seu sonho!",
        "Motorista de sucesso e aquele que nunca desiste!",
        "Hoje e um otimo dia para bater sua meta!",
        "Sua dedicacao e o combustivel do seu sucesso!",
        "O melhor horario para trabalhar e agora!",
        "Cada corrida bem feita e um cliente fiel!",
        "Sucesso e a soma de pequenas conquistas diarias!",
        "Voce esta no caminho certo, continue!",
        "Foco, forca e fe! Seu esforco tem valor!",
        "Cada corrida aceita e uma oportunidade de ganhar mais!"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("FluxoApp", MODE_PRIVATE)
        db = DatabaseHelper(this)

        configurarToolbarEDrawer()
        configurarBotoes()
        configurarBotaoTema()
        atualizarStatus()
        atualizarStats()
        exibirFrase()
        aplicarTema()

        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else if (prefs.getBoolean("flutuante_ativo", true)) {
            try { startService(Intent(this, FloatingEarningsService::class.java)) } catch (_: Exception) {}
        }
    }

    override fun onResume() {
        super.onResume()
        atualizarStatus()
        atualizarStats()
        aplicarTema()
        atualizarIconeTema()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }

    // ══════════════════════════════════════
    // TEMA DIA / NOITE
    // ══════════════════════════════════════
    private fun configurarBotaoTema() {
        val btnTema = findViewById<ImageButton>(R.id.btnTema)
        atualizarIconeTema()
        btnTema?.setOnClickListener {
            val atual = prefs.getInt("modo_tema", -1)
            // Ciclo: auto → dia (0) → noite (1) → auto (-1)
            val novoModo = when (atual) {
                -1 -> 0   // auto → forçar dia
                0  -> 1   // dia  → forçar noite
                else -> -1 // noite → auto
            }
            prefs.edit().putInt("modo_tema", novoModo).apply()
            aplicarTema()
            atualizarIconeTema()
            val msg = when (novoModo) {
                0 -> "Modo DIA ativado"
                1 -> "Modo NOITE ativado"
                else -> "Modo automatico (horario)"
            }
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }
    }

    private fun atualizarIconeTema() {
        val btnTema = findViewById<ImageButton>(R.id.btnTema) ?: return
        val modo = prefs.getInt("modo_tema", -1)
        val noturno = ThemeHelper.isModoNoturno(prefs)
        val emoji = when {
            modo == 0 -> "☀️"
            modo == 1 -> "🌙"
            noturno -> "🌙"
            else -> "☀️"
        }
        // Usa um drawable padrão e muda a tint conforme o tema
        val tint = if (noturno) Color.parseColor("#00E5FF") else Color.parseColor("#0095B3")
        btnTema.setColorFilter(tint)
        // Mostra o estado no label
        findViewById<TextView>(R.id.tvTemaLabel)?.text = emoji
    }

    private fun aplicarTema() {
        val noturno = ThemeHelper.isModoNoturno(prefs)
        val bgDark    = ThemeHelper.cor("bg_dark", noturno)
        val bgCard    = ThemeHelper.cor("bg_card", noturno)
        val textMain  = ThemeHelper.cor("text_white", noturno)
        val textGray  = ThemeHelper.cor("text_gray", noturno)
        val cyan      = ThemeHelper.cor("accent_cyan", noturno)
        val green     = ThemeHelper.cor("accent_green", noturno)

        // Fundo geral
        findViewById<View>(R.id.rootLayout)?.setBackgroundColor(bgDark)
        // Toolbar
        findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)?.setBackgroundColor(bgCard)
        // Frase
        findViewById<TextView>(R.id.tvFraseDia)?.setTextColor(textGray)
        // Ganho
        findViewById<TextView>(R.id.tvGanhoHoje)?.let { tv ->
            if (tv.currentTextColor != Color.parseColor("#FFD740")) tv.setTextColor(green)
        }
        // Textos de valores
        listOf(R.id.tvTotalCorridas, R.id.tvMediaKm, R.id.tvMediaCorrida,
               R.id.tvStatus, R.id.tvMetaDia).forEach {
            try { findViewById<TextView>(it)?.setTextColor(textMain) } catch (_: Exception) {}
        }
        // Fundo do scroll aplicado via rootLayout já configurado acima
    }

    // ══════════════════════════════════════
    // CELEBRAÇÃO META — UMA VEZ POR DIA
    // ══════════════════════════════════════
    private fun verificarCelebracao(total: Float, meta: Float) {
        if (meta <= 0) return
        if (total < meta) return
        val hoje = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(java.util.Date())
        val ultima = prefs.getString("ultima_celebracao", "")
        if (ultima == hoje) return
        prefs.edit().putString("ultima_celebracao", hoje).apply()
        celebrarMeta()
    }

    private fun celebrarMeta() {
        try {
            val corDourado = Color.parseColor("#FFD740")
            val rootView = window.decorView.rootView

            // Fundo pisca dourado
            repeat(8) { i ->
                handler.postDelayed({
                    try { rootView.setBackgroundColor(if (i % 2 == 0) corDourado else Color.TRANSPARENT) } catch (_: Exception) {}
                }, i * 180L)
            }
            handler.postDelayed({ try { rootView.setBackgroundColor(Color.TRANSPARENT) } catch (_: Exception) {} }, 1500L)

            // Valor anima e fica dourado
            val tvGanho = findViewById<TextView>(R.id.tvGanhoHoje)
            tvGanho?.let {
                val scaleX = ObjectAnimator.ofFloat(it, "scaleX", 1f, 1.5f, 1.2f)
                val scaleY = ObjectAnimator.ofFloat(it, "scaleY", 1f, 1.5f, 1.2f)
                AnimatorSet().apply { playTogether(scaleX, scaleY); duration = 700; interpolator = AccelerateDecelerateInterpolator(); start() }
                repeat(8) { i -> handler.postDelayed({ try { it.setTextColor(if (i % 2 == 0) corDourado else Color.WHITE) } catch (_: Exception) {} }, i * 200L) }
                handler.postDelayed({ try { it.setTextColor(corDourado) } catch (_: Exception) {} }, 1800L)
            }

            // Tudo dourado
            handler.postDelayed({
                try {
                    findViewById<TextView>(R.id.tvMetaDia)?.setTextColor(corDourado)
                    findViewById<ProgressBar>(R.id.progressMetaDia)?.progressTintList =
                        android.content.res.ColorStateList.valueOf(corDourado)
                } catch (_: Exception) {}
            }, 1800L)

            // Vibração comemorativa
            try {
                val v = getSystemService(VIBRATOR_SERVICE) as android.os.Vibrator
                v.vibrate(longArrayOf(0, 150, 80, 150, 80, 150, 80, 500), -1)
            } catch (_: Exception) {}

            // Som de aplauso (sequência ritmada)
            try {
                val tone = android.media.ToneGenerator(android.media.AudioManager.STREAM_NOTIFICATION, 100)
                listOf(0L, 110L, 220L, 330L, 440L, 550L, 660L, 770L, 900L, 1030L, 1160L).forEach { d ->
                    handler.postDelayed({ try { tone.startTone(android.media.ToneGenerator.TONE_PROP_ACK, 75) } catch (_: Exception) {} }, d)
                }
                handler.postDelayed({ try { tone.release() } catch (_: Exception) {} }, 1400L)
            } catch (_: Exception) {}

            // Toast
            handler.postDelayed({ Toast.makeText(this, "META BATIDA! PARABENS GUERREIRO!", Toast.LENGTH_LONG).show() }, 600L)
            atualizarWidget()
        } catch (_: Exception) {}
    }

    fun atualizarWidget() {
        try {
            val mgr = AppWidgetManager.getInstance(this)
            val ids = mgr.getAppWidgetIds(ComponentName(this, FluxoWidgetProvider::class.java))
            ids.forEach { FluxoWidgetProvider.updateWidget(this, mgr, it) }
        } catch (_: Exception) {}
    }

    private fun configurarToolbarEDrawer() {
        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        drawerLayout = findViewById(R.id.drawerLayout)
        val navView = findViewById<NavigationView>(R.id.navView)
        navView.setNavigationItemSelectedListener(this)
        val toggle = ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.app_name, R.string.app_name)
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()
        try { toggle.drawerArrowDrawable.color = getColor(R.color.accent_cyan) } catch (_: Exception) {}
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        drawerLayout.closeDrawer(GravityCompat.START)
        when (item.itemId) {
            R.id.nav_configuracoes -> startActivity(Intent(this, SettingsActivity::class.java))
            R.id.nav_relatorios   -> startActivity(Intent(this, ReportsActivity::class.java))
            R.id.nav_financas     -> startActivity(Intent(this, FinanceActivity::class.java))
            R.id.nav_historico    -> startActivity(Intent(this, HistoryActivity::class.java))
            R.id.nav_sobre        -> startActivity(Intent(this, AboutActivity::class.java))
            R.id.nav_sair -> {
                prefs.edit().putBoolean("servico_ativo", false).apply()
                try { stopService(Intent(this, FloatingEarningsService::class.java)) } catch (_: Exception) {}
                Toast.makeText(this, "Servico desativado", Toast.LENGTH_SHORT).show()
                atualizarStatus()
            }
        }
        return true
    }

    private fun configurarBotoes() {
        findViewById<Button>(R.id.btnPermissaoAcessibilidade)?.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.btnPermissaoOverlay)?.setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        val switchServico = findViewById<Switch>(R.id.switchServico)
        switchServico?.isChecked = prefs.getBoolean("servico_ativo", true)
        switchServico?.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("servico_ativo", isChecked).apply()
            if (isChecked && prefs.getBoolean("flutuante_ativo", true))
                try { startService(Intent(this, FloatingEarningsService::class.java)) } catch (_: Exception) {}
            else if (!isChecked)
                try { stopService(Intent(this, FloatingEarningsService::class.java)) } catch (_: Exception) {}
            Toast.makeText(this, if (isChecked) "Servico ATIVADO" else "Servico PAUSADO", Toast.LENGTH_SHORT).show()
            atualizarStatus()
        }
        val switchAuto = findViewById<Switch>(R.id.switchAutoAceitar)
        switchAuto?.isChecked = prefs.getBoolean("auto_aceitar", false)
        switchAuto?.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("auto_aceitar", isChecked).apply()
        }
        val etMinimo = findViewById<EditText>(R.id.etMinimoPorKm)
        etMinimo?.setText("%.2f".format(prefs.getFloat("minimo_km", 1.20f)))
        findViewById<Button>(R.id.btnSalvar)?.setOnClickListener {
            val v = etMinimo?.text.toString().replace(",", ".").toFloatOrNull()
            if (v != null && v > 0) {
                prefs.edit().putFloat("minimo_km", v).apply()
                Toast.makeText(this, "R$ ${"%.2f".format(v)}/km salvo!", Toast.LENGTH_SHORT).show()
            } else Toast.makeText(this, "Valor invalido", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnHistorico)?.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        findViewById<TextView>(R.id.btnHistorico2)?.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
    }

    private fun exibirFrase() {
        val dayOfYear = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR)
        findViewById<TextView>(R.id.tvFraseDia)?.text = FRASES[dayOfYear % FRASES.size]
    }

    private fun atualizarStatus() {
        val tvStatus = findViewById<TextView>(R.id.tvStatus)
        val btnAcess = findViewById<Button>(R.id.btnPermissaoAcessibilidade)
        val btnOverlay = findViewById<Button>(R.id.btnPermissaoOverlay)
        val servicoAtivo = prefs.getBoolean("servico_ativo", true)
        btnAcess?.visibility = View.GONE; btnOverlay?.visibility = View.GONE
        when {
            !servicoAtivo -> tvStatus?.text = "Servico pausado"
            !isAccessibilityEnabled() && !Settings.canDrawOverlays(this) -> {
                tvStatus?.text = "Ative Acessibilidade e Sobreposicao!"
                btnAcess?.visibility = View.VISIBLE; btnOverlay?.visibility = View.VISIBLE
            }
            !isAccessibilityEnabled() -> { tvStatus?.text = "Ative a Acessibilidade!"; btnAcess?.visibility = View.VISIBLE }
            !Settings.canDrawOverlays(this) -> { tvStatus?.text = "Ative a sobreposicao!"; btnOverlay?.visibility = View.VISIBLE }
            else -> tvStatus?.text = "Monitorando o Maxim!"
        }
    }

    private fun atualizarStats() {
        val corridas = db.buscarHoje()
        val resumo = db.resumo(corridas)
        val total = resumo["total"] ?: 0f
        val meta = prefs.getFloat("meta_diaria", 0f)
        val noturno = ThemeHelper.isModoNoturno(prefs)
        val green = ThemeHelper.cor("accent_green", noturno)

        findViewById<TextView>(R.id.tvGanhoHoje)?.apply {
            text = "R$ ${"%.2f".format(total)}"
            if (currentTextColor != Color.parseColor("#FFD740")) setTextColor(green)
        }
        findViewById<TextView>(R.id.tvTotalCorridas)?.text = "${(resumo["corridas"] ?: 0f).toInt()}"
        findViewById<TextView>(R.id.tvMediaKm)?.text = "R$ ${"%.2f".format(resumo["media_km"] ?: 0f)}"
        findViewById<TextView>(R.id.tvMediaCorrida)?.text = "R$ ${"%.2f".format(resumo["media_corrida"] ?: 0f)}"

        val progressMeta = findViewById<ProgressBar>(R.id.progressMetaDia)
        val tvMeta = findViewById<TextView>(R.id.tvMetaDia)
        if (meta > 0) {
            val percent = ((total / meta) * 100).toInt().coerceIn(0, 100)
            progressMeta?.progress = percent
            try {
                val cor = if (percent >= 100) "#FFD740" else if (percent >= 75) "#00E676" else "#00E5FF"
                progressMeta?.progressTintList = android.content.res.ColorStateList.valueOf(Color.parseColor(cor))
            } catch (_: Exception) {}
            tvMeta?.text = "Meta: R$ ${"%.0f".format(meta)} ($percent%)"
            progressMeta?.visibility = View.VISIBLE; tvMeta?.visibility = View.VISIBLE
            verificarCelebracao(total, meta)
        } else {
            progressMeta?.visibility = View.GONE; tvMeta?.visibility = View.GONE
        }
        atualizarWidget()
    }

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.contains("fluxoapp", ignoreCase = true) ||
               enabled.contains("MaximAccessibilityService", ignoreCase = true)
    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) drawerLayout.closeDrawer(GravityCompat.START)
        else super.onBackPressed()
    }
}
