package com.fluxoapp

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

/**
 * MainActivity — FluxoApp
 *
 * Ponto de entrada principal. Responsável por lifecycle e navegação.
 *
 * Lógica extraída para helpers:
 *   - MainUiHelper.kt      → tema, shimmer, drawer header
 *   - MainServiceHelper.kt → serviço de acessibilidade, licença, dialogs
 *   - MainStatsHelper.kt   → stats, dicas, celebração, widget, notificações
 */
class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    internal lateinit var prefs: SharedPreferences
    internal lateinit var db: DatabaseHelper
    internal var drawerLayout: DrawerLayout? = null
    internal val handler = Handler(Looper.getMainLooper())

    internal val DICAS = listOf(
        "Cada km rodado é um passo a mais para seu sonho!",
        "Motorista de sucesso é aquele que nunca desiste!",
        "Hoje é um ótimo dia para bater sua meta!",
        "Sua dedicação é o combustível do seu sucesso!",
        "O melhor horário para trabalhar é agora!",
        "Cada corrida bem feita é um cliente fiel!",
        "Sucesso é a soma de pequenas conquistas diárias!",
        "Você está no caminho certo, continue!",
        "Foco, força e fé! Seu esforço tem valor!",
        "Cada corrida aceita é uma oportunidade de ganhar mais!"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeSelector.aplicar(this)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("FluxoApp", MODE_PRIVATE)
        db    = DatabaseHelper(this)

        if (!LicenseManager.estaLogado()) {
            startActivity(Intent(this, LoginActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            })
            finish(); return
        }

        if (!prefs.getBoolean("onboarding_ok", false)) {
            startActivity(Intent(this, OnboardingActivity::class.java))
            finish(); return
        }

        verificarLicencaERestringir()

        if (prefs.getBoolean("mostrar_aviso_trial", true)) {
            window.decorView.post { mostrarDialogTrial() }
        }

        try { configurarToolbarEDrawer() } catch (_: Throwable) {}
        try { configurarBotaoTema()      } catch (_: Throwable) {}
        try { configurarNavegacao()      } catch (_: Throwable) {}
        try { aplicarTema()              } catch (_: Throwable) {}
        try { atualizarStats()           } catch (_: Throwable) {}
        try { exibirDica()               } catch (_: Throwable) {}

        window.decorView.post {
            try { iniciarShimmer()    } catch (_: Throwable) {}
            try { aplicarTemaGlobal() } catch (_: Throwable) {}
        }
    }

    override fun onResume() {
        super.onResume()
        try {
            LicenseManager.uid()?.let { uid ->
                AppStartupManager.atualizarLastSeen(uid)
                val vc = packageManager.getPackageInfo(packageName, 0).versionCode
                AppStartupManager.verificarConfigApp(this, vc) {}
                verificarNotificacoes()

                val email = LicenseManager.email() ?: ""
                val nome  = prefs.getString("perfil_nome", "Motorista") ?: "Motorista"
                PaymentManager.verificarPagamentosPendentes(uid, email, nome) {
                    runOnUiThread {
                        prefs.edit().putString("plano_atual", PaymentManager.planoMensal.id).apply()
                        try { atualizarStats() } catch (_: Throwable) {}
                        android.widget.Toast.makeText(
                            this, "✅ Pagamento confirmado! Plano mensal ativado.",
                            android.widget.Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
        } catch (_: Throwable) {}

        try { UpdateManager.verificar(this) } catch (_: Throwable) {}
        try { atualizarStats()     } catch (_: Throwable) {}
        try { aplicarTema()        } catch (_: Throwable) {}
        try { atualizarIconeTema() } catch (_: Throwable) {}
        try { sendBroadcast(Intent(FloatingEarningsService.ACTION_TEMA)) } catch (_: Throwable) {}
        window.decorView.post {
            try { iniciarShimmer()    } catch (_: Throwable) {}
            try { aplicarTemaGlobal() } catch (_: Throwable) {}
            try {
                val nv = findViewById<NavigationView>(R.id.navView)
                if (nv != null) configurarHeaderDrawer(nv)
            } catch (_: Throwable) {}
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }

    override fun onBackPressed() {
        val dl = drawerLayout
        if (dl != null && dl.isDrawerOpen(GravityCompat.START))
            dl.closeDrawer(GravityCompat.START)
        else super.onBackPressed()
    }

    // ── Toolbar + Drawer ──────────────────────────────────────────────────

    private fun configurarToolbarEDrawer() {
        try {
            val toolbar = findViewById<Toolbar>(R.id.toolbar)
            if (toolbar != null) setSupportActionBar(toolbar)
            supportActionBar?.setDisplayShowTitleEnabled(false)
        } catch (_: Throwable) {}

        try {
            drawerLayout = findViewById(R.id.drawerLayout)
            val navView  = findViewById<NavigationView>(R.id.navView)
            navView?.setNavigationItemSelectedListener(this)
            drawerLayout?.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED)
        } catch (_: Throwable) {}

        try {
            val dl = drawerLayout
            findViewById<View>(R.id.btnMenu)?.setOnClickListener {
                if (dl == null) return@setOnClickListener
                if (dl.isDrawerOpen(GravityCompat.START)) dl.closeDrawer(GravityCompat.START)
                else dl.openDrawer(GravityCompat.START)
            }
        } catch (_: Throwable) {}

        try {
            val navView = findViewById<NavigationView>(R.id.navView)
            if (navView != null) configurarHeaderDrawer(navView)
        } catch (_: Throwable) {}
    }

    internal fun configurarHeaderDrawer(navView: NavigationView) {
        val header = navView.getHeaderView(0) ?: return
        val accent  = ThemeHelper.cor("accent_gold", prefs)
        val bgDark  = ThemeHelper.cor("bg_dark", prefs)
        val txtW    = ThemeHelper.cor("text_white", prefs)
        val txtG    = ThemeHelper.cor("text_gray", prefs)
        val dp      = resources.displayMetrics.density

        header.findViewById<android.widget.LinearLayout>(R.id.navHeaderBg)?.apply {
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(
                    android.graphics.Color.argb(80,
                        android.graphics.Color.red(accent),
                        android.graphics.Color.green(accent),
                        android.graphics.Color.blue(accent)),
                    bgDark
                )
            )
        }

        val nome    = prefs.getString("perfil_nome",   "Motorista")           ?: "Motorista"
        val cidade  = prefs.getString("perfil_cidade", "Bragança - PA")       ?: "Bragança - PA"
        val status  = prefs.getString("perfil_status", "🚀 Trabalhando duro!") ?: "🚀 Trabalhando duro!"
        val veiculo = prefs.getString("perfil_veiculo", "moto")               ?: "moto"
        val iconeVeiculo = when (veiculo) { "carro" -> "🚗"; "bike" -> "🚴"; else -> "🏍️" }

        header.findViewById<android.widget.TextView>(R.id.tvNomePerfil)?.apply {
            text = "$iconeVeiculo  $nome"; setTextColor(txtW)
        }
        header.findViewById<android.widget.TextView>(R.id.tvCidadePerfil)?.apply {
            text = "📍 $cidade"; setTextColor(txtG)
        }
        header.findViewById<android.widget.TextView>(R.id.tvStatusPerfil)?.apply {
            text = status; setTextColor(accent)
        }

        val iv = header.findViewById<android.widget.ImageView>(R.id.ivFotoPerfil)
        prefs.getString("perfil_foto", null)?.let { path ->
            try {
                val bmp = android.graphics.BitmapFactory.decodeFile(path)
                if (bmp != null) {
                    val size = minOf(bmp.width, bmp.height)
                    val sq   = android.graphics.Bitmap.createBitmap(bmp, (bmp.width-size)/2, (bmp.height-size)/2, size, size)
                    val out  = android.graphics.Bitmap.createBitmap(size, size, android.graphics.Bitmap.Config.ARGB_8888)
                    val canvas = android.graphics.Canvas(out)
                    val paint  = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
                    canvas.drawCircle(size/2f, size/2f, size/2f, paint)
                    paint.xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.SRC_IN)
                    canvas.drawBitmap(sq, 0f, 0f, paint)
                    iv?.setImageBitmap(out)
                }
            } catch (_: Throwable) {}
        }
        try {
            iv?.background = android.graphics.drawable.GradientDrawable().apply {
                shape = 1
                setColor(android.graphics.Color.TRANSPARENT)
                setStroke((3f * dp).toInt(), accent)
            }
            iv?.clipToOutline = true
            iv?.outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        } catch (_: Throwable) {}

        header.findViewById<android.widget.TextView>(R.id.tvEditarFoto)?.apply {
            setBackgroundColor(accent)
            setTextColor(android.graphics.Color.parseColor("#001A00"))
            setOnClickListener {
                drawerLayout?.closeDrawer(GravityCompat.START)
                startActivity(Intent(this@MainActivity, ProfileActivity::class.java))
            }
        }

        Thread {
            try {
                val dbLocal  = DatabaseHelper(this)
                val cal      = java.util.Calendar.getInstance()
                val mes      = dbLocal.buscarMes(cal.get(java.util.Calendar.MONTH), cal.get(java.util.Calendar.YEAR))
                val resumo   = dbLocal.resumo(mes)
                val total    = resumo["total"]    ?: 0f
                val corridas = (resumo["corridas"] ?: 0f).toInt()
                val media    = if (corridas > 0) total / corridas else 0f
                runOnUiThread {
                    header.findViewById<android.widget.TextView>(R.id.tvStatMesValor)?.apply {
                        text = "R$${if (total >= 1000) "%.0f".format(total/1000)+"k" else "%.0f".format(total)}"
                        setTextColor(accent)
                    }
                    header.findViewById<android.widget.TextView>(R.id.tvStatCorridasValor)?.apply {
                        text = "$corridas"; setTextColor(accent)
                    }
                    header.findViewById<android.widget.TextView>(R.id.tvStatMediaValor)?.apply {
                        text = "R${"%.0f".format(media)}"; setTextColor(accent)
                    }
                }
            } catch (_: Throwable) {}
        }.start()
    }

    // ── Navegação ─────────────────────────────────────────────────────────

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        drawerLayout?.closeDrawer(GravityCompat.START)
        when (item.itemId) {
            R.id.nav_assinar       -> startActivity(Intent(this, PlansActivity::class.java))
            R.id.nav_perfil        -> startActivity(Intent(this, ProfileActivity::class.java))
            R.id.nav_configuracoes -> startActivity(Intent(this, SettingsActivity::class.java))
            R.id.nav_sobre         -> startActivity(Intent(this, AboutActivity::class.java))
            R.id.nav_sair          -> confirmarSaida()
        }
        return true
    }

    private fun confirmarSaida() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Sair")
            .setMessage("Deseja sair da sua conta?")
            .setPositiveButton("Sair") { _, _ ->
                LicenseManager.logout()
                startActivity(Intent(this, LoginActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                })
                finish()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun configurarNavegacao() {
        findViewById<View>(R.id.btnBottomInicio)?.setOnClickListener { /* tela inicial */ }
        findViewById<View>(R.id.btnBottomCorridas)?.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        findViewById<View>(R.id.btnBottomMetricas)?.setOnClickListener {
            startActivity(Intent(this, ReportsActivity::class.java))
        }
        findViewById<View>(R.id.btnBottomFinancas)?.setOnClickListener {
            startActivity(Intent(this, FinanceActivity::class.java))
        }
        findViewById<View>(R.id.cardGanhos)?.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        configurarBotaoServico()
    }
}
