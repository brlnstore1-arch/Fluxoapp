package com.fluxoapp

import android.animation.AnimatorSet
import android.view.animation.AccelerateDecelerateInterpolator
import android.animation.ValueAnimator
import android.animation.ObjectAnimator
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.MenuItem
import android.view.View
import android.widget.*
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.cardview.widget.CardView
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    private lateinit var prefs: SharedPreferences
    private lateinit var db: DatabaseHelper
    private var drawerLayout: DrawerLayout? = null
    private val handler = Handler(Looper.getMainLooper())

    private val DICAS = listOf(
        "Cada km rodado é um passo a mais para seu sonho!",
        "Motorista de sucesso é aquele que nunca desiste!",
        "Hoje é um ótimo dia para bater sua meta!",
        "Sua dedicação é o combustível do seu sucesso!",
        "O melhor horário para trabalhar é agora!",
        "Cada corrida bem feita é um cliente fiel!",
        "Sucesso é a soma de pequenas conquistas diárias!",
        "Você está no caminho certo, continue!",
        "Foco, força e fé! Seu esforço tem valor!",
        "Cada corrida aceita é uma oportunidade de ganhar mais!"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ThemeSelector aplica o tema XML ANTES do inflate — resolve crash MIUI
        ThemeSelector.aplicar(this)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("FluxoApp", MODE_PRIVATE)
        db    = DatabaseHelper(this)

        // Verificar login Firebase — se não logado, ir para LoginActivity
        if (!LicenseManager.estaLogado()) {
            startActivity(android.content.Intent(this, LoginActivity::class.java).apply {
                flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK or
                        android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK
            })
            finish(); return
        }

        if (!prefs.getBoolean("onboarding_ok", false)) {
            startActivity(Intent(this, OnboardingActivity::class.java))
            finish(); return
        }

        // Verificar licença e aplicar restrições premium se necessário
        verificarLicencaERestringir()

        // Cada função protegida individualmente — uma falha não afeta as outras
        try { configurarToolbarEDrawer() } catch (_: Throwable) {}
        try { configurarBotaoTema()      } catch (_: Throwable) {}
        try { configurarNavegacao()      } catch (_: Throwable) {}
        try { aplicarTema()              } catch (_: Throwable) {}
        try { atualizarStats()           } catch (_: Throwable) {}
        try { exibirDica()               } catch (_: Throwable) {}

        // Shimmer e tema global APÓS layout completo — evita crash com Gold
        window.decorView.post {
            try { iniciarShimmer()    } catch (_: Throwable) {}
            try { aplicarTemaGlobal() } catch (_: Throwable) {}
        }
    }

    override fun onResume() {
        super.onResume()
        try { atualizarStats()     } catch (_: Throwable) {}
        try { aplicarTema()        } catch (_: Throwable) {}
        try { atualizarIconeTema() } catch (_: Throwable) {}
        try { sendBroadcast(Intent(FloatingEarningsService.ACTION_TEMA)) } catch (_: Throwable) {}
        window.decorView.post {
            try { iniciarShimmer()    } catch (_: Throwable) {}
            try { aplicarTemaGlobal() } catch (_: Throwable) {}
            try {
                val nv = findViewById<com.google.android.material.navigation.NavigationView>(R.id.navView)
                if (nv != null) configurarHeaderDrawer(nv)
            } catch (_: Throwable) {}
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }

    // ──────────────────────────────────────────────────────────
    // TOOLBAR + DRAWER
    // ──────────────────────────────────────────────────────────
    private fun configurarToolbarEDrawer() {
        try {
            val toolbar = findViewById<Toolbar>(R.id.toolbar)
            if (toolbar != null) setSupportActionBar(toolbar)
            supportActionBar?.setDisplayShowTitleEnabled(false)
        } catch (_: Throwable) {}

        try {
            drawerLayout = findViewById(R.id.drawerLayout)
            val navView  = findViewById<NavigationView>(R.id.navView)
            navView?.setNavigationItemSelectedListener(this)
            drawerLayout?.setDrawerLockMode(
                androidx.drawerlayout.widget.DrawerLayout.LOCK_MODE_UNLOCKED)
        } catch (_: Throwable) {}

        try {
            val dl = drawerLayout
            findViewById<View>(R.id.btnMenu)?.setOnClickListener {
                if (dl == null) return@setOnClickListener
                if (dl.isDrawerOpen(GravityCompat.START))
                    dl.closeDrawer(GravityCompat.START)
                else
                    dl.openDrawer(GravityCompat.START)
            }
        } catch (_: Throwable) {}

        try {
            val navView = findViewById<NavigationView>(R.id.navView)
            if (navView != null) configurarHeaderDrawer(navView)
        } catch (_: Throwable) {}
    }

    private fun configurarHeaderDrawer(navView: com.google.android.material.navigation.NavigationView) {
        val header = navView.getHeaderView(0) ?: return
        val p = prefs

        // Aplicar cores do tema no header
        val accent = ThemeHelper.cor("accent_gold", p)
        val bgDark  = ThemeHelper.cor("bg_dark", p)
        val bgCard  = ThemeHelper.cor("bg_card", p)
        val txtW    = ThemeHelper.cor("text_white", p)
        val txtG    = ThemeHelper.cor("text_gray", p)
        val dp      = resources.displayMetrics.density

        // Fundo do header com gradiente leve
        header.findViewById<android.widget.LinearLayout>(R.id.navHeaderBg)?.apply {
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(
                    android.graphics.Color.argb(80,
                        android.graphics.Color.red(accent),
                        android.graphics.Color.green(accent),
                        android.graphics.Color.blue(accent)),
                    bgDark
                )
            )
        }

        // Nome, cidade e status
        val nome   = p.getString("perfil_nome",   "Motorista")   ?: "Motorista"
        val cidade = p.getString("perfil_cidade", "Bragança - PA") ?: "Bragança - PA"
        val status = p.getString("perfil_status", "🚀 Trabalhando duro!") ?: "🚀 Trabalhando duro!"
        val veiculo = p.getString("perfil_veiculo", "moto") ?: "moto"
        val iconeVeiculo = when(veiculo) { "carro" -> "🚗"; "bike" -> "🚴"; else -> "🏍️" }

        header.findViewById<android.widget.TextView>(R.id.tvNomePerfil)?.apply {
            text = "$iconeVeiculo  $nome"
            setTextColor(txtW)
        }
        header.findViewById<android.widget.TextView>(R.id.tvCidadePerfil)?.apply {
            text = "📍 $cidade"; setTextColor(txtG)
        }
        header.findViewById<android.widget.TextView>(R.id.tvStatusPerfil)?.apply {
            text = status; setTextColor(accent)
        }

        // Foto de perfil circular
        val iv = header.findViewById<android.widget.ImageView>(R.id.ivFotoPerfil)
        val fotoPath = p.getString("perfil_foto", null)
        if (fotoPath != null) {
            try {
                val bmp = android.graphics.BitmapFactory.decodeFile(fotoPath)
                if (bmp != null) {
                    val size = minOf(bmp.width, bmp.height)
                    val sq   = android.graphics.Bitmap.createBitmap(bmp, (bmp.width-size)/2, (bmp.height-size)/2, size, size)
                    val out  = android.graphics.Bitmap.createBitmap(size, size, android.graphics.Bitmap.Config.ARGB_8888)
                    val canvas = android.graphics.Canvas(out)
                    val paint  = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
                    canvas.drawCircle(size/2f, size/2f, size/2f, paint)
                    paint.xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.SRC_IN)
                    canvas.drawBitmap(sq, 0f, 0f, paint)
                    iv?.setImageBitmap(out)
                }
            } catch (_: Throwable) {}
        }
        // Moldura circular na foto
        try {
            iv?.background = android.graphics.drawable.GradientDrawable().apply {
                shape = 1 // GradientDrawable.OVAL
                setColor(android.graphics.Color.TRANSPARENT)
                setStroke((3f * dp).toInt(), accent)
            }
            iv?.clipToOutline = true
            iv?.outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        } catch (_: Throwable) {}

        // Botão editar foto (abre ProfileActivity)
        header.findViewById<android.widget.TextView>(R.id.tvEditarFoto)?.apply {
            setBackgroundColor(accent)
            setTextColor(android.graphics.Color.parseColor("#001A00"))
            setOnClickListener {
                drawerLayout?.closeDrawer(GravityCompat.START)
                startActivity(Intent(this@MainActivity, ProfileActivity::class.java))
            }
        }

        // Stats do mês
        Thread {
            try {
                val db = DatabaseHelper(this)
                val cal = java.util.Calendar.getInstance()
                val mes = db.buscarMes(cal.get(java.util.Calendar.MONTH), cal.get(java.util.Calendar.YEAR))
                val resumo = db.resumo(mes)
                val total    = resumo["total"] ?: 0f
                val corridas = (resumo["corridas"] ?: 0f).toInt()
                val media    = if (corridas > 0) total / corridas else 0f

                runOnUiThread {
                    header.findViewById<android.widget.TextView>(R.id.tvStatMesValor)?.apply {
                        text = "R$${if (total >= 1000) "%.0f".format(total/1000)+"k" else "%.0f".format(total)}"
                        setTextColor(accent)
                    }
                    header.findViewById<android.widget.TextView>(R.id.tvStatCorridasValor)?.apply {
                        text = "$corridas"; setTextColor(accent)
                    }
                    header.findViewById<android.widget.TextView>(R.id.tvStatMediaValor)?.apply {
                        text = "R$${"%.0f".format(media)}"; setTextColor(accent)
                    }
                }
            } catch (_: Throwable) {}
        }.start()
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        drawerLayout?.closeDrawer(GravityCompat.START)
        when (item.itemId) {
            R.id.nav_perfil        -> startActivity(Intent(this, ProfileActivity::class.java))
            R.id.nav_configuracoes -> startActivity(Intent(this, SettingsActivity::class.java))
            R.id.nav_sobre         -> startActivity(Intent(this, AboutActivity::class.java))
            R.id.nav_sair          -> confirmarSaida()
        }
        return true
    }

    private fun confirmarSaida() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Sair")
            .setMessage("Deseja sair da sua conta?")
            .setPositiveButton("Sair") { _, _ ->
                LicenseManager.logout()
                startActivity(Intent(this, LoginActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                })
                finish()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    /**
     * Verifica licença no Firestore e restringe funções premium se necessário.
     * Funções bloqueadas sem plano: serviço de acessibilidade, overlay, auto-aceitar,
     * botão flutuante. Histórico, configurações e relatórios continuam acessíveis.
     */
    private fun verificarLicencaERestringir() {
        LicenseManager.verificarLicenca { status ->
            runOnUiThread {
                if (!status.temAcesso) {
                    // Desativar serviço de acessibilidade se estava ativo
                    if (prefs.getBoolean("servico_ativo", true)) {
                        prefs.edit().putBoolean("servico_ativo", false).apply()
                        try { stopService(Intent(this, FloatingEarningsService::class.java)) } catch (_: Throwable) {}
                    }
                    // Desativar auto-aceitar e auto-recusar
                    prefs.edit()
                        .putBoolean("auto_aceitar", false)
                        .putBoolean("auto_recusar", false)
                        .apply()
                    // Mostrar banner de aviso no topo
                    mostrarBannerLicenca(status.mensagem)
                }
            }
        }
    }

    private fun mostrarBannerLicenca(mensagem: String) {
        try {
            val p    = prefs
            val dp   = resources.displayMetrics.density
            val corR = ThemeHelper.cor("accent_red", p)
            val txtW = ThemeHelper.cor("text_white", p)

            // Reutilizar o tvStatusServico como banner se existir, senão Toast
            val tvStatus = findViewById<android.widget.TextView>(R.id.tvStatusServico)
            if (tvStatus != null) {
                tvStatus.text = "⚠️ $mensagem"
                tvStatus.setTextColor(txtW)
                tvStatus.setBackgroundColor(corR)
                tvStatus.visibility = android.view.View.VISIBLE
                tvStatus.setOnClickListener {
                    // Futuramente: abrir tela de planos
                    android.widget.Toast.makeText(this,
                        "Em breve: assine o FluxoApp!", android.widget.Toast.LENGTH_LONG).show()
                }
            } else {
                android.widget.Toast.makeText(this, "⚠️ $mensagem", android.widget.Toast.LENGTH_LONG).show()
            }
        } catch (_: Throwable) {}
    }

    override fun onBackPressed() {
        val dl = drawerLayout
        if (dl != null && dl.isDrawerOpen(GravityCompat.START))
            dl.closeDrawer(GravityCompat.START)
        else super.onBackPressed()
    }

    // ──────────────────────────────────────────────────────────
    // NAVEGAÇÃO
    // ──────────────────────────────────────────────────────────
    private fun configurarNavegacao() {
        // Bottom nav
        findViewById<View>(R.id.btnBottomInicio)?.setOnClickListener { /* já está aqui */ }
        findViewById<View>(R.id.btnBottomCorridas)?.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        findViewById<View>(R.id.btnBottomMetricas)?.setOnClickListener {
            startActivity(Intent(this, ReportsActivity::class.java))
        }
        findViewById<View>(R.id.btnBottomFinancas)?.setOnClickListener {
            startActivity(Intent(this, FinanceActivity::class.java))
        }
        // Card de ganhos → histórico
        findViewById<View>(R.id.cardGanhos)?.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        // Botão de serviço — toggle ativar/desativar
        configurarBotaoServico()
    }

    // ──────────────────────────────────────────────────────────
    // BOTÃO DE SERVIÇO (ATIVAR / DESATIVAR)
    // ──────────────────────────────────────────────────────────
    private fun configurarBotaoServico() {
        atualizarBotaoServico()
        findViewById<View>(R.id.btnServico)?.setOnClickListener {
            val ativo = prefs.getBoolean("servico_ativo", true)
            if (!ativo) {
                // Ativar → verificar permissões primeiro
                when {
                    !isAccessibilityEnabled() -> {
                        mostrarDialogAcessibilidade()
                        return@setOnClickListener
                    }
                    !Settings.canDrawOverlays(this) -> {
                        Toast.makeText(this, "Permita a sobreposição de tela", Toast.LENGTH_LONG).show()
                        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                        return@setOnClickListener
                    }
                    else -> {
                        prefs.edit().putBoolean("servico_ativo", true).apply()
                        try { startService(Intent(this, FloatingEarningsService::class.java)) } catch (_: Throwable) {}
                        Toast.makeText(this, "Serviço ativado!", Toast.LENGTH_SHORT).show()
                    }
                }
            } else {
                // Desativar
                prefs.edit().putBoolean("servico_ativo", false).apply()
                try { stopService(Intent(this, FloatingEarningsService::class.java)) } catch (_: Throwable) {}
                Toast.makeText(this, "Serviço desativado", Toast.LENGTH_SHORT).show()
            }
            atualizarBotaoServico()
        }
    }

    private fun atualizarBotaoServico() {
        val btn    = try { findViewById<FrameLayout>(R.id.btnServico) }  catch (_: Throwable) { null } ?: return
        val tvPrin = try { findViewById<TextView>(R.id.tvStatusBar) }    catch (_: Throwable) { null }
        val tvSub  = try { findViewById<TextView>(R.id.tvStatusSub) }    catch (_: Throwable) { null }
        val dot    = try { findViewById<View>(R.id.dotServico) }          catch (_: Throwable) { null }
        val ativo  = prefs.getBoolean("servico_ativo", true)
        val permOk = isAccessibilityEnabled() && Settings.canDrawOverlays(this)

        when {
            !ativo -> {
                btn.setBackgroundResource(R.drawable.btn_servico_inativo)
                tvPrin?.text = "SERVIÇO DESATIVADO"
                tvSub?.text  = "Toque para ativar o monitoramento"
                dot?.setBackgroundColor(Color.parseColor("#FF4560"))
            }
            !permOk -> {
                btn.setBackgroundResource(R.drawable.btn_servico_inativo)
                tvPrin?.text = "PERMISSÃO NECESSÁRIA"
                tvSub?.text  = "Toque para configurar"
                dot?.setBackgroundColor(Color.parseColor("#F0B429"))
            }
            else -> {
                btn.setBackgroundResource(R.drawable.btn_servico_ativo)
                tvPrin?.text = "SERVIÇO ATIVO"
                tvSub?.text  = "Monitorando corridas automaticamente"
                try { dot?.setBackgroundResource(R.drawable.dot_status) } catch (_: Throwable) {
                    dot?.setBackgroundColor(Color.parseColor("#00E676"))
                }
            }
        }
    }

    // ──────────────────────────────────────────────────────────
    // TEMA
    // ──────────────────────────────────────────────────────────
    private fun configurarBotaoTema() {
        atualizarIconeTema()
        findViewById<ImageButton>(R.id.btnTema)?.setOnClickListener {
            val atual = prefs.getInt("modo_tema", -1)
            val novo  = when (atual) { -1 -> 0; 0 -> 1; else -> -1 }
            prefs.edit().putInt("modo_tema", novo).apply()
            aplicarTema()
            aplicarTemaGlobal()
            atualizarIconeTema()
            // FIX: notificar flutuante sobre mudança de tema
            try { sendBroadcast(Intent(FloatingEarningsService.ACTION_TEMA)) } catch (_: Throwable) {}
            try { startService(Intent(this, FloatingEarningsService::class.java).apply {
                action = FloatingEarningsService.ACTION_TEMA
            }) } catch (_: Throwable) {}
            val msg = when (novo) { 0 -> "Modo DIA"; 1 -> "Modo NOITE"; else -> "Modo AUTO" }
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }
    }

    private fun atualizarIconeTema() {
        val modo   = prefs.getInt("modo_tema", -1)
        val noturno = ThemeHelper.isModoNoturno(prefs)
        val lbl = when { modo == 0 -> "dia"; modo == 1 -> "noite"; noturno -> "noite"; else -> "dia" }
        try { findViewById<TextView>(R.id.tvTemaLabel)?.text = lbl } catch (_: Throwable) {}
        try { findViewById<ImageButton>(R.id.btnTema)?.setColorFilter(ThemeHelper.cor("accent_gold", prefs)) } catch (_: Throwable) {}
    }

    // ──────────────────────────────────────────────────────────
    // APLICAR TEMA
    // ──────────────────────────────────────────────────────────
    private fun gdSolid(color: Int, radius: Float, strokeColor: Int = 0, sw: Float = 0f): GradientDrawable {
        val dp = resources.displayMetrics.density
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius * dp
            if (sw > 0) setStroke((sw * dp).toInt(), strokeColor)
        }
    }

    private fun aplicarTema() {
        val bgDark  = ThemeHelper.cor("bg_dark",    prefs)
        val bgCard  = ThemeHelper.cor("bg_card",    prefs)
        val bgSect  = ThemeHelper.cor("bg_section", prefs)
        val toolbar = ThemeHelper.cor("toolbar",    prefs)
        val txtG    = ThemeHelper.cor("text_gray",  prefs)
        val txtW    = ThemeHelper.cor("text_white", prefs)
        val accent  = ThemeHelper.cor("accent_gold",  prefs)
        val gold    = ThemeHelper.cor("accent_gold",  prefs)
        val border  = ThemeHelper.cor("border",       prefs)
        val isGold  = ThemeHelper.getTema(prefs) == "gold"

        // Root + toolbar
        try { findViewById<FrameLayout>(R.id.rootLayout)?.setBackgroundColor(bgDark) } catch (_: Throwable) {}
        try { findViewById<Toolbar>(R.id.toolbar)?.setBackgroundColor(toolbar) } catch (_: Throwable) {}

        // Drawer — fundo do painel lateral e atualizar header
        try {
            findViewById<com.google.android.material.navigation.NavigationView>(R.id.navView)?.apply {
                setBackgroundColor(bgDark)
                itemTextColor = android.content.res.ColorStateList.valueOf(txtW)
                itemIconTintList = android.content.res.ColorStateList.valueOf(accent)
            }
        } catch (_: Throwable) {}
        try {
            val nv = findViewById<com.google.android.material.navigation.NavigationView>(R.id.navView)
            if (nv != null) configurarHeaderDrawer(nv)
        } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvLogo)?.setTextColor(accent) } catch (_: Throwable) {}
        for (id in listOf(R.id.menuLine1, R.id.menuLine2, R.id.menuLine3))
            try { findViewById<View>(id)?.setBackgroundColor(accent) } catch (_: Throwable) {}

        // Card ganhos
        try {
            val cv = findViewById<CardView>(R.id.cardGanhos)
            cv?.setCardBackgroundColor(bgCard)
            val inner = cv?.getChildAt(0)
            inner?.setBackgroundResource(if (isGold) R.drawable.earnings_card_gold else R.drawable.earnings_card_bg)
        } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvLabelGanhos)?.setTextColor(txtG) } catch (_: Throwable) {}
        // Card de ganhos é sempre escuro — valor usa accent (dourado/ciano) para garantir visibilidade
        try { findViewById<TextView>(R.id.tvGanhoHoje)?.setTextColor(accent) } catch (_: Throwable) {}

        // Stats
        for (id in listOf(R.id.statCorridas, R.id.statKm, R.id.statMedia))
            try { findViewById<View>(id)?.background = gdSolid(bgSect, 10f, border, 1f) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvStatCorridas)?.setTextColor(accent) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvStatKm)?.setTextColor(gold)       } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvStatMedia)?.setTextColor(gold)    } catch (_: Throwable) {}

        // Card meta
        try { findViewById<CardView>(R.id.cardMeta)?.setCardBackgroundColor(bgCard)    } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvMetaInfo)?.setTextColor(txtG)              } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvMetaPercent)?.setTextColor(gold)           } catch (_: Throwable) {}
        try {
            val cl = android.content.res.ColorStateList.valueOf(accent)
            findViewById<ProgressBar>(R.id.progressMetaDia)?.progressTintList = cl
        } catch (_: Throwable) {}

        // Dica
        try {
            findViewById<LinearLayout>(R.id.layoutDica)?.background = gdSolid(bgCard, 8f, border, 1f)
        } catch (_: Throwable) {}
        try { findViewById<View>(R.id.dicaBorder)?.setBackgroundColor(accent) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvDica)?.setTextColor(txtG)       } catch (_: Throwable) {}

        // Bottom nav
        try { findViewById<LinearLayout>(R.id.bottomNav)?.setBackgroundColor(bgCard)  } catch (_: Throwable) {}
        try { findViewById<View>(R.id.indicadorInicio)?.setBackgroundColor(accent)      } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvBotInicio)?.setTextColor(accent)            } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvBotCorridas)?.setTextColor(txtG)          } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvBotMetricas)?.setTextColor(txtG)          } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvBotFinancas)?.setTextColor(txtG)          } catch (_: Throwable) {}

        // Drawer
        try { findViewById<NavigationView>(R.id.navView)?.setBackgroundColor(bgCard)  } catch (_: Throwable) {}

        // Atualizar botão de serviço com o tema certo (só muda cor do bg, o drawable cuida do resto)
        atualizarBotaoServico()
    }

    // ──────────────────────────────────────────────────────────
    // STATS
    // ──────────────────────────────────────────────────────────
    private fun atualizarStats() {
        val corridas = try { db.buscarHoje() } catch (_: Throwable) { emptyList() }
        val resumo   = try { db.resumo(corridas) } catch (_: Throwable) { mapOf() }
        val total    = resumo["total"]         ?: 0f
        val km       = resumo["km_total"]      ?: 0f
        val media    = resumo["media_corrida"] ?: 0f
        val qtd      = (resumo["corridas"]     ?: 0f).toInt()
        val meta     = prefs.getFloat("meta_diaria", 0f)
        val accent     = ThemeHelper.cor("accent_gold", prefs)
        val gold     = ThemeHelper.cor("accent_gold", prefs)

        try { findViewById<TextView>(R.id.tvGanhoHoje)?.text   = "%.2f".format(total).replace(".", ",") } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvStatCorridas)?.text = "$qtd"                                 } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvStatKm)?.text       = "%.1f km".format(km).replace(".", ",") } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvStatMedia)?.text    = "R$ %.2f".format(media).replace(".", ",") } catch (_: Throwable) {}

        // Meta
        val cardMeta = try { findViewById<CardView>(R.id.cardMeta) } catch (_: Throwable) { null }
        if (meta > 0f) {
            val pct = ((total / meta) * 100).toInt().coerceIn(0, 100)
            cardMeta?.visibility = View.VISIBLE
            try { findViewById<TextView>(R.id.tvMetaInfo)?.text    = "META DIÁRIA · R$ %.0f".format(meta) } catch (_: Throwable) {}
            try { findViewById<TextView>(R.id.tvMetaPercent)?.text = "$pct%"                               } catch (_: Throwable) {}
            try {
                val pb  = findViewById<ProgressBar>(R.id.progressMetaDia)
                pb?.progress = pct
                val accentMeta = ThemeHelper.cor("accent_gold", prefs)
                val corMeta = when {
                    pct >= 100 -> android.graphics.Color.parseColor("#FFD740")
                    pct >= 75  -> ThemeHelper.cor("accent_green", prefs)
                    else       -> accentMeta
                }
                pb?.progressTintList = android.content.res.ColorStateList.valueOf(corMeta)
            } catch (_: Throwable) {}
            if (total >= meta) verificarCelebracao(total, meta)
        } else {
            cardMeta?.visibility = View.GONE
        }

        exibirDica()
        atualizarWidget()
        atualizarBotaoServico()
    }

    // ──────────────────────────────────────────────────────────
    // SHIMMER DENTRO DAS LETRAS
    // ──────────────────────────────────────────────────────────
    private fun iniciarShimmer() {
        try {
            findViewById<View>(R.id.viewShimmer)?.visibility = View.INVISIBLE
            val tvLogo = findViewById<TextView>(R.id.tvLogo) ?: return
            ThemeHelper.animarLogoShimmer(tvLogo, prefs)
        } catch (_: Throwable) {}
    }

    // ──────────────────────────────────────────────────────────
    // DICA
    // ──────────────────────────────────────────────────────────
    private fun exibirDica() {
        try {
            val corridas = db.buscarHoje()
            val qtd  = corridas.size
            val day  = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR)
            val dica = when {
                qtd == 0 -> DICAS[day % DICAS.size]
                qtd < 3  -> "Você já fez $qtd corrida${if (qtd > 1) "s" else ""} hoje. Continue assim!"
                qtd < 10 -> "Você já fez $qtd corridas hoje. Ótimo ritmo!"
                else     -> "Dia incrível! $qtd corridas completas!"
            }
            findViewById<TextView>(R.id.tvDica)?.text = dica
        } catch (_: Throwable) {}
    }

    // ──────────────────────────────────────────────────────────
    // CELEBRAÇÃO
    // ──────────────────────────────────────────────────────────
    private fun verificarCelebracao(total: Float, meta: Float) {
        if (meta <= 0 || total < meta) return
        val hoje = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(java.util.Date())
        if (prefs.getString("ultima_celebracao", "") == hoje) return
        prefs.edit().putString("ultima_celebracao", hoje).apply()
        celebrarMeta()
    }

    private fun celebrarMeta() {
        try {
            val gold = ThemeHelper.cor("accent_gold", prefs)
            val root = window.decorView.rootView
            repeat(8) { i ->
                handler.postDelayed({
                    try { root.setBackgroundColor(if (i % 2 == 0) gold else Color.TRANSPARENT) } catch (_: Throwable) {}
                }, i * 180L)
            }
            handler.postDelayed({ try { root.setBackgroundColor(Color.TRANSPARENT) } catch (_: Throwable) {} }, 1500L)
            val tv = try { findViewById<TextView>(R.id.tvGanhoHoje) } catch (_: Throwable) { null }
            tv?.let {
                AnimatorSet().apply {
                    playTogether(
                        ObjectAnimator.ofFloat(it, "scaleX", 1f, 1.4f, 1.1f),
                        ObjectAnimator.ofFloat(it, "scaleY", 1f, 1.4f, 1.1f)
                    )
                    duration = 600; interpolator = AccelerateDecelerateInterpolator(); start()
                }
            }
            try { (getSystemService(VIBRATOR_SERVICE) as android.os.Vibrator).vibrate(longArrayOf(0,150,80,150,80,500), -1) } catch (_: Throwable) {}
            handler.postDelayed({ Toast.makeText(this, "META BATIDA! PARABÉNS!", Toast.LENGTH_LONG).show() }, 600L)
            atualizarWidget()
        } catch (_: Throwable) {}
    }

    // ──────────────────────────────────────────────────────────
    // WIDGET
    // ──────────────────────────────────────────────────────────
    fun atualizarWidget() {
        try {
            val mgr = AppWidgetManager.getInstance(this)
            AppWidgetManager.getInstance(this)
                .getAppWidgetIds(ComponentName(this, FluxoWidgetProvider::class.java))
                .forEach { FluxoWidgetProvider.updateWidget(this, mgr, it) }
        } catch (_: Throwable) {}
    }

    private fun mostrarDialogAcessibilidade() {
        val prefs = getSharedPreferences("FluxoApp", MODE_PRIVATE)
        val passo1Feito = prefs.getBoolean("acessib_passo1_feito", false)

        if (!passo1Feito) {
            val msg = "Vamos ativar em 2 passos simples.\n\n" +
                "PASSO 1 de 2\n" +
                "Voce sera direcionado para Acessibilidade.\n\n" +
                "ATENCAO: vai aparecer um aviso de configuracao restrita - isso e normal!\n\n" +
                "Toque em OK nesse aviso e volte aqui para o Passo 2."
            android.app.AlertDialog.Builder(this)
                .setTitle("Ativar Monitoramento")
                .setMessage(msg)
                .setPositiveButton("Ir para Acessibilidade") { _, _ ->
                    prefs.edit().putBoolean("acessib_passo1_feito", true).apply()
                    try {
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        })
                    } catch (_: Throwable) {}
                }
                .setNegativeButton("Cancelar") { d, _ -> d.dismiss() }
                .show()
        } else {
            val msg = "PASSO 2 de 2\n\n" +
                "Libere a restricao:\n\n" +
                "1. Toque em Ir para Aplicativos\n" +
                "2. Toque nos 3 pontos no canto superior direito\n" +
                "3. Toque em Permitir configuracoes restritas\n" +
                "4. Volte aqui e ative o monitoramento\n\n" +
                "Apos liberar, o FluxoApp funcionara normalmente!"
            android.app.AlertDialog.Builder(this)
                .setTitle("Liberar Restricao")
                .setMessage(msg)
                .setPositiveButton("Ir para Aplicativos") { _, _ ->
                    prefs.edit().putBoolean("acessib_passo1_feito", false).apply()
                    try {
                        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = android.net.Uri.parse("package:$packageName")
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        })
                    } catch (_: Throwable) {
                        try {
                            startActivity(Intent(Settings.ACTION_APPLICATION_SETTINGS).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            })
                        } catch (_: Throwable) {}
                    }
                }
                .setNegativeButton("Cancelar") { d, _ ->
                    prefs.edit().putBoolean("acessib_passo1_feito", false).apply()
                    d.dismiss()
                }
                .show()
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        return try {
            val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            s.contains("fluxoapp", ignoreCase = true) || s.contains("MaximAccessibilityService", ignoreCase = true)
        } catch (_: Throwable) { false }
    }
}
