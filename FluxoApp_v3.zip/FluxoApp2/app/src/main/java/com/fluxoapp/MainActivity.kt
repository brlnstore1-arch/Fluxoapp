package com.fluxoapp

import android.animation.AnimatorSet
import android.view.animation.AccelerateDecelerateInterpolator
import android.animation.ValueAnimator
import android.animation.ObjectAnimator
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.MenuItem
import android.view.View
import android.widget.*
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.cardview.widget.CardView
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    private lateinit var prefs: SharedPreferences
    private lateinit var db: DatabaseHelper
    private lateinit var drawerLayout: DrawerLayout
    private val handler = Handler(Looper.getMainLooper())

    private val DICAS = listOf(
        "Cada km rodado é um passo a mais para seu sonho!",
        "Motorista de sucesso é aquele que nunca desiste!",
        "Hoje é um ótimo dia para bater sua meta!",
        "Sua dedicação é o combustível do seu sucesso!",
        "O melhor horário para trabalhar é agora!",
        "Cada corrida bem feita é um cliente fiel!",
        "Sucesso é a soma de pequenas conquistas diárias!",
        "Você está no caminho certo, continue!",
        "Foco, força e fé! Seu esforço tem valor!",
        "Cada corrida aceita é uma oportunidade de ganhar mais!"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            setContentView(R.layout.activity_main)
            prefs = getSharedPreferences("FluxoApp", MODE_PRIVATE)
            db   = DatabaseHelper(this)

            if (!prefs.getBoolean("onboarding_ok", false)) {
                startActivity(Intent(this, OnboardingActivity::class.java))
                finish(); return
            }

            configurarToolbarEDrawer()
            configurarBotaoTema()
            configurarNavegacao()
            iniciarShimmer()
            aplicarTema()
            aplicarTemaGlobal()
            atualizarStats()
            exibirDica()

        } catch (e: Exception) {
            android.util.Log.e("FluxoApp", "Crash onCreate: ${e.message}", e)
        }
    }

    override fun onResume() {
        super.onResume()
        try {
            atualizarStats()
            aplicarTema()
            aplicarTemaGlobal()
            atualizarIconeTema()
            iniciarShimmer() // reinicia com cores do tema atual
            try { sendBroadcast(Intent(FloatingEarningsService.ACTION_TEMA)) } catch (_: Exception) {}
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }

    // ──────────────────────────────────────────────────────────
    // TOOLBAR + DRAWER
    // ──────────────────────────────────────────────────────────
    private fun configurarToolbarEDrawer() {
        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)

        drawerLayout = findViewById(R.id.drawerLayout)
        val navView  = findViewById<NavigationView>(R.id.navView)
        navView.setNavigationItemSelectedListener(this)

        findViewById<View>(R.id.btnMenu)?.setOnClickListener {
            if (drawerLayout.isDrawerOpen(GravityCompat.START))
                drawerLayout.closeDrawer(GravityCompat.START)
            else
                drawerLayout.openDrawer(GravityCompat.START)
        }
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        drawerLayout.closeDrawer(GravityCompat.START)
        when (item.itemId) {
            R.id.nav_configuracoes -> startActivity(Intent(this, SettingsActivity::class.java))
            R.id.nav_sobre         -> startActivity(Intent(this, AboutActivity::class.java))
        }
        return true
    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START))
            drawerLayout.closeDrawer(GravityCompat.START)
        else super.onBackPressed()
    }

    // ──────────────────────────────────────────────────────────
    // NAVEGAÇÃO
    // ──────────────────────────────────────────────────────────
    private fun configurarNavegacao() {
        // Bottom nav
        findViewById<View>(R.id.btnBottomInicio)?.setOnClickListener { /* já está aqui */ }
        findViewById<View>(R.id.btnBottomCorridas)?.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        findViewById<View>(R.id.btnBottomMetricas)?.setOnClickListener {
            startActivity(Intent(this, ReportsActivity::class.java))
        }
        findViewById<View>(R.id.btnBottomFinancas)?.setOnClickListener {
            startActivity(Intent(this, FinanceActivity::class.java))
        }
        // Card de ganhos → histórico
        findViewById<View>(R.id.cardGanhos)?.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        // Botão de serviço — toggle ativar/desativar
        configurarBotaoServico()
    }

    // ──────────────────────────────────────────────────────────
    // BOTÃO DE SERVIÇO (ATIVAR / DESATIVAR)
    // ──────────────────────────────────────────────────────────
    private fun configurarBotaoServico() {
        atualizarBotaoServico()
        findViewById<View>(R.id.btnServico)?.setOnClickListener {
            val ativo = prefs.getBoolean("servico_ativo", true)
            if (!ativo) {
                // Ativar → verificar permissões primeiro
                when {
                    !isAccessibilityEnabled() -> {
                        Toast.makeText(this, "Ative o serviço de acessibilidade primeiro", Toast.LENGTH_LONG).show()
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        return@setOnClickListener
                    }
                    !Settings.canDrawOverlays(this) -> {
                        Toast.makeText(this, "Permita a sobreposição de tela", Toast.LENGTH_LONG).show()
                        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                        return@setOnClickListener
                    }
                    else -> {
                        prefs.edit().putBoolean("servico_ativo", true).apply()
                        try { startService(Intent(this, FloatingEarningsService::class.java)) } catch (_: Exception) {}
                        Toast.makeText(this, "Serviço ativado!", Toast.LENGTH_SHORT).show()
                    }
                }
            } else {
                // Desativar
                prefs.edit().putBoolean("servico_ativo", false).apply()
                try { stopService(Intent(this, FloatingEarningsService::class.java)) } catch (_: Exception) {}
                Toast.makeText(this, "Serviço desativado", Toast.LENGTH_SHORT).show()
            }
            atualizarBotaoServico()
        }
    }

    private fun atualizarBotaoServico() {
        val btn    = try { findViewById<FrameLayout>(R.id.btnServico) }  catch (_: Exception) { null } ?: return
        val tvPrin = try { findViewById<TextView>(R.id.tvStatusBar) }    catch (_: Exception) { null }
        val tvSub  = try { findViewById<TextView>(R.id.tvStatusSub) }    catch (_: Exception) { null }
        val dot    = try { findViewById<View>(R.id.dotServico) }          catch (_: Exception) { null }
        val ativo  = prefs.getBoolean("servico_ativo", true)
        val permOk = isAccessibilityEnabled() && Settings.canDrawOverlays(this)

        when {
            !ativo -> {
                btn.setBackgroundResource(R.drawable.btn_servico_inativo)
                tvPrin?.text = "SERVIÇO DESATIVADO"
                tvSub?.text  = "Toque para ativar o monitoramento"
                dot?.setBackgroundColor(Color.parseColor("#FF4560"))
            }
            !permOk -> {
                btn.setBackgroundResource(R.drawable.btn_servico_inativo)
                tvPrin?.text = "PERMISSÃO NECESSÁRIA"
                tvSub?.text  = "Toque para configurar"
                dot?.setBackgroundColor(Color.parseColor("#F0B429"))
            }
            else -> {
                btn.setBackgroundResource(R.drawable.btn_servico_ativo)
                tvPrin?.text = "SERVIÇO ATIVO"
                tvSub?.text  = "Monitorando corridas automaticamente"
                try { dot?.setBackgroundResource(R.drawable.dot_status) } catch (_: Exception) {
                    dot?.setBackgroundColor(Color.parseColor("#00E676"))
                }
            }
        }
    }

    // ──────────────────────────────────────────────────────────
    // TEMA
    // ──────────────────────────────────────────────────────────
    private fun configurarBotaoTema() {
        atualizarIconeTema()
        findViewById<ImageButton>(R.id.btnTema)?.setOnClickListener {
            val atual = prefs.getInt("modo_tema", -1)
            val novo  = when (atual) { -1 -> 0; 0 -> 1; else -> -1 }
            prefs.edit().putInt("modo_tema", novo).apply()
            aplicarTema()
            aplicarTemaGlobal()
            atualizarIconeTema()
            val msg = when (novo) { 0 -> "Modo DIA"; 1 -> "Modo NOITE"; else -> "Modo AUTO" }
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }
    }

    private fun atualizarIconeTema() {
        val modo   = prefs.getInt("modo_tema", -1)
        val noturno = ThemeHelper.isModoNoturno(prefs)
        val lbl = when { modo == 0 -> "dia"; modo == 1 -> "noite"; noturno -> "noite"; else -> "dia" }
        try { findViewById<TextView>(R.id.tvTemaLabel)?.text = lbl } catch (_: Exception) {}
        try { findViewById<ImageButton>(R.id.btnTema)?.setColorFilter(ThemeHelper.cor("accent_gold", prefs)) } catch (_: Exception) {}
    }

    // ──────────────────────────────────────────────────────────
    // APLICAR TEMA
    // ──────────────────────────────────────────────────────────
    private fun gdSolid(color: Int, radius: Float, strokeColor: Int = 0, sw: Float = 0f): GradientDrawable {
        val dp = resources.displayMetrics.density
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius * dp
            if (sw > 0) setStroke((sw * dp).toInt(), strokeColor)
        }
    }

    private fun aplicarTema() {
        val bgDark  = ThemeHelper.cor("bg_dark",    prefs)
        val bgCard  = ThemeHelper.cor("bg_card",    prefs)
        val bgSect  = ThemeHelper.cor("bg_section", prefs)
        val toolbar = ThemeHelper.cor("toolbar",    prefs)
        val txtG    = ThemeHelper.cor("text_gray",  prefs)
        val txtW    = ThemeHelper.cor("text_white", prefs)
        val accent  = ThemeHelper.cor("accent_gold",  prefs)
        val gold    = ThemeHelper.cor("accent_gold",  prefs)
        val border  = ThemeHelper.cor("border",       prefs)
        val isGold  = ThemeHelper.getTema(prefs) == "gold"

        // Root + toolbar
        try { findViewById<FrameLayout>(R.id.rootLayout)?.setBackgroundColor(bgDark) } catch (_: Exception) {}
        try { findViewById<Toolbar>(R.id.toolbar)?.setBackgroundColor(toolbar) } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvLogo)?.setTextColor(accent) } catch (_: Exception) {}
        for (id in listOf(R.id.menuLine1, R.id.menuLine2, R.id.menuLine3))
            try { findViewById<View>(id)?.setBackgroundColor(accent) } catch (_: Exception) {}

        // Card ganhos
        try {
            val cv = findViewById<CardView>(R.id.cardGanhos)
            cv?.setCardBackgroundColor(bgCard)
            val inner = cv?.getChildAt(0)
            inner?.setBackgroundResource(if (isGold) R.drawable.earnings_card_gold else R.drawable.earnings_card_bg)
        } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvLabelGanhos)?.setTextColor(txtG) } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvGanhoHoje)?.setTextColor(txtW)   } catch (_: Exception) {}

        // Stats
        for (id in listOf(R.id.statCorridas, R.id.statKm, R.id.statMedia))
            try { findViewById<View>(id)?.background = gdSolid(bgSect, 10f, border, 1f) } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvStatCorridas)?.setTextColor(accent) } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvStatKm)?.setTextColor(gold)       } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvStatMedia)?.setTextColor(gold)    } catch (_: Exception) {}

        // Card meta
        try { findViewById<CardView>(R.id.cardMeta)?.setCardBackgroundColor(bgCard)    } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvMetaInfo)?.setTextColor(txtG)              } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvMetaPercent)?.setTextColor(gold)           } catch (_: Exception) {}
        try {
            val cl = android.content.res.ColorStateList.valueOf(accent)
            findViewById<ProgressBar>(R.id.progressMetaDia)?.progressTintList = cl
        } catch (_: Exception) {}

        // Dica
        try {
            findViewById<LinearLayout>(R.id.layoutDica)?.background = gdSolid(bgCard, 8f, border, 1f)
        } catch (_: Exception) {}
        try { findViewById<View>(R.id.dicaBorder)?.setBackgroundColor(accent) } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvDica)?.setTextColor(txtG)       } catch (_: Exception) {}

        // Bottom nav
        try { findViewById<LinearLayout>(R.id.bottomNav)?.setBackgroundColor(bgCard)  } catch (_: Exception) {}
        try { findViewById<View>(R.id.indicadorInicio)?.setBackgroundColor(accent)      } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvBotInicio)?.setTextColor(accent)            } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvBotCorridas)?.setTextColor(txtG)          } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvBotMetricas)?.setTextColor(txtG)          } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvBotFinancas)?.setTextColor(txtG)          } catch (_: Exception) {}

        // Drawer
        try { findViewById<NavigationView>(R.id.navView)?.setBackgroundColor(bgCard)  } catch (_: Exception) {}

        // Atualizar botão de serviço com o tema certo (só muda cor do bg, o drawable cuida do resto)
        atualizarBotaoServico()
    }

    // ──────────────────────────────────────────────────────────
    // STATS
    // ──────────────────────────────────────────────────────────
    private fun atualizarStats() {
        val corridas = try { db.buscarHoje() } catch (_: Exception) { emptyList() }
        val resumo   = try { db.resumo(corridas) } catch (_: Exception) { mapOf() }
        val total    = resumo["total"]         ?: 0f
        val km       = resumo["km_total"]      ?: 0f
        val media    = resumo["media_corrida"] ?: 0f
        val qtd      = (resumo["corridas"]     ?: 0f).toInt()
        val meta     = prefs.getFloat("meta_diaria", 0f)
        val accent     = ThemeHelper.cor("accent_gold", prefs)
        val gold     = ThemeHelper.cor("accent_gold", prefs)

        try { findViewById<TextView>(R.id.tvGanhoHoje)?.text   = "%.2f".format(total).replace(".", ",") } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvStatCorridas)?.text = "$qtd"                                 } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvStatKm)?.text       = "%.1f km".format(km).replace(".", ",") } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvStatMedia)?.text    = "R$ %.2f".format(media).replace(".", ",") } catch (_: Exception) {}

        // Meta
        val cardMeta = try { findViewById<CardView>(R.id.cardMeta) } catch (_: Exception) { null }
        if (meta > 0f) {
            val pct = ((total / meta) * 100).toInt().coerceIn(0, 100)
            cardMeta?.visibility = View.VISIBLE
            try { findViewById<TextView>(R.id.tvMetaInfo)?.text    = "META DIÁRIA · R$ %.0f".format(meta) } catch (_: Exception) {}
            try { findViewById<TextView>(R.id.tvMetaPercent)?.text = "$pct%"                               } catch (_: Exception) {}
            try {
                val pb  = findViewById<ProgressBar>(R.id.progressMetaDia)
                pb?.progress = pct
                val cor = when { pct >= 100 -> "#FFD740"; pct >= 75 -> "#00E676"; else -> "#C9A84C" }
                pb?.progressTintList = android.content.res.ColorStateList.valueOf(Color.parseColor(cor))
            } catch (_: Exception) {}
            if (total >= meta) verificarCelebracao(total, meta)
        } else {
            cardMeta?.visibility = View.GONE
        }

        exibirDica()
        atualizarWidget()
        atualizarBotaoServico()
    }

    // ──────────────────────────────────────────────────────────
    // SHIMMER DENTRO DAS LETRAS
    // ──────────────────────────────────────────────────────────
    private fun iniciarShimmer() {
        try {
            findViewById<View>(R.id.viewShimmer)?.visibility = View.INVISIBLE
            val tvLogo = findViewById<TextView>(R.id.tvLogo) ?: return
            ThemeHelper.animarLogoShimmer(tvLogo, prefs)
        } catch (_: Exception) {}
    }

    // ──────────────────────────────────────────────────────────
    // DICA
    // ──────────────────────────────────────────────────────────
    private fun exibirDica() {
        try {
            val corridas = db.buscarHoje()
            val qtd  = corridas.size
            val day  = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR)
            val dica = when {
                qtd == 0 -> DICAS[day % DICAS.size]
                qtd < 3  -> "Você já fez $qtd corrida${if (qtd > 1) "s" else ""} hoje. Continue assim!"
                qtd < 10 -> "Você já fez $qtd corridas hoje. Ótimo ritmo!"
                else     -> "Dia incrível! $qtd corridas completas!"
            }
            findViewById<TextView>(R.id.tvDica)?.text = dica
        } catch (_: Exception) {}
    }

    // ──────────────────────────────────────────────────────────
    // CELEBRAÇÃO
    // ──────────────────────────────────────────────────────────
    private fun verificarCelebracao(total: Float, meta: Float) {
        if (meta <= 0 || total < meta) return
        val hoje = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(java.util.Date())
        if (prefs.getString("ultima_celebracao", "") == hoje) return
        prefs.edit().putString("ultima_celebracao", hoje).apply()
        celebrarMeta()
    }

    private fun celebrarMeta() {
        try {
            val gold = Color.parseColor("#FFD740")
            val root = window.decorView.rootView
            repeat(8) { i ->
                handler.postDelayed({
                    try { root.setBackgroundColor(if (i % 2 == 0) gold else Color.TRANSPARENT) } catch (_: Exception) {}
                }, i * 180L)
            }
            handler.postDelayed({ try { root.setBackgroundColor(Color.TRANSPARENT) } catch (_: Exception) {} }, 1500L)
            val tv = try { findViewById<TextView>(R.id.tvGanhoHoje) } catch (_: Exception) { null }
            tv?.let {
                AnimatorSet().apply {
                    playTogether(
                        ObjectAnimator.ofFloat(it, "scaleX", 1f, 1.4f, 1.1f),
                        ObjectAnimator.ofFloat(it, "scaleY", 1f, 1.4f, 1.1f)
                    )
                    duration = 600; interpolator = AccelerateDecelerateInterpolator(); start()
                }
            }
            try { (getSystemService(VIBRATOR_SERVICE) as android.os.Vibrator).vibrate(longArrayOf(0,150,80,150,80,500), -1) } catch (_: Exception) {}
            handler.postDelayed({ Toast.makeText(this, "META BATIDA! PARABÉNS!", Toast.LENGTH_LONG).show() }, 600L)
            atualizarWidget()
        } catch (_: Exception) {}
    }

    // ──────────────────────────────────────────────────────────
    // WIDGET
    // ──────────────────────────────────────────────────────────
    fun atualizarWidget() {
        try {
            val mgr = AppWidgetManager.getInstance(this)
            AppWidgetManager.getInstance(this)
                .getAppWidgetIds(ComponentName(this, FluxoWidgetProvider::class.java))
                .forEach { FluxoWidgetProvider.updateWidget(this, mgr, it) }
        } catch (_: Exception) {}
    }

    private fun isAccessibilityEnabled(): Boolean {
        return try {
            val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            s.contains("fluxoapp", ignoreCase = true) || s.contains("MaximAccessibilityService", ignoreCase = true)
        } catch (_: Exception) { false }
    }
}
