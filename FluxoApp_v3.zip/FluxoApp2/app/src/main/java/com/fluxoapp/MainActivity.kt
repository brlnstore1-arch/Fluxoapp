package com.fluxoapp

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.MenuItem
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.*
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.cardview.widget.CardView
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    private lateinit var prefs: SharedPreferences
    private lateinit var db: DatabaseHelper
    private lateinit var drawerLayout: DrawerLayout
    private val handler = Handler(Looper.getMainLooper())

    private val FRASES = listOf(
        "Cada km rodado e um passo a mais para seu sonho!",
        "Motorista de sucesso e aquele que nunca desiste!",
        "Hoje e um otimo dia para bater sua meta!",
        "Sua dedicacao e o combustivel do seu sucesso!",
        "O melhor horario para trabalhar e agora!",
        "Cada corrida bem feita e um cliente fiel!",
        "Sucesso e a soma de pequenas conquistas diarias!",
        "Voce esta no caminho certo, continue!",
        "Foco, forca e fe! Seu esforco tem valor!",
        "Cada corrida aceita e uma oportunidade de ganhar mais!"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            setContentView(R.layout.activity_main)
            prefs = getSharedPreferences("FluxoApp", MODE_PRIVATE)
            db = DatabaseHelper(this)
            configurarToolbarEDrawer()
            configurarBotoes()
            configurarBotaoTema()
            iniciarShimmer()
            aplicarLogo3D()
            configurarMenuEmojis()
            atualizarStatus()
            atualizarStats()
            exibirFrase()
            aplicarTema()
            if (!Settings.canDrawOverlays(this)) {
                try { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) } catch (_: Exception) {}
            } else if (prefs.getBoolean("flutuante_ativo", true)) {
                try { startService(Intent(this, FloatingEarningsService::class.java)) } catch (_: Exception) {}
            }
        } catch (e: Exception) {
            android.util.Log.e("FluxoApp", "Crash onCreate: ${e.message}", e)
            try { Toast.makeText(this, "Erro: ${e.javaClass.simpleName}", Toast.LENGTH_LONG).show() } catch (_: Exception) {}
        }
    }

    override fun onResume() {
        super.onResume()
        atualizarStatus()
        atualizarStats()
        aplicarTema()
        atualizarIconeTema()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }

    private fun configurarBotaoTema() {
        atualizarIconeTema()
        findViewById<ImageButton>(R.id.btnTema)?.setOnClickListener {
            val atual = prefs.getInt("modo_tema", -1)
            val novo = when (atual) { -1 -> 0; 0 -> 1; else -> -1 }
            prefs.edit().putInt("modo_tema", novo).apply()
            aplicarTema()
            atualizarIconeTema()
            Toast.makeText(this, when (novo) { 0 -> "Modo DIA"; 1 -> "Modo NOITE"; else -> "Modo AUTO" }, Toast.LENGTH_SHORT).show()
        }
    }

    private fun atualizarIconeTema() {
        val btnTema = findViewById<ImageButton>(R.id.btnTema) ?: return
        val modo = prefs.getInt("modo_tema", -1)
        val noturno = ThemeHelper.isModoNoturno(prefs)
        val emoji = when { modo == 0 -> "sol"; modo == 1 -> "lua"; noturno -> "lua"; else -> "sol" }
        btnTema.setColorFilter(ThemeHelper.cor("accent_cyan", prefs))
        findViewById<TextView>(R.id.tvTemaLabel)?.text = emoji
    }

    private fun gd(color: Int, radius: Float, borderColor: Int = 0, borderWidth: Int = 0): GradientDrawable {
        val dp = resources.displayMetrics.density
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius * dp
            if (borderWidth > 0) setStroke((borderWidth * dp).toInt(), borderColor)
        }
    }

    private fun aplicarTema() {
        val bgDark   = ThemeHelper.cor("bg_dark",      prefs)
        val bgCard   = ThemeHelper.cor("bg_card",       prefs)
        val bgSect   = ThemeHelper.cor("bg_section",    prefs)
        val corToolbar = ThemeHelper.cor("toolbar",     prefs)
        val textMain = ThemeHelper.cor("text_white",    prefs)
        val textGray = ThemeHelper.cor("text_gray",     prefs)
        val cyan     = ThemeHelper.cor("accent_cyan",   prefs)
        val green    = ThemeHelper.cor("accent_green",  prefs)
        val gold     = ThemeHelper.cor("accent_gold",   prefs)
        val border   = ThemeHelper.cor("border",        prefs)

        // Fundo geral + toolbar
        try { findViewById<View>(R.id.rootLayout)?.setBackgroundColor(bgDark) } catch (_: Exception) {}
        try { findViewById<Toolbar>(R.id.toolbar)?.setBackgroundColor(corToolbar) } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvLogo)?.setTextColor(cyan) } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvFraseDia)?.setTextColor(textGray) } catch (_: Exception) {}

        // CardViews
        for (id in listOf(R.id.cardResumo, R.id.cardGanhos, R.id.cardMinimo, R.id.cardStatus, R.id.cardAutoAceitar)) {
            try { findViewById<CardView>(id)?.setCardBackgroundColor(bgCard) } catch (_: Exception) {}
        }

        // Stat cards
        for (id in listOf(R.id.statCorridas, R.id.statMediaKm, R.id.statMediaCorrida)) {
            try { findViewById<View>(id)?.background = gd(bgSect, 12f, border, 1) } catch (_: Exception) {}
        }

        // Valores em acento
        try { findViewById<TextView>(R.id.tvTotalCorridas)?.setTextColor(cyan) } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvMediaKm)?.setTextColor(gold) } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvMediaCorrida)?.setTextColor(gold) } catch (_: Exception) {}

        // Labels de secao
        for (id in listOf(R.id.tvLabelResumo, R.id.tvLabelGanhos, R.id.tvLabelMinimo)) {
            try { findViewById<TextView>(id)?.setTextColor(textGray) } catch (_: Exception) {}
        }
        try { findViewById<TextView>(R.id.tvLabelAutoAceitar)?.setTextColor(textMain) } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvSubAutoAceitar)?.setTextColor(textGray) } catch (_: Exception) {}

        // Ganho do dia
        try {
            val tv = findViewById<TextView>(R.id.tvGanhoHoje)
            if (tv?.currentTextColor != gold) tv?.setTextColor(green)
        } catch (_: Exception) {}

        // Status e meta
        try { findViewById<TextView>(R.id.tvStatus)?.setTextColor(textMain) } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvMetaDia)?.setTextColor(textGray) } catch (_: Exception) {}

        // Botoes
        val isGold = ThemeHelper.getTema(prefs) == "gold"
        val btnText = if (isGold) Color.parseColor("#1A0E00") else bgDark
        try { findViewById<Button>(R.id.btnSalvar)?.apply { background = gd(cyan, 12f); setTextColor(btnText) } } catch (_: Exception) {}
        try { findViewById<Button>(R.id.btnHistorico)?.apply { background = gd(Color.TRANSPARENT, 12f, cyan, 2); setTextColor(cyan) } } catch (_: Exception) {}
        try { findViewById<Button>(R.id.btnPermissaoAcessibilidade)?.background = gd(cyan, 12f) } catch (_: Exception) {}
        try { findViewById<Button>(R.id.btnPermissaoOverlay)?.background = gd(cyan, 12f) } catch (_: Exception) {}

        // Input
        try { findViewById<EditText>(R.id.etMinimoPorKm)?.apply { background = gd(bgSect, 8f, border, 1); setTextColor(textMain) } } catch (_: Exception) {}

        // Link historico + switch
        try { findViewById<TextView>(R.id.btnHistorico2)?.setTextColor(cyan) } catch (_: Exception) {}
        try { findViewById<Switch>(R.id.switchServico)?.setTextColor(cyan) } catch (_: Exception) {}

        // Progress
        try {
            val csl = android.content.res.ColorStateList.valueOf(cyan)
            findViewById<ProgressBar>(R.id.progressMetaDia)?.progressTintList = csl
        } catch (_: Exception) {}

        // Drawer
        try { findViewById<NavigationView>(R.id.navView)?.setBackgroundColor(bgCard) } catch (_: Exception) {}
    }

    private fun verificarCelebracao(total: Float, meta: Float) {
        if (meta <= 0 || total < meta) return
        val hoje = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(java.util.Date())
        if (prefs.getString("ultima_celebracao", "") == hoje) return
        prefs.edit().putString("ultima_celebracao", hoje).apply()
        celebrarMeta()
    }

    private fun celebrarMeta() {
        try {
            val cor = Color.parseColor("#FFD740")
            val root = window.decorView.rootView
            repeat(8) { i -> handler.postDelayed({ try { root.setBackgroundColor(if (i % 2 == 0) cor else Color.TRANSPARENT) } catch (_: Exception) {} }, i * 180L) }
            handler.postDelayed({ try { root.setBackgroundColor(Color.TRANSPARENT) } catch (_: Exception) {} }, 1500L)
            val tv = findViewById<TextView>(R.id.tvGanhoHoje)
            tv?.let {
                AnimatorSet().apply {
                    playTogether(ObjectAnimator.ofFloat(it, "scaleX", 1f, 1.5f, 1.2f), ObjectAnimator.ofFloat(it, "scaleY", 1f, 1.5f, 1.2f))
                    duration = 700; interpolator = AccelerateDecelerateInterpolator(); start()
                }
                repeat(8) { i -> handler.postDelayed({ try { it.setTextColor(if (i % 2 == 0) cor else Color.WHITE) } catch (_: Exception) {} }, i * 200L) }
                handler.postDelayed({ try { it.setTextColor(cor) } catch (_: Exception) {} }, 1800L)
            }
            try { (getSystemService(VIBRATOR_SERVICE) as android.os.Vibrator).vibrate(longArrayOf(0, 150, 80, 150, 80, 150, 80, 500), -1) } catch (_: Exception) {}
            try {
                val tone = android.media.ToneGenerator(android.media.AudioManager.STREAM_NOTIFICATION, 100)
                listOf(0L, 110L, 220L, 330L, 440L, 550L, 660L, 770L, 900L, 1030L, 1160L).forEach { d ->
                    handler.postDelayed({ try { tone.startTone(android.media.ToneGenerator.TONE_PROP_ACK, 75) } catch (_: Exception) {} }, d)
                }
                handler.postDelayed({ try { tone.release() } catch (_: Exception) {} }, 1400L)
            } catch (_: Exception) {}
            handler.postDelayed({ Toast.makeText(this, "META BATIDA! PARABENS GUERREIRO!", Toast.LENGTH_LONG).show() }, 600L)
            atualizarWidget()
        } catch (_: Exception) {}
    }

    fun atualizarWidget() {
        try {
            val mgr = AppWidgetManager.getInstance(this)
            AppWidgetManager.getInstance(this)
                .getAppWidgetIds(ComponentName(this, FluxoWidgetProvider::class.java))
                .forEach { FluxoWidgetProvider.updateWidget(this, mgr, it) }
        } catch (_: Exception) {}
    }

    private fun aplicarLogo3D() {
        try {
            val tv = findViewById<TextView>(R.id.tvLogo) ?: return
            tv.setShadowLayer(6f, 4f, 4f, Color.parseColor("#CC000000"))
            tv.paint.isAntiAlias = true
        } catch (_: Exception) {}
    }

    private fun iniciarShimmer() {
        try {
            val shimmer = findViewById<View>(R.id.viewShimmer) ?: return
            val container = findViewById<FrameLayout>(R.id.titleContainer) ?: return
            container.post {
                val largura = container.width.toFloat()
                val shimmerW = shimmer.width.toFloat()
                val tvLogo = findViewById<TextView>(R.id.tvLogo)
                val logoX = tvLogo?.x ?: (largura / 2f - 100f)
                val logoW = tvLogo?.width?.toFloat() ?: 200f
                android.animation.ValueAnimator.ofFloat(logoX - shimmerW, logoX + logoW + shimmerW).apply {
                    duration = 900; startDelay = 1200
                    repeatCount = android.animation.ValueAnimator.INFINITE
                    repeatMode = android.animation.ValueAnimator.REVERSE
                    interpolator = AccelerateDecelerateInterpolator()
                    addUpdateListener { anim -> shimmer.translationX = anim.animatedValue as Float; shimmer.alpha = 0.8f }
                    start()
                }
            }
        } catch (_: Exception) {}
    }

    private fun configurarMenuEmojis() {
        try {
            val menu = findViewById<NavigationView>(R.id.navView).menu
            menu.findItem(R.id.nav_historico)?.title     = "Historico"
            menu.findItem(R.id.nav_relatorios)?.title    = "Relatorios"
            menu.findItem(R.id.nav_financas)?.title      = "Abastecimentos"
            menu.findItem(R.id.nav_configuracoes)?.title = "Configuracoes"
            menu.findItem(R.id.nav_sobre)?.title         = "Sobre o App"
            menu.findItem(R.id.nav_sair)?.title          = "Desativar Servico"
        } catch (_: Exception) {}
    }

    private fun configurarToolbarEDrawer() {
        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        drawerLayout = findViewById(R.id.drawerLayout)
        val navView = findViewById<NavigationView>(R.id.navView)
        navView.setNavigationItemSelectedListener(this)
        val toggle = ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.app_name, R.string.app_name)
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()
        try { toggle.drawerArrowDrawable.color = getColor(R.color.accent_cyan) } catch (_: Exception) {}
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        drawerLayout.closeDrawer(GravityCompat.START)
        when (item.itemId) {
            R.id.nav_configuracoes -> startActivity(Intent(this, SettingsActivity::class.java))
            R.id.nav_relatorios    -> startActivity(Intent(this, ReportsActivity::class.java))
            R.id.nav_financas      -> startActivity(Intent(this, FinanceActivity::class.java))
            R.id.nav_historico     -> startActivity(Intent(this, HistoryActivity::class.java))
            R.id.nav_sobre         -> startActivity(Intent(this, AboutActivity::class.java))
            R.id.nav_sair -> {
                prefs.edit().putBoolean("servico_ativo", false).apply()
                try { stopService(Intent(this, FloatingEarningsService::class.java)) } catch (_: Exception) {}
                Toast.makeText(this, "Servico desativado", Toast.LENGTH_SHORT).show()
                atualizarStatus()
            }
        }
        return true
    }

    private fun configurarBotoes() {
        findViewById<Button>(R.id.btnPermissaoAcessibilidade)?.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        findViewById<Button>(R.id.btnPermissaoOverlay)?.setOnClickListener { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }

        val switchServico = findViewById<Switch>(R.id.switchServico)
        switchServico?.isChecked = prefs.getBoolean("servico_ativo", true)
        switchServico?.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("servico_ativo", isChecked).apply()
            if (isChecked && prefs.getBoolean("flutuante_ativo", true))
                try { startService(Intent(this, FloatingEarningsService::class.java)) } catch (_: Exception) {}
            else if (!isChecked)
                try { stopService(Intent(this, FloatingEarningsService::class.java)) } catch (_: Exception) {}
            Toast.makeText(this, if (isChecked) "Servico ATIVADO" else "Servico PAUSADO", Toast.LENGTH_SHORT).show()
            atualizarStatus()
        }

        val switchAuto = findViewById<Switch>(R.id.switchAutoAceitar)
        switchAuto?.isChecked = prefs.getBoolean("auto_aceitar", false)
        switchAuto?.setOnCheckedChangeListener { _, isChecked -> prefs.edit().putBoolean("auto_aceitar", isChecked).apply() }

        val etMinimo = findViewById<EditText>(R.id.etMinimoPorKm)
        etMinimo?.setText("%.2f".format(prefs.getFloat("minimo_km", 1.20f)))
        findViewById<Button>(R.id.btnSalvar)?.setOnClickListener {
            val v = etMinimo?.text.toString().replace(",", ".").toFloatOrNull()
            if (v != null && v > 0) { prefs.edit().putFloat("minimo_km", v).apply(); Toast.makeText(this, "R$ ${"%.2f".format(v)}/km salvo!", Toast.LENGTH_SHORT).show() }
            else Toast.makeText(this, "Valor invalido", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnHistorico)?.setOnClickListener { startActivity(Intent(this, HistoryActivity::class.java)) }
        findViewById<TextView>(R.id.btnHistorico2)?.setOnClickListener { startActivity(Intent(this, HistoryActivity::class.java)) }
    }

    private fun exibirFrase() {
        val day = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR)
        findViewById<TextView>(R.id.tvFraseDia)?.text = FRASES[day % FRASES.size]
    }

    private fun atualizarStatus() {
        val tvStatus   = findViewById<TextView>(R.id.tvStatus)
        val btnAcess   = findViewById<Button>(R.id.btnPermissaoAcessibilidade)
        val btnOverlay = findViewById<Button>(R.id.btnPermissaoOverlay)
        val ativo = prefs.getBoolean("servico_ativo", true)
        btnAcess?.visibility = View.GONE
        btnOverlay?.visibility = View.GONE
        when {
            !ativo -> tvStatus?.text = "Servico pausado"
            !isAccessibilityEnabled() && !Settings.canDrawOverlays(this) -> {
                tvStatus?.text = "Ative Acessibilidade e Sobreposicao!"
                btnAcess?.visibility = View.VISIBLE
                btnOverlay?.visibility = View.VISIBLE
            }
            !isAccessibilityEnabled() -> { tvStatus?.text = "Ative a Acessibilidade!"; btnAcess?.visibility = View.VISIBLE }
            !Settings.canDrawOverlays(this) -> { tvStatus?.text = "Ative a sobreposicao!"; btnOverlay?.visibility = View.VISIBLE }
            else -> tvStatus?.text = "Monitorando o Maxim!"
        }
    }

    private fun atualizarStats() {
        val corridas = db.buscarHoje()
        val resumo   = db.resumo(corridas)
        val total    = resumo["total"] ?: 0f
        val meta     = prefs.getFloat("meta_diaria", 0f)
        val green    = ThemeHelper.cor("accent_green", prefs)
        val gold     = ThemeHelper.cor("accent_gold",  prefs)

        findViewById<TextView>(R.id.tvGanhoHoje)?.apply { text = "R$ ${"%.2f".format(total)}"; if (currentTextColor != gold) setTextColor(green) }
        findViewById<TextView>(R.id.tvTotalCorridas)?.text  = "${(resumo["corridas"] ?: 0f).toInt()}"
        findViewById<TextView>(R.id.tvMediaKm)?.text        = "R$ ${"%.2f".format(resumo["media_km"] ?: 0f)}"
        findViewById<TextView>(R.id.tvMediaCorrida)?.text   = "R$ ${"%.2f".format(resumo["media_corrida"] ?: 0f)}"

        val pb  = findViewById<ProgressBar>(R.id.progressMetaDia)
        val tvM = findViewById<TextView>(R.id.tvMetaDia)
        if (meta > 0) {
            val pct = ((total / meta) * 100).toInt().coerceIn(0, 100)
            pb?.progress = pct
            try {
                val cor = when { pct >= 100 -> "#FFD740"; pct >= 75 -> "#00E676"; else -> "#00E5FF" }
                pb?.progressTintList = android.content.res.ColorStateList.valueOf(Color.parseColor(cor))
            } catch (_: Exception) {}
            tvM?.text = "Meta: R$ ${"%.0f".format(meta)} ($pct%)"
            pb?.visibility = View.VISIBLE; tvM?.visibility = View.VISIBLE
            verificarCelebracao(total, meta)
        } else { pb?.visibility = View.GONE; tvM?.visibility = View.GONE }
        atualizarWidget()
    }

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.contains("fluxoapp", ignoreCase = true) || enabled.contains("MaximAccessibilityService", ignoreCase = true)
    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) drawerLayout.closeDrawer(GravityCompat.START)
        else super.onBackPressed()
    }
}
