package com.fluxoapp

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.MenuItem
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.*
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.cardview.widget.CardView
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    private lateinit var prefs: SharedPreferences
    private lateinit var db: DatabaseHelper
    private lateinit var drawerLayout: DrawerLayout
    private val handler = Handler(Looper.getMainLooper())

    private val DICAS = listOf(
        "Cada km rodado e um passo a mais para seu sonho!",
        "Motorista de sucesso e aquele que nunca desiste!",
        "Hoje e um otimo dia para bater sua meta!",
        "Sua dedicacao e o combustivel do seu sucesso!",
        "O melhor horario para trabalhar e agora!",
        "Cada corrida bem feita e um cliente fiel!",
        "Sucesso e a soma de pequenas conquistas diarias!",
        "Voce esta no caminho certo, continue!",
        "Foco, forca e fe! Seu esforco tem valor!",
        "Cada corrida aceita e uma oportunidade de ganhar mais!"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            setContentView(R.layout.activity_main)
            prefs = getSharedPreferences("FluxoApp", MODE_PRIVATE)
            db = DatabaseHelper(this)

            configurarToolbarEDrawer()
            configurarBotaoTema()
            configurarNavegacao()
            iniciarShimmer()
            aplicarLogo3D()
            configurarMenuEmojis()
            atualizarStatus()
            atualizarStats()
            exibirDica()
            aplicarTema()

            if (!Settings.canDrawOverlays(this)) {
                try { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) } catch (_: Exception) {}
            } else if (prefs.getBoolean("flutuante_ativo", true)) {
                try { startService(Intent(this, FloatingEarningsService::class.java)) } catch (_: Exception) {}
            }
        } catch (e: Exception) {
            android.util.Log.e("FluxoApp", "Crash onCreate: ${e.message}", e)
            try { Toast.makeText(this, "Erro: ${e.javaClass.simpleName}", Toast.LENGTH_LONG).show() } catch (_: Exception) {}
        }
    }

    override fun onResume() {
        super.onResume()
        atualizarStatus()
        atualizarStats()
        aplicarTema()
        atualizarIconeTema()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }

    // ──────────────────────────────────────
    // NAVEGACAO
    // ──────────────────────────────────────
    private fun configurarNavegacao() {
        // Bottom nav
        findViewById<View>(R.id.btnBottomInicio)?.setOnClickListener {
            // ja esta aqui
        }
        findViewById<View>(R.id.btnBottomCorridas)?.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        findViewById<View>(R.id.btnBottomMetricas)?.setOnClickListener {
            startActivity(Intent(this, ReportsActivity::class.java))
        }

        // Botoes rapidos
        findViewById<View>(R.id.btnNavHistorico)?.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        findViewById<View>(R.id.btnNavRelatorios)?.setOnClickListener {
            startActivity(Intent(this, ReportsActivity::class.java))
        }
        findViewById<View>(R.id.btnNavAbastec)?.setOnClickListener {
            startActivity(Intent(this, FinanceActivity::class.java))
        }

        // Toque no card de ganhos abre historico
        findViewById<View>(R.id.cardGanhos)?.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
    }

    // ──────────────────────────────────────
    // TEMA
    // ──────────────────────────────────────
    private fun configurarBotaoTema() {
        atualizarIconeTema()
        findViewById<ImageButton>(R.id.btnTema)?.setOnClickListener {
            val atual = prefs.getInt("modo_tema", -1)
            val novo = when (atual) { -1 -> 0; 0 -> 1; else -> -1 }
            prefs.edit().putInt("modo_tema", novo).apply()
            aplicarTema()
            atualizarIconeTema()
            Toast.makeText(this, when (novo) { 0 -> "Modo DIA"; 1 -> "Modo NOITE"; else -> "Modo AUTO" }, Toast.LENGTH_SHORT).show()
        }
    }

    private fun atualizarIconeTema() {
        val btn = findViewById<ImageButton>(R.id.btnTema) ?: return
        val modo = prefs.getInt("modo_tema", -1)
        val noturno = ThemeHelper.isModoNoturno(prefs)
        val label = when { modo == 0 -> "sol"; modo == 1 -> "lua"; noturno -> "lua"; else -> "sol" }
        btn.setColorFilter(ThemeHelper.cor("accent_cyan", prefs))
        findViewById<TextView>(R.id.tvTemaLabel)?.text = label
    }

    // ──────────────────────────────────────
    // APLICAR TEMA — usa apenas IDs que existem no novo layout
    // ──────────────────────────────────────
    private fun gd(color: Int, radius: Float, borderColor: Int = 0, bw: Int = 0): GradientDrawable {
        val dp = resources.displayMetrics.density
        return GradientDrawable().apply {
            setColor(color); cornerRadius = radius * dp
            if (bw > 0) setStroke((bw * dp).toInt(), borderColor)
        }
    }

    private fun aplicarTema() {
        val bgDark   = ThemeHelper.cor("bg_dark",      prefs)
        val bgCard   = ThemeHelper.cor("bg_card",       prefs)
        val bgSect   = ThemeHelper.cor("bg_section",    prefs)
        val corToolbar = ThemeHelper.cor("toolbar",     prefs)
        val textMain = ThemeHelper.cor("text_white",    prefs)
        val textGray = ThemeHelper.cor("text_gray",     prefs)
        val cyan     = ThemeHelper.cor("accent_cyan",   prefs)
        val green    = ThemeHelper.cor("accent_green",  prefs)
        val gold     = ThemeHelper.cor("accent_gold",   prefs)
        val border   = ThemeHelper.cor("border",        prefs)

        // Fundo geral
        try { findViewById<View>(R.id.rootLayout)?.setBackgroundColor(bgDark) } catch (_: Exception) {}

        // Toolbar
        try { findViewById<Toolbar>(R.id.toolbar)?.setBackgroundColor(corToolbar) } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvLogo)?.setTextColor(cyan) } catch (_: Exception) {}

        // Barra de status do servico
        try { findViewById<View>(R.id.statusBar)?.setBackgroundColor(bgCard) } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvStatusBar)?.setTextColor(textGray) } catch (_: Exception) {}

        // Card principal: ganhos
        try { findViewById<CardView>(R.id.cardGanhos)?.setCardBackgroundColor(bgCard) } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvLabelGanhos)?.setTextColor(textGray) } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvGanhoHoje)?.let { if (it.currentTextColor != gold) it.setTextColor(green) } } catch (_: Exception) {}

        // Stat cards
        for (id in listOf(R.id.statCorridas, R.id.statKm, R.id.statMedia)) {
            try { findViewById<View>(id)?.background = gd(bgSect, 12f, border, 1) } catch (_: Exception) {}
        }
        try { findViewById<TextView>(R.id.tvStatCorridas)?.setTextColor(cyan) } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvStatKm)?.setTextColor(gold) } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvStatMedia)?.setTextColor(gold) } catch (_: Exception) {}

        // Card meta
        try { findViewById<CardView>(R.id.cardMeta)?.setCardBackgroundColor(bgCard) } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvMetaInfo)?.setTextColor(textGray) } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvMetaPercent)?.setTextColor(gold) } catch (_: Exception) {}
        try { findViewById<ProgressBar>(R.id.progressMetaDia)?.progressTintList = android.content.res.ColorStateList.valueOf(cyan) } catch (_: Exception) {}

        // Dica
        try {
            val layoutDica = findViewById<View>(R.id.layoutDica)
            layoutDica?.setBackgroundColor(bgCard)
            val gd = GradientDrawable().apply { setColor(bgCard) }
            layoutDica?.background = gd
        } catch (_: Exception) {}
        try { findViewById<View>(R.id.dicaBorder)?.setBackgroundColor(cyan) } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvDica)?.setTextColor(textGray) } catch (_: Exception) {}

        // Botoes rapidos
        for (id in listOf(R.id.btnNavHistorico, R.id.btnNavRelatorios, R.id.btnNavAbastec)) {
            try { findViewById<View>(id)?.background = gd(bgSect, 14f, border, 1) } catch (_: Exception) {}
        }
        for (id in listOf(R.id.tvIconHistorico, R.id.tvIconRelatorios, R.id.tvIconAbastec)) {
            try { findViewById<TextView>(id)?.setTextColor(cyan) } catch (_: Exception) {}
        }

        // Bottom nav
        try { findViewById<View>(R.id.bottomNav)?.setBackgroundColor(bgCard) } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvIconBotInicio)?.setTextColor(cyan) } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvBotInicio)?.setTextColor(cyan) } catch (_: Exception) {}
        for (id in listOf(R.id.tvIconBotCorridas, R.id.tvBotCorridas, R.id.tvIconBotMetricas, R.id.tvBotMetricas)) {
            try { findViewById<TextView>(id)?.setTextColor(textGray) } catch (_: Exception) {}
        }

        // Drawer
        try { findViewById<NavigationView>(R.id.navView)?.setBackgroundColor(bgCard) } catch (_: Exception) {}
    }

    // ──────────────────────────────────────
    // CELEBRACAO META
    // ──────────────────────────────────────
    private fun verificarCelebracao(total: Float, meta: Float) {
        if (meta <= 0 || total < meta) return
        val hoje = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(java.util.Date())
        if (prefs.getString("ultima_celebracao", "") == hoje) return
        prefs.edit().putString("ultima_celebracao", hoje).apply()
        celebrarMeta()
    }

    private fun celebrarMeta() {
        try {
            val cor = Color.parseColor("#FFD740")
            val root = window.decorView.rootView
            repeat(8) { i -> handler.postDelayed({ try { root.setBackgroundColor(if (i % 2 == 0) cor else Color.TRANSPARENT) } catch (_: Exception) {} }, i * 180L) }
            handler.postDelayed({ try { root.setBackgroundColor(Color.TRANSPARENT) } catch (_: Exception) {} }, 1500L)
            val tv = findViewById<TextView>(R.id.tvGanhoHoje)
            tv?.let {
                AnimatorSet().apply {
                    playTogether(ObjectAnimator.ofFloat(it, "scaleX", 1f, 1.5f, 1.2f), ObjectAnimator.ofFloat(it, "scaleY", 1f, 1.5f, 1.2f))
                    duration = 700; interpolator = AccelerateDecelerateInterpolator(); start()
                }
                repeat(8) { i -> handler.postDelayed({ try { it.setTextColor(if (i % 2 == 0) cor else Color.WHITE) } catch (_: Exception) {} }, i * 200L) }
                handler.postDelayed({ try { it.setTextColor(cor) } catch (_: Exception) {} }, 1800L)
            }
            try { (getSystemService(VIBRATOR_SERVICE) as android.os.Vibrator).vibrate(longArrayOf(0, 150, 80, 150, 80, 150, 80, 500), -1) } catch (_: Exception) {}
            try {
                val tone = android.media.ToneGenerator(android.media.AudioManager.STREAM_NOTIFICATION, 100)
                listOf(0L, 110L, 220L, 330L, 440L, 550L, 660L, 770L, 900L).forEach { d ->
                    handler.postDelayed({ try { tone.startTone(android.media.ToneGenerator.TONE_PROP_ACK, 75) } catch (_: Exception) {} }, d)
                }
                handler.postDelayed({ try { tone.release() } catch (_: Exception) {} }, 1200L)
            } catch (_: Exception) {}
            handler.postDelayed({ Toast.makeText(this, "META BATIDA! PARABENS GUERREIRO!", Toast.LENGTH_LONG).show() }, 600L)
            atualizarWidget()
        } catch (_: Exception) {}
    }

    fun atualizarWidget() {
        try {
            val mgr = AppWidgetManager.getInstance(this)
            AppWidgetManager.getInstance(this)
                .getAppWidgetIds(ComponentName(this, FluxoWidgetProvider::class.java))
                .forEach { FluxoWidgetProvider.updateWidget(this, mgr, it) }
        } catch (_: Exception) {}
    }

    private fun aplicarLogo3D() {
        try {
            val tv = findViewById<TextView>(R.id.tvLogo) ?: return
            tv.setShadowLayer(6f, 4f, 4f, Color.parseColor("#CC000000"))
            tv.paint.isAntiAlias = true
        } catch (_: Exception) {}
    }

    private fun iniciarShimmer() {
        try {
            val shimmer = findViewById<View>(R.id.viewShimmer) ?: return
            val container = findViewById<FrameLayout>(R.id.titleContainer) ?: return
            container.post {
                val largura = container.width.toFloat()
                val shimmerW = shimmer.width.toFloat()
                val tvLogo = findViewById<TextView>(R.id.tvLogo)
                val logoX = tvLogo?.x ?: (largura / 2f - 100f)
                val logoW = tvLogo?.width?.toFloat() ?: 200f
                android.animation.ValueAnimator.ofFloat(logoX - shimmerW, logoX + logoW + shimmerW).apply {
                    duration = 900; startDelay = 1200
                    repeatCount = android.animation.ValueAnimator.INFINITE
                    repeatMode = android.animation.ValueAnimator.REVERSE
                    interpolator = AccelerateDecelerateInterpolator()
                    addUpdateListener { anim -> shimmer.translationX = anim.animatedValue as Float; shimmer.alpha = 0.8f }
                    start()
                }
            }
        } catch (_: Exception) {}
    }

    private fun configurarMenuEmojis() {
        try {
            val menu = findViewById<NavigationView>(R.id.navView).menu
            menu.findItem(R.id.nav_historico)?.title     = "Historico"
            menu.findItem(R.id.nav_relatorios)?.title    = "Relatorios"
            menu.findItem(R.id.nav_financas)?.title      = "Abastecimentos"
            menu.findItem(R.id.nav_configuracoes)?.title = "Configuracoes"
            menu.findItem(R.id.nav_sobre)?.title         = "Sobre o App"
            menu.findItem(R.id.nav_sair)?.title          = "Desativar Servico"
        } catch (_: Exception) {}
    }

    private fun configurarToolbarEDrawer() {
        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        drawerLayout = findViewById(R.id.drawerLayout)
        val navView = findViewById<NavigationView>(R.id.navView)
        navView.setNavigationItemSelectedListener(this)
        val toggle = ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.app_name, R.string.app_name)
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()
        try { toggle.drawerArrowDrawable.color = getColor(R.color.accent_cyan) } catch (_: Exception) {}
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        drawerLayout.closeDrawer(GravityCompat.START)
        when (item.itemId) {
            R.id.nav_configuracoes -> startActivity(Intent(this, SettingsActivity::class.java))
            R.id.nav_relatorios    -> startActivity(Intent(this, ReportsActivity::class.java))
            R.id.nav_financas      -> startActivity(Intent(this, FinanceActivity::class.java))
            R.id.nav_historico     -> startActivity(Intent(this, HistoryActivity::class.java))
            R.id.nav_sobre         -> startActivity(Intent(this, AboutActivity::class.java))
            R.id.nav_sair -> {
                prefs.edit().putBoolean("servico_ativo", false).apply()
                try { stopService(Intent(this, FloatingEarningsService::class.java)) } catch (_: Exception) {}
                Toast.makeText(this, "Servico desativado", Toast.LENGTH_SHORT).show()
                atualizarStatus()
            }
        }
        return true
    }

    private fun exibirDica() {
        try {
            val day = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR)
            val corridas = db.buscarHoje()
            val qtd = corridas.size
            val dica = when {
                qtd == 0 -> DICAS[day % DICAS.size]
                qtd < 3  -> "Voce ja fez $qtd corrida${if (qtd > 1) "s" else ""} hoje. Continua!"
                qtd < 10 -> "Voce ja fez $qtd corridas hoje. Continue assim!"
                else     -> "Otimo dia! $qtd corridas completas!"
            }
            findViewById<TextView>(R.id.tvDica)?.text = dica
        } catch (_: Exception) {}
    }

    private fun atualizarStatus() {
        val tvBar = findViewById<TextView>(R.id.tvStatusBar)
        val dot   = findViewById<View>(R.id.dotServico)
        val ativo = prefs.getBoolean("servico_ativo", true)
        val temAcess   = isAccessibilityEnabled()
        val temOverlay = Settings.canDrawOverlays(this)

        when {
            !ativo -> {
                tvBar?.text = "SERVICO PAUSADO"
                dot?.setBackgroundColor(Color.parseColor("#FF1744"))
            }
            !temAcess && !temOverlay -> {
                tvBar?.text = "Toque para ativar permissoes!"
                dot?.setBackgroundColor(Color.parseColor("#FFD740"))
                // Toque na barra de status abre configuracoes
                findViewById<View>(R.id.statusBar)?.setOnClickListener {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
            }
            !temAcess -> {
                tvBar?.text = "Ative a Acessibilidade!"
                dot?.setBackgroundColor(Color.parseColor("#FFD740"))
                findViewById<View>(R.id.statusBar)?.setOnClickListener {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
            }
            !temOverlay -> {
                tvBar?.text = "Ative a Sobreposicao!"
                dot?.setBackgroundColor(Color.parseColor("#FFD740"))
                findViewById<View>(R.id.statusBar)?.setOnClickListener {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }
            }
            else -> {
                tvBar?.text = "SERVICO ATIVO . MONITORANDO"
                dot?.setBackgroundResource(R.drawable.dot_status)
                // Toque vai para configuracoes
                findViewById<View>(R.id.statusBar)?.setOnClickListener {
                    startActivity(Intent(this, SettingsActivity::class.java))
                }
            }
        }
    }

    private fun atualizarStats() {
        val corridas = db.buscarHoje()
        val resumo   = db.resumo(corridas)
        val total    = resumo["total"] ?: 0f
        val kmTotal  = resumo["km_total"] ?: 0f
        val meta     = prefs.getFloat("meta_diaria", 0f)
        val green    = ThemeHelper.cor("accent_green", prefs)
        val gold     = ThemeHelper.cor("accent_gold",  prefs)

        // Valor principal
        try {
            val tv = findViewById<TextView>(R.id.tvGanhoHoje)
            tv?.text = "R$ ${"%.2f".format(total)}"
            if (tv?.currentTextColor != gold) tv?.setTextColor(green)
        } catch (_: Exception) {}

        // Stat cards
        try { findViewById<TextView>(R.id.tvStatCorridas)?.text = "${(resumo["corridas"] ?: 0f).toInt()}" } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvStatKm)?.text = "${"%.1f".format(kmTotal)} km" } catch (_: Exception) {}
        try { findViewById<TextView>(R.id.tvStatMedia)?.text = "R$ ${"%.2f".format(resumo["media_corrida"] ?: 0f)}" } catch (_: Exception) {}

        // Meta
        val cardMeta = try { findViewById<CardView>(R.id.cardMeta) } catch (_: Exception) { null }
        if (meta > 0) {
            val pct = ((total / meta) * 100).toInt().coerceIn(0, 100)
            try { cardMeta?.visibility = View.VISIBLE } catch (_: Exception) {}
            try { findViewById<TextView>(R.id.tvMetaInfo)?.text = "META DIARIA . R$ ${"%.0f".format(meta)}" } catch (_: Exception) {}
            try { findViewById<TextView>(R.id.tvMetaPercent)?.text = "$pct%" } catch (_: Exception) {}
            try {
                val pb = findViewById<ProgressBar>(R.id.progressMetaDia)
                pb?.progress = pct
                val cor = when { pct >= 100 -> "#FFD740"; pct >= 75 -> "#00E676"; else -> "#00E5FF" }
                pb?.progressTintList = android.content.res.ColorStateList.valueOf(Color.parseColor(cor))
            } catch (_: Exception) {}
            verificarCelebracao(total, meta)
        } else {
            try { cardMeta?.visibility = View.GONE } catch (_: Exception) {}
        }

        // Dica inteligente
        exibirDica()
        atualizarWidget()
    }

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.contains("fluxoapp", ignoreCase = true) || enabled.contains("MaximAccessibilityService", ignoreCase = true)
    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) drawerLayout.closeDrawer(GravityCompat.START)
        else super.onBackPressed()
    }
}
