package com.fluxoapp

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            // Layout programático — sem depender de nenhum arquivo XML
            val layout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(Color.parseColor("#0E0E0E"))
                gravity = android.view.Gravity.CENTER
            }

            val texto = TextView(this).apply {
                text = "✅ FluxoApp abriu com sucesso!"
                textSize = 22f
                setTextColor(Color.parseColor("#C9A84C"))
                gravity = android.view.Gravity.CENTER
                setPadding(40, 40, 40, 40)
            }

            val sub = TextView(this).apply {
                text = "Android ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT})\n${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}"
                textSize = 14f
                setTextColor(Color.parseColor("#7A6A50"))
                gravity = android.view.Gravity.CENTER
                setPadding(40, 20, 40, 40)
            }

            layout.addView(texto)
            layout.addView(sub)
            setContentView(layout)

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
