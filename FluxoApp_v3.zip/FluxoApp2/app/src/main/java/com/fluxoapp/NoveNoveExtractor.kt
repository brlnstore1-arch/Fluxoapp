package com.fluxoapp

import android.view.accessibility.AccessibilityNodeInfo

/**
 * NoveNoveExtractor — FluxoApp
 *
 * Funções de extração de dados da tela da 99, 100% independentes do
 * MaximExtractor.kt. Baseado no layout real da tela de oferta da 99:
 *
 *   R$5,30
 *   R$2,13 Tarifa base dinâmica incl.
 *   ⭐5,00 · 52 corridas · ✅CPF verif.
 *   ↑5min (2,7km)
 *   rua sn 4, 12, Santa Isabel do Pará
 *   ↓5min (2,4km)
 *   Rua Encarnacion Granado, 1308, Santa Izabel do Pará
 *   [Aceitar]
 *
 * Diferenças importantes em relação ao Taxsee:
 *   - Tempo e km vêm juntos: "5min (2,7km)" (não separados)
 *   - Não existe botão "Recusar" (só ícone X)
 *   - Endereços não usam prefixo "Rua"/"Avenida" de forma consistente
 *     (ex: "rua sn 4, 12, ...") então a detecção de endereço é mais solta
 */

internal fun NoveNoveAccessibilityService.extrairValor99(texto: String): Float? {
    // Primeiro valor R$ da tela é o valor total da corrida (R$5,30).
    // O segundo valor R$ é a tarifa base (R$2,13) — não deve ser confundido.
    val regex = Regex("""r\$\s*([0-9]+[,.][0-9]{2})""", RegexOption.IGNORE_CASE)
    return regex.find(texto)
        ?.groupValues?.get(1)
        ?.replace(",", ".")
        ?.toFloatOrNull()
        ?.takeIf { it >= 1f }
}

/**
 * Extrai o km total da corrida somando os trechos "Xmin (Ykm)" que aparecem
 * na tela (trecho até o passageiro + trecho até o destino).
 */
internal fun NoveNoveAccessibilityService.extrairKm99(texto: String): Float? {
    val regex = Regex("""([0-9]+[,.][0-9]+)\s*km""", RegexOption.IGNORE_CASE)
    val valores = regex.findAll(texto)
        .mapNotNull { it.groupValues[1].replace(",", ".").toFloatOrNull() }
        .filter { it > 0f }
        .toList()

    return when {
        valores.size >= 2 -> valores[0] + valores[1]  // origem + destino
        valores.size == 1 -> valores[0]
        else              -> null
    }
}

/**
 * Extrai o tempo até o passageiro (primeiro "Xmin" da tela).
 */
internal fun NoveNoveAccessibilityService.extrairTempo99(texto: String): String {
    val regex = Regex("""(\d+)\s*min""", RegexOption.IGNORE_CASE)
    return regex.find(texto)?.let { "${it.groupValues[1]} min" } ?: ""
}

/**
 * Extrai o tipo de veículo/serviço solicitado (Moto, 99Pop, etc).
 */
internal fun NoveNoveAccessibilityService.extrairTipo99(texto: String): String {
    val regex = Regex("""(moto|carro|99pop|99x|comfort|top)""", RegexOption.IGNORE_CASE)
    return regex.find(texto)?.value?.replaceFirstChar { it.uppercase() } ?: "Desconhecido"
}

/**
 * Extrai os dois endereços mostrados na tela (origem/destino).
 * A 99 nem sempre usa prefixos padronizados ("Rua", "Avenida"), então a
 * heurística é mais permissiva: qualquer linha longa com vírgula que não
 * seja um valor monetário nem contenha "min"/"km".
 */
internal fun NoveNoveAccessibilityService.extrairOrigemDestino99(raiz: AccessibilityNodeInfo): Pair<String, String> {
    val enderecos = mutableListOf<String>()
    visitarNos99(raiz) { no ->
        val txt = no.text?.toString()?.trim() ?: ""
        if (txt.length > 8 && no.isVisibleToUser) {
            val temVirgula  = txt.contains(",")
            val temPreco    = txt.contains("r$", ignoreCase = true)
            val temTempoKm  = Regex("""\d+\s*(min|km)""", RegexOption.IGNORE_CASE).containsMatchIn(txt)
            val ehAvaliacao = txt.contains("corridas", ignoreCase = true) ||
                               txt.contains("verif",    ignoreCase = true)
            if (temVirgula && !temPreco && !temTempoKm && !ehAvaliacao) {
                enderecos.add(txt)
            }
        }
    }
    return Pair(enderecos.getOrNull(0) ?: "", enderecos.getOrNull(1) ?: "")
}

/**
 * A 99 não expõe forma de pagamento na tela de oferta na maioria das versões.
 * Retorna vazio — o campo fica em branco no registro da corrida, sem
 * inventar um valor que não veio da tela.
 */
internal fun NoveNoveAccessibilityService.extrairFormaPagamento99(texto: String): String = when {
    texto.contains("pix", ignoreCase = true)      -> "PIX"
    texto.contains("dinheiro", ignoreCase = true) -> "Dinheiro"
    texto.contains("cartão", ignoreCase = true) ||
    texto.contains("cartao", ignoreCase = true)   -> "Cartão"
    else                                           -> ""
}

/**
 * Verifica se o texto da tela corresponde ao padrão de oferta da 99.
 * Usado para diferenciar de outras telas do próprio app (mapa, corrida em
 * andamento, etc) antes de tentar extrair dados de oferta.
 */
internal fun NoveNoveAccessibilityService.ehTela99DeOferta(texto: String): Boolean {
    val temValor = texto.contains("r$", ignoreCase = true)
    val temTipo  = Regex("""(moto|carro|99pop|99x)""", RegexOption.IGNORE_CASE).containsMatchIn(texto)
    val temTempoKm = Regex("""\d+\s*min.*\d+[,.]\d+\s*km""", RegexOption.IGNORE_CASE).containsMatchIn(texto)
    return temValor && (temTipo || temTempoKm)
}
