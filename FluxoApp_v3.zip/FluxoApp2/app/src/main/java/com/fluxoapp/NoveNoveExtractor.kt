package com.fluxoapp

import android.view.accessibility.AccessibilityNodeInfo

/**
 * NoveNoveExtractor — FluxoApp
 *
 * Extração de dados da tela do app 99:
 *   - Valor da oferta (ex: R$ 5,30)
 *   - Km da oferta (ex: 2,7 km)
 *   - Tempo de chegada (ex: 5 min)
 *   - Tipo de veículo (Moto, Carro, etc)
 *   - Nome do cliente (quando disponível)
 */

internal fun MaximAccessibilityService.extrairValor99(texto: String): Float? {
    // 99 mostra: "R$ 5,30" ou "R$5,30"
    val regex = Regex("""r\$\s*([0-9]+[,.][0-9]{2})""", RegexOption.IGNORE_CASE)
    return regex.find(texto)
        ?.groupValues?.get(1)
        ?.replace(",", ".")
        ?.toFloatOrNull()
        ?.takeIf { it >= 1f }
}

internal fun MaximAccessibilityService.extrairKm99(texto: String): Float? {
    // 99 mostra: "2,7 km" ou "2.7 km"
    // Pode haver múltiplos números de km (origem e destino)
    // Pega o primeiro valor encontrado
    val regex = Regex("""([0-9]+[,.][0-9]+)\s*km""", RegexOption.IGNORE_CASE)
    val valores = regex.findAll(texto)
        .mapNotNull { it.groupValues[1].replace(",", ".").toFloatOrNull() }
        .filter { it > 0f }
        .toList()

    return if (valores.size >= 2) {
        valores[0] + valores[1]  // origem + destino
    } else if (valores.size == 1) {
        valores[0]
    } else {
        null
    }
}

internal fun MaximAccessibilityService.extrairTempo99(texto: String): String {
    // 99 mostra: "5 min" ou "5min"
    val regex = Regex("""(\d+)\s*min""", RegexOption.IGNORE_CASE)
    return regex.find(texto)?.let { "${"$"}{it.groupValues[1]} min" } ?: ""
}

internal fun MaximAccessibilityService.extrairTipo99(texto: String): String {
    // 99 mostra: "Moto", "Carro", "X", etc
    val regex = Regex("""(Moto|Carro|X|UberX|uberx|carro|moto)""", RegexOption.IGNORE_CASE)
    return regex.find(texto)?.value ?: "Desconhecido"
}

internal fun MaximAccessibilityService.extrairCliente99(texto: String): String? {
    // 99 às vezes mostra nome do cliente na notificação
    // Padrão pode variar, então é opcional
    val regex = Regex("""Cliente:\s*([A-Za-zÀ-ÿ\s]+)""", RegexOption.IGNORE_CASE)
    return regex.find(texto)?.groupValues?.get(1)?.trim()
}

/**
 * Verifica se o texto é de uma corrida da 99.
 * Procura por palavras-chave características do app 99.
 */
internal fun MaximAccessibilityService.eh99(texto: String): Boolean {
    val indicadores = listOf(
        "moto", "carro", "x", "uberx",
        "tarifa base", "dinâmica",
        "99pop", "99x"
    )
    return indicadores.any { texto.contains(it, ignoreCase = true) } &&
           texto.contains("r$", ignoreCase = true)
}
