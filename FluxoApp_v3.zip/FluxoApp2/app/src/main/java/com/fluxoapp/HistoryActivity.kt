package com.fluxoapp

import android.app.DatePickerDialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class HistoryActivity : AppCompatActivity() {
    private lateinit var db: DatabaseHelper
    private lateinit var prefs: android.content.SharedPreferences
    private var corridasAtuais: List<Corrida> = emptyList()
    private val expandidoSet = mutableSetOf<Int>()

    private var modoAtual = "dia"
    private val calNav    = Calendar.getInstance()

    private val sdfDiaCurto = SimpleDateFormat("dd/MM EEE", Locale("pt", "BR"))
    private val sdfDiaLongo = SimpleDateFormat("dd/MM/yyyy EEE", Locale("pt", "BR"))
    private val sdfSemana   = SimpleDateFormat("dd/MM", Locale("pt", "BR"))
    private val sdfMes      = SimpleDateFormat("MMMM yyyy", Locale("pt", "BR"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeSelector.aplicar(this)
        setContentView(R.layout.activity_history)
        db    = DatabaseHelper(this)
        prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        aplicarTema()
        aplicarTemaGlobal()
        configurarBotoes()
        atualizarChips()
        carregarPeriodoAtual()
    }

    // ── BOTÕES ────────────────────────────────────────────────
    private fun configurarBotoes() {
        findViewById<ImageButton>(R.id.btnVoltar).setOnClickListener { finish() }

        // Botão de busca
        findViewById<ImageButton>(R.id.btnBuscar)?.setOnClickListener { toggleBusca() }

        // Campo de busca
        findViewById<android.widget.EditText>(R.id.etBusca)?.apply {
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) { executarBusca(s.toString()) }
            })
        }

        findViewById<Button>(R.id.chipDia)?.setOnClickListener    { mudarModo("dia")    }
        findViewById<Button>(R.id.chipSemana)?.setOnClickListener { mudarModo("semana") }
        findViewById<Button>(R.id.chipMes)?.setOnClickListener    { mudarModo("mes")    }
        findViewById<Button>(R.id.chipAno)?.setOnClickListener    { mudarModo("ano")    }

        findViewById<ImageButton>(R.id.btnNavAnterior)?.setOnClickListener { navegar(-1) }
        findViewById<ImageButton>(R.id.btnNavProximo)?.setOnClickListener  { navegar(+1) }

        // Clique longo na label → abrir calendário para escolher qualquer data
        findViewById<TextView>(R.id.tvNavLabel)?.setOnLongClickListener {
            abrirCalendario(); true
        }
    }

    // ── MODO ──────────────────────────────────────────────────
    private fun mudarModo(modo: String) {
        modoAtual = modo
        if (modo == "dia") calNav.time = Date() // volta para hoje ao clicar em DIA
        atualizarChips()
        carregarPeriodoAtual()
    }

    // ── NAVEGAR ───────────────────────────────────────────────
    private fun navegar(direcao: Int) {
        when (modoAtual) {
            "dia"    -> calNav.add(Calendar.DAY_OF_YEAR, direcao)
            "semana" -> calNav.add(Calendar.WEEK_OF_YEAR, direcao)
            "mes"    -> calNav.add(Calendar.MONTH, direcao)
            "ano"    -> calNav.add(Calendar.YEAR, direcao)
        }
        carregarPeriodoAtual()
    }

    // ── CARREGAR PERÍODO ──────────────────────────────────────
    private fun carregarPeriodoAtual() {
        val hoje  = Calendar.getInstance()
        val ontem = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }

        val corridas: List<Corrida>
        val label: String
        var ehPeriodoAtual = false

        when (modoAtual) {
            "dia" -> {
                corridas = db.buscarDia(
                    calNav.get(Calendar.YEAR),
                    calNav.get(Calendar.MONTH),
                    calNav.get(Calendar.DAY_OF_MONTH)
                )
                label = when {
                    isMesmoDia(calNav, hoje)  -> "HOJE · ${sdfDiaCurto.format(calNav.time).uppercase()}"
                    isMesmoDia(calNav, ontem) -> "ONTEM · ${sdfDiaCurto.format(calNav.time).uppercase()}"
                    else                      -> sdfDiaLongo.format(calNav.time).uppercase()
                }
                ehPeriodoAtual = isMesmoDia(calNav, hoje)
            }
            "semana" -> {
                val ini = calNav.clone() as Calendar
                ini.set(Calendar.DAY_OF_WEEK, ini.firstDayOfWeek)
                ini.set(Calendar.HOUR_OF_DAY, 0); ini.set(Calendar.MINUTE, 0)
                ini.set(Calendar.SECOND, 0);      ini.set(Calendar.MILLISECOND, 0)
                val fim = ini.clone() as Calendar
                fim.add(Calendar.DAY_OF_YEAR, 6)
                fim.set(Calendar.HOUR_OF_DAY, 23); fim.set(Calendar.MINUTE, 59)
                fim.set(Calendar.SECOND, 59)
                corridas = db.buscarPorPeriodo(ini.timeInMillis, fim.timeInMillis)
                label = "${sdfSemana.format(ini.time)} – ${sdfSemana.format(fim.time)}"
                ehPeriodoAtual = calNav.get(Calendar.WEEK_OF_YEAR) == hoje.get(Calendar.WEEK_OF_YEAR)
                              && calNav.get(Calendar.YEAR) == hoje.get(Calendar.YEAR)
            }
            "mes" -> {
                corridas = db.buscarMes(calNav.get(Calendar.MONTH), calNav.get(Calendar.YEAR))
                label = sdfMes.format(calNav.time).uppercase()
                ehPeriodoAtual = calNav.get(Calendar.MONTH) == hoje.get(Calendar.MONTH)
                              && calNav.get(Calendar.YEAR)  == hoje.get(Calendar.YEAR)
            }
            "ano" -> {
                corridas = db.buscarAno(calNav.get(Calendar.YEAR))
                label = calNav.get(Calendar.YEAR).toString()
                ehPeriodoAtual = calNav.get(Calendar.YEAR) == hoje.get(Calendar.YEAR)
            }
            else -> { corridas = emptyList(); label = "" }
        }

        // Desabilitar seta "próximo" se já está no período atual
        try {
            val btn = findViewById<ImageButton>(R.id.btnNavProximo)
            btn?.alpha    = if (ehPeriodoAtual) 0.3f else 1.0f
            btn?.isEnabled = !ehPeriodoAtual
        } catch (_: Throwable) {}

        exibir(corridas, label)
    }

    private fun isMesmoDia(a: Calendar, b: Calendar) =
        a.get(Calendar.YEAR)        == b.get(Calendar.YEAR) &&
        a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)

    // ── CALENDÁRIO (clique longo) ─────────────────────────────
    private fun abrirCalendario() {
        DatePickerDialog(this, { _, ano, mes, dia ->
            calNav.set(ano, mes, dia)
            modoAtual = "dia"
            atualizarChips()
            carregarPeriodoAtual()
        },
        calNav.get(Calendar.YEAR),
        calNav.get(Calendar.MONTH),
        calNav.get(Calendar.DAY_OF_MONTH)).show()
    }

    // ── CHIPS VISUAIS ─────────────────────────────────────────
    private fun atualizarChips() {
        val accent = ThemeHelper.cor("accent_gold", prefs)
        val bgDark = ThemeHelper.cor("bg_dark", prefs)
        val dp     = resources.displayMetrics.density

        mapOf(R.id.chipDia to "dia", R.id.chipSemana to "semana",
              R.id.chipMes to "mes", R.id.chipAno to "ano"
        ).forEach { (id, modo) ->
            try {
                val btn = findViewById<Button>(id) ?: return@forEach
                if (modo == modoAtual) {
                    btn.background = GradientDrawable().apply {
                        setColor(accent); cornerRadius = 8f * dp
                    }
                    btn.setTextColor(bgDark)
                } else {
                    btn.background = GradientDrawable().apply {
                        setColor(Color.TRANSPARENT); cornerRadius = 8f * dp
                        setStroke((1.5f * dp).toInt(), accent)
                    }
                    btn.setTextColor(accent)
                }
            } catch (_: Throwable) {}
        }
    }

    // ── EXIBIR CORRIDAS ───────────────────────────────────────
    private fun exibir(corridas: List<Corrida>, label: String) {
        corridasAtuais = corridas
        expandidoSet.clear()

        val p      = prefs
        val accent = ThemeHelper.cor("accent_gold", p)
        val txtW   = ThemeHelper.cor("text_white",  p)
        val txtG   = ThemeHelper.cor("text_gray",   p)
        val bgCard = ThemeHelper.cor("bg_card",     p)
        val border = ThemeHelper.cor("border",      p)
        val dp     = resources.displayMetrics.density

        // Label de navegação
        try { findViewById<TextView>(R.id.tvNavLabel)?.apply {
            text = label; setTextColor(accent)
        }} catch (_: Throwable) {}

        // Resumo
        val total = corridas.sumOf { it.valor.toDouble() }
        val qtd   = corridas.size
        val km    = corridas.sumOf { it.kmTotal.toDouble() }
        val media = if (qtd > 0) total / qtd else 0.0

        val resumoTxt = if (qtd == 0) "Nenhuma corrida neste período." else buildString {
            append("$qtd corrida${if (qtd != 1) "s" else ""}   ·   ")
            append("R$ ${"%.2f".format(total)}   ·   ")
            append("${"%.1f".format(km)} km\n")
            append("Média: R$ ${"%.2f".format(media)} por corrida")
        }
        try { findViewById<TextView>(R.id.tvResumo)?.apply {
            text = resumoTxt; setTextColor(txtW); setBackgroundColor(bgCard)
        }} catch (_: Throwable) {}

        // Lista
        val listView = try { findViewById<ListView>(R.id.listViewCorridas) } catch (_: Throwable) { null } ?: return
        listView.adapter = CorridaAdapter(corridas)
        listView.setBackgroundColor(ThemeHelper.cor("bg_dark", p))
    }

    // ── ADAPTER ───────────────────────────────────────────────
    inner class CorridaAdapter(private val lista: List<Corrida>) : BaseAdapter() {
        override fun getCount() = lista.size
        override fun getItem(pos: Int) = lista[pos]
        override fun getItemId(pos: Int) = lista[pos].id

        override fun getView(pos: Int, convertView: View?, parent: ViewGroup): View {
            val p       = prefs
            val accent  = ThemeHelper.cor("accent_gold", p)
            val txtW    = ThemeHelper.cor("text_white",  p)
            val txtG    = ThemeHelper.cor("text_gray",   p)
            val bgCard  = ThemeHelper.cor("bg_card",     p)
            val border  = ThemeHelper.cor("border",      p)
            val green   = ThemeHelper.cor("accent_green", p)
            val red     = ThemeHelper.cor("accent_red",   p)
            val dp      = resources.displayMetrics.density
            val corrida = lista[pos]
            val expandido = expandidoSet.contains(pos)

            val view = convertView ?: LayoutInflater.from(this@HistoryActivity)
                .inflate(R.layout.item_corrida, parent, false)

            view.background = GradientDrawable().apply {
                setColor(bgCard); cornerRadius = 10f * dp
                setStroke((1f * dp).toInt(), border)
            }

            try {
                // Ícone de status (vale a pena ou não)
                view.findViewById<TextView>(R.id.tvStatusIcon)?.apply {
                    text = if (corrida.valeAPena) "✓" else "✗"
                    setTextColor(if (corrida.valeAPena) green else red)
                }

                // Hora + Valor
                val orig = corrida.origem.replace("🏠 ","").replace("🏁 ","").trim()
                val dest = corrida.destino.replace("🏠 ","").replace("🏁 ","").trim()
                view.findViewById<TextView>(R.id.tvHoraValor)?.apply {
                    text = "${corrida.hora}   R$ ${"%.2f".format(corrida.valor)}"
                    setTextColor(accent)
                }

                // Ganho/km resumido
                view.findViewById<TextView>(R.id.tvGanhoKmResumido)?.apply {
                    text = "${"%.1f".format(corrida.kmTotal)}km · R$${"%.2f".format(corrida.ganhoPorKm)}/km"
                    setTextColor(txtG)
                }

                // Rota resumida
                view.findViewById<TextView>(R.id.tvRota)?.apply {
                    text = if (orig.isNotBlank()) orig.take(40) + if (orig.length > 40) "…" else "" else "Sem origem"
                    setTextColor(txtG)
                }

                // Área expandida
                val layoutExpandido = view.findViewById<View>(R.id.layoutExpandido)
                layoutExpandido?.visibility = if (expandido) View.VISIBLE else View.GONE

                if (expandido) {
                    view.findViewById<TextView>(R.id.tvValorDetalhe)?.apply {
                        text = "R$ ${"%.2f".format(corrida.valor)}"; setTextColor(txtW)
                    }
                    view.findViewById<TextView>(R.id.tvKmDetalhe)?.apply {
                        text = "${"%.2f".format(corrida.kmTotal)} km"; setTextColor(txtW)
                    }
                    view.findViewById<TextView>(R.id.tvGanhoKmDetalhe)?.apply {
                        text = "R$ ${"%.2f".format(corrida.ganhoPorKm)}/km"; setTextColor(txtW)
                    }
                    view.findViewById<TextView>(R.id.tvOrigemDetalhe)?.apply {
                        text = orig.ifBlank { "—" }; setTextColor(txtW)
                    }
                    view.findViewById<TextView>(R.id.tvDestinoDetalhe)?.apply {
                        text = dest.ifBlank { "—" }; setTextColor(txtW)
                    }
                    view.findViewById<TextView>(R.id.tvPagamentoDetalhe)?.apply {
                        text = corrida.formaPagamento.ifBlank { "—" }; setTextColor(txtW)
                    }
                    view.findViewById<TextView>(R.id.tvTempoDetalhe)?.apply {
                        text = corrida.tempoExecucao.ifBlank { "—" }; setTextColor(txtW)
                    }
                    val horario = buildString {
                        if (corrida.horaInicio.isNotBlank()) append("${corrida.horaInicio} → ")
                        if (corrida.horaFim.isNotBlank()) append(corrida.horaFim)
                    }
                    view.findViewById<TextView>(R.id.tvHorarioDetalhe)?.apply {
                        text = horario.ifBlank { "—" }; setTextColor(txtW)
                    }
                    view.findViewById<TextView>(R.id.tvPassageiro)?.apply {
                        text = corrida.passageiro.ifBlank { "—" }; setTextColor(accent)
                    }
                    view.findViewById<Button>(R.id.btnApagarCorrida)?.setOnClickListener {
                        android.app.AlertDialog.Builder(this@HistoryActivity)
                            .setTitle("Apagar corrida?")
                            .setMessage("R$ ${"%.2f".format(corrida.valor)} às ${corrida.hora}")
                            .setPositiveButton("Apagar") { _, _ ->
                                db.deletarCorrida(corrida.id)
                                carregarPeriodoAtual()
                            }
                            .setNeutralButton("Editar valor") { _, _ ->
                                mostrarEdicaoRapida(corrida)
                            }
                            .setNegativeButton("Cancelar", null)
                            .show()
                    }
                }
            } catch (_: Throwable) {}

            // Toque → expandir/recolher
            view.setOnClickListener {
                if (expandidoSet.contains(pos)) expandidoSet.remove(pos)
                else expandidoSet.add(pos)
                notifyDataSetChanged()
            }

            // Pressão longa → menu de ações (editar / apagar)
            view.setOnLongClickListener {
                mostrarMenuAcoesCorrida(corrida)
                true
            }

            return view
        }
    }

    // ── MENU DE AÇÕES DA CORRIDA (pressão longa) ────────────────
    private fun mostrarMenuAcoesCorrida(corrida: Corrida) {
        val p      = prefs
        val accent = ThemeHelper.cor("accent_gold", p)
        val bgCard = ThemeHelper.cor("bg_card", p)
        val bgDark = ThemeHelper.cor("bg_dark", p)
        val txtW   = ThemeHelper.cor("text_white", p)
        val txtG   = ThemeHelper.cor("text_gray", p)
        val red    = ThemeHelper.cor("accent_red", p)
        val dp     = resources.displayMetrics.density
        val green  = ThemeHelper.cor("accent_green", p)

        // Container principal
        val root = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(bgCard); cornerRadius = 20f * dp
                setStroke((1.5f * dp).toInt(), accent)
            }
            clipToOutline = true
        }

        // Header colorido com info da corrida
        val headerBg = android.graphics.Color.argb(
            220, android.graphics.Color.red(accent),
            android.graphics.Color.green(accent), android.graphics.Color.blue(accent))
        val header = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.argb(60,
                android.graphics.Color.red(accent),
                android.graphics.Color.green(accent),
                android.graphics.Color.blue(accent)))
            setPadding((20*dp).toInt(), (16*dp).toInt(), (20*dp).toInt(), (16*dp).toInt())
        }

        // Valor grande
        header.addView(android.widget.TextView(this).apply {
            text = "R$ ${"%.2f".format(corrida.valor)}"
            textSize = 28f; setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(accent); gravity = android.view.Gravity.CENTER
        })
        // Hora e data
        header.addView(android.widget.TextView(this).apply {
            text = "${corrida.hora}  ·  ${corrida.data}"
            textSize = 13f; setTextColor(txtG)
            gravity = android.view.Gravity.CENTER
            setPadding(0, (4*dp).toInt(), 0, 0)
        })
        // Origem se disponível
        if (corrida.origem.isNotBlank()) {
            header.addView(android.widget.TextView(this).apply {
                text = corrida.origem.replace("🏠 ", "").take(45)
                textSize = 11f; setTextColor(txtG)
                gravity = android.view.Gravity.CENTER
                setPadding(0, (2*dp).toInt(), 0, 0)
            })
        }
        // Stats km e R$/km
        val statsRow = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER
            setPadding(0, (8*dp).toInt(), 0, 0)
        }
        val kmStr = if (corrida.kmTotal > 0) "${"%.1f".format(corrida.kmTotal)} km" else "—"
        val gkmStr = if (corrida.ganhoPorKm > 0) "R$${"%.2f".format(corrida.ganhoPorKm)}/km" else "—"
        for (txt in listOf(kmStr, "  ·  ", gkmStr)) {
            statsRow.addView(android.widget.TextView(this).apply {
                text = txt; textSize = 12f
                setTextColor(if (txt.contains("km") || txt.contains("R$")) txtW else txtG)
            })
        }
        header.addView(statsRow)
        root.addView(header)

        // Divider
        root.addView(android.view.View(this).apply {
            setBackgroundColor(android.graphics.Color.argb(40,
                android.graphics.Color.red(accent),
                android.graphics.Color.green(accent),
                android.graphics.Color.blue(accent)))
            layoutParams = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, (1*dp).toInt())
        })

        // Botão Editar
        fun btnAcao(texto: String, icone: String, cor: Int): android.widget.LinearLayout {
            return android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding((20*dp).toInt(), (16*dp).toInt(), (20*dp).toInt(), (16*dp).toInt())
                isClickable = true
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(android.graphics.Color.TRANSPARENT)
                    cornerRadius = 0f
                }
                addView(android.widget.TextView(this@HistoryActivity).apply {
                    text = icone; textSize = 20f
                    setPadding(0, 0, (12*dp).toInt(), 0)
                })
                addView(android.widget.TextView(this@HistoryActivity).apply {
                    text = texto; textSize = 15f
                    setTypeface(null, android.graphics.Typeface.BOLD)
                    setTextColor(cor)
                })
            }
        }

        val btnEditar = btnAcao("Editar valor", "✏️", accent)
        val btnApagar = btnAcao("Apagar corrida", "🗑️", red)
        root.addView(btnEditar)

        // Divider fino
        root.addView(android.view.View(this).apply {
            setBackgroundColor(android.graphics.Color.argb(25,
                android.graphics.Color.red(txtG),
                android.graphics.Color.green(txtG),
                android.graphics.Color.blue(txtG)))
            layoutParams = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, (1*dp).toInt()).apply {
                setMargins((20*dp).toInt(), 0, (20*dp).toInt(), 0)
            }
        })
        root.addView(btnApagar)

        val dialog = android.app.AlertDialog.Builder(this)
            .setView(root)
            .create()

        dialog.window?.apply {
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT))
        }

        btnEditar.setOnClickListener {
            dialog.dismiss()
            mostrarEdicaoRapida(corrida)
        }
        btnApagar.setOnClickListener {
            dialog.dismiss()
            mostrarConfirmarApagar(corrida)
        }
        dialog.show()
    }

    // ── CONFIRMAR APAGAR ──────────────────────────────────────
    private fun mostrarConfirmarApagar(corrida: Corrida) {
        val p      = prefs
        val accent = ThemeHelper.cor("accent_gold", p)
        val bgCard = ThemeHelper.cor("bg_card", p)
        val txtW   = ThemeHelper.cor("text_white", p)
        val txtG   = ThemeHelper.cor("text_gray", p)
        val red    = ThemeHelper.cor("accent_red", p)
        val dp     = resources.displayMetrics.density

        val root = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(bgCard); cornerRadius = 20f * dp
                setStroke((1.5f * dp).toInt(), red)
            }
            setPadding((24*dp).toInt(), (24*dp).toInt(), (24*dp).toInt(), (20*dp).toInt())
        }

        root.addView(android.widget.TextView(this).apply {
            text = "🗑️  Apagar corrida?"
            textSize = 18f; setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(red); gravity = android.view.Gravity.CENTER
        })
        root.addView(android.widget.TextView(this).apply {
            text = "R$ ${"%.2f".format(corrida.valor)}  ·  ${corrida.hora}  ·  ${corrida.data}"
            textSize = 13f; setTextColor(txtG)
            gravity = android.view.Gravity.CENTER
            setPadding(0, (8*dp).toInt(), 0, (20*dp).toInt())
        })

        val btnsRow = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER
        }
        fun btnRow(texto: String, cor: Int, fill: Boolean): android.widget.TextView {
            return android.widget.TextView(this).apply {
                text = texto; textSize = 14f
                setTypeface(null, android.graphics.Typeface.BOLD)
                gravity = android.view.Gravity.CENTER
                layoutParams = android.widget.LinearLayout.LayoutParams(0,
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    setMargins((4*dp).toInt(), 0, (4*dp).toInt(), 0)
                }
                setPadding((12*dp).toInt(), (12*dp).toInt(), (12*dp).toInt(), (12*dp).toInt())
                background = android.graphics.drawable.GradientDrawable().apply {
                    if (fill) setColor(cor) else setColor(android.graphics.Color.TRANSPARENT)
                    cornerRadius = 10f * dp
                    if (!fill) setStroke((1.5f * dp).toInt(), cor)
                }
                setTextColor(if (fill) android.graphics.Color.WHITE else cor)
            }
        }
        val btnCancelar = btnRow("Cancelar", accent, false)
        val btnApagar   = btnRow("Apagar", red, true)
        btnsRow.addView(btnCancelar); btnsRow.addView(btnApagar)
        root.addView(btnsRow)

        val dialog = android.app.AlertDialog.Builder(this)
            .setView(root).create()
        dialog.window?.setBackgroundDrawable(
            android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT))
        btnCancelar.setOnClickListener { dialog.dismiss() }
        btnApagar.setOnClickListener {
            dialog.dismiss()
            db.deletarCorrida(corrida.id)
            carregarPeriodoAtual()
            FluxoToast.sucesso(this, "Corrida apagada")
        }
        dialog.show()
    }

    // ── EDIÇÃO RÁPIDA ─────────────────────────────────────────
    private fun mostrarEdicaoRapida(corrida: Corrida) {
        val p      = prefs
        val accent = ThemeHelper.cor("accent_gold", p)
        val bgCard = ThemeHelper.cor("bg_card", p)
        val txtW   = ThemeHelper.cor("text_white", p)
        val txtG   = ThemeHelper.cor("text_gray", p)
        val dp     = resources.displayMetrics.density

        val root = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(bgCard); cornerRadius = 20f * dp
                setStroke((1.5f * dp).toInt(), accent)
            }
            setPadding((24*dp).toInt(), (24*dp).toInt(), (24*dp).toInt(), (20*dp).toInt())
        }

        // Título
        root.addView(android.widget.TextView(this).apply {
            text = "✏️  Editar valor"
            textSize = 18f; setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(accent); gravity = android.view.Gravity.CENTER
        })

        // Info da corrida
        root.addView(android.widget.TextView(this).apply {
            text = "${corrida.hora}  ·  ${corrida.data}"
            textSize = 12f; setTextColor(txtG); gravity = android.view.Gravity.CENTER
            setPadding(0, (6*dp).toInt(), 0, (4*dp).toInt())
        })
        if (corrida.origem.isNotBlank()) {
            root.addView(android.widget.TextView(this).apply {
                text = corrida.origem.replace("🏠 ","").take(45)
                textSize = 11f; setTextColor(txtG); gravity = android.view.Gravity.CENTER
                setPadding(0, 0, 0, (12*dp).toInt())
            })
        }

        // Campo de valor com destaque
        val etContainer = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(android.graphics.Color.argb(30,
                    android.graphics.Color.red(accent),
                    android.graphics.Color.green(accent),
                    android.graphics.Color.blue(accent)))
                cornerRadius = 12f * dp
                setStroke((1f * dp).toInt(), accent)
            }
            setPadding((16*dp).toInt(), (4*dp).toInt(), (16*dp).toInt(), (4*dp).toInt())
            layoutParams = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                setMargins(0, 0, 0, (20*dp).toInt())
            }
        }
        etContainer.addView(android.widget.TextView(this).apply {
            text = "R$"; textSize = 20f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(accent)
            setPadding(0, 0, (8*dp).toInt(), 0)
        })
        val et = android.widget.EditText(this).apply {
            setText("%.2f".format(corrida.valor)); selectAll()
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                        android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            textSize = 26f; setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(txtW); setBackgroundColor(android.graphics.Color.TRANSPARENT)
            gravity = android.view.Gravity.CENTER
            layoutParams = android.widget.LinearLayout.LayoutParams(0,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        etContainer.addView(et)
        root.addView(etContainer)

        // Botões
        val btnsRow = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER
        }
        fun btnAcao(texto: String, fill: Boolean, cor: Int): android.widget.TextView {
            return android.widget.TextView(this).apply {
                text = texto; textSize = 14f
                setTypeface(null, android.graphics.Typeface.BOLD)
                gravity = android.view.Gravity.CENTER
                layoutParams = android.widget.LinearLayout.LayoutParams(0,
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    setMargins((4*dp).toInt(), 0, (4*dp).toInt(), 0)
                }
                setPadding((12*dp).toInt(), (12*dp).toInt(), (12*dp).toInt(), (12*dp).toInt())
                background = android.graphics.drawable.GradientDrawable().apply {
                    if (fill) setColor(cor) else setColor(android.graphics.Color.TRANSPARENT)
                    cornerRadius = 10f * dp
                    if (!fill) setStroke((1.5f * dp).toInt(), cor)
                }
                setTextColor(if (fill) android.graphics.Color.parseColor("#001A00") else cor)
            }
        }
        val btnCancelar = btnAcao("Cancelar", false, accent)
        val btnSalvar   = btnAcao("Salvar ✓", true, accent)
        btnsRow.addView(btnCancelar); btnsRow.addView(btnSalvar)
        root.addView(btnsRow)

        val dialog = android.app.AlertDialog.Builder(this)
            .setView(root).create()
        dialog.window?.setBackgroundDrawable(
            android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT))
        btnCancelar.setOnClickListener { dialog.dismiss() }
        btnSalvar.setOnClickListener {
            val novoValor = et.text.toString().replace(",", ".").toFloatOrNull()
            if (novoValor != null && novoValor > 0f) {
                dialog.dismiss()
                db.editarCorrida(corrida.id, novoValor)
                carregarPeriodoAtual()
                FluxoToast.sucesso(this, "Valor atualizado → R$${"%.2f".format(novoValor)}")
            } else {
                FluxoToast.erro(this, "Valor inválido")
            }
        }
        dialog.show()
        et.requestFocus()
        val imm = getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
        imm.showSoftInput(et, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
    }

    // ── BUSCA ─────────────────────────────────────────────────
    private var modosBusca = false
    private val handlerBusca = android.os.Handler(android.os.Looper.getMainLooper())
    private var runnerBusca: Runnable? = null

    private fun toggleBusca() {
        modosBusca = !modosBusca
        val layoutBusca = try { findViewById<android.view.View>(R.id.layoutBusca) } catch (_: Throwable) { null }
        val et          = try { findViewById<android.widget.EditText>(R.id.etBusca) } catch (_: Throwable) { null }
        val accent      = ThemeHelper.cor("accent_gold", prefs)

        if (modosBusca) {
            layoutBusca?.visibility = android.view.View.VISIBLE
            et?.requestFocus()
            val imm = getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
            imm.showSoftInput(et, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
        } else {
            layoutBusca?.visibility = android.view.View.GONE
            et?.setText("")
            val imm = getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
            imm.hideSoftInputFromWindow(et?.windowToken, 0)
            carregarPeriodoAtual() // volta ao período normal
        }
    }

    private fun executarBusca(query: String) {
        // FIX 9: debounce 300ms + query em background thread
        runnerBusca?.let { handlerBusca.removeCallbacks(it) }
        if (query.length < 2) { carregarPeriodoAtual(); return }
        val runner = Runnable {
            Thread {
                val q = query.lowercase()
                val resultado = try {
                    db.buscarTodas().filter { c ->
                        c.origem.lowercase().contains(q) ||
                        c.destino.lowercase().contains(q) ||
                        c.passageiro.lowercase().contains(q) ||
                        c.formaPagamento.lowercase().contains(q) ||
                        c.hora.contains(q) || c.data.contains(q) ||
                        "%.2f".format(c.valor).contains(q)
                    }
                } catch (_: Throwable) { emptyList() }
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    val n = resultado.size
                    exibir(resultado, "$n resultado${if (n != 1) "s" else ""} para \"$query\"")
                }
            }.start()
        }
        runnerBusca = runner
        handlerBusca.postDelayed(runner, 300L)
    }


    // ── TEMA ──────────────────────────────────────────────────
    private fun aplicarTema() {
        val p      = prefs
        val bg     = ThemeHelper.cor("bg_dark",     p)
        val bgCard = ThemeHelper.cor("bg_card",     p)
        val accent = ThemeHelper.cor("accent_gold", p)
        val txtW   = ThemeHelper.cor("text_white",  p)
        val border = ThemeHelper.cor("border",      p)
        val toolbar= ThemeHelper.cor("toolbar",     p)
        val dp     = resources.displayMetrics.density

        try { findViewById<android.view.View>(R.id.rootLayoutHistory)?.setBackgroundColor(bg) } catch (_: Throwable) {}
        try { findViewById<ImageButton>(R.id.btnVoltar)?.setColorFilter(accent) } catch (_: Throwable) {}
        try { findViewById<ImageButton>(R.id.btnNavAnterior)?.setColorFilter(accent) } catch (_: Throwable) {}
        try { findViewById<ImageButton>(R.id.btnNavProximo)?.setColorFilter(accent)  } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvNavLabel)?.setTextColor(accent) } catch (_: Throwable) {}

        // Fundo das barras de chips e navegação
        for (id in listOf(R.id.rootLayoutHistory)) {
            try { findViewById<android.view.View>(id)?.setBackgroundColor(bg) } catch (_: Throwable) {}
        }
    }
}
