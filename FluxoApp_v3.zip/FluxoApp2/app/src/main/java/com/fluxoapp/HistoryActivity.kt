package com.fluxoapp

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class HistoryActivity : AppCompatActivity() {
    private lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)
        db = DatabaseHelper(this)
        findViewById<ImageButton>(R.id.btnVoltar).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnHoje).setOnClickListener { exibir(db.buscarHoje(), "HOJE") }
        findViewById<Button>(R.id.btnSemana).setOnClickListener { exibir(db.buscarSemana(), "SEMANA") }
        findViewById<Button>(R.id.btnMes).setOnClickListener {
            val c = Calendar.getInstance()
            exibir(db.buscarMes(c.get(Calendar.MONTH), c.get(Calendar.YEAR)), "MÊS")
        }
        findViewById<Button>(R.id.btnAno).setOnClickListener {
            exibir(db.buscarAno(Calendar.getInstance().get(Calendar.YEAR)), "ANO")
        }
        findViewById<Button>(R.id.btnPersonalizado).setOnClickListener { abrirPersonalizado() }
        exibir(db.buscarHoje(), "HOJE")
    }

    private fun abrirPersonalizado() {
        val cal = Calendar.getInstance()
        DatePickerDialog(this, { _, a, m, d ->
            val inicio = Calendar.getInstance().apply { set(a,m,d,0,0,0); set(Calendar.MILLISECOND,0) }.timeInMillis
            DatePickerDialog(this, { _, a2, m2, d2 ->
                val fim = Calendar.getInstance().apply { set(a2,m2,d2,23,59,59) }.timeInMillis
                exibir(db.buscarPorPeriodo(inicio, fim), "PERSONALIZADO")
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun exibir(corridas: List<Corrida>, titulo: String) {
        findViewById<TextView>(R.id.tvTitulo).text = titulo
        val r = db.resumo(corridas)
        findViewById<TextView>(R.id.tvResumo).text =
            "💰 Total: R$ ${"%.2f".format(r["total"])}\n" +
            "🚗 Corridas: ${(r["corridas"]?:0f).toInt()}\n" +
            "📏 KM: ${"%.1f".format(r["km_total"])} km\n" +
            "⚡ Média/km: R$ ${"%.2f".format(r["media_km"])}\n" +
            "📊 Média/corrida: R$ ${"%.2f".format(r["media_corrida"])}"

        val itens = corridas.map { c ->
            val e = if (c.valeAPena) "✅" else "❌"
            val d = if (c.destino.isNotEmpty()) "\n📍 ${c.destino.take(35)}" else ""
            val p = if (c.formaPagamento.isNotEmpty()) " | ${c.formaPagamento}" else ""
            "$e ${c.hora} — R$ ${"%.2f".format(c.valor)} | ${"%.1f".format(c.kmTotal)}km$p$d"
        }
        findViewById<ListView>(R.id.listViewCorridas).adapter =
            ArrayAdapter(this, android.R.layout.simple_list_item_1, itens)
    }
}
