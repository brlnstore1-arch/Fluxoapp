package com.fluxoapp

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class HistoryActivity : AppCompatActivity() {
    private lateinit var db: DatabaseHelper
    private var corridasAtuais: List<Corrida> = emptyList()
    private var tituloAtual = "HOJE"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)
        db = DatabaseHelper(this)
        aplicarTema()
        findViewById<ImageButton>(R.id.btnVoltar).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnHoje).setOnClickListener { exibir(db.buscarHoje(), "HOJE") }
        findViewById<Button>(R.id.btnSemana).setOnClickListener { exibir(db.buscarSemana(), "SEMANA") }
        findViewById<Button>(R.id.btnMes).setOnClickListener {
            val c = Calendar.getInstance()
            exibir(db.buscarMes(c.get(Calendar.MONTH), c.get(Calendar.YEAR)), "MES")
        }
        findViewById<Button>(R.id.btnAno).setOnClickListener {
            exibir(db.buscarAno(Calendar.getInstance().get(Calendar.YEAR)), "ANO")
        }
        findViewById<Button>(R.id.btnPersonalizado).setOnClickListener { abrirPersonalizado() }
        exibir(db.buscarHoje(), "HOJE")
    }

    private fun aplicarTema() {
        val prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val noturno = ThemeHelper.isModoNoturno(prefs)
        findViewById<View>(R.id.rootLayoutHistory)?.setBackgroundColor(ThemeHelper.cor("bg_dark", noturno))
    }

    private fun abrirPersonalizado() {
        val cal = Calendar.getInstance()
        DatePickerDialog(this, { _, a, m, d ->
            val inicio = Calendar.getInstance().apply { set(a,m,d,0,0,0); set(Calendar.MILLISECOND,0) }.timeInMillis
            DatePickerDialog(this, { _, a2, m2, d2 ->
                val fim = Calendar.getInstance().apply { set(a2,m2,d2,23,59,59) }.timeInMillis
                exibir(db.buscarPorPeriodo(inicio, fim), "PERSONALIZADO")
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun exibir(corridas: List<Corrida>, titulo: String) {
        corridasAtuais = corridas
        tituloAtual = titulo
        val prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val noturno = ThemeHelper.isModoNoturno(prefs)
        val textMain = ThemeHelper.cor("text_white", noturno)
        val textGray = ThemeHelper.cor("text_gray", noturno)
        val bgCard   = ThemeHelper.cor("bg_card", noturno)
        val cyan     = ThemeHelper.cor("accent_cyan", noturno)

        findViewById<TextView>(R.id.tvTitulo).apply {
            text = titulo; setTextColor(cyan)
        }
        val r = db.resumo(corridas)
        findViewById<TextView>(R.id.tvResumo).apply {
            text = "Total: R$ ${"%.2f".format(r["total"])}\n" +
                   "Corridas: ${(r["corridas"]?:0f).toInt()}\n" +
                   "KM: ${"%.1f".format(r["km_total"])} km\n" +
                   "Media/km: R$ ${"%.2f".format(r["media_km"])}\n" +
                   "Media/corrida: R$ ${"%.2f".format(r["media_corrida"])}"
            setTextColor(textMain)
            setBackgroundColor(bgCard)
        }

        val lv = findViewById<ListView>(R.id.listViewCorridas)
        val adapter = object : ArrayAdapter<Corrida>(this, 0, corridas) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val view = convertView ?: LayoutInflater.from(context)
                    .inflate(R.layout.item_corrida, parent, false)
                val c = corridas[position]

                // Linha 1: status + hora + valor + km + pagamento
                val status = if (c.valeAPena) "V" else "X"
                val pag = if (c.formaPagamento.isNotEmpty()) " | ${c.formaPagamento}" else ""
                view.findViewById<TextView>(R.id.itemLinha1).apply {
                    text = "$status  ${c.hora} — R$ ${"%.2f".format(c.valor)} | ${"%.1f".format(c.kmTotal)}km$pag"
                    setTextColor(if (c.valeAPena) Color.parseColor("#00E676") else Color.parseColor("#FF5252"))
                }

                // Linha 2: endereço de PARTIDA (origem)
                val tvOrigem = view.findViewById<TextView>(R.id.itemOrigem)
                if (c.origem.isNotEmpty()) {
                    tvOrigem.text = "De: ${c.origem.take(45)}"
                    tvOrigem.setTextColor(ThemeHelper.cor("accent_cyan", noturno))
                    tvOrigem.visibility = View.VISIBLE
                } else {
                    tvOrigem.visibility = View.GONE
                }

                // Linha 3: endereço de DESTINO
                val tvDestino = view.findViewById<TextView>(R.id.itemDestino)
                if (c.destino.isNotEmpty()) {
                    tvDestino.text = "Para: ${c.destino.take(45)}"
                    tvDestino.setTextColor(textGray)
                    tvDestino.visibility = View.VISIBLE
                } else {
                    tvDestino.visibility = View.GONE
                }

                // Linha 4: dica de segurar
                view.findViewById<TextView>(R.id.itemDica).apply {
                    text = "Segure para apagar"
                    setTextColor(ThemeHelper.cor("border", noturno))
                }

                view.setBackgroundColor(bgCard)
                return view
            }
        }

        lv.adapter = adapter
        lv.setOnItemLongClickListener { _, _, position, _ ->
            val corrida = corridas[position]
            AlertDialog.Builder(this)
                .setTitle("Apagar corrida?")
                .setMessage(
                    "Corrida das ${corrida.hora} — R$ ${"%.2f".format(corrida.valor)}\n\n" +
                    "Essa corrida sera removida do historico.\n" +
                    "Use isso se o passageiro cancelou."
                )
                .setPositiveButton("Apagar") { _, _ ->
                    db.deletarCorrida(corrida.id)
                    Toast.makeText(this, "Corrida apagada!", Toast.LENGTH_SHORT).show()
                    recarregar()
                }
                .setNegativeButton("Cancelar", null)
                .show()
            true
        }
    }

    private fun recarregar() {
        val c = Calendar.getInstance()
        when (tituloAtual) {
            "HOJE" -> exibir(db.buscarHoje(), "HOJE")
            "SEMANA" -> exibir(db.buscarSemana(), "SEMANA")
            "ANO" -> exibir(db.buscarAno(c.get(Calendar.YEAR)), "ANO")
            "MES" -> exibir(db.buscarMes(c.get(Calendar.MONTH), c.get(Calendar.YEAR)), "MES")
            else -> exibir(db.buscarHoje(), "HOJE")
        }
    }
}
