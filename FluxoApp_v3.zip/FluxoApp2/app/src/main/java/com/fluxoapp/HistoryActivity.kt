package com.fluxoapp

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class HistoryActivity : AppCompatActivity() {
    private lateinit var db: DatabaseHelper
    private var corridasAtuais: List<Corrida> = emptyList()
    private var tituloAtual = "HOJE"
    private val expandidoSet = mutableSetOf<Int>() // posições expandidas

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)
        db = DatabaseHelper(this)
        aplicarTema()

        findViewById<ImageButton>(R.id.btnVoltar).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnHoje).setOnClickListener { exibir(db.buscarHoje(), "HOJE") }
        findViewById<Button>(R.id.btnSemana).setOnClickListener { exibir(db.buscarSemana(), "SEMANA") }
        findViewById<Button>(R.id.btnMes).setOnClickListener {
            val c = Calendar.getInstance()
            exibir(db.buscarMes(c.get(Calendar.MONTH), c.get(Calendar.YEAR)), "MES")
        }
        findViewById<Button>(R.id.btnAno).setOnClickListener {
            exibir(db.buscarAno(Calendar.getInstance().get(Calendar.YEAR)), "ANO")
        }
        findViewById<Button>(R.id.btnPersonalizado).setOnClickListener { abrirPersonalizado() }
        exibir(db.buscarHoje(), "HOJE")
    }

    private fun aplicarTema() {
        val prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val noturno = ThemeHelper.isModoNoturno(prefs)
        findViewById<View>(R.id.rootLayoutHistory)?.setBackgroundColor(ThemeHelper.cor("bg_dark", noturno))
    }

    private fun abrirPersonalizado() {
        val cal = Calendar.getInstance()
        DatePickerDialog(this, { _, a, m, d ->
            val inicio = Calendar.getInstance().apply { set(a, m, d, 0, 0, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
            DatePickerDialog(this, { _, a2, m2, d2 ->
                val fim = Calendar.getInstance().apply { set(a2, m2, d2, 23, 59, 59) }.timeInMillis
                exibir(db.buscarPorPeriodo(inicio, fim), "PERSONALIZADO")
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun exibir(corridas: List<Corrida>, titulo: String) {
        corridasAtuais = corridas
        tituloAtual = titulo
        expandidoSet.clear()

        val prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val noturno = ThemeHelper.isModoNoturno(prefs)
        val textMain = ThemeHelper.cor("text_white", noturno)
        val bgCard   = ThemeHelper.cor("bg_card", noturno)
        val cyan     = ThemeHelper.cor("accent_cyan", noturno)

        findViewById<TextView>(R.id.tvTitulo).apply {
            text = titulo; setTextColor(cyan)
        }

        val r = db.resumo(corridas)
        val melhorCorrida = corridas.maxByOrNull { it.valor }
        val melhorTexto = if (melhorCorrida != null) "  Melhor: R$ ${"%.2f".format(melhorCorrida.valor)}" else ""

        findViewById<TextView>(R.id.tvResumo).apply {
            text = "Total: R$ ${"%.2f".format(r["total"])}  |  " +
                   "${(r["corridas"] ?: 0f).toInt()} corridas  |  " +
                   "${"%.1f".format(r["km_total"])} km\n" +
                   "Media/corrida: R$ ${"%.2f".format(r["media_corrida"])}  |  " +
                   "R$ ${"%.2f".format(r["media_km"])}/km$melhorTexto"
            setTextColor(textMain)
            setBackgroundColor(bgCard)
        }

        val lv = findViewById<ListView>(R.id.listViewCorridas)
        lv.adapter = CorridaAdapter(corridas, noturno)
        lv.setOnItemClickListener { _, _, position, _ ->
            if (expandidoSet.contains(position)) expandidoSet.remove(position)
            else expandidoSet.add(position)
            (lv.adapter as CorridaAdapter).notifyDataSetChanged()
        }
    }

    inner class CorridaAdapter(
        private val corridas: List<Corrida>,
        private val noturno: Boolean
    ) : ArrayAdapter<Corrida>(this, 0, corridas) {

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val view = convertView ?: LayoutInflater.from(context)
                .inflate(R.layout.item_corrida, parent, false)

            val c = corridas[position]
            val expandido = expandidoSet.contains(position)

            val bgCard   = ThemeHelper.cor("bg_card", noturno)
            val textMain = ThemeHelper.cor("text_white", noturno)
            val textGray = ThemeHelper.cor("text_gray", noturno)
            val green    = ThemeHelper.cor("accent_green", noturno)
            val red      = ThemeHelper.cor("accent_red", noturno)
            val cyan     = ThemeHelper.cor("accent_cyan", noturno)

            view.setBackgroundColor(bgCard)

            // ── FECHADO ──
            val tvStatusIcon = view.findViewById<TextView>(R.id.tvStatusIcon)
            val corStatus = if (c.valeAPena) green else red
            tvStatusIcon.text = if (c.valeAPena) "V" else "X"
            tvStatusIcon.setTextColor(corStatus)

            val horaPrincipal = if (c.horaInicio.isNotEmpty()) c.horaInicio else c.hora
            view.findViewById<TextView>(R.id.tvHoraValor).apply {
                text = "$horaPrincipal  R$ ${"%.2f".format(c.valor)}"
                setTextColor(corStatus)
            }

            view.findViewById<TextView>(R.id.tvGanhoKmResumido).apply {
                text = "R$ ${"%.2f".format(c.ganhoPorKm)}/km"
                setTextColor(textGray)
            }

            // Linha 1: origem > destino
            val origemCurta = c.origem.substringBefore("(").trim().take(22)
            val destinoCurto = c.destino.substringBefore("(").trim().take(22)
            val rotaTexto = when {
                origemCurta.isNotEmpty() && destinoCurto.isNotEmpty() -> "$origemCurta > $destinoCurto"
                origemCurta.isNotEmpty() -> origemCurta
                else -> c.hora
            }
            view.findViewById<TextView>(R.id.tvRota).apply {
                text = rotaTexto
                setTextColor(textGray)
            }
            // Linha 2: passageiro
            val tvPassFechado = view.findViewById<TextView>(R.id.tvPassageiroFechado)
            if (c.passageiro.isNotEmpty()) {
                tvPassFechado?.visibility = View.VISIBLE
                tvPassFechado?.text = c.passageiro
                tvPassFechado?.setTextColor(cyan)
            } else {
                tvPassFechado?.visibility = View.GONE
            }

            // ── EXPANDIDO ──
            val layoutExpandido = view.findViewById<LinearLayout>(R.id.layoutExpandido)
            layoutExpandido.visibility = if (expandido) View.VISIBLE else View.GONE

            if (expandido) {
                // Passageiro
                val layoutPassageiro = view.findViewById<LinearLayout>(R.id.layoutPassageiro)
                if (c.passageiro.isNotEmpty()) {
                    layoutPassageiro.visibility = View.VISIBLE
                    view.findViewById<TextView>(R.id.tvPassageiro).apply {
                        text = c.passageiro; setTextColor(cyan)
                    }
                } else layoutPassageiro.visibility = View.GONE

                view.findViewById<TextView>(R.id.tvValorDetalhe).apply {
                    text = "R$ ${"%.2f".format(c.valor)}"
                    setTextColor(if (c.valeAPena) green else red)
                    textSize = 14f
                }

                view.findViewById<TextView>(R.id.tvKmDetalhe).apply {
                    text = "${"%.2f".format(c.kmTotal)} km"
                    setTextColor(textMain)
                }

                view.findViewById<TextView>(R.id.tvGanhoKmDetalhe).apply {
                    text = "R$ ${"%.2f".format(c.ganhoPorKm)}/km"
                    setTextColor(textMain)
                }

                // Tempo
                val layoutTempo = view.findViewById<LinearLayout>(R.id.layoutTempo)
                if (c.tempoExecucao.isNotEmpty()) {
                    layoutTempo.visibility = View.VISIBLE
                    view.findViewById<TextView>(R.id.tvTempoDetalhe).apply {
                        text = c.tempoExecucao; setTextColor(textMain)
                    }
                } else layoutTempo.visibility = View.GONE

                // Pagamento
                val layoutPag = view.findViewById<LinearLayout>(R.id.layoutPagamento)
                if (c.formaPagamento.isNotEmpty()) {
                    layoutPag.visibility = View.VISIBLE
                    view.findViewById<TextView>(R.id.tvPagamentoDetalhe).apply {
                        text = c.formaPagamento; setTextColor(textMain)
                    }
                } else layoutPag.visibility = View.GONE

                // Origem
                val layoutOrigem = view.findViewById<LinearLayout>(R.id.layoutOrigem)
                if (c.origem.isNotEmpty()) {
                    layoutOrigem.visibility = View.VISIBLE
                    view.findViewById<TextView>(R.id.tvOrigemDetalhe).apply {
                        text = c.origem; setTextColor(textMain)
                    }
                } else layoutOrigem.visibility = View.GONE

                // Destino
                val layoutDestino = view.findViewById<LinearLayout>(R.id.layoutDestino)
                if (c.destino.isNotEmpty()) {
                    layoutDestino.visibility = View.VISIBLE
                    view.findViewById<TextView>(R.id.tvDestinoDetalhe).apply {
                        text = c.destino; setTextColor(textMain)
                    }
                } else layoutDestino.visibility = View.GONE

                // Horário início/fim
                val layoutHorario = view.findViewById<LinearLayout>(R.id.layoutHorario)
                val horarioTexto = when {
                    c.horaInicio.isNotEmpty() && c.horaFim.isNotEmpty() -> "${c.horaInicio} ate ${c.horaFim}"
                    c.horaInicio.isNotEmpty() -> "Inicio: ${c.horaInicio}"
                    else -> c.hora
                }
                layoutHorario.visibility = View.VISIBLE
                view.findViewById<TextView>(R.id.tvHorarioDetalhe).apply {
                    text = horarioTexto; setTextColor(textMain)
                }

                // Botão apagar
                view.findViewById<Button>(R.id.btnApagarCorrida).setOnClickListener {
                    AlertDialog.Builder(this@HistoryActivity)
                        .setTitle("Apagar corrida?")
                        .setMessage(
                            "Corrida das ${horaPrincipal} — R$ ${"%.2f".format(c.valor)}\n" +
                            if (c.passageiro.isNotEmpty()) "Passageiro: ${c.passageiro}" else ""
                        )
                        .setPositiveButton("Apagar") { _, _ ->
                            db.deletarCorrida(c.id)
                            atualizarFlutuante()
                            Toast.makeText(this@HistoryActivity, "Corrida apagada!", Toast.LENGTH_SHORT).show()
                            recarregar()
                        }
                        .setNegativeButton("Cancelar", null)
                        .show()
                }
            }

            return view
        }
    }

    private fun atualizarFlutuante() {
        try {
            sendBroadcast(Intent("com.fluxoapp.ATUALIZAR_FLUTUANTE"))
        } catch (_: Exception) {}
        try {
            startService(Intent(this, FloatingEarningsService::class.java).apply { action = "ATUALIZAR" })
        } catch (_: Exception) {}
    }

    private fun recarregar() {
        val c = Calendar.getInstance()
        when (tituloAtual) {
            "HOJE" -> exibir(db.buscarHoje(), "HOJE")
            "SEMANA" -> exibir(db.buscarSemana(), "SEMANA")
            "ANO" -> exibir(db.buscarAno(c.get(Calendar.YEAR)), "ANO")
            "MES" -> exibir(db.buscarMes(c.get(Calendar.MONTH), c.get(Calendar.YEAR)), "MES")
            else -> exibir(db.buscarHoje(), "HOJE")
        }
    }
}
