package com.fluxoapp

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class HistoryActivity : AppCompatActivity() {
    private lateinit var db: DatabaseHelper
    private lateinit var prefs: android.content.SharedPreferences
    private var corridasAtuais: List<Corrida> = emptyList()
    private var tituloAtual = "HOJE"
    private val expandidoSet = mutableSetOf<Int>() // posições expandidas

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)
        db = DatabaseHelper(this)
        prefs = getSharedPreferences("FluxoApp", android.content.Context.MODE_PRIVATE)
        aplicarTema()

        findViewById<ImageButton>(R.id.btnVoltar).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnHoje).setOnClickListener { exibir(db.buscarHoje(), "HOJE") }
        findViewById<Button>(R.id.btnSemana).setOnClickListener { exibir(db.buscarSemana(), "SEMANA") }
        findViewById<Button>(R.id.btnMes).setOnClickListener {
            val c = Calendar.getInstance()
            exibir(db.buscarMes(c.get(Calendar.MONTH), c.get(Calendar.YEAR)), "MES")
        }
        findViewById<Button>(R.id.btnAno).setOnClickListener {
            exibir(db.buscarAno(Calendar.getInstance().get(Calendar.YEAR)), "ANO")
        }
        findViewById<Button>(R.id.btnPersonalizado).setOnClickListener { abrirPersonalizado() }
        exibir(db.buscarHoje(), "HOJE")
    }

    private fun aplicarTema() {
        val p      = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        val bg     = ThemeHelper.cor("bg_dark",     p)
        val bgCard = ThemeHelper.cor("bg_card",     p)
        val bgSect = ThemeHelper.cor("bg_section",  p)
        val accent = ThemeHelper.cor("accent_gold", p)
        val gold   = ThemeHelper.cor("accent_gold", p)
        val txtW   = ThemeHelper.cor("text_white",  p)
        val txtG   = ThemeHelper.cor("text_gray",   p)
        val border = ThemeHelper.cor("border",      p)
        val toolbar= ThemeHelper.cor("toolbar",     p)
        val dp = resources.displayMetrics.density
        fun gd(cor: Int, r: Float, bCor: Int = 0, bw: Float = 0f) =
            android.graphics.drawable.GradientDrawable().apply {
                setColor(cor); cornerRadius = r * dp
                if (bw > 0) setStroke((bw * dp).toInt(), bCor)
            }

        try { findViewById<View>(R.id.rootLayoutHistory)?.setBackgroundColor(bg) } catch (_: Exception) {}

        // Header toolbar
        try {
            val header = (findViewById<View>(R.id.rootLayoutHistory) as? android.widget.LinearLayout)?.getChildAt(0)
            header?.setBackgroundColor(toolbar)
        } catch (_: Exception) {}
        try { findViewById<ImageButton>(R.id.btnVoltar)?.setColorFilter(accent) } catch (_: Exception) {}

        // Filtros bar
        try {
            val scrollFiltros = (findViewById<View>(R.id.rootLayoutHistory) as? android.widget.LinearLayout)?.getChildAt(1)
            scrollFiltros?.setBackgroundColor(bgCard)
        } catch (_: Exception) {}

        // Botões filtro
        for (id in listOf(R.id.btnHoje, R.id.btnSemana, R.id.btnMes, R.id.btnAno, R.id.btnPersonalizado)) {
            try {
                findViewById<Button>(id)?.apply {
                    background = gd(bgCard, 10f, border, 1f)
                    setTextColor(accent)
                }
            } catch (_: Exception) {}
        }
        // Destaque no botão ativo (Hoje por padrão)
        try { findViewById<Button>(R.id.btnHoje)?.background = gd(bgSect, 10f, accent, 2f) } catch (_: Exception) {}

        // Resumo
        try { findViewById<TextView>(R.id.tvResumo)?.apply {
            setBackgroundColor(bgCard)
            setTextColor(txtW)
        }} catch (_: Exception) {}

        // Lista
        try { findViewById<android.widget.ListView>(R.id.listViewCorridas)?.setBackgroundColor(bg) } catch (_: Exception) {}
    }

    private fun abrirPersonalizado() {
        val cal = Calendar.getInstance()
        DatePickerDialog(this, { _, a, m, d ->
            val inicio = Calendar.getInstance().apply { set(a, m, d, 0, 0, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
            DatePickerDialog(this, { _, a2, m2, d2 ->
                val fim = Calendar.getInstance().apply { set(a2, m2, d2, 23, 59, 59) }.timeInMillis
                exibir(db.buscarPorPeriodo(inicio, fim), "PERSONALIZADO")
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun exibir(corridas: List<Corrida>, titulo: String) {
        corridasAtuais = corridas
        tituloAtual = titulo
        expandidoSet.clear()

        val prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
                val textMain = ThemeHelper.cor("text_white", prefs)
        val bgCard   = ThemeHelper.cor("bg_card", prefs)
        val accent     = ThemeHelper.cor("accent_gold", prefs)

        findViewById<TextView>(R.id.tvTitulo).apply {
            text = titulo; setTextColor(accent)
        }

        val r = db.resumo(corridas)
        val melhorCorrida = corridas.maxByOrNull { it.valor }
        val melhorTexto = if (melhorCorrida != null) "  Melhor: R$ ${"%.2f".format(melhorCorrida.valor)}" else ""

        findViewById<TextView>(R.id.tvResumo).apply {
            text = "Total: R$ ${"%.2f".format(r["total"])}  |  " +
                   "${(r["corridas"] ?: 0f).toInt()} corridas  |  " +
                   "${"%.1f".format(r["km_total"])} km\n" +
                   "Media/corrida: R$ ${"%.2f".format(r["media_corrida"])}  |  " +
                   "R$ ${"%.2f".format(r["media_km"])}/km$melhorTexto"
            setTextColor(textMain)
            setBackgroundColor(bgCard)
        }

        val lv = findViewById<ListView>(R.id.listViewCorridas)
        lv.adapter = CorridaAdapter(corridas, prefs)
        lv.setOnItemClickListener { _, _, position, _ ->
            if (expandidoSet.contains(position)) expandidoSet.remove(position)
            else expandidoSet.add(position)
            (lv.adapter as CorridaAdapter).notifyDataSetChanged()
        }
    }

    inner class CorridaAdapter(
        private val corridas: List<Corrida>,
        private val prefs: android.content.SharedPreferences
    ) : ArrayAdapter<Corrida>(this, 0, corridas) {

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val view = convertView ?: LayoutInflater.from(context)
                .inflate(R.layout.item_corrida, parent, false)

            val c = corridas[position]
            val expandido = expandidoSet.contains(position)

            val bgCard   = ThemeHelper.cor("bg_card", prefs)
            val textMain = ThemeHelper.cor("text_white", prefs)
            val textGray = ThemeHelper.cor("text_gray", prefs)
            val green    = ThemeHelper.cor("accent_green", prefs)
            val red      = ThemeHelper.cor("accent_red", prefs)
            val accent     = ThemeHelper.cor("accent_gold", prefs)

            view.setBackgroundColor(bgCard)

            // ── FECHADO ──
            val tvStatusIcon = view.findViewById<TextView>(R.id.tvStatusIcon)
            val corStatus = if (c.valeAPena) green else red
            tvStatusIcon.text = if (c.valeAPena) "V" else "X"
            tvStatusIcon.setTextColor(corStatus)

            val horaPrincipal = if (c.horaInicio.isNotEmpty()) c.horaInicio else c.hora
            view.findViewById<TextView>(R.id.tvHoraValor).apply {
                text = "$horaPrincipal  R$ ${"%.2f".format(c.valor)}"
                setTextColor(corStatus)
            }

            view.findViewById<TextView>(R.id.tvGanhoKmResumido).apply {
                text = "R$ ${"%.2f".format(c.ganhoPorKm)}/km"
                setTextColor(textGray)
            }

            // Linha 1: origem > destino
            val origemCurta = c.origem.substringBefore("(").trim().take(22)
            val destinoCurto = c.destino.substringBefore("(").trim().take(22)
            val rotaTexto = when {
                origemCurta.isNotEmpty() && destinoCurto.isNotEmpty() -> "$origemCurta > $destinoCurto"
                origemCurta.isNotEmpty() -> origemCurta
                else -> c.hora
            }
            view.findViewById<TextView>(R.id.tvRota).apply {
                text = rotaTexto
                setTextColor(textGray)
            }
            // Linha 2: passageiro
            val tvPassFechado = view.findViewById<TextView>(R.id.tvPassageiroFechado)
            if (c.passageiro.isNotEmpty()) {
                tvPassFechado?.visibility = View.VISIBLE
                tvPassFechado?.text = c.passageiro
                tvPassFechado?.setTextColor(accent)
            } else {
                tvPassFechado?.visibility = View.GONE
            }

            // ── EXPANDIDO ──
            val layoutExpandido = view.findViewById<LinearLayout>(R.id.layoutExpandido)
            layoutExpandido.visibility = if (expandido) View.VISIBLE else View.GONE

            if (expandido) {
                // Passageiro
                val layoutPassageiro = view.findViewById<LinearLayout>(R.id.layoutPassageiro)
                if (c.passageiro.isNotEmpty()) {
                    layoutPassageiro.visibility = View.VISIBLE
                    view.findViewById<TextView>(R.id.tvPassageiro).apply {
                        text = c.passageiro; setTextColor(accent)
                    }
                } else layoutPassageiro.visibility = View.GONE

                view.findViewById<TextView>(R.id.tvValorDetalhe).apply {
                    text = "R$ ${"%.2f".format(c.valor)}"
                    setTextColor(if (c.valeAPena) green else red)
                    textSize = 14f
                }

                view.findViewById<TextView>(R.id.tvKmDetalhe).apply {
                    text = "${"%.2f".format(c.kmTotal)} km"
                    setTextColor(textMain)
                }

                view.findViewById<TextView>(R.id.tvGanhoKmDetalhe).apply {
                    text = "R$ ${"%.2f".format(c.ganhoPorKm)}/km"
                    setTextColor(textMain)
                }

                // Tempo
                val layoutTempo = view.findViewById<LinearLayout>(R.id.layoutTempo)
                if (c.tempoExecucao.isNotEmpty()) {
                    layoutTempo.visibility = View.VISIBLE
                    view.findViewById<TextView>(R.id.tvTempoDetalhe).apply {
                        text = c.tempoExecucao; setTextColor(textMain)
                    }
                } else layoutTempo.visibility = View.GONE

                // Pagamento
                val layoutPag = view.findViewById<LinearLayout>(R.id.layoutPagamento)
                if (c.formaPagamento.isNotEmpty()) {
                    layoutPag.visibility = View.VISIBLE
                    view.findViewById<TextView>(R.id.tvPagamentoDetalhe).apply {
                        text = c.formaPagamento; setTextColor(textMain)
                    }
                } else layoutPag.visibility = View.GONE

                // Origem
                val layoutOrigem = view.findViewById<LinearLayout>(R.id.layoutOrigem)
                if (c.origem.isNotEmpty()) {
                    layoutOrigem.visibility = View.VISIBLE
                    view.findViewById<TextView>(R.id.tvOrigemDetalhe).apply {
                        text = c.origem; setTextColor(textMain)
                    }
                } else layoutOrigem.visibility = View.GONE

                // Destino
                val layoutDestino = view.findViewById<LinearLayout>(R.id.layoutDestino)
                if (c.destino.isNotEmpty()) {
                    layoutDestino.visibility = View.VISIBLE
                    view.findViewById<TextView>(R.id.tvDestinoDetalhe).apply {
                        text = c.destino; setTextColor(textMain)
                    }
                } else layoutDestino.visibility = View.GONE

                // Horário início/fim
                val layoutHorario = view.findViewById<LinearLayout>(R.id.layoutHorario)
                val horarioTexto = when {
                    c.horaInicio.isNotEmpty() && c.horaFim.isNotEmpty() -> "${c.horaInicio} ate ${c.horaFim}"
                    c.horaInicio.isNotEmpty() -> "Inicio: ${c.horaInicio}"
                    else -> c.hora
                }
                layoutHorario.visibility = View.VISIBLE
                view.findViewById<TextView>(R.id.tvHorarioDetalhe).apply {
                    text = horarioTexto; setTextColor(textMain)
                }

                // Botão apagar
                view.findViewById<Button>(R.id.btnApagarCorrida).setOnClickListener {
                    AlertDialog.Builder(this@HistoryActivity)
                        .setTitle("Apagar corrida?")
                        .setMessage(
                            "Corrida das ${horaPrincipal} — R$ ${"%.2f".format(c.valor)}\n" +
                            if (c.passageiro.isNotEmpty()) "Passageiro: ${c.passageiro}" else ""
                        )
                        .setPositiveButton("Apagar") { _, _ ->
                            db.deletarCorrida(c.id)
                            atualizarFlutuante()
                            Toast.makeText(this@HistoryActivity, "Corrida apagada!", Toast.LENGTH_SHORT).show()
                            recarregar()
                        }
                        .setNegativeButton("Cancelar", null)
                        .show()
                }
            }

            return view
        }
    }

    private fun atualizarFlutuante() {
        try {
            sendBroadcast(Intent("com.fluxoapp.ATUALIZAR_FLUTUANTE"))
        } catch (_: Exception) {}
        try {
            startService(Intent(this, FloatingEarningsService::class.java).apply { action = "ATUALIZAR" })
        } catch (_: Exception) {}
    }

    private fun recarregar() {
        val c = Calendar.getInstance()
        when (tituloAtual) {
            "HOJE" -> exibir(db.buscarHoje(), "HOJE")
            "SEMANA" -> exibir(db.buscarSemana(), "SEMANA")
            "ANO" -> exibir(db.buscarAno(c.get(Calendar.YEAR)), "ANO")
            "MES" -> exibir(db.buscarMes(c.get(Calendar.MONTH), c.get(Calendar.YEAR)), "MES")
            else -> exibir(db.buscarHoje(), "HOJE")
        }
    }
}
