package com.fluxoapp

import android.app.DatePickerDialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class HistoryActivity : AppCompatActivity() {
    private lateinit var db: DatabaseHelper
    private lateinit var prefs: android.content.SharedPreferences
    private var corridasAtuais: List<Corrida> = emptyList()
    private val expandidoSet = mutableSetOf<Int>()

    private var modoAtual = "dia"
    private val calNav    = Calendar.getInstance()

    private val sdfDiaCurto = SimpleDateFormat("dd/MM EEE", Locale("pt", "BR"))
    private val sdfDiaLongo = SimpleDateFormat("dd/MM/yyyy EEE", Locale("pt", "BR"))
    private val sdfSemana   = SimpleDateFormat("dd/MM", Locale("pt", "BR"))
    private val sdfMes      = SimpleDateFormat("MMMM yyyy", Locale("pt", "BR"))

    override fun attachBaseContext(base: android.content.Context) {
        super.attachBaseContext(FontHelper.wrap(base))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeSelector.aplicar(this)
        setContentView(R.layout.activity_history)
        db    = DatabaseHelper(this)
        prefs = getSharedPreferences("FluxoApp", Context.MODE_PRIVATE)
        aplicarTema()
        aplicarTemaGlobal()
        configurarBotoes()
        atualizarChips()
        carregarPeriodoAtual()
        BottomNavHelper.configurar(this, BottomNavHelper.ABA_HISTORICO)
    }

    // ── BOTÕES ────────────────────────────────────────────────
    private fun configurarBotoes() {
        findViewById<ImageButton>(R.id.btnVoltar).setOnClickListener { finish() }

        // FAB: nova corrida — abre RideTrackerActivity (manual + GPS automático)
        try {
            val fab = findViewById<com.google.android.material.floatingactionbutton.FloatingActionButton>(R.id.fabAddCorrida)
            fab?.backgroundTintList = android.content.res.ColorStateList.valueOf(
                ThemeHelper.cor("accent", prefs)
            )
            fab?.setColorFilter(ThemeHelper.cor("bg_dark", prefs))
            fab?.setOnClickListener {
                startActivity(android.content.Intent(this, RideTrackerActivity::class.java))
            }
        } catch (_: Throwable) {}

        // Botão de busca
        findViewById<ImageButton>(R.id.btnBuscar)?.setOnClickListener { toggleBusca() }

        // Avatar do perfil
        findViewById<android.view.View>(R.id.viewAvatarCircle)?.setOnClickListener {
            try { startActivity(android.content.Intent(this, ProfileActivity::class.java)) } catch (_: Throwable) {}
        }

        // Campo de busca
        findViewById<android.widget.EditText>(R.id.etBusca)?.apply {
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) { executarBusca(s.toString()) }
            })
        }

        findViewById<Button>(R.id.chipDia)?.setOnClickListener    { mudarModo("dia")    }
        findViewById<Button>(R.id.chipSemana)?.setOnClickListener { mudarModo("semana") }
        findViewById<Button>(R.id.chipMes)?.setOnClickListener    { mudarModo("mes")    }
        findViewById<Button>(R.id.chipAno)?.setOnClickListener    { mudarModo("ano")    }

        findViewById<ImageButton>(R.id.btnNavAnterior)?.setOnClickListener { navegar(-1) }
        findViewById<ImageButton>(R.id.btnNavProximo)?.setOnClickListener  { navegar(+1) }

        // Clique longo na label → abrir calendário para escolher qualquer data
        findViewById<TextView>(R.id.tvNavLabel)?.setOnLongClickListener {
            abrirCalendario(); true
        }
    }

    // ── MODO ──────────────────────────────────────────────────
    private fun mudarModo(modo: String) {
        modoAtual = modo
        if (modo == "dia") calNav.time = Date() // volta para hoje ao clicar em DIA
        atualizarChips()
        carregarPeriodoAtual()
    }

    // ── NAVEGAR ───────────────────────────────────────────────
    private fun navegar(direcao: Int) {
        when (modoAtual) {
            "dia"    -> calNav.add(Calendar.DAY_OF_YEAR, direcao)
            "semana" -> calNav.add(Calendar.WEEK_OF_YEAR, direcao)
            "mes"    -> calNav.add(Calendar.MONTH, direcao)
            "ano"    -> calNav.add(Calendar.YEAR, direcao)
        }
        carregarPeriodoAtual()
    }

    // ── CARREGAR PERÍODO ──────────────────────────────────────
    private fun carregarPeriodoAtual() {
        val hoje  = Calendar.getInstance()
        val ontem = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }

        val corridas: List<Corrida>
        val label: String
        var ehPeriodoAtual = false

        when (modoAtual) {
            "dia" -> {
                corridas = db.buscarDia(
                    calNav.get(Calendar.YEAR),
                    calNav.get(Calendar.MONTH),
                    calNav.get(Calendar.DAY_OF_MONTH)
                )
                label = when {
                    isMesmoDia(calNav, hoje)  -> "HOJE · ${sdfDiaCurto.format(calNav.time).uppercase()}"
                    isMesmoDia(calNav, ontem) -> "ONTEM · ${sdfDiaCurto.format(calNav.time).uppercase()}"
                    else                      -> sdfDiaLongo.format(calNav.time).uppercase()
                }
                ehPeriodoAtual = isMesmoDia(calNav, hoje)
            }
            "semana" -> {
                val ini = calNav.clone() as Calendar
                ini.set(Calendar.DAY_OF_WEEK, ini.firstDayOfWeek)
                ini.set(Calendar.HOUR_OF_DAY, 0); ini.set(Calendar.MINUTE, 0)
                ini.set(Calendar.SECOND, 0);      ini.set(Calendar.MILLISECOND, 0)
                val fim = ini.clone() as Calendar
                fim.add(Calendar.DAY_OF_YEAR, 6)
                fim.set(Calendar.HOUR_OF_DAY, 23); fim.set(Calendar.MINUTE, 59)
                fim.set(Calendar.SECOND, 59)
                corridas = db.buscarPorPeriodo(ini.timeInMillis, fim.timeInMillis)
                label = "${sdfSemana.format(ini.time)} – ${sdfSemana.format(fim.time)}"
                ehPeriodoAtual = calNav.get(Calendar.WEEK_OF_YEAR) == hoje.get(Calendar.WEEK_OF_YEAR)
                              && calNav.get(Calendar.YEAR) == hoje.get(Calendar.YEAR)
            }
            "mes" -> {
                corridas = db.buscarMes(calNav.get(Calendar.MONTH), calNav.get(Calendar.YEAR))
                label = sdfMes.format(calNav.time).uppercase()
                ehPeriodoAtual = calNav.get(Calendar.MONTH) == hoje.get(Calendar.MONTH)
                              && calNav.get(Calendar.YEAR)  == hoje.get(Calendar.YEAR)
            }
            "ano" -> {
                corridas = db.buscarAno(calNav.get(Calendar.YEAR))
                label = calNav.get(Calendar.YEAR).toString()
                ehPeriodoAtual = calNav.get(Calendar.YEAR) == hoje.get(Calendar.YEAR)
            }
            else -> { corridas = emptyList(); label = "" }
        }

        // Desabilitar seta "próximo" se já está no período atual
        try {
            val btn = findViewById<ImageButton>(R.id.btnNavProximo)
            btn?.alpha    = if (ehPeriodoAtual) 0.3f else 1.0f
            btn?.isEnabled = !ehPeriodoAtual
        } catch (_: Throwable) {}

        exibir(corridas, label)
    }

    private fun isMesmoDia(a: Calendar, b: Calendar) =
        a.get(Calendar.YEAR)        == b.get(Calendar.YEAR) &&
        a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)

    // ── CALENDÁRIO (clique longo) ─────────────────────────────
    private fun abrirCalendario() {
        DatePickerDialog(this, { _, ano, mes, dia ->
            calNav.set(ano, mes, dia)
            modoAtual = "dia"
            atualizarChips()
            carregarPeriodoAtual()
        },
        calNav.get(Calendar.YEAR),
        calNav.get(Calendar.MONTH),
        calNav.get(Calendar.DAY_OF_MONTH)).show()
    }

    // ── CHIPS VISUAIS ─────────────────────────────────────────
    private fun atualizarChips() {
        val accent = ThemeHelper.cor("accent_gold", prefs)
        val bgCard = ThemeHelper.cor("bg_card", prefs)
        val dp     = resources.displayMetrics.density
        val sobreGradiente = corContraste(accent)

        mapOf(R.id.chipDia to "dia", R.id.chipSemana to "semana",
              R.id.chipMes to "mes", R.id.chipAno to "ano"
        ).forEach { (id, modo) ->
            try {
                val btn = findViewById<Button>(id) ?: return@forEach
                if (modo == modoAtual) {
                    // Pílula ativa — sólida, destacada sobre o trilho translúcido
                    btn.background = GradientDrawable().apply {
                        setColor(bgCard); cornerRadius = 18f * dp
                    }
                    btn.setTextColor(accent)
                } else {
                    btn.background = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
                    btn.setTextColor(Color.argb(200, Color.red(sobreGradiente), Color.green(sobreGradiente), Color.blue(sobreGradiente)))
                }
            } catch (_: Throwable) {}
        }
    }

    // ── EXIBIR CORRIDAS ───────────────────────────────────────
    private fun exibir(corridas: List<Corrida>, label: String) {
        corridasAtuais = corridas
        expandidoSet.clear()

        val p      = prefs
        val accent = ThemeHelper.cor("accent_gold", p)
        val txtW   = ThemeHelper.cor("text_white",  p)
        val txtG   = ThemeHelper.cor("text_gray",   p)
        val bgCard = ThemeHelper.cor("bg_card",     p)
        val border = ThemeHelper.cor("border",      p)
        val dp     = resources.displayMetrics.density

        // Label de navegação
        try { findViewById<TextView>(R.id.tvNavLabel)?.apply {
            text = label; setTextColor(accent)
        }} catch (_: Throwable) {}

        // Resumo — card estruturado (antes era um bloco de texto corrido)
        val total = corridas.sumOf { it.valor.toDouble() }
        val qtd   = corridas.size
        val km    = corridas.sumOf { it.kmTotal.toDouble() }
        val media = if (qtd > 0) total / qtd else 0.0
        val green = ThemeHelper.cor("accent_green", p)

        try {
            findViewById<View>(R.id.cardResumo)?.visibility = if (qtd == 0) View.GONE else View.VISIBLE
            findViewById<View>(R.id.tvHistVazio)?.visibility = if (qtd == 0) View.VISIBLE else View.GONE
            findViewById<TextView>(R.id.tvHistTotalValor)?.apply {
                text = "R$ ${"%.2f".format(total)}"; setTextColor(txtW)
            }
            findViewById<TextView>(R.id.tvHistTotalLabel)?.setTextColor(txtG)
            findViewById<TextView>(R.id.tvHistQtdCorridas)?.apply {
                text = "$qtd"; setTextColor(accent)
            }
            findViewById<TextView>(R.id.tvHistKmTotal)?.apply {
                text = "%.1f".format(km); setTextColor(txtW)
            }
            findViewById<TextView>(R.id.tvHistMediaCorrida)?.apply {
                text = "R$ ${"%.2f".format(media)}"; setTextColor(green)
            }
        } catch (_: Throwable) {}

        // Lista
        val listView = try { findViewById<ListView>(R.id.listViewCorridas) } catch (_: Throwable) { null } ?: return
        listView.adapter = CorridaAdapter(corridas)
        listView.setBackgroundColor(ThemeHelper.cor("bg_dark", p))
    }

    // ── ADAPTER ───────────────────────────────────────────────
    inner class CorridaAdapter(private val lista: List<Corrida>) : BaseAdapter() {
        override fun getCount() = lista.size
        override fun getItem(pos: Int) = lista[pos]
        override fun getItemId(pos: Int) = lista[pos].id

        override fun getView(pos: Int, convertView: View?, parent: ViewGroup): View {
            val p       = prefs
            val accent  = ThemeHelper.cor("accent_gold", p)
            val txtW    = ThemeHelper.cor("text_white",  p)
            val txtG    = ThemeHelper.cor("text_gray",   p)
            val bgCard  = ThemeHelper.cor("bg_card",     p)
            val border  = ThemeHelper.cor("border",      p)
            val green   = ThemeHelper.cor("accent_green", p)
            val red     = ThemeHelper.cor("accent_red",   p)
            val dp      = resources.displayMetrics.density
            val corrida = lista[pos]
            val expandido = expandidoSet.contains(pos)

            // Escala de fonte: 0=pequeno(0.85x) 1=médio(1.0x) 2=grande(1.2x)
            val escalaFonte = when (prefs.getInt("tamanho_fonte", 1)) {
                0 -> 0.85f; 2 -> 1.20f; else -> 1.0f
            }

            val view = convertView ?: LayoutInflater.from(this@HistoryActivity)
                .inflate(R.layout.item_corrida, parent, false)

            view.findViewById<LinearLayout>(R.id.cardCorridaInner)?.background = GradientDrawable().apply {
                setColor(bgCard); cornerRadius = 12f * dp
                setStroke((1f * dp).toInt(), border)
            }

            try {
                val corBadge = if (corrida.valeAPena) green else red

                // Ícone circular de status — antes era só um caractere ✓/✗ solto
                view.findViewById<View>(R.id.viewStatusCircle)?.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.argb(46, Color.red(corBadge), Color.green(corBadge), Color.blue(corBadge)))
                }
                view.findViewById<TextView>(R.id.tvStatusIcon)?.apply {
                    text = if (corrida.valeAPena) "✓" else "✗"
                    setTextColor(corBadge)
                }

                val orig = corrida.origem.replace("🏠 ","").replace("🏁 ","").trim()
                val dest = corrida.destino.replace("🏠 ","").replace("🏁 ","").trim()

                // Rota — agora é a linha principal (branca/negrito), como o
                // "nome do estabelecimento" numa linha de extrato bancário
                view.findViewById<TextView>(R.id.tvRota)?.apply {
                    text = if (dest.isNotBlank()) dest.take(32) + if (dest.length > 32) "…" else ""
                           else if (orig.isNotBlank()) orig.take(32) else "Corrida sem destino"
                    setTextColor(txtW)
                    textSize = 13f * escalaFonte
                }

                // Km · R$/km — subtítulo cinza
                view.findViewById<TextView>(R.id.tvGanhoKmResumido)?.apply {
                    text = "${"%.1f".format(corrida.kmTotal)} km · R$${"%.2f".format(corrida.ganhoPorKm)}/km"
                    setTextColor(txtG)
                    textSize = 11f * escalaFonte
                }

                // Valor — agora é o elemento em destaque, alinhado à direita
                // e colorido conforme vale/não vale a pena (como "entrada"
                // ou "saída" num extrato de banco)
                view.findViewById<TextView>(R.id.tvHoraValor)?.apply {
                    text = "R$ ${"%.2f".format(corrida.valor)}"
                    setTextColor(corBadge)
                    textSize = 16f * escalaFonte
                }
                view.findViewById<TextView>(R.id.tvHoraSomente)?.apply {
                    text = corrida.hora
                    setTextColor(txtG)
                    textSize = 10f * escalaFonte
                }

                // Área expandida
                val layoutExpandido = view.findViewById<View>(R.id.layoutExpandido)
                layoutExpandido?.visibility = if (expandido) View.VISIBLE else View.GONE

                if (expandido) {
                    view.findViewById<TextView>(R.id.tvValorDetalhe)?.apply {
                        text = "R$ ${"%.2f".format(corrida.valor)}"; setTextColor(txtW)
                        textSize = 14f * escalaFonte
                    }
                    view.findViewById<TextView>(R.id.tvKmDetalhe)?.apply {
                        text = "${"%.2f".format(corrida.kmTotal)} km"; setTextColor(txtW)
                        textSize = 13f * escalaFonte
                    }
                    view.findViewById<TextView>(R.id.tvGanhoKmDetalhe)?.apply {
                        text = "R$ ${"%.2f".format(corrida.ganhoPorKm)}/km"; setTextColor(txtW)
                        textSize = 13f * escalaFonte
                    }
                    view.findViewById<TextView>(R.id.tvOrigemDetalhe)?.apply {
                        text = orig.ifBlank { "—" }; setTextColor(txtW)
                        textSize = 12f * escalaFonte
                    }
                    view.findViewById<TextView>(R.id.tvDestinoDetalhe)?.apply {
                        text = dest.ifBlank { "—" }; setTextColor(txtW)
                        textSize = 12f * escalaFonte
                    }
                    view.findViewById<TextView>(R.id.tvPagamentoDetalhe)?.apply {
                        text = corrida.formaPagamento.ifBlank { "—" }; setTextColor(txtW)
                        textSize = 12f * escalaFonte
                    }
                    view.findViewById<TextView>(R.id.tvTempoDetalhe)?.apply {
                        text = corrida.tempoExecucao.ifBlank { "—" }; setTextColor(txtW)
                        textSize = 12f * escalaFonte
                    }
                    val horario = buildString {
                        if (corrida.horaInicio.isNotBlank()) append("${corrida.horaInicio} → ")
                        if (corrida.horaFim.isNotBlank()) append(corrida.horaFim)
                    }
                    view.findViewById<TextView>(R.id.tvHorarioDetalhe)?.apply {
                        text = horario.ifBlank { "—" }; setTextColor(txtW)
                        textSize = 12f * escalaFonte
                    }
                    view.findViewById<TextView>(R.id.tvPassageiro)?.apply {
                        text = corrida.passageiro.ifBlank { "—" }; setTextColor(accent)
                        textSize = 12f * escalaFonte
                    }
                    // botão apagar removido do card expandido — usar pressão longa
                }
            } catch (_: Throwable) {}

            // Toque → expandir/recolher
            view.setOnClickListener {
                if (expandidoSet.contains(pos)) expandidoSet.remove(pos)
                else expandidoSet.add(pos)
                notifyDataSetChanged()
            }

            // Pressão longa → menu de ações (editar / apagar)
            view.setOnLongClickListener {
                mostrarMenuAcoesCorrida(corrida)
                true
            }

            return view
        }
    }

    // ── MENU DE AÇÕES DA CORRIDA (pressão longa) ────────────────
    private fun mostrarMenuAcoesCorrida(corrida: Corrida) {
        val p      = prefs
        val accent = ThemeHelper.cor("accent_gold", p)
        val bgCard = ThemeHelper.cor("bg_card", p)
        val bgDark = ThemeHelper.cor("bg_dark", p)
        val txtW   = ThemeHelper.cor("text_white", p)
        val txtG   = ThemeHelper.cor("text_gray", p)
        val red    = ThemeHelper.cor("accent_red", p)
        val dp     = resources.displayMetrics.density
        val green  = ThemeHelper.cor("accent_green", p)

        // Container principal
        val root = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(bgCard); cornerRadius = 20f * dp
                setStroke((1.5f * dp).toInt(), accent)
            }
            clipToOutline = true
        }

        // Header colorido com info da corrida
        val headerBg = android.graphics.Color.argb(
            220, android.graphics.Color.red(accent),
            android.graphics.Color.green(accent), android.graphics.Color.blue(accent))
        val header = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.argb(60,
                android.graphics.Color.red(accent),
                android.graphics.Color.green(accent),
                android.graphics.Color.blue(accent)))
            setPadding((20*dp).toInt(), (16*dp).toInt(), (20*dp).toInt(), (16*dp).toInt())
        }

        // Valor grande
        header.addView(android.widget.TextView(this).apply {
            text = "R$ ${"%.2f".format(corrida.valor)}"
            textSize = 28f; setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(accent); gravity = android.view.Gravity.CENTER
        })
        // Hora e data
        header.addView(android.widget.TextView(this).apply {
            text = "${corrida.hora}  ·  ${corrida.data}"
            textSize = 13f; setTextColor(txtG)
            gravity = android.view.Gravity.CENTER
            setPadding(0, (4*dp).toInt(), 0, 0)
        })
        // Origem se disponível
        if (corrida.origem.isNotBlank()) {
            header.addView(android.widget.TextView(this).apply {
                text = corrida.origem.replace("🏠 ", "").take(45)
                textSize = 11f; setTextColor(txtG)
                gravity = android.view.Gravity.CENTER
                setPadding(0, (2*dp).toInt(), 0, 0)
            })
        }
        // Stats km e R$/km
        val statsRow = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER
            setPadding(0, (8*dp).toInt(), 0, 0)
        }
        val kmStr = if (corrida.kmTotal > 0) "${"%.1f".format(corrida.kmTotal)} km" else "—"
        val gkmStr = if (corrida.ganhoPorKm > 0) "R$${"%.2f".format(corrida.ganhoPorKm)}/km" else "—"
        for (txt in listOf(kmStr, "  ·  ", gkmStr)) {
            statsRow.addView(android.widget.TextView(this).apply {
                text = txt; textSize = 12f
                setTextColor(if (txt.contains("km") || txt.contains("R$")) txtW else txtG)
            })
        }
        header.addView(statsRow)
        root.addView(header)

        // Divider
        root.addView(android.view.View(this).apply {
            setBackgroundColor(android.graphics.Color.argb(40,
                android.graphics.Color.red(accent),
                android.graphics.Color.green(accent),
                android.graphics.Color.blue(accent)))
            layoutParams = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, (1*dp).toInt())
        })

        // Botão Editar
        fun btnAcao(texto: String, icone: String, cor: Int): android.widget.LinearLayout {
            return android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding((20*dp).toInt(), (16*dp).toInt(), (20*dp).toInt(), (16*dp).toInt())
                isClickable = true
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(android.graphics.Color.TRANSPARENT)
                    cornerRadius = 0f
                }
                addView(android.widget.TextView(this@HistoryActivity).apply {
                    text = icone; textSize = 20f
                    setPadding(0, 0, (12*dp).toInt(), 0)
                })
                addView(android.widget.TextView(this@HistoryActivity).apply {
                    text = texto; textSize = 15f
                    setTypeface(null, android.graphics.Typeface.BOLD)
                    setTextColor(cor)
                })
            }
        }

        // Botão compartilhar com gradiente animado
        val btnCompartilhar = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding((20*dp).toInt(), (16*dp).toInt(), (20*dp).toInt(), (16*dp).toInt())
            isClickable = true
            // Cor do compartilhar segue o tema (gold = dourado, azul = ciano)
            val corShare = ThemeHelper.cor("accent", prefs)
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(
                    android.graphics.Color.argb(40,
                        android.graphics.Color.red(corShare),
                        android.graphics.Color.green(corShare),
                        android.graphics.Color.blue(corShare)),
                    android.graphics.Color.argb(80,
                        android.graphics.Color.red(corShare),
                        android.graphics.Color.green(corShare),
                        android.graphics.Color.blue(corShare)),
                    android.graphics.Color.argb(40,
                        android.graphics.Color.red(corShare),
                        android.graphics.Color.green(corShare),
                        android.graphics.Color.blue(corShare))
                )
            )
            addView(android.widget.TextView(this@HistoryActivity).apply {
                text = "📤"; textSize = 20f
                setPadding(0, 0, (12*dp).toInt(), 0)
            })
            addView(android.widget.TextView(this@HistoryActivity).apply {
                text = "Compartilhar corrida"; textSize = 15f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(ThemeHelper.cor("accent", prefs))
            })
        }

        // Animar gradiente do botão compartilhar
        try {
            val corShare = ThemeHelper.cor("accent", prefs)
            val anim = android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 1800; repeatCount = android.animation.ValueAnimator.INFINITE
                repeatMode = android.animation.ValueAnimator.REVERSE
                addUpdateListener { va ->
                    val f = va.animatedValue as Float
                    btnCompartilhar.background = android.graphics.drawable.GradientDrawable(
                        android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
                        intArrayOf(
                            android.graphics.Color.argb((20 + (60*f)).toInt(),
                                android.graphics.Color.red(corShare),
                                android.graphics.Color.green(corShare),
                                android.graphics.Color.blue(corShare)),
                            android.graphics.Color.argb((80 + (80*f)).toInt(),
                                android.graphics.Color.red(corShare),
                                android.graphics.Color.green(corShare),
                                android.graphics.Color.blue(corShare)),
                            android.graphics.Color.argb((20 + (60*f)).toInt(),
                                android.graphics.Color.red(corShare),
                                android.graphics.Color.green(corShare),
                                android.graphics.Color.blue(corShare))
                        )
                    )
                }
                start()
            }
            btnCompartilhar.tag = anim
        } catch (_: Throwable) {}

        val btnEditar = btnAcao("Editar valor", "✏️", accent)
        val btnApagar = btnAcao("Apagar corrida", "🗑️", red)

        fun divider() = android.view.View(this).apply {
            setBackgroundColor(android.graphics.Color.argb(25,
                android.graphics.Color.red(txtG),
                android.graphics.Color.green(txtG),
                android.graphics.Color.blue(txtG)))
            layoutParams = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, (1*dp).toInt()).apply {
                setMargins((20*dp).toInt(), 0, (20*dp).toInt(), 0)
            }
        }

        root.addView(btnCompartilhar)
        root.addView(divider())
        root.addView(btnEditar)
        root.addView(divider())
        root.addView(btnApagar)

        val dialog = android.app.AlertDialog.Builder(this)
            .setView(root)
            .create()

        dialog.window?.apply {
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT))
        }

        btnCompartilhar.setOnClickListener {
            dialog.dismiss()
            (btnCompartilhar.tag as? android.animation.ValueAnimator)?.cancel()
            compartilharCorrida(corrida)
        }
        btnEditar.setOnClickListener {
            dialog.dismiss()
            (btnCompartilhar.tag as? android.animation.ValueAnimator)?.cancel()
            mostrarEdicaoRapida(corrida)
        }
        btnApagar.setOnClickListener {
            dialog.dismiss()
            (btnCompartilhar.tag as? android.animation.ValueAnimator)?.cancel()
            mostrarConfirmarApagar(corrida)
        }
        dialog.setOnDismissListener {
            (btnCompartilhar.tag as? android.animation.ValueAnimator)?.cancel()
        }
        dialog.show()
    }

    // ── CONFIRMAR APAGAR ──────────────────────────────────────
    private fun compartilharCorrida(corrida: Corrida) {
        val sb = StringBuilder()
        sb.append("🚀 FluxoApp — Corrida registrada\n")
        sb.append("━━━━━━━━━━━━━━━━━━━━\n")
        sb.append("💰 Valor: R$ ${"%.2f".format(corrida.valor)}\n")
        if (corrida.kmTotal > 0)
            sb.append("📍 Distância: ${"%.1f".format(corrida.kmTotal)} km\n")
        if (corrida.ganhoPorKm > 0)
            sb.append("📈 Ganho/km: R$ ${"%.2f".format(corrida.ganhoPorKm)}\n")
        sb.append("💳 Pagamento: ${corrida.formaPagamento}\n")
        if (corrida.horaInicio.isNotBlank() && corrida.horaFim.isNotBlank())
            sb.append("⏱ Horário: ${corrida.horaInicio} → ${corrida.horaFim}\n")
        if (corrida.tempoExecucao.isNotBlank())
            sb.append("🕐 Duração: ${corrida.tempoExecucao}\n")
        if (corrida.origem.isNotBlank())
            sb.append("📌 Origem: ${corrida.origem.replace("🏠 ", "").take(60)}\n")
        sb.append("━━━━━━━━━━━━━━━━━━━━\n")
        sb.append("${corrida.data} • ${corrida.hora}")

        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(android.content.Intent.EXTRA_TEXT, sb.toString())
        }
        startActivity(android.content.Intent.createChooser(intent, "Compartilhar corrida"))
    }

    private fun mostrarConfirmarApagar(corrida: Corrida) {
        val p      = prefs
        val accent = ThemeHelper.cor("accent_gold", p)
        val bgCard = ThemeHelper.cor("bg_card", p)
        val txtW   = ThemeHelper.cor("text_white", p)
        val txtG   = ThemeHelper.cor("text_gray", p)
        val red    = ThemeHelper.cor("accent_red", p)
        val dp     = resources.displayMetrics.density

        val root = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(bgCard); cornerRadius = 20f * dp
                setStroke((1.5f * dp).toInt(), red)
            }
            setPadding((24*dp).toInt(), (24*dp).toInt(), (24*dp).toInt(), (20*dp).toInt())
        }

        root.addView(android.widget.TextView(this).apply {
            text = "🗑️  Apagar corrida?"
            textSize = 18f; setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(red); gravity = android.view.Gravity.CENTER
        })
        root.addView(android.widget.TextView(this).apply {
            text = "R$ ${"%.2f".format(corrida.valor)}  ·  ${corrida.hora}  ·  ${corrida.data}"
            textSize = 13f; setTextColor(txtG)
            gravity = android.view.Gravity.CENTER
            setPadding(0, (8*dp).toInt(), 0, (20*dp).toInt())
        })

        val btnsRow = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER
        }
        fun btnRow(texto: String, cor: Int, fill: Boolean): android.widget.TextView {
            return android.widget.TextView(this).apply {
                text = texto; textSize = 14f
                setTypeface(null, android.graphics.Typeface.BOLD)
                gravity = android.view.Gravity.CENTER
                layoutParams = android.widget.LinearLayout.LayoutParams(0,
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    setMargins((4*dp).toInt(), 0, (4*dp).toInt(), 0)
                }
                setPadding((12*dp).toInt(), (12*dp).toInt(), (12*dp).toInt(), (12*dp).toInt())
                background = android.graphics.drawable.GradientDrawable().apply {
                    if (fill) setColor(cor) else setColor(android.graphics.Color.TRANSPARENT)
                    cornerRadius = 10f * dp
                    if (!fill) setStroke((1.5f * dp).toInt(), cor)
                }
                setTextColor(if (fill) android.graphics.Color.WHITE else cor)
            }
        }
        val btnCancelar = btnRow("Cancelar", accent, false)
        val btnApagar   = btnRow("Apagar", red, true)
        btnsRow.addView(btnCancelar); btnsRow.addView(btnApagar)
        root.addView(btnsRow)

        val dialog = android.app.AlertDialog.Builder(this)
            .setView(root).create()
        dialog.window?.setBackgroundDrawable(
            android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT))
        btnCancelar.setOnClickListener { dialog.dismiss() }
        btnApagar.setOnClickListener {
            dialog.dismiss()
            db.deletarCorrida(corrida.id)
            carregarPeriodoAtual()
            FluxoToast.sucesso(this, "Corrida apagada")
        }
        dialog.show()
    }

    // ── EDIÇÃO RÁPIDA ─────────────────────────────────────────
    private fun mostrarEdicaoRapida(corrida: Corrida) {
        val p      = prefs
        val accent = ThemeHelper.cor("accent_gold", p)
        val bgCard = ThemeHelper.cor("bg_card", p)
        val txtW   = ThemeHelper.cor("text_white", p)
        val txtG   = ThemeHelper.cor("text_gray", p)
        val dp     = resources.displayMetrics.density

        val root = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(bgCard); cornerRadius = 20f * dp
                setStroke((1.5f * dp).toInt(), accent)
            }
            setPadding((24*dp).toInt(), (24*dp).toInt(), (24*dp).toInt(), (20*dp).toInt())
        }

        // Título
        root.addView(android.widget.TextView(this).apply {
            text = "✏️  Editar valor"
            textSize = 18f; setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(accent); gravity = android.view.Gravity.CENTER
        })

        // Info da corrida
        root.addView(android.widget.TextView(this).apply {
            text = "${corrida.hora}  ·  ${corrida.data}"
            textSize = 12f; setTextColor(txtG); gravity = android.view.Gravity.CENTER
            setPadding(0, (6*dp).toInt(), 0, (4*dp).toInt())
        })
        if (corrida.origem.isNotBlank()) {
            root.addView(android.widget.TextView(this).apply {
                text = corrida.origem.replace("🏠 ","").take(45)
                textSize = 11f; setTextColor(txtG); gravity = android.view.Gravity.CENTER
                setPadding(0, 0, 0, (12*dp).toInt())
            })
        }

        // Campo de valor com destaque
        val etContainer = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(android.graphics.Color.argb(30,
                    android.graphics.Color.red(accent),
                    android.graphics.Color.green(accent),
                    android.graphics.Color.blue(accent)))
                cornerRadius = 12f * dp
                setStroke((1f * dp).toInt(), accent)
            }
            setPadding((16*dp).toInt(), (4*dp).toInt(), (16*dp).toInt(), (4*dp).toInt())
            layoutParams = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                setMargins(0, 0, 0, (20*dp).toInt())
            }
        }
        etContainer.addView(android.widget.TextView(this).apply {
            text = "R$"; textSize = 20f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(accent)
            setPadding(0, 0, (8*dp).toInt(), 0)
        })
        val et = android.widget.EditText(this).apply {
            setText("%.2f".format(corrida.valor)); selectAll()
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                        android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            textSize = 26f; setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(txtW); setBackgroundColor(android.graphics.Color.TRANSPARENT)
            gravity = android.view.Gravity.CENTER
            layoutParams = android.widget.LinearLayout.LayoutParams(0,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        etContainer.addView(et)
        root.addView(etContainer)

        // Botões
        val btnsRow = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER
        }
        fun btnAcao(texto: String, fill: Boolean, cor: Int): android.widget.TextView {
            return android.widget.TextView(this).apply {
                text = texto; textSize = 14f
                setTypeface(null, android.graphics.Typeface.BOLD)
                gravity = android.view.Gravity.CENTER
                layoutParams = android.widget.LinearLayout.LayoutParams(0,
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    setMargins((4*dp).toInt(), 0, (4*dp).toInt(), 0)
                }
                setPadding((12*dp).toInt(), (12*dp).toInt(), (12*dp).toInt(), (12*dp).toInt())
                background = android.graphics.drawable.GradientDrawable().apply {
                    if (fill) setColor(cor) else setColor(android.graphics.Color.TRANSPARENT)
                    cornerRadius = 10f * dp
                    if (!fill) setStroke((1.5f * dp).toInt(), cor)
                }
                setTextColor(if (fill) android.graphics.Color.parseColor("#001A00") else cor)
            }
        }
        val btnCancelar = btnAcao("Cancelar", false, accent)
        val btnSalvar   = btnAcao("Salvar ✓", true, accent)
        btnsRow.addView(btnCancelar); btnsRow.addView(btnSalvar)
        root.addView(btnsRow)

        val dialog = android.app.AlertDialog.Builder(this)
            .setView(root).create()
        dialog.window?.setBackgroundDrawable(
            android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT))
        btnCancelar.setOnClickListener { dialog.dismiss() }
        btnSalvar.setOnClickListener {
            val novoValor = et.text.toString().replace(",", ".").toFloatOrNull()
            if (novoValor != null && novoValor > 0f) {
                dialog.dismiss()
                db.editarCorrida(corrida.id, novoValor)
                carregarPeriodoAtual()
                FluxoToast.sucesso(this, "Valor atualizado → R$${"%.2f".format(novoValor)}")
            } else {
                FluxoToast.erro(this, "Valor inválido")
            }
        }
        dialog.show()
        et.requestFocus()
        val imm = getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
        imm.showSoftInput(et, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
    }

    // ── BUSCA ─────────────────────────────────────────────────
    private var modosBusca = false
    private val handlerBusca = android.os.Handler(android.os.Looper.getMainLooper())
    private var runnerBusca: Runnable? = null

    private fun toggleBusca() {
        modosBusca = !modosBusca
        val layoutBusca = try { findViewById<android.view.View>(R.id.layoutBusca) } catch (_: Throwable) { null }
        val et          = try { findViewById<android.widget.EditText>(R.id.etBusca) } catch (_: Throwable) { null }
        val accent      = ThemeHelper.cor("accent_gold", prefs)

        if (modosBusca) {
            layoutBusca?.visibility = android.view.View.VISIBLE
            et?.requestFocus()
            val imm = getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
            imm.showSoftInput(et, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
        } else {
            layoutBusca?.visibility = android.view.View.GONE
            et?.setText("")
            val imm = getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
            imm.hideSoftInputFromWindow(et?.windowToken, 0)
            carregarPeriodoAtual() // volta ao período normal
        }
    }

    private fun executarBusca(query: String) {
        // FIX 9: debounce 300ms + query em background thread
        runnerBusca?.let { handlerBusca.removeCallbacks(it) }
        if (query.length < 2) { carregarPeriodoAtual(); return }
        val runner = Runnable {
            Thread {
                val q = query.lowercase()
                val resultado = try {
                    db.buscarTodas().filter { c ->
                        c.origem.lowercase().contains(q) ||
                        c.destino.lowercase().contains(q) ||
                        c.passageiro.lowercase().contains(q) ||
                        c.formaPagamento.lowercase().contains(q) ||
                        c.hora.contains(q) || c.data.contains(q) ||
                        "%.2f".format(c.valor).contains(q)
                    }
                } catch (_: Throwable) { emptyList() }
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    val n = resultado.size
                    exibir(resultado, "$n resultado${if (n != 1) "s" else ""} para \"$query\"")
                }
            }.start()
        }
        runnerBusca = runner
        handlerBusca.postDelayed(runner, 300L)
    }


    // ── TEMA ──────────────────────────────────────────────────
    private fun aplicarTema() {
        val p      = prefs
        val bg     = ThemeHelper.cor("bg_dark",     p)
        val bgCard = ThemeHelper.cor("bg_card",     p)
        val accent = ThemeHelper.cor("accent_gold", p)
        val txtW   = ThemeHelper.cor("text_white",  p)
        val txtG   = ThemeHelper.cor("text_gray",   p)
        val border = ThemeHelper.cor("border",      p)
        val dp     = resources.displayMetrics.density

        // Cor de conteúdo (texto/ícone) com contraste adequado sobre o
        // gradiente — calculada a partir do próprio "accent" do tema, não
        // fixa. Temas claros (accent escuro) recebem texto branco por cima;
        // temas com accent bem claro recebem texto escuro.
        val sobreGradiente = corContraste(accent)
        // Tom mais escuro do MESMO accent, usado como 2º stop do gradiente —
        // derivado matematicamente da cor do tema, nunca um hex fixo.
        val accentEscuro = escurecer(accent, 0.72f)

        try { findViewById<android.view.View>(R.id.rootLayoutHistory)?.setBackgroundColor(bg) } catch (_: Throwable) {}

        // ── CABEÇALHO — gradiente accent → accent escuro (diagonal) ────────
        try {
            findViewById<android.view.View>(R.id.headerGradiente)?.background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR, intArrayOf(accent, accentEscuro)
            )
        } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvTituloHeader)?.setTextColor(sobreGradiente) } catch (_: Throwable) {}
        try { findViewById<ImageButton>(R.id.btnVoltar)?.setColorFilter(sobreGradiente) } catch (_: Throwable) {}
        try { findViewById<ImageButton>(R.id.btnBuscar)?.setColorFilter(sobreGradiente) } catch (_: Throwable) {}

        // Avatar — círculo translúcido sobre o gradiente, iniciais do nome salvo
        try {
            findViewById<android.view.View>(R.id.viewAvatarCircle)?.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(66, Color.red(sobreGradiente), Color.green(sobreGradiente), Color.blue(sobreGradiente)))
            }
            val nome = p.getString("nome_usuario", null)
                ?: com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.displayName
            findViewById<TextView>(R.id.tvAvatarIniciais)?.apply {
                text = nome?.trim()?.firstOrNull()?.uppercaseChar()?.toString() ?: "👤"
                setTextColor(sobreGradiente)
            }
        } catch (_: Throwable) {}

        // ── ABAS DE PERÍODO — trilho translúcido + pílula ativa sólida ─────
        try {
            findViewById<android.view.View>(R.id.trilhoPeriodo)?.background = GradientDrawable().apply {
                setColor(Color.argb(46, Color.red(sobreGradiente), Color.green(sobreGradiente), Color.blue(sobreGradiente)))
                cornerRadius = 21f * dp
            }
        } catch (_: Throwable) {}

        // ── NAVEGAÇÃO DE DATA — pílula clara derivada do accent ────────────
        try {
            findViewById<android.view.View>(R.id.pilulaData)?.background = GradientDrawable().apply {
                setColor(Color.argb(30, Color.red(accent), Color.green(accent), Color.blue(accent)))
                cornerRadius = 23f * dp
            }
        } catch (_: Throwable) {}
        try { findViewById<ImageButton>(R.id.btnNavAnterior)?.setColorFilter(accent) } catch (_: Throwable) {}
        try { findViewById<ImageButton>(R.id.btnNavProximo)?.setColorFilter(accent)  } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvNavLabel)?.setTextColor(accent) } catch (_: Throwable) {}

        // ── RESUMO ──────────────────────────────────────────────────────
        try { findViewById<TextView>(R.id.tvHistTotalValor)?.setTextColor(txtW) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvHistTotalLabel)?.setTextColor(txtG) } catch (_: Throwable) {}
        try {
            findViewById<android.view.View>(R.id.cardStats)?.background = GradientDrawable().apply {
                setColor(bgCard); cornerRadius = 18f * dp
                setStroke((1f * dp).toInt(), border)
            }
        } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvHistQtdCorridas)?.setTextColor(accent) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvHistKmTotal)?.setTextColor(txtW) } catch (_: Throwable) {}
        try { findViewById<TextView>(R.id.tvHistMediaCorrida)?.setTextColor(ThemeHelper.cor("accent_green", p)) } catch (_: Throwable) {}

        atualizarChips()
    }

    /** Escolhe preto ou branco conforme a luminância da cor recebida — usado
     *  pra garantir contraste sobre o gradiente, sem depender de nenhuma
     *  cor fixa: é sempre calculado a partir do accent atual do tema. */
    private fun corContraste(cor: Int): Int {
        val luminancia = (0.299 * Color.red(cor) + 0.587 * Color.green(cor) + 0.114 * Color.blue(cor)) / 255
        return if (luminancia > 0.6) Color.BLACK else Color.WHITE
    }

    /** Escurece uma cor multiplicando o brilho (V do HSV) pelo fator — usado
     *  pra gerar o 2º stop do gradiente a partir do accent do próprio tema. */
    private fun escurecer(cor: Int, fator: Float): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(cor, hsv)
        hsv[2] *= fator
        return Color.HSVToColor(Color.alpha(cor), hsv)
    }

    // ── ADICIONAR CORRIDA MANUAL ──────────────────────────────
    private fun mostrarDialogoAdicionarCorrida() {
        // Reutilizar a lógica de corrida manual da FinanceActivity via diálogo próprio
        val p      = prefs
        val accent = ThemeHelper.cor("accent_gold", p)
        val bgCard = ThemeHelper.cor("bg_card", p)
        val txtW   = ThemeHelper.cor("text_white", p)
        val txtG   = ThemeHelper.cor("text_gray", p)
        val dp     = resources.displayMetrics.density

        val root = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            background  = android.graphics.drawable.GradientDrawable().apply {
                setColor(bgCard); cornerRadius = 20f * dp
                setStroke((1.5f * dp).toInt(), accent)
            }
            setPadding((24*dp).toInt(), (20*dp).toInt(), (24*dp).toInt(), (20*dp).toInt())
        }

        root.addView(android.widget.TextView(this).apply {
            text = "➕  Adicionar corrida"
            textSize = 17f; setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(accent); setPadding(0, 0, 0, (16*dp).toInt())
        })

        fun campo(label: String, hint: String, tipo: Int): android.widget.EditText {
            root.addView(android.widget.TextView(this).apply {
                text = label; textSize = 11f; setTextColor(txtG)
                setPadding(0, 0, 0, (4*dp).toInt())
            })
            return android.widget.EditText(this).apply {
                this.hint = hint; inputType = tipo
                setTextColor(txtW); setHintTextColor(txtG)
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(android.graphics.Color.argb(40,
                        android.graphics.Color.red(accent),
                        android.graphics.Color.green(accent),
                        android.graphics.Color.blue(accent)))
                    cornerRadius = 8f * dp
                }
                setPadding((10*dp).toInt(), (8*dp).toInt(), (10*dp).toInt(), (8*dp).toInt())
                layoutParams = android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                    setMargins(0, 0, 0, (12*dp).toInt())
                }
            }.also { root.addView(it) }
        }

        val etValor = campo("Valor (R$)", "Ex: 8,50", android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val etKm    = campo("Quilometragem", "Ex: 2.5", android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val etOrig  = campo("Origem", "Bairro ou endereço", android.text.InputType.TYPE_CLASS_TEXT)
        val etDest  = campo("Destino", "Bairro ou endereço", android.text.InputType.TYPE_CLASS_TEXT)

        // Forma de pagamento
        root.addView(android.widget.TextView(this).apply {
            text = "Forma de pagamento"; textSize = 11f; setTextColor(txtG)
            setPadding(0, 0, 0, (4*dp).toInt())
        })
        val spinner = android.widget.Spinner(this).apply {
            val formas = listOf("Dinheiro", "PIX", "Cartão", "Online")
            adapter = android.widget.ArrayAdapter(this@HistoryActivity,
                android.R.layout.simple_spinner_item, formas).also {
                it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            layoutParams = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                (44*dp).toInt()).apply { setMargins(0, 0, 0, (16*dp).toInt()) }
        }
        root.addView(spinner)

        val dialog = android.app.AlertDialog.Builder(this).setView(root).create()
        dialog.window?.setBackgroundDrawable(
            android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT))

        val rowBtns = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER
        }
        fun btnRow(texto: String, cor: Int, fill: Boolean) = android.widget.TextView(this).apply {
            text = texto; textSize = 14f
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = android.view.Gravity.CENTER
            layoutParams = android.widget.LinearLayout.LayoutParams(0,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins((4*dp).toInt(), 0, (4*dp).toInt(), 0)
            }
            setPadding((12*dp).toInt(), (12*dp).toInt(), (12*dp).toInt(), (12*dp).toInt())
            background = android.graphics.drawable.GradientDrawable().apply {
                if (fill) setColor(cor) else setColor(android.graphics.Color.TRANSPARENT)
                cornerRadius = 10f * dp
                if (!fill) setStroke((1.5f * dp).toInt(), cor)
            }
            setTextColor(if (fill) android.graphics.Color.parseColor("#000000") else cor)
        }

        val btnCancelar = btnRow("Cancelar", accent, false)
        val btnSalvar   = btnRow("Salvar ✓", accent, true)
        rowBtns.addView(btnCancelar); rowBtns.addView(btnSalvar)
        root.addView(rowBtns)

        dialog.show()
        btnCancelar.setOnClickListener { dialog.dismiss() }
        btnSalvar.setOnClickListener {
            val valor = etValor.text.toString().replace(",", ".").toFloatOrNull() ?: 0f
            if (valor <= 0f) { FluxoToast.erro(this, "Informe o valor da corrida"); return@setOnClickListener }
            val km    = etKm.text.toString().replace(",", ".").toFloatOrNull() ?: 0f
            val gpkm  = if (km > 0f) valor / km else 0f
            val forma = spinner.selectedItem.toString()
            val prefs2 = getSharedPreferences("FluxoApp", android.content.Context.MODE_PRIVATE)
            val minKm  = prefs2.getFloat("minimo_km", 1.20f)
            val minVal = prefs2.getFloat("minimo_valor", 0f)
            val vale   = gpkm >= minKm && (minVal <= 0f || valor >= minVal)
            val agora  = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
            val hoje   = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(java.util.Date())
            val cal    = java.util.Calendar.getInstance()
            val mes    = "%02d/%04d".format(cal.get(java.util.Calendar.MONTH) + 1, cal.get(java.util.Calendar.YEAR))
            val ano    = "%04d".format(cal.get(java.util.Calendar.YEAR))
            db.inserirCorrida(Corrida(
                valor = valor, kmTotal = km, ganhoPorKm = gpkm, valeAPena = vale,
                origem = etOrig.text.toString(), destino = etDest.text.toString(),
                formaPagamento = forma, passageiro = "", horaInicio = agora,
                horaFim = agora, tempoExecucao = "",
                data = hoje, hora = agora, mes = mes, ano = ano,
                timestamp = System.currentTimeMillis()
            ))
            dialog.dismiss()
            carregarPeriodoAtual()
            FluxoToast.sucesso(this, "Corrida adicionada!")
        }
    }

}
