package com.fluxoapp

import android.content.Context
import android.content.Intent
import com.google.firebase.firestore.FirebaseFirestore

object AppStartupManager {

    fun verificarConfigApp(context: Context, versionCode: Int, onOk: () -> Unit) {
        FirebaseFirestore.getInstance()
            .document("config/app")
            .get()
            .addOnSuccessListener { doc ->
                if (!doc.exists()) { onOk(); return@addOnSuccessListener }
                val manutencao   = doc.getBoolean("manutencao") ?: false
                val versaoMinima = doc.getLong("versaoMinima")?.toInt() ?: 0
                val msgMaint     = doc.getString("mensagemManutencao") ?: "App em manutenção. Volte em breve!"
                val msgVersao    = doc.getString("mensagemVersao")     ?: "Nova versão disponível. Atualize o app."
                when {
                    manutencao -> context.startActivity(
                        Intent(context, MaintenanceActivity::class.java).apply {
                            putExtra("mensagem", msgMaint)
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        })
                    versionCode < versaoMinima -> context.startActivity(
                        Intent(context, UpdateRequiredActivity::class.java).apply {
                            putExtra("mensagem", msgVersao)
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        })
                    else -> onOk()
                }
            }
            .addOnFailureListener { onOk() }
    }

    fun salvarDeviceInfo(uid: String) {
        val info = hashMapOf(
            "brand"          to android.os.Build.BRAND,
            "model"          to android.os.Build.MODEL,
            "androidVersion" to android.os.Build.VERSION.RELEASE,
            "sdkVersion"     to android.os.Build.VERSION.SDK_INT,
            "appVersion"     to BuildConfig.VERSION_NAME,
            "versionCode"    to BuildConfig.VERSION_CODE
        )
        FirebaseFirestore.getInstance().document("users/$uid")
            .update("deviceInfo", info, "lastSeen", com.google.firebase.Timestamp.now())
    }

    fun atualizarLastSeen(uid: String) {
        FirebaseFirestore.getInstance().document("users/$uid")
            .update("lastSeen", com.google.firebase.Timestamp.now())
    }
}
