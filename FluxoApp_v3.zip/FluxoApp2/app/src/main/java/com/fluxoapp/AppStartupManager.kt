package com.fluxoapp

import android.content.Context
import android.content.Intent
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions

object AppStartupManager {

    fun verificarConfigApp(context: Context, versionCode: Int, onOk: () -> Unit) {
        FirebaseFirestore.getInstance()
            .document("config/app")
            .get()
            .addOnSuccessListener { doc ->
                if (!doc.exists()) { onOk(); return@addOnSuccessListener }
                val manutencao   = doc.getBoolean("manutencao") ?: false
                val versaoMinima = doc.getLong("versaoMinima")?.toInt() ?: 0
                val msgMaint     = doc.getString("mensagemManutencao") ?: "App em manutenção. Volte em breve!"
                val msgVersao    = doc.getString("mensagemVersao")     ?: "Nova versão disponível. Atualize o app."
                when {
                    manutencao -> context.startActivity(
                        Intent(context, MaintenanceActivity::class.java).apply {
                            putExtra("mensagem", msgMaint)
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        })
                    versionCode < versaoMinima -> context.startActivity(
                        Intent(context, UpdateRequiredActivity::class.java).apply {
                            putExtra("mensagem", msgVersao)
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        })
                    else -> onOk()
                }
            }
            .addOnFailureListener { onOk() }
    }

    /**
     * Salva informações do dispositivo e versão do app no Firestore.
     * Chamado no startup e após atualização de versão.
     */
    fun salvarDeviceInfo(uid: String) {
        val db = FirebaseFirestore.getInstance()
        val info = hashMapOf(
            "brand"          to android.os.Build.BRAND,
            "model"          to android.os.Build.MODEL,
            "androidVersion" to android.os.Build.VERSION.RELEASE,
            "sdkVersion"     to android.os.Build.VERSION.SDK_INT,
            "appVersion"     to BuildConfig.VERSION_NAME,
            "versionCode"    to BuildConfig.VERSION_CODE
        )
        db.document("users/$uid")
            .update(
                "deviceInfo", info,
                "lastSeen",   Timestamp.now(),
                "atualizadoEm", Timestamp.now()
            )
            .addOnFailureListener {
                // Documento pode não existir ainda — usar set merge
                db.document("users/$uid").set(
                    mapOf("deviceInfo" to info, "lastSeen" to Timestamp.now()),
                    SetOptions.merge()
                )
            }
    }

    /**
     * Atualiza lastSeen e o campo atualizadoEm.
     * Chamado a cada onResume da MainActivity.
     */
    fun atualizarLastSeen(uid: String) {
        FirebaseFirestore.getInstance().document("users/$uid")
            .update("lastSeen", Timestamp.now())
            .addOnFailureListener { /* silencioso — pode não ter conexão */ }
    }

    /**
     * Registra o trial no historicoPlanos quando o usuário é criado.
     * Painel admin usa essa subcoleção para mostrar histórico de planos.
     */
    fun registrarTrialHistorico(uid: String) {
        val db  = FirebaseFirestore.getInstance()
        val agora = Timestamp.now()
        val expiracao = Timestamp(agora.seconds + (7 * 86400), 0)
        db.collection("users").document(uid)
            .collection("historicoPlanos")
            .add(mapOf(
                "plano"      to "trial",
                "valor"      to 0.0,
                "ativadoEm"  to agora,
                "expiracao"  to expiracao,
                "origem"     to "app_registro"
            ))
    }

    /**
     * Verifica se o usuário foi bloqueado ou teve plano alterado pelo admin
     * durante a sessão. Chama o callback com true se deve forçar logout/restrição.
     */
    fun verificarStatusRemoto(uid: String, onBloqueado: () -> Unit, onExpirado: () -> Unit) {
        FirebaseFirestore.getInstance().document("users/$uid")
            .get()
            .addOnSuccessListener { doc ->
                if (!doc.exists()) return@addOnSuccessListener
                val status = doc.getString("status") ?: "ativo"
                val plano  = doc.getString("plano")  ?: "trial"
                val expTs  = doc.getTimestamp("dataExpiracao")

                when {
                    status == "bloqueado" || plano == "bloqueado" -> onBloqueado()
                    expTs != null && expTs.toDate().before(java.util.Date()) -> onExpirado()
                }
            }
            .addOnFailureListener { /* sem conexão — não restringir */ }
    }
}
