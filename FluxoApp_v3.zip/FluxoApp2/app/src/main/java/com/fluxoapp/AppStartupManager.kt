package com.fluxoapp

import android.content.Context
import android.content.Intent
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions

object AppStartupManager {

    fun verificarConfigApp(context: Context, versionCode: Int, onOk: () -> Unit) {
        FirebaseFirestore.getInstance()
            .document("config/app")
            .get()
            .addOnSuccessListener { doc ->
                if (!doc.exists()) { onOk(); return@addOnSuccessListener }
                val manutencao   = doc.getBoolean("manutencao") ?: false
                val versaoMinima = doc.getLong("versaoMinima")?.toInt() ?: 0
                val msgMaint     = doc.getString("mensagemManutencao") ?: "App em manutenção. Volte em breve!"
                val msgVersao    = doc.getString("mensagemVersao")     ?: "Nova versão disponível. Atualize o app."
                when {
                    manutencao -> context.startActivity(
                        Intent(context, MaintenanceActivity::class.java).apply {
                            putExtra("mensagem", msgMaint)
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        })
                    versionCode < versaoMinima -> context.startActivity(
                        Intent(context, UpdateRequiredActivity::class.java).apply {
                            putExtra("mensagem", msgVersao)
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        })
                    else -> onOk()
                }
            }
            .addOnFailureListener { onOk() }
    }

    /**
     * Salva informações do dispositivo e versão do app no Firestore.
     * Chamado no startup e após atualização de versão.
     */
    /**
     * Salva informações do dispositivo e versão do app no Firestore.
     * Chamado no login/cadastro E a cada onResume do app (via lógica
     * inteligente abaixo) — antes só era salvo uma vez no login, então se
     * o motorista atualizasse o app ou o Android, o painel admin nunca
     * mais recebia essa informação atualizada.
     *
     * Pra não gastar escrita no Firestore toda vez que o app volta ao
     * primeiro plano, só reenvia quando algo de fato mudou (comparado com
     * o último valor salvo localmente) ou depois de 24h, como garantia.
     */
    fun salvarDeviceInfo(uid: String, context: android.content.Context? = null) {
        val db = FirebaseFirestore.getInstance()
        val info = hashMapOf(
            "brand"          to android.os.Build.BRAND,
            "model"          to android.os.Build.MODEL,
            "androidVersion" to android.os.Build.VERSION.RELEASE,
            "sdkVersion"     to android.os.Build.VERSION.SDK_INT,
            "appVersion"     to BuildConfig.VERSION_NAME,
            "versionCode"    to BuildConfig.VERSION_CODE
        )

        // Verifica se precisa mesmo escrever (evita chamadas repetidas
        // sempre que o app volta ao primeiro plano)
        if (context != null) {
            val prefs = context.getSharedPreferences("FluxoApp", android.content.Context.MODE_PRIVATE)
            val assinaturaAtual = "${android.os.Build.MODEL}|${BuildConfig.VERSION_CODE}|${android.os.Build.VERSION.SDK_INT}"
            val assinaturaSalva = prefs.getString("device_info_assinatura", "")
            val ultimoEnvioMs   = prefs.getLong("device_info_ultimo_envio", 0L)
            val passou24h       = System.currentTimeMillis() - ultimoEnvioMs > 24 * 60 * 60 * 1000L

            if (assinaturaAtual == assinaturaSalva && !passou24h) {
                // Nada mudou e ainda não passou 1 dia — não precisa reenviar
                return
            }
            prefs.edit()
                .putString("device_info_assinatura", assinaturaAtual)
                .putLong("device_info_ultimo_envio", System.currentTimeMillis())
                .apply()
        }

        db.document("users/$uid")
            .update(
                "deviceInfo", info,
                "lastSeen",   Timestamp.now(),
                "atualizadoEm", Timestamp.now()
            )
            .addOnFailureListener {
                // Documento pode não existir ainda — usar set merge
                db.document("users/$uid").set(
                    mapOf("deviceInfo" to info, "lastSeen" to Timestamp.now()),
                    SetOptions.merge()
                )
            }
    }

    /**
     * Atualiza lastSeen e o campo atualizadoEm.
     * Chamado a cada onResume da MainActivity.
     */
    fun atualizarLastSeen(uid: String) {
        FirebaseFirestore.getInstance().document("users/$uid")
            .update("lastSeen", Timestamp.now())
            .addOnFailureListener { /* silencioso — pode não ter conexão */ }
    }

    /**
     * Registra o trial no historicoPlanos quando o usuário é criado.
     * Painel admin usa essa subcoleção para mostrar histórico de planos.
     */
    fun registrarTrialHistorico(uid: String) {
        val db  = FirebaseFirestore.getInstance()
        val agora = Timestamp.now()
        val expiracao = Timestamp(agora.seconds + (7 * 86400), 0)
        db.collection("users").document(uid)
            .collection("historicoPlanos")
            .add(mapOf(
                "plano"      to "trial",
                "valor"      to 0.0,
                "ativadoEm"  to agora,
                "expiracao"  to expiracao,
                "origem"     to "app_registro"
            ))
    }

    /**
     * Verifica se o usuário foi bloqueado ou teve plano alterado pelo admin
     * durante a sessão. Chama o callback com true se deve forçar logout/restrição.
     */
    fun verificarStatusRemoto(uid: String, onBloqueado: () -> Unit, onExpirado: () -> Unit) {
        FirebaseFirestore.getInstance().document("users/$uid")
            .get()
            .addOnSuccessListener { doc ->
                if (!doc.exists()) return@addOnSuccessListener
                val status = doc.getString("status") ?: "ativo"
                val plano  = doc.getString("plano")  ?: "trial"
                val expTs  = doc.getTimestamp("dataExpiracao")

                when {
                    status == "bloqueado" || plano == "bloqueado" -> onBloqueado()
                    expTs != null && expTs.toDate().before(java.util.Date()) -> onExpirado()
                }
            }
            .addOnFailureListener { /* sem conexão — não restringir */ }
    }
}
