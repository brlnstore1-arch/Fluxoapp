package com.fluxoapp

import android.util.Log

/**
 * Logging centralizado — substitui os catch {} vazios.
 * Em produção, integrar Firebase Crashlytics aqui quando disponível.
 */
object FluxoLog {

    private const val TAG = "FluxoApp"

    fun e(local: String, erro: Throwable) {
        Log.e(TAG, "[$local] ${erro.message}", erro)
        // FirebaseCrashlytics.getInstance().recordException(erro) // futuro
    }

    fun w(local: String, msg: String) {
        Log.w(TAG, "[$local] $msg")
    }

    fun d(local: String, msg: String) {
        Log.d(TAG, "[$local] $msg")
    }
}

/**
 * Extension para executar um bloco com logging de erro.
 * Uso: runSafe("nomeDoContexto") { minhaOperacao() }
 */
inline fun <T> runSafe(local: String, block: () -> T?): T? = try {
    block()
} catch (e: Throwable) {
    FluxoLog.e(local, e)
    null
}
