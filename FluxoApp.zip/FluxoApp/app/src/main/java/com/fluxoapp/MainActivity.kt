package com.fluxoapp

import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("FluxoApp", MODE_PRIVATE)
        db = DatabaseHelper(this)
        configurarBotoes()
        atualizarStatus()
        atualizarStats()

        // Pedir permissão de overlay automaticamente se não tiver
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
        } else {
            // Iniciar botão flutuante
            startService(Intent(this, FloatingEarningsService::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        atualizarStatus()
        atualizarStats()
    }

    private fun configurarBotoes() {
        // Botão acessibilidade
        findViewById<Button>(R.id.btnPermissaoAcessibilidade).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        // Botão overlay
        findViewById<Button>(R.id.btnPermissaoOverlay).setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
        }

        // Salvar mínimo
        findViewById<Button>(R.id.btnSalvar).setOnClickListener {
            val etMinimo = findViewById<EditText>(R.id.etMinimoPorKm)
            val valor = etMinimo.text.toString().replace(",", ".").toFloatOrNull()
            if (valor != null && valor > 0) {
                prefs.edit().putFloat("minimo_km", valor).apply()
                Toast.makeText(this, "✅ Salvo: R$ ${"%.2f".format(valor)}/km", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "⚠️ Digite um valor válido!", Toast.LENGTH_SHORT).show()
            }
        }

        // Botão ligar/desligar serviço
        val switchServico = findViewById<Switch>(R.id.switchServico)
        switchServico.isChecked = prefs.getBoolean("servico_ativo", true)
        switchServico.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("servico_ativo", isChecked).apply()
            Toast.makeText(this,
                if (isChecked) "✅ Serviço ATIVADO" else "⏸ Serviço PAUSADO",
                Toast.LENGTH_SHORT).show()
            atualizarStatus()
        }

        // Botão auto-aceitar
        val switchAutoAceitar = findViewById<Switch>(R.id.switchAutoAceitar)
        switchAutoAceitar.isChecked = prefs.getBoolean("auto_aceitar", false)
        switchAutoAceitar.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("auto_aceitar", isChecked).apply()
            Toast.makeText(this,
                if (isChecked) "🤖 Auto-aceitar ATIVADO" else "🖐 Auto-aceitar DESATIVADO",
                Toast.LENGTH_SHORT).show()
        }

        // Zerar dia
        findViewById<TextView>(R.id.btnZerar).setOnClickListener {
            Toast.makeText(this, "Histórico fica salvo no banco de dados!", Toast.LENGTH_SHORT).show()
        }

        // Ver histórico
        findViewById<Button>(R.id.btnHistorico).setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }

        // Carregar mínimo atual
        val minimo = prefs.getFloat("minimo_km", 1.20f)
        findViewById<EditText>(R.id.etMinimoPorKm).setText("%.2f".format(minimo))
    }

    private fun atualizarStatus() {
        val tvStatus = findViewById<TextView>(R.id.tvStatus)
        val btnAcess = findViewById<Button>(R.id.btnPermissaoAcessibilidade)
        val btnOverlay = findViewById<Button>(R.id.btnPermissaoOverlay)
        val servicoAtivo = prefs.getBoolean("servico_ativo", true)

        val acessAtivo = isAccessibilityEnabled()
        val overlayAtivo = Settings.canDrawOverlays(this)

        btnAcess.visibility = android.view.View.GONE
        btnOverlay.visibility = android.view.View.GONE

        when {
            !servicoAtivo -> {
                tvStatus.text = "⏸ Serviço pausado"
            }
            !acessAtivo && !overlayAtivo -> {
                tvStatus.text = "🔴 Ative Acessibilidade e Sobreposição!"
                btnAcess.visibility = android.view.View.VISIBLE
                btnOverlay.visibility = android.view.View.VISIBLE
            }
            !acessAtivo -> {
                tvStatus.text = "🔴 Ative a Acessibilidade!"
                btnAcess.visibility = android.view.View.VISIBLE
            }
            !overlayAtivo -> {
                tvStatus.text = "🟡 Ative a sobreposição de tela!"
                btnOverlay.visibility = android.view.View.VISIBLE
            }
            else -> {
                tvStatus.text = "🟢 Monitorando o Maxim!"
            }
        }
    }

    private fun atualizarStats() {
        val corridas = db.buscarHoje()
        val resumo = db.resumo(corridas)
        findViewById<TextView>(R.id.tvGanhoHoje).text = "R$ ${"%.2f".format(resumo["total"] ?: 0f)}"
        findViewById<TextView>(R.id.tvTotalCorridas).text = "${(resumo["corridas"] ?: 0f).toInt()}"
        findViewById<TextView>(R.id.tvMediaCorrida).text = "R$ ${"%.2f".format(resumo["media_corrida"] ?: 0f)}"
        findViewById<TextView>(R.id.tvMediaKm).text = "R$ ${"%.2f".format(resumo["media_km"] ?: 0f)}"
    }

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.contains("fluxoapp", ignoreCase = true) ||
               enabled.contains("MaximAccessibilityService", ignoreCase = true)
    }
}
