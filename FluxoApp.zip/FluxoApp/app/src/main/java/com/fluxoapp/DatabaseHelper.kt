package com.fluxoapp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.*

data class Corrida(
    val id: Long = 0,
    val valor: Float,
    val kmTotal: Float,
    val ganhoPorKm: Float,
    val valeAPena: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val data: String = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date()),
    val hora: String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()),
    val mes: String = SimpleDateFormat("MM/yyyy", Locale.getDefault()).format(Date()),
    val ano: String = SimpleDateFormat("yyyy", Locale.getDefault()).format(Date())
)

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, "fluxoapp.db", null, 2) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE corridas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                valor REAL,
                km_total REAL,
                ganho_por_km REAL,
                vale_a_pena INTEGER,
                timestamp INTEGER,
                data TEXT,
                hora TEXT,
                mes TEXT,
                ano TEXT
            )
        """)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS corridas")
        onCreate(db)
    }

    fun inserirCorrida(corrida: Corrida): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("valor", corrida.valor)
            put("km_total", corrida.kmTotal)
            put("ganho_por_km", corrida.ganhoPorKm)
            put("vale_a_pena", if (corrida.valeAPena) 1 else 0)
            put("timestamp", corrida.timestamp)
            put("data", corrida.data)
            put("hora", corrida.hora)
            put("mes", corrida.mes)
            put("ano", corrida.ano)
        }
        return db.insert("corridas", null, values)
    }

    fun buscarPorPeriodo(dataInicio: Long, dataFim: Long): List<Corrida> {
        val lista = mutableListOf<Corrida>()
        val db = readableDatabase
        val cursor = db.query(
            "corridas", null,
            "timestamp >= ? AND timestamp <= ?",
            arrayOf(dataInicio.toString(), dataFim.toString()),
            null, null, "timestamp DESC"
        )
        while (cursor.moveToNext()) {
            lista.add(Corrida(
                id = cursor.getLong(cursor.getColumnIndexOrThrow("id")),
                valor = cursor.getFloat(cursor.getColumnIndexOrThrow("valor")),
                kmTotal = cursor.getFloat(cursor.getColumnIndexOrThrow("km_total")),
                ganhoPorKm = cursor.getFloat(cursor.getColumnIndexOrThrow("ganho_por_km")),
                valeAPena = cursor.getInt(cursor.getColumnIndexOrThrow("vale_a_pena")) == 1,
                timestamp = cursor.getLong(cursor.getColumnIndexOrThrow("timestamp")),
                data = cursor.getString(cursor.getColumnIndexOrThrow("data")),
                hora = cursor.getString(cursor.getColumnIndexOrThrow("hora")),
                mes = cursor.getString(cursor.getColumnIndexOrThrow("mes")),
                ano = cursor.getString(cursor.getColumnIndexOrThrow("ano"))
            ))
        }
        cursor.close()
        return lista
    }

    fun buscarHoje(): List<Corrida> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
        val inicio = cal.timeInMillis
        cal.set(Calendar.HOUR_OF_DAY, 23); cal.set(Calendar.MINUTE, 59); cal.set(Calendar.SECOND, 59)
        return buscarPorPeriodo(inicio, cal.timeInMillis)
    }

    fun buscarSemana(): List<Corrida> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_WEEK, cal.firstDayOfWeek)
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
        val inicio = cal.timeInMillis
        return buscarPorPeriodo(inicio, System.currentTimeMillis())
    }

    fun buscarMes(mes: Int, ano: Int): List<Corrida> {
        val cal = Calendar.getInstance()
        cal.set(ano, mes, 1, 0, 0, 0)
        val inicio = cal.timeInMillis
        cal.set(ano, mes + 1, 1, 0, 0, 0)
        return buscarPorPeriodo(inicio, cal.timeInMillis)
    }

    fun buscarAno(ano: Int): List<Corrida> {
        val cal = Calendar.getInstance()
        cal.set(ano, 0, 1, 0, 0, 0)
        val inicio = cal.timeInMillis
        cal.set(ano + 1, 0, 1, 0, 0, 0)
        return buscarPorPeriodo(inicio, cal.timeInMillis)
    }

    fun resumo(corridas: List<Corrida>): Map<String, Float> {
        val total = corridas.sumOf { it.valor.toDouble() }.toFloat()
        val kmTotal = corridas.sumOf { it.kmTotal.toDouble() }.toFloat()
        val mediaKm = if (kmTotal > 0) total / kmTotal else 0f
        val mediaCorrida = if (corridas.isNotEmpty()) total / corridas.size else 0f
        return mapOf(
            "total" to total,
            "corridas" to corridas.size.toFloat(),
            "km_total" to kmTotal,
            "media_km" to mediaKm,
            "media_corrida" to mediaCorrida
        )
    }
}
