package com.fluxoapp

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class HistoryActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private lateinit var listView: ListView
    private lateinit var tvResumo: TextView
    private lateinit var tvTitulo: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)
        db = DatabaseHelper(this)

        listView = findViewById(R.id.listViewCorridas)
        tvResumo = findViewById(R.id.tvResumo)
        tvTitulo = findViewById(R.id.tvTitulo)

        findViewById<Button>(R.id.btnHoje).setOnClickListener { carregarHoje() }
        findViewById<Button>(R.id.btnSemana).setOnClickListener { carregarSemana() }
        findViewById<Button>(R.id.btnMes).setOnClickListener { carregarMesAtual() }
        findViewById<Button>(R.id.btnAno).setOnClickListener { carregarAnoAtual() }
        findViewById<Button>(R.id.btnPersonalizado).setOnClickListener { abrirPersonalizado() }
        findViewById<ImageButton>(R.id.btnVoltar).setOnClickListener { finish() }

        carregarHoje()
    }

    private fun carregarHoje() {
        tvTitulo.text = "HOJE"
        exibirCorridas(db.buscarHoje())
    }

    private fun carregarSemana() {
        tvTitulo.text = "ESTA SEMANA"
        exibirCorridas(db.buscarSemana())
    }

    private fun carregarMesAtual() {
        val cal = Calendar.getInstance()
        tvTitulo.text = "ESTE MÊS"
        exibirCorridas(db.buscarMes(cal.get(Calendar.MONTH), cal.get(Calendar.YEAR)))
    }

    private fun carregarAnoAtual() {
        val ano = Calendar.getInstance().get(Calendar.YEAR)
        tvTitulo.text = "ANO $ano"
        exibirCorridas(db.buscarAno(ano))
    }

    private fun abrirPersonalizado() {
        val cal = Calendar.getInstance()
        DatePickerDialog(this, { _, ano, mes, dia ->
            val inicio = Calendar.getInstance().apply { set(ano, mes, dia, 0, 0, 0) }.timeInMillis
            DatePickerDialog(this, { _, ano2, mes2, dia2 ->
                val fim = Calendar.getInstance().apply { set(ano2, mes2, dia2, 23, 59, 59) }.timeInMillis
                tvTitulo.text = "PERSONALIZADO"
                exibirCorridas(db.buscarPorPeriodo(inicio, fim))
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun exibirCorridas(corridas: List<Corrida>) {
        val resumo = db.resumo(corridas)
        tvResumo.text = buildString {
            append("💰 Total: R$ ${"%.2f".format(resumo["total"])}\n")
            append("🚗 Corridas: ${(resumo["corridas"] ?: 0f).toInt()}\n")
            append("📏 KM Total: ${"%.1f".format(resumo["km_total"])} km\n")
            append("⚡ Média/km: R$ ${"%.2f".format(resumo["media_km"])}\n")
            append("📊 Média/corrida: R$ ${"%.2f".format(resumo["media_corrida"])}")
        }

        val itens = corridas.map { c ->
            val emoji = if (c.valeAPena) "✅" else "❌"
            "$emoji ${c.hora} — R$ ${"%.2f".format(c.valor)} | ${"%.1f".format(c.kmTotal)}km | R$ ${"%.2f".format(c.ganhoPorKm)}/km"
        }

        listView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, itens).also {
            listView.adapter = it
        }

        if (corridas.isEmpty()) {
            tvResumo.text = "Nenhuma corrida registrada neste período."
        }
    }
}
