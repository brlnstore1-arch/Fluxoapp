package com.fluxoapp

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class MaximAccessibilityService : AccessibilityService() {

    private lateinit var prefs: SharedPreferences
    private lateinit var db: DatabaseHelper
    private var overlayVisivel = false
    private var ultimoHashCorrida = ""
    private var ultimoTempoProcessado = 0L
    private val DEBOUNCE_MS = 3000L // 3 segundos entre processamentos
    private val handler = Handler(Looper.getMainLooper())
    private var corridaAtual: DadosCorrida? = null

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("FluxoApp", MODE_PRIVATE)
        db = DatabaseHelper(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return

        // Verificar se o serviço está ativado
        if (!prefs.getBoolean("servico_ativo", true)) {
            if (overlayVisivel) esconderOverlay()
            return
        }

        val tipo = event.eventType
        if (tipo != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            tipo != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) return

        // Debounce - evita processar múltiplas vezes
        val agora = System.currentTimeMillis()
        if (agora - ultimoTempoProcessado < DEBOUNCE_MS) return

        val root = rootInActiveWindow ?: return
        val textos = coletarTodosTextos(root)

        val temPedido = textos.any { t ->
            t.contains("Pedido atribuído", ignoreCase = true) ||
            t.contains("Pedido atribuido", ignoreCase = true) ||
            t.contains("atribuído", ignoreCase = true) ||
            t.contains("Nova corrida", ignoreCase = true) ||
            t.contains("Nova ordem", ignoreCase = true) ||
            t.contains("New order", ignoreCase = true) ||
            t.contains("Recusar", ignoreCase = true) ||
            (t.contains("Aceitar", ignoreCase = true) && textos.any { it.contains("km", ignoreCase = true) })
        }

        val temValor = textos.any { it.contains("R$", ignoreCase = true) }
        val temKm = textos.any { it.contains("km", ignoreCase = true) }

        if (temPedido || (temValor && temKm)) {
            val dados = extrairDadosCorrida(textos) ?: return

            // Gerar hash único da corrida para evitar duplicatas
            val hash = "${dados.valor}_${dados.kmCorrida}"
            if (hash == ultimoHashCorrida) return

            ultimoHashCorrida = hash
            ultimoTempoProcessado = agora
            corridaAtual = dados

            salvarCorrida(dados)
            mostrarOverlay(dados)

            // Auto-aceitar se ativado
            val autoAceitar = prefs.getBoolean("auto_aceitar", false)
            val minimo = prefs.getFloat("minimo_km", 1.20f)
            val kmTotal = dados.kmBuscar + dados.kmCorrida
            val ganhoPorKm = if (kmTotal > 0) dados.valor / kmTotal else 0f

            if (autoAceitar && ganhoPorKm >= minimo) {
                handler.postDelayed({ clicarAceitar(root) }, 1500)
            }

        } else {
            if (overlayVisivel) {
                // Reset hash quando corrida desaparecer
                ultimoHashCorrida = ""
                esconderOverlay()
            }
        }
    }

    private fun coletarTodosTextos(node: AccessibilityNodeInfo): List<String> {
        val lista = mutableListOf<String>()
        fun percorrer(n: AccessibilityNodeInfo) {
            n.text?.toString()?.trim()?.let { if (it.isNotBlank()) lista.add(it) }
            for (i in 0 until n.childCount) {
                val filho = n.getChild(i) ?: continue
                percorrer(filho)
                filho.recycle()
            }
        }
        percorrer(node)
        return lista
    }

    private fun extrairDadosCorrida(textos: List<String>): DadosCorrida? {
        val padraoValor = Regex("""R\$\s*(\d+[,.]?\d*)""")
        val padraoKm = Regex("""(\d+[,.]?\d*)\s*km""", RegexOption.IGNORE_CASE)

        var valor: Float? = null
        val kms = mutableListOf<Float>()

        for (texto in textos) {
            if (valor == null) {
                padraoValor.find(texto)?.let {
                    val v = it.groupValues[1].replace(",", ".").toFloatOrNull()
                    if (v != null && v > 0) valor = v
                }
            }
            padraoKm.findAll(texto).forEach {
                it.groupValues[1].replace(",", ".").toFloatOrNull()?.let { km ->
                    if (km >= 0) kms.add(km)
                }
            }
        }

        val kmBuscar = kms.getOrElse(0) { 0f }
        val kmCorrida = kms.getOrElse(1) { kms.getOrElse(0) { 0f } }

        return if (valor != null && valor!! > 0) {
            DadosCorrida(valor = valor!!, kmBuscar = kmBuscar, kmCorrida = kmCorrida)
        } else null
    }

    private fun clicarAceitar(root: AccessibilityNodeInfo) {
        fun procurar(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
            val texto = node.text?.toString() ?: ""
            val desc = node.contentDescription?.toString() ?: ""
            if ((texto.contains("Aceitar", ignoreCase = true) ||
                 desc.contains("Aceitar", ignoreCase = true)) &&
                node.isClickable) return node
            for (i in 0 until node.childCount) {
                val filho = node.getChild(i) ?: continue
                val resultado = procurar(filho)
                if (resultado != null) return resultado
                filho.recycle()
            }
            return null
        }
        procurar(root)?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun salvarCorrida(dados: DadosCorrida) {
        val kmTotal = dados.kmBuscar + dados.kmCorrida
        val ganhoPorKm = if (kmTotal > 0) dados.valor / kmTotal else 0f
        val minimo = prefs.getFloat("minimo_km", 1.20f)
        db.inserirCorrida(Corrida(
            valor = dados.valor,
            kmTotal = kmTotal,
            ganhoPorKm = ganhoPorKm,
            valeAPena = ganhoPorKm >= minimo
        ))
    }

    private fun mostrarOverlay(dados: DadosCorrida) {
        overlayVisivel = true
        val minimo = prefs.getFloat("minimo_km", 1.20f)
        val kmTotal = dados.kmBuscar + dados.kmCorrida
        val ganhoPorKm = if (kmTotal > 0) dados.valor / kmTotal else 0f

        // Buscar stats do dia
        val corridasHoje = db.buscarHoje()
        val resumo = db.resumo(corridasHoje)

        startService(Intent(this, OverlayService::class.java).apply {
            action = "MOSTRAR"
            putExtra("km_total", kmTotal)
            putExtra("ganho_por_km", ganhoPorKm)
            putExtra("vale_a_pena", ganhoPorKm >= minimo)
            putExtra("ganho_hoje", resumo["total"] ?: 0f)
            putExtra("media_km_hoje", resumo["media_km"] ?: 0f)
            putExtra("auto_aceitar", prefs.getBoolean("auto_aceitar", false))
        })
    }

    private fun esconderOverlay() {
        overlayVisivel = false
        startService(Intent(this, OverlayService::class.java).apply { action = "ESCONDER" })
    }

    override fun onInterrupt() {}

    data class DadosCorrida(val valor: Float, val kmBuscar: Float, val kmCorrida: Float)
}
