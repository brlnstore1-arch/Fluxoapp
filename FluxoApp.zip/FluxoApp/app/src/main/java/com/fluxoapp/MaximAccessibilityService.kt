package com.fluxoapp

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class MaximAccessibilityService : AccessibilityService() {

    private lateinit var prefs: SharedPreferences
    private lateinit var db: DatabaseHelper
    private var overlayVisivel = false
    private var ultimoHashCorrida = ""
    private var ultimoTempoProcessado = 0L
    private val DEBOUNCE_MS = 3000L // 3 segundos entre processamentos
    private val handler = Handler(Looper.getMainLooper())
    private var corridaAtual: DadosCorrida? = null

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("FluxoApp", MODE_PRIVATE)
        db = DatabaseHelper(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return

        // Verificar se o serviço está ativado
        if (!prefs.getBoolean("servico_ativo", true)) {
            if (overlayVisivel) esconderOverlay()
            return
        }

        val tipo = event.eventType
        if (tipo != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            tipo != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) return

        // Debounce - evita processar múltiplas vezes
        val agora = System.currentTimeMillis()
        if (agora - ultimoTempoProcessado < DEBOUNCE_MS) return

        val root = rootInActiveWindow ?: return
        val textos = coletarTodosTextos(root)

        // Só detecta se tiver "Pedido atribuído!" E botão "Recusar" juntos
        // Isso garante que é SOMENTE a tela de nova corrida
        val temPedidoAtribuido = textos.any { t ->
            t.contains("Pedido atribuído", ignoreCase = true) ||
            t.contains("Pedido atribuido", ignoreCase = true)
        }
        val temBotaoRecusar = textos.any { t ->
            t.trim().equals("Recusar", ignoreCase = true)
        }
        val temCancelamento = textos.any { t ->
            t.contains("pedido será cancelado em", ignoreCase = true) ||
            t.contains("pedido sera cancelado em", ignoreCase = true)
        }

        val ehTelaNovaCorrida = temPedidoAtribuido || (temBotaoRecusar && temCancelamento)
        val temValor = textos.any { it.contains("R$") }
        val temKm = textos.any { it.trim().matches(Regex("""^\d+[,\.]\d+\s*km\.?$""", RegexOption.IGNORE_CASE)) }

        if (ehTelaNovaCorrida && temValor && temKm) {
            val dados = extrairDadosCorrida(textos) ?: return

            // Gerar hash único da corrida para evitar duplicatas
            val hash = "${dados.valor}_${dados.kmCorrida}"
            if (hash == ultimoHashCorrida) return

            ultimoHashCorrida = hash
            ultimoTempoProcessado = agora
            corridaAtual = dados

            salvarCorrida(dados)
            mostrarOverlay(dados)
            // Atualizar botão flutuante
            startService(Intent(this, FloatingEarningsService::class.java).apply {
                action = "ATUALIZAR"
            })

            // Auto-aceitar se ativado
            val autoAceitar = prefs.getBoolean("auto_aceitar", false)
            val minimo = prefs.getFloat("minimo_km", 1.20f)
            val kmTotal = dados.kmBuscar + dados.kmCorrida
            val ganhoPorKm = if (kmTotal > 0) dados.valor / kmTotal else 0f

            if (autoAceitar && ganhoPorKm >= minimo) {
                handler.postDelayed({ 
                    clicarAceitar(root)
                    tocarSomAceitar()
                }, 3000)
            }

        } else {
            if (overlayVisivel) {
                // Reset hash quando corrida desaparecer
                ultimoHashCorrida = ""
                esconderOverlay()
            }
        }
    }

    private fun coletarTodosTextos(node: AccessibilityNodeInfo): List<String> {
        val lista = mutableListOf<String>()
        fun percorrer(n: AccessibilityNodeInfo) {
            n.text?.toString()?.trim()?.let { if (it.isNotBlank()) lista.add(it) }
            for (i in 0 until n.childCount) {
                val filho = n.getChild(i) ?: continue
                percorrer(filho)
                filho.recycle()
            }
        }
        percorrer(node)
        return lista
    }

    private fun extrairDadosCorrida(textos: List<String>): DadosCorrida? {
        // Padrões exatos baseados no layout real do Taxsee Driver
        val padraoValor = Regex("""R\$\s*(\d+[,\.]\d+)""")
        val padraoKm = Regex("""^(\d+[,\.]\d+)\s*km\.?$""", RegexOption.IGNORE_CASE)

        var valor: Float? = null
        var kmBuscar: Float? = null  // "Até o endereço"
        var kmCorrida: Float? = null // "Distância da rota"

        for (i in textos.indices) {
            val texto = textos[i].trim()

            // Extrair valor R$ (pega o maior valor = valor total da corrida)
            padraoValor.find(texto)?.let {
                val v = it.groupValues[1].replace(",", ".").toFloatOrNull()
                if (v != null && v > 0) {
                    if (valor == null || v > valor!!) valor = v
                }
            }

            // Detectar km pelo contexto do texto seguinte
            padraoKm.find(texto)?.let {
                val km = it.groupValues[1].replace(",", ".").toFloatOrNull() ?: return@let
                val proximoTexto = textos.getOrElse(i + 1) { "" }.lowercase()
                when {
                    proximoTexto.contains("até o endereço") ||
                    proximoTexto.contains("ate o endereco") -> kmBuscar = km

                    proximoTexto.contains("distância da rota") ||
                    proximoTexto.contains("distancia da rota") -> kmCorrida = km

                    // Fallback: primeiro km = buscar, segundo = corrida
                    kmBuscar == null -> kmBuscar = km
                    kmCorrida == null -> kmCorrida = km
                }
            }
        }

        return if (valor != null && valor!! > 0) {
            // Extrair endereços e forma de pagamento
            var origem = ""
            var destino = ""
            var formaPagamento = ""
            var encontrouOrigem = false

            for (texto in textos) {
                when {
                    texto.contains("em dinheiro", ignoreCase = true) -> formaPagamento = "Dinheiro"
                    texto.contains("por PIX", ignoreCase = true) ||
                    texto.contains("via PIX", ignoreCase = true) -> formaPagamento = "PIX"
                    texto.contains("🏠") || (texto.contains("bairro") && !encontrouOrigem) -> {
                        origem = texto.replace("🏠", "").trim()
                        encontrouOrigem = true
                    }
                    texto.contains("🏁") || (texto.contains("bairro") && encontrouOrigem && destino.isEmpty()) -> {
                        destino = texto.replace("🏁", "").trim()
                    }
                }
            }

            DadosCorrida(
                valor = valor!!,
                kmBuscar = kmBuscar ?: 0f,
                kmCorrida = kmCorrida ?: 0f,
                origem = origem,
                destino = destino,
                formaPagamento = formaPagamento
            )
        } else null
    }

    private fun tocarSomAceitar() {
        try {
            val toneGen = android.media.ToneGenerator(
                android.media.AudioManager.STREAM_NOTIFICATION, 100
            )
            // Bipe duplo: aceito!
            toneGen.startTone(android.media.ToneGenerator.TONE_PROP_ACK, 200)
            handler.postDelayed({
                toneGen.startTone(android.media.ToneGenerator.TONE_PROP_ACK, 300)
                handler.postDelayed({ toneGen.release() }, 400)
            }, 300)
        } catch (_: Exception) {}
    }

    private fun clicarAceitar(root: AccessibilityNodeInfo) {
        fun procurar(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
            val texto = node.text?.toString() ?: ""
            val desc = node.contentDescription?.toString() ?: ""
            if ((texto.contains("Aceitar", ignoreCase = true) ||
                 desc.contains("Aceitar", ignoreCase = true)) &&
                node.isClickable) return node
            for (i in 0 until node.childCount) {
                val filho = node.getChild(i) ?: continue
                val resultado = procurar(filho)
                if (resultado != null) return resultado
                filho.recycle()
            }
            return null
        }
        procurar(root)?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun salvarCorrida(dados: DadosCorrida) {
        val kmTotal = dados.kmBuscar + dados.kmCorrida
        val ganhoPorKm = if (kmTotal > 0) dados.valor / kmTotal else 0f
        val minimo = prefs.getFloat("minimo_km", 1.20f)
        db.inserirCorrida(Corrida(
            valor = dados.valor,
            kmTotal = kmTotal,
            ganhoPorKm = ganhoPorKm,
            valeAPena = ganhoPorKm >= minimo,
            origem = dados.origem,
            destino = dados.destino,
            formaPagamento = dados.formaPagamento
        ))
    }

    private fun mostrarOverlay(dados: DadosCorrida) {
        overlayVisivel = true
        val minimo = prefs.getFloat("minimo_km", 1.20f)
        val kmTotal = dados.kmBuscar + dados.kmCorrida
        val ganhoPorKm = if (kmTotal > 0) dados.valor / kmTotal else 0f

        startService(Intent(this, OverlayService::class.java).apply {
            action = "MOSTRAR"
            putExtra("valor", dados.valor)
            putExtra("km_total", kmTotal)
            putExtra("ganho_por_km", ganhoPorKm)
            putExtra("vale_a_pena", ganhoPorKm >= minimo)
            putExtra("auto_aceitar", prefs.getBoolean("auto_aceitar", false))
        })
    }

    private fun esconderOverlay() {
        overlayVisivel = false
        startService(Intent(this, OverlayService::class.java).apply { action = "ESCONDER" })
    }

    override fun onInterrupt() {}

    data class DadosCorrida(
        val valor: Float,
        val kmBuscar: Float,
        val kmCorrida: Float,
        val origem: String = "",
        val destino: String = "",
        val formaPagamento: String = ""
    )
}
