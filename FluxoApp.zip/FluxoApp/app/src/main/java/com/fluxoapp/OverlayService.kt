package com.fluxoapp

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import java.text.NumberFormat
import java.util.Locale

class OverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private val moeda = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "MOSTRAR" -> mostrarOverlay(
                valor = intent.getFloatExtra("valor", 0f),
                kmTotal = intent.getFloatExtra("km_total", 0f),
                ganhoPorKm = intent.getFloatExtra("ganho_por_km", 0f),
                valeAPena = intent.getBooleanExtra("vale_a_pena", false),
                autoAceitar = intent.getBooleanExtra("auto_aceitar", false)
            )
            "ESCONDER" -> esconderOverlay()
        }
        return START_STICKY
    }

    private fun mostrarOverlay(
        valor: Float, kmTotal: Float, ganhoPorKm: Float,
        valeAPena: Boolean, autoAceitar: Boolean
    ) {
        esconderOverlay()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        overlayView = LayoutInflater.from(this).inflate(R.layout.overlay_layout, null)

        overlayView!!.findViewById<TextView>(R.id.tvValor).text = moeda.format(valor)
        overlayView!!.findViewById<TextView>(R.id.tvKmTotal).text = "${"%.1f".format(kmTotal)} km"
        overlayView!!.findViewById<TextView>(R.id.tvGanhoPorKm).text = "R$ ${"%.2f".format(ganhoPorKm)}/km"

        val tvValeAPena = overlayView!!.findViewById<TextView>(R.id.tvValeAPena)
        val headerLayout = overlayView!!.findViewById<View>(R.id.headerLayout)
        val tvAutoAceitar = overlayView!!.findViewById<TextView>(R.id.tvAutoAceitar)

        tvAutoAceitar.visibility = if (autoAceitar) View.VISIBLE else View.GONE

        if (valeAPena) {
            headerLayout.setBackgroundResource(R.drawable.overlay_header_green)
            tvValeAPena.text = "✅  VALE A PENA!"
            tvValeAPena.setBackgroundResource(R.drawable.btn_green)
            tvValeAPena.setTextColor(0xFF003300.toInt())
        } else {
            headerLayout.setBackgroundResource(R.drawable.overlay_header_red)
            tvValeAPena.text = "❌  NÃO VALE A PENA"
            tvValeAPena.setBackgroundResource(R.drawable.btn_red)
            tvValeAPena.setTextColor(0xFFFFFFFF.toInt())
        }

        overlayView!!.findViewById<TextView>(R.id.btnFechar).setOnClickListener { esconderOverlay() }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 0
        }

        windowManager?.addView(overlayView, params)
    }

    private fun esconderOverlay() {
        overlayView?.let {
            try { windowManager?.removeView(it) } catch (_: Exception) {}
            overlayView = null
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        esconderOverlay()
    }
}
