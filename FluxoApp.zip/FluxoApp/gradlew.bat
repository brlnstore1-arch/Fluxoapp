@rem Gradle startup script for Windows
@if "%DEBUG%" == "" @echo off
@rem Add default JVM options here.
set DIRNAME=%~dp0
"%DIRNAME%\gradle\wrapper\gradle-wrapper.jar" %*
