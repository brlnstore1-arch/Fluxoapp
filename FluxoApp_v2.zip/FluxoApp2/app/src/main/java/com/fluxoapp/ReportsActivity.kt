package com.fluxoapp

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.Calendar

class ReportsActivity : AppCompatActivity() {
    private lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reports)
        db = DatabaseHelper(this)
        findViewById<ImageButton>(R.id.btnVoltar).setOnClickListener { finish() }
        gerarRelatorio()
    }

    private fun gerarRelatorio() {
        val todas = db.buscarTodas()
        val hoje = db.buscarHoje()
        val semana = db.buscarSemana()
        val cal = Calendar.getInstance()
        val mes = db.buscarMes(cal.get(Calendar.MONTH), cal.get(Calendar.YEAR))

        val rHoje = db.resumo(hoje)
        val rSemana = db.resumo(semana)
        val rMes = db.resumo(mes)
        val rTodas = db.resumo(todas)

        // Resumos por período
        val tvResumo = findViewById<TextView>(R.id.tvRelatorioResumo)
        tvResumo.text = buildString {
            append("📅 HOJE\n")
            append("  R$ ${"%.2f".format(rHoje["total"])} em ${(rHoje["corridas"]?:0f).toInt()} corridas\n\n")
            append("📅 ESTA SEMANA\n")
            append("  R$ ${"%.2f".format(rSemana["total"])} em ${(rSemana["corridas"]?:0f).toInt()} corridas\n\n")
            append("📅 ESTE MÊS\n")
            append("  R$ ${"%.2f".format(rMes["total"])} em ${(rMes["corridas"]?:0f).toInt()} corridas\n\n")
            append("📊 GERAL\n")
            append("  Total histórico: R$ ${"%.2f".format(rTodas["total"])}\n")
            append("  Total de corridas: ${(rTodas["corridas"]?:0f).toInt()}\n")
            append("  Média geral/km: R$ ${"%.2f".format(rTodas["media_km"])}")
        }

        // Análise por hora
        val ganhosPorHora = Array(24) { 0f }
        val corridasPorHora = Array(24) { 0 }
        todas.forEach { c ->
            val hora = c.hora.split(":").firstOrNull()?.toIntOrNull() ?: return@forEach
            ganhosPorHora[hora] += c.valor
            corridasPorHora[hora]++
        }

        val melhorHora = ganhosPorHora.indices.maxByOrNull { ganhosPorHora[it] } ?: 0
        val melhorDia = calcularMelhorDia(todas)
        val taxaAceitacao = if (todas.isNotEmpty()) {
            val aceitas = todas.count { it.valeAPena }
            (aceitas.toFloat() / todas.size * 100).toInt()
        } else 0

        val tvInteligencia = findViewById<TextView>(R.id.tvInteligencia)
        tvInteligencia.text = buildString {
            if (todas.isNotEmpty()) {
                append("🕐 Melhor horário: ${melhorHora}h às ${melhorHora+1}h\n")
                append("   Ganho: R$ ${"%.2f".format(ganhosPorHora[melhorHora])}\n\n")
                append("📆 Melhor dia da semana: $melhorDia\n\n")
                append("✅ Taxa de corridas boas: $taxaAceitacao%\n\n")
                val melhorCorrida = todas.maxByOrNull { it.valor }
                if (melhorCorrida != null)
                    append("🏆 Melhor corrida: R$ ${"%.2f".format(melhorCorrida.valor)} em ${melhorCorrida.data}")
            } else {
                append("Ainda sem dados suficientes.\nFaça algumas corridas para ver a análise!")
            }
        }
    }

    private fun calcularMelhorDia(corridas: List<Corrida>): String {
        val dias = arrayOf("Dom","Seg","Ter","Qua","Qui","Sex","Sáb")
        val ganhosDia = Array(7) { 0f }
        corridas.forEach { c ->
            try {
                val sdf = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault())
                val d = sdf.parse(c.data) ?: return@forEach
                val cal = Calendar.getInstance().apply { time = d }
                ganhosDia[cal.get(Calendar.DAY_OF_WEEK) - 1] += c.valor
            } catch (_: Exception) {}
        }
        val melhor = ganhosDia.indices.maxByOrNull { ganhosDia[it] } ?: 0
        return dias[melhor]
    }
}
