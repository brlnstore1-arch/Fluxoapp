package com.fluxoapp

import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.MenuItem
import android.widget.*
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    private lateinit var prefs: SharedPreferences
    private lateinit var db: DatabaseHelper
    private lateinit var drawerLayout: DrawerLayout

    private val FRASES = listOf(
        "Cada km rodado é um passo a mais para seu sonho! 🚀",
        "Motorista de sucesso é aquele que nunca desiste! 💪",
        "Hoje é um ótimo dia para bater sua meta! 🎯",
        "Sua dedicação é o combustível do seu sucesso! ⚡",
        "O melhor horário para trabalhar é agora! 🔥",
        "Cada corrida bem feita é um cliente fiel! ⭐",
        "Sucesso é a soma de pequenas conquistas diárias! 💰",
        "Você está no caminho certo, continue! 🏆"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("FluxoApp", MODE_PRIVATE)
        db = DatabaseHelper(this)

        configurarToolbarEDrawer()
        configurarBotoes()
        atualizarStatus()
        atualizarStats()
        exibirFrase()

        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else if (prefs.getBoolean("flutuante_ativo", true)) {
            startService(Intent(this, FloatingEarningsService::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        atualizarStatus()
        atualizarStats()
    }

    private fun configurarToolbarEDrawer() {
        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)

        drawerLayout = findViewById(R.id.drawerLayout)
        val navView = findViewById<NavigationView>(R.id.navView)
        navView.setNavigationItemSelectedListener(this)

        val toggle = ActionBarDrawerToggle(this, drawerLayout, toolbar,
            R.string.app_name, R.string.app_name)
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()
        toggle.drawerArrowDrawable.color = getColor(R.color.accent_cyan)
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        drawerLayout.closeDrawer(GravityCompat.START)
        when (item.itemId) {
            R.id.nav_configuracoes -> startActivity(Intent(this, SettingsActivity::class.java))
            R.id.nav_relatorios -> startActivity(Intent(this, ReportsActivity::class.java))
            R.id.nav_financas -> startActivity(Intent(this, FinanceActivity::class.java))
            R.id.nav_historico -> startActivity(Intent(this, HistoryActivity::class.java))
            R.id.nav_sobre -> startActivity(Intent(this, AboutActivity::class.java))
            R.id.nav_sair -> {
                prefs.edit().putBoolean("servico_ativo", false).apply()
                stopService(Intent(this, FloatingEarningsService::class.java))
                Toast.makeText(this, "⏹ Serviço desativado", Toast.LENGTH_SHORT).show()
                atualizarStatus()
            }
        }
        return true
    }

    private fun configurarBotoes() {
        // Acessibilidade
        findViewById<Button>(R.id.btnPermissaoAcessibilidade).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        // Overlay
        findViewById<Button>(R.id.btnPermissaoOverlay).setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        // Switch serviço
        val switchServico = findViewById<Switch>(R.id.switchServico)
        switchServico.isChecked = prefs.getBoolean("servico_ativo", true)
        switchServico.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("servico_ativo", isChecked).apply()
            if (isChecked && prefs.getBoolean("flutuante_ativo", true)) {
                startService(Intent(this, FloatingEarningsService::class.java))
            } else if (!isChecked) {
                stopService(Intent(this, FloatingEarningsService::class.java))
            }
            Toast.makeText(this, if (isChecked) "✅ Serviço ATIVADO" else "⏸ Serviço PAUSADO", Toast.LENGTH_SHORT).show()
            atualizarStatus()
        }
        // Switch auto-aceitar
        val switchAuto = findViewById<Switch>(R.id.switchAutoAceitar)
        switchAuto.isChecked = prefs.getBoolean("auto_aceitar", false)
        switchAuto.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("auto_aceitar", isChecked).apply()
        }
        // Salvar mínimo
        val etMinimo = findViewById<EditText>(R.id.etMinimoPorKm)
        etMinimo.setText("%.2f".format(prefs.getFloat("minimo_km", 1.20f)))
        findViewById<Button>(R.id.btnSalvar).setOnClickListener {
            val v = etMinimo.text.toString().replace(",", ".").toFloatOrNull()
            if (v != null && v > 0) {
                prefs.edit().putFloat("minimo_km", v).apply()
                Toast.makeText(this, "✅ R$ ${"%.2f".format(v)}/km salvo!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "⚠️ Valor inválido", Toast.LENGTH_SHORT).show()
            }
        }
        // Ver histórico
        findViewById<Button>(R.id.btnHistorico).setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        // Link "Ver histórico completo" dentro do card de ganhos
        findViewById<TextView>(R.id.btnHistorico2)?.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
    }

    private fun exibirFrase() {
        val dayOfYear = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR)
        val frase = FRASES[dayOfYear % FRASES.size]
        findViewById<TextView>(R.id.tvFraseDia)?.text = frase
    }

    private fun atualizarStatus() {
        val tvStatus = findViewById<TextView>(R.id.tvStatus)
        val btnAcess = findViewById<Button>(R.id.btnPermissaoAcessibilidade)
        val btnOverlay = findViewById<Button>(R.id.btnPermissaoOverlay)
        val servicoAtivo = prefs.getBoolean("servico_ativo", true)
        val acessAtivo = isAccessibilityEnabled()
        val overlayAtivo = Settings.canDrawOverlays(this)

        btnAcess.visibility = android.view.View.GONE
        btnOverlay.visibility = android.view.View.GONE

        when {
            !servicoAtivo -> tvStatus.text = "⏸ Serviço pausado"
            !acessAtivo && !overlayAtivo -> {
                tvStatus.text = "🔴 Ative Acessibilidade e Sobreposição!"
                btnAcess.visibility = android.view.View.VISIBLE
                btnOverlay.visibility = android.view.View.VISIBLE
            }
            !acessAtivo -> {
                tvStatus.text = "🔴 Ative a Acessibilidade!"
                btnAcess.visibility = android.view.View.VISIBLE
            }
            !overlayAtivo -> {
                tvStatus.text = "🟡 Ative a sobreposição!"
                btnOverlay.visibility = android.view.View.VISIBLE
            }
            else -> tvStatus.text = "🟢 Monitorando o Maxim!"
        }
    }

    private fun atualizarStats() {
        val corridas = db.buscarHoje()
        val resumo = db.resumo(corridas)
        val total = resumo["total"] ?: 0f
        val meta = prefs.getFloat("meta_diaria", 0f)

        findViewById<TextView>(R.id.tvGanhoHoje).text = "R$ ${"%.2f".format(total)}"
        findViewById<TextView>(R.id.tvTotalCorridas).text = "${(resumo["corridas"] ?: 0f).toInt()}"
        findViewById<TextView>(R.id.tvMediaKm).text = "R$ ${"%.2f".format(resumo["media_km"] ?: 0f)}"
        findViewById<TextView>(R.id.tvMediaCorrida).text = "R$ ${"%.2f".format(resumo["media_corrida"] ?: 0f)}"

        val progressMeta = findViewById<ProgressBar>(R.id.progressMetaDia)
        val tvMeta = findViewById<TextView>(R.id.tvMetaDia)
        if (meta > 0) {
            val percent = ((total / meta) * 100).toInt().coerceIn(0, 100)
            progressMeta.progress = percent
            tvMeta.text = "Meta: R$ ${"%.0f".format(meta)} ($percent%)"
            progressMeta.visibility = android.view.View.VISIBLE
            tvMeta.visibility = android.view.View.VISIBLE
        } else {
            progressMeta.visibility = android.view.View.GONE
            tvMeta.visibility = android.view.View.GONE
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.contains("fluxoapp", ignoreCase = true) ||
               enabled.contains("MaximAccessibilityService", ignoreCase = true)
    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START))
            drawerLayout.closeDrawer(GravityCompat.START)
        else super.onBackPressed()
    }
}
